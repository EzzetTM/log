package com.skyworldclans;

import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.bank.ClanBankService;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.request.ClanRequestService;
import com.skyworldclans.clan.xp.ClanXpService;
import com.skyworldclans.clan.election.ClanElectionService;
import com.skyworldclans.clan.service.ClanService;
import com.skyworldclans.clan.service.ClanMembershipService;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.nio.file.Path;
import java.util.Objects;

final class ClanStorageRuntime implements AutoCloseable {
    private final SqliteClanStore store;
    private final ClanService service;
    private final ClanMembershipService membershipService;
    private final ClanRequestService requestService;
    private final ClanXpService xpService;
    private final ClanElectionService electionService;
    private final ClanBankService bankService;
    private final StoreCloser storeCloser;
    private boolean closed;

    private ClanStorageRuntime(
            SqliteClanStore store,
            ClanService service,
            ClanMembershipService membershipService,
            ClanRequestService requestService,
            ClanXpService xpService,
            ClanElectionService electionService,
            ClanBankService bankService,
            StoreCloser storeCloser) {
        this.store = store;
        this.service = service;
        this.membershipService = membershipService;
        this.requestService = requestService;
        this.xpService = xpService;
        this.electionService = electionService;
        this.bankService = bankService;
        this.storeCloser = storeCloser;
    }

    static ClanStorageRuntime open(Path databasePath) {
        return open(databasePath, SqliteClanStore::open, ClanStorageRuntime::createService,
                SqliteClanStore::close);
    }

    static ClanStorageRuntime open(
            Path databasePath,
            StoreOpener storeOpener,
            ServiceFactory serviceFactory) {
        return open(databasePath, storeOpener, serviceFactory, SqliteClanStore::close);
    }

    static ClanStorageRuntime open(
            Path databasePath,
            StoreOpener storeOpener,
            ServiceFactory serviceFactory,
            StoreCloser storeCloser) {
        Objects.requireNonNull(databasePath, "databasePath");
        Objects.requireNonNull(storeOpener, "storeOpener");
        Objects.requireNonNull(serviceFactory, "serviceFactory");
        Objects.requireNonNull(storeCloser, "storeCloser");

        SqliteClanStore store = storeOpener.open(databasePath);
        try {
            ClanService service = serviceFactory.create(store);
            ClanMembershipService membershipService = new ClanMembershipService(store);
            ClanRequestService requestService = new ClanRequestService(
                    store, store, java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
            ClanXpService xpService = new ClanXpService(store, java.time.Clock.systemUTC());
            ClanElectionService electionService = new ClanElectionService(
                    store, store, membershipService, java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
            ClanBankService bankService = new ClanBankService(store, store, java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
            return new ClanStorageRuntime(store, service, membershipService, requestService, xpService, electionService, bankService, storeCloser);
        } catch (RuntimeException | Error exception) {
            try {
                storeCloser.close(store);
            } catch (RuntimeException | Error closeException) {
                if (closeException != exception) {
                    exception.addSuppressed(closeException);
                }
            }
            throw exception;
        }
    }

    SqliteClanStore store() {
        ensureOpen();
        return store;
    }

    ClanService service() {
        ensureOpen();
        return service;
    }

    ClanMembershipService membershipService() {
        ensureOpen();
        return membershipService;
    }

    ClanRequestService requestService() {
        ensureOpen();
        return requestService;
    }

    ClanXpService xpService() {
        ensureOpen();
        return xpService;
    }

    ClanElectionService electionService() {
        ensureOpen();
        return electionService;
    }

    ClanBankService bankService() {
        ensureOpen();
        return bankService;
    }

    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;
        storeCloser.close(store);
    }

    private void ensureOpen() {
        if (closed) {
            throw new IllegalStateException("Clan storage runtime is closed");
        }
    }

    private static ClanService createService(ClanCatalog catalog) {
        return new ClanService(catalog, new ClanMembershipStateValidator());
    }

    @FunctionalInterface
    interface StoreOpener {
        SqliteClanStore open(Path databasePath);
    }

    @FunctionalInterface
    interface ServiceFactory {
        ClanService create(ClanCatalog catalog);
    }

    @FunctionalInterface
    interface StoreCloser {
        void close(SqliteClanStore store);
    }
}

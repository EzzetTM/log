package com.skyworldclans.clan.membership;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanMembershipTenurePolicyTest {
    private static final Duration REQUIRED_TENURE = Duration.ofDays(7);
    private static final Instant MEMBERSHIP_STARTED_AT = Instant.parse("2026-01-01T00:00:00Z");

    private final ClanMembershipTenurePolicy policy = new ClanMembershipTenurePolicy();

    @Test
    void rejectsNullMembershipStart() {
        assertFalse(policy.isEligibleForBankReward(null, MEMBERSHIP_STARTED_AT.plus(REQUIRED_TENURE)));
    }

    @Test
    void rejectsNullCurrentTime() {
        assertFalse(policy.isEligibleForBankReward(MEMBERSHIP_STARTED_AT, null));
    }

    @Test
    void rejectsBothArgumentsNull() {
        assertFalse(policy.isEligibleForBankReward(null, null));
    }

    @Test
    void rejectsMembershipDurationShorterThanSevenDays() {
        assertFalse(policy.isEligibleForBankReward(
                MEMBERSHIP_STARTED_AT,
                MEMBERSHIP_STARTED_AT.plus(Duration.ofDays(6))));
    }

    @Test
    void rejectsTheInstantImmediatelyBeforeSevenDayBoundary() {
        Instant boundary = MEMBERSHIP_STARTED_AT.plus(REQUIRED_TENURE);

        assertFalse(policy.isEligibleForBankReward(
                MEMBERSHIP_STARTED_AT,
                boundary.minusNanos(1)));
    }

    @Test
    void acceptsExactlySevenDaysOfMembership() {
        assertTrue(policy.isEligibleForBankReward(
                MEMBERSHIP_STARTED_AT,
                MEMBERSHIP_STARTED_AT.plus(REQUIRED_TENURE)));
    }

    @Test
    void acceptsMembershipLongerThanSevenDays() {
        assertTrue(policy.isEligibleForBankReward(
                MEMBERSHIP_STARTED_AT,
                MEMBERSHIP_STARTED_AT.plus(REQUIRED_TENURE).plusNanos(1)));
    }

    @Test
    void rejectsMembershipStartInTheFuture() {
        assertFalse(policy.isEligibleForBankReward(
                MEMBERSHIP_STARTED_AT.plusSeconds(1),
                MEMBERSHIP_STARTED_AT));
    }

    @Test
    void identicalInputsAlwaysProduceIdenticalResults() {
        Instant now = MEMBERSHIP_STARTED_AT.plus(REQUIRED_TENURE);

        assertTrue(policy.isEligibleForBankReward(MEMBERSHIP_STARTED_AT, now));
        assertTrue(policy.isEligibleForBankReward(MEMBERSHIP_STARTED_AT, now));
        assertFalse(policy.isEligibleForBankReward(MEMBERSHIP_STARTED_AT, now.minusNanos(1)));
        assertFalse(policy.isEligibleForBankReward(MEMBERSHIP_STARTED_AT, now.minusNanos(1)));
    }

    @Test
    void usesOnlySuppliedInstantsAndDoesNotDependOnSystemClock() {
        Instant historicalStart = Instant.parse("1970-01-01T00:00:00Z");
        Instant futureStart = Instant.parse("2500-01-01T00:00:00Z");

        assertTrue(policy.isEligibleForBankReward(
                historicalStart, historicalStart.plus(REQUIRED_TENURE)));
        assertFalse(policy.isEligibleForBankReward(
                futureStart, futureStart.plus(Duration.ofDays(6))));
    }
}

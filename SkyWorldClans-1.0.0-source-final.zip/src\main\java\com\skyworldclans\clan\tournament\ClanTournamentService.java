package com.skyworldclans.clan.tournament;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Clock;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * Tournament lifecycle and building-tournament voting.
 *
 * <p>Owner-approved voting rules are enforced: one immutable vote per UUID, participants may not
 * vote for their own clan, tournament members do not vote, results stay hidden until voting closes.
 * The additional settings requested by the owner are exposed explicitly: minimum votes, duration,
 * permission, points per vote, optional abstention and result hiding.</p>
 *
 * <p>Registration is intentionally blocked: the entry-fee policy is not approved, and inventing a
 * price or declaring registration free is forbidden.</p>
 */
public final class ClanTournamentService {
    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final Clock clock;
    private final Supplier<UUID> ids;
    private final Predicate<UUID> votePermission;

    public ClanTournamentService(ClanCatalog clans, SqliteClanStore store, Clock clock, Supplier<UUID> ids,
            Predicate<UUID> votePermission) {
        this.clans = Objects.requireNonNull(clans); this.store = Objects.requireNonNull(store);
        this.clock = Objects.requireNonNull(clock); this.ids = Objects.requireNonNull(ids);
        this.votePermission = Objects.requireNonNull(votePermission);
    }

    public Result create(UUID actorId, String discipline, String name, int teamSize, int voteMinimum,
            int voteDurationMinutes, int votePoints, boolean allowAbstain, boolean hideResults) {
        if (actorId == null || discipline == null || name == null || name.isBlank())
            return Result.INVALID;
        if (!List.of("PVP", "PARKOUR", "BUILDING", "RESOURCE_GATHERING", "TREASURE_HUNT")
                .contains(discipline.toUpperCase(java.util.Locale.ROOT))) return Result.INVALID;
        if (teamSize != 3 && teamSize != 5 && teamSize != 10) return Result.INVALID;
        var created = store.insertTournament(ids.get(), discipline.toUpperCase(java.util.Locale.ROOT),
                name, teamSize, actorId, Math.max(0, voteMinimum), Math.max(1, voteDurationMinutes),
                "skyworldclans.tournament.vote", Math.max(1, votePoints), allowAbstain, hideResults,
                clock.instant());
        return switch (created.status()) {
            case CREATED -> new Result(Status.CREATED, created.tournament());
            default -> Result.INVALID;
        };
    }

    /** Always blocked until the owner approves the registration fee policy. */
    public Result openRegistration(UUID actorId, UUID tournamentId, java.time.Duration window) {
        var tournament = store.findTournament(tournamentId).orElse(null);
        if (tournament == null) return Result.NOT_FOUND;
        var result = store.openTournamentRegistration(tournamentId, actorId,
                clock.instant().plus(window == null ? java.time.Duration.ofDays(1) : window), clock.instant());
        return new Result(result.status() == SqliteClanStore.TournamentStatus.REGISTRATION_BLOCKED
                ? Status.REGISTRATION_BLOCKED : Status.INVALID, result.tournament());
    }

    /** Building discipline: one immutable vote per player, not for their own clan. */
    public Result vote(UUID voterId, UUID tournamentId, UUID targetClanId) {
        var tournament = store.findTournament(tournamentId).orElse(null);
        if (tournament == null) return Result.NOT_FOUND;
        if (!"BUILDING".equals(tournament.discipline())) return Result.VOTE_NOT_ALLOWED;
        if (!votePermission.test(voterId)) return Result.NOT_ELIGIBLE;
        Clan ownClan = clans.findByPlayerId(voterId).orElse(null);
        if (ownClan != null && ownClan.id().equals(targetClanId)) return Result.VOTE_OWN_CLAN;
        if (store.findTournamentVote(tournamentId, voterId).isPresent()) return Result.ALREADY_VOTED;
        var cast = store.castTournamentVote(ids.get(), tournamentId, voterId, targetClanId,
                tournament.votePoints(), clock.instant());
        return switch (cast) {
            case CREATED -> new Result(Status.VOTED, tournament);
            case ALREADY_VOTED -> Result.ALREADY_VOTED;
            case STATE_CONFLICT -> Result.VOTING_CLOSED;
            default -> Result.INVALID;
        };
    }

    /** Results stay hidden while voting is open when the owner left hiding enabled. */
    public Map<UUID, Integer> results(UUID tournamentId) {
        var tournament = store.findTournament(tournamentId).orElse(null);
        if (tournament == null) return Map.of();
        boolean closed = tournament.votingClosesAt() != null
                && !clock.instant().isBefore(tournament.votingClosesAt());
        if (tournament.hideResults() && !closed) return Map.of();
        return store.tournamentTally(tournamentId);
    }

    public Optional<SqliteClanStore.ClanTournament> find(UUID tournamentId) {
        return store.findTournament(tournamentId);
    }

    public List<SqliteClanStore.ClanTournament> list(int limit) {
        return store.findTournaments(null, limit);
    }

    /** Owner/admin lifecycle step: close registration, run, finish or cancel. */
    public Result changeState(UUID actorId, UUID tournamentId, String state) {
        if (actorId == null || tournamentId == null || state == null) return Result.INVALID;
        String normalized = state.trim().toUpperCase(java.util.Locale.ROOT);
        if (!List.of("REGISTRATION_CLOSED", "RUNNING", "FINISHED", "CANCELLED").contains(normalized))
            return Result.INVALID;
        var tournament = store.findTournament(tournamentId).orElse(null);
        if (tournament == null) return Result.NOT_FOUND;
        var updated = store.setTournamentState(tournamentId, normalized, actorId, clock.instant());
        return switch (updated) {
            case UPDATED -> new Result(Status.STATE_CHANGED,
                    store.findTournament(tournamentId).orElse(null));
            case STATE_CONFLICT -> Result.STATE_CONFLICT;
            case NOT_FOUND -> Result.NOT_FOUND;
            default -> Result.INVALID;
        };
    }

    public Result revokeVote(UUID actorId, UUID tournamentId, UUID voterId, String reason) {
        var status = store.revokeTournamentVote(tournamentId, voterId, actorId, reason, clock.instant());
        return status == SqliteClanStore.TournamentStatus.UPDATED
                ? new Result(Status.VOTE_REVOKED, store.findTournament(tournamentId).orElse(null))
                : Result.NOT_FOUND;
    }

    public enum Status {
        CREATED, VOTED, VOTE_REVOKED, STATE_CHANGED, INVALID, NOT_FOUND, ALREADY_VOTED, NOT_ELIGIBLE,
        VOTE_OWN_CLAN, VOTE_NOT_ALLOWED, VOTING_CLOSED, REGISTRATION_BLOCKED, STATE_CONFLICT
    }

    public record Result(Status status, SqliteClanStore.ClanTournament tournament) {
        static final Result INVALID = new Result(Status.INVALID, null);
        static final Result NOT_FOUND = new Result(Status.NOT_FOUND, null);
        static final Result ALREADY_VOTED = new Result(Status.ALREADY_VOTED, null);
        static final Result NOT_ELIGIBLE = new Result(Status.NOT_ELIGIBLE, null);
        static final Result VOTE_OWN_CLAN = new Result(Status.VOTE_OWN_CLAN, null);
        static final Result VOTE_NOT_ALLOWED = new Result(Status.VOTE_NOT_ALLOWED, null);
        static final Result VOTING_CLOSED = new Result(Status.VOTING_CLOSED, null);
        static final Result STATE_CONFLICT = new Result(Status.STATE_CONFLICT, null);
    }
}
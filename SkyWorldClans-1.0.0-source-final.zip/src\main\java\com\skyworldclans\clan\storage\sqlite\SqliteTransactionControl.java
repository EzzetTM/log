package com.skyworldclans.clan.storage.sqlite;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

interface SqliteTransactionControl {
    SqliteTransactionControl JDBC = new SqliteTransactionControl() {
        @Override
        public void begin(Connection connection) throws SQLException {
            execute(connection, "BEGIN IMMEDIATE");
        }

        @Override
        public void commit(Connection connection) throws SQLException {
            execute(connection, "COMMIT");
        }

        @Override
        public void rollback(Connection connection) throws SQLException {
            execute(connection, "ROLLBACK");
        }

        private void execute(Connection connection, String sql) throws SQLException {
            try (Statement statement = connection.createStatement()) {
                statement.execute(sql);
            }
        }
    };

    void begin(Connection connection) throws SQLException;

    void commit(Connection connection) throws SQLException;

    void rollback(Connection connection) throws SQLException;
}

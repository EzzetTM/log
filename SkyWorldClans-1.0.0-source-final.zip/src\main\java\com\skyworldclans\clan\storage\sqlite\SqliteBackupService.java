package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.storage.StorageException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;

/** Creates and retains the scheduled SQLite backups required by the project specification. */
public final class SqliteBackupService {
    public static final int RETAINED_BACKUP_COUNT = 30;
    private static final String FILE_PREFIX = "skyworldclans-";
    private static final String FILE_SUFFIX = ".sqlite";
    private static final DateTimeFormatter FILE_TIME = DateTimeFormatter
            .ofPattern("yyyyMMdd-HHmmss-SSS")
            .withZone(ZoneOffset.UTC);

    private final SqliteClanStore store;
    private final Path backupDirectory;
    private final Clock clock;

    public SqliteBackupService(SqliteClanStore store, Path backupDirectory) {
        this(store, backupDirectory, Clock.systemUTC());
    }

    SqliteBackupService(SqliteClanStore store, Path backupDirectory, Clock clock) {
        this.store = Objects.requireNonNull(store, "store");
        this.backupDirectory = Objects.requireNonNull(backupDirectory, "backupDirectory")
                .toAbsolutePath().normalize();
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /** Creates one verified backup, then removes only older backups beyond the retention limit. */
    public synchronized BackupResult createBackup() {
        try {
            Files.createDirectories(backupDirectory);
            Instant now = clock.instant();
            String fileName = FILE_PREFIX + FILE_TIME.format(now) + "-"
                    + UUID.randomUUID().toString().substring(0, 8) + FILE_SUFFIX;
            Path destination = backupDirectory.resolve(fileName);
            Path created = store.backupTo(destination);
            PruneResult prune = pruneOldBackups();
            return new BackupResult(created, prune.removed(), prune.warnings());
        } catch (IOException exception) {
            throw new StorageException("Could not prepare SQLite backup directory: "
                    + backupDirectory, exception);
        }
    }

    public synchronized java.util.Optional<BackupMetadata> latestBackup() {
        if (!Files.isDirectory(backupDirectory)) return java.util.Optional.empty();
        try (Stream<Path> files = Files.list(backupDirectory)) {
            List<Path> candidates = files.filter(Files::isRegularFile)
                    .filter(path -> isManagedBackup(path.getFileName().toString()))
                    .sorted(Comparator.comparing((Path path) -> path.getFileName().toString()).reversed())
                    .toList();
            for (Path candidate : candidates) {
                String fileName = candidate.getFileName().toString();
                int timestampEnd = fileName.lastIndexOf('-');
                if (timestampEnd <= FILE_PREFIX.length()) continue;
                try {
                    String timestamp = fileName.substring(FILE_PREFIX.length(), timestampEnd);
                    Instant createdAt = Instant.from(FILE_TIME.parse(timestamp));
                    return java.util.Optional.of(new BackupMetadata(candidate, createdAt));
                } catch (java.time.DateTimeException ignored) {
                    // Skip unrelated or malformed files that happen to use the managed prefix.
                }
            }
            return java.util.Optional.empty();
        } catch (IOException exception) {
            throw new StorageException("Could not inspect latest SQLite backup", exception);
        }
    }

    private PruneResult pruneOldBackups() {
        List<Path> backups;
        try (Stream<Path> files = Files.list(backupDirectory)) {
            backups = files
                    .filter(Files::isRegularFile)
                    .filter(path -> isManagedBackup(path.getFileName().toString()))
                    .sorted(Comparator.comparing((Path path) -> path.getFileName().toString()).reversed())
                    .toList();
        } catch (IOException exception) {
            return new PruneResult(List.of(), List.of(
                    "Backup was created, but retention scan failed: " + exception.getMessage()));
        }
        if (backups.size() <= RETAINED_BACKUP_COUNT) {
            return new PruneResult(List.of(), List.of());
        }
        List<Path> removed = new java.util.ArrayList<>();
        List<String> warnings = new java.util.ArrayList<>();
        for (Path obsolete : backups.subList(RETAINED_BACKUP_COUNT, backups.size())) {
            try {
                Files.delete(obsolete);
                removed.add(obsolete);
            } catch (IOException exception) {
                warnings.add("Could not delete old backup " + obsolete + ": "
                        + exception.getMessage());
            }
        }
        return new PruneResult(List.copyOf(removed), List.copyOf(warnings));
    }

    private record PruneResult(List<Path> removed, List<String> warnings) {
    }

    private static boolean isManagedBackup(String fileName) {
        return fileName.startsWith(FILE_PREFIX) && fileName.endsWith(FILE_SUFFIX);
    }

    public record BackupMetadata(Path path, Instant createdAt) {
        public BackupMetadata { Objects.requireNonNull(path, "path"); Objects.requireNonNull(createdAt, "createdAt"); }
    }

    public record BackupResult(
            Path backup, List<Path> removedOlderBackups, List<String> warnings) {
        public BackupResult {
            Objects.requireNonNull(backup, "backup");
            removedOlderBackups = List.copyOf(Objects.requireNonNull(
                    removedOlderBackups, "removedOlderBackups"));
            warnings = List.copyOf(Objects.requireNonNull(warnings, "warnings"));
        }
    }
}

package com.skyworldclans.clan.application.purchase;

import java.util.Objects;

public final class CapacityPurchaseRecoveryPolicy {
    private CapacityPurchaseRecoveryPolicy() {
    }

    public static CapacityPurchaseRecoveryAction classify(CapacityPurchaseOperation operation) {
        Objects.requireNonNull(operation, "operation");
        return switch (operation.state()) {
            case PREPARED, DEBIT_CONFIRMED ->
                    CapacityPurchaseRecoveryAction.SAFE_TO_CONTINUE_INTERNAL_PROCESSING;
            case CALLING ->
                    CapacityPurchaseRecoveryAction.REQUIRES_EXTERNAL_RESULT_RECONCILIATION;
            case UNKNOWN, COMPENSATION_FAILED ->
                    CapacityPurchaseRecoveryAction.REQUIRES_MANUAL_OR_SEPARATE_RECOVERY;
            case COMPENSATION_PENDING ->
                    CapacityPurchaseRecoveryAction.SAFE_TO_START_COMPENSATION;
            case COMPENSATION_CALLING ->
                    CapacityPurchaseRecoveryAction.REQUIRES_COMPENSATION_RESULT_RECONCILIATION;
            case COMPENSATION_UNKNOWN ->
                    CapacityPurchaseRecoveryAction.REQUIRES_MANUAL_OR_SEPARATE_RECOVERY;
            case COMMITTED, FAILED_NO_EFFECT, COMPENSATED ->
                    CapacityPurchaseRecoveryAction.COMPLETED;
        };
    }
}

package com.skyworldclans.clan.xp;

import java.time.Instant;
import java.util.UUID;

public interface ClanXpStore {
    ClanXpAwardResult awardClanXp(UUID clanId, ClanXpEventType type,
            UUID actorId, String idempotencyKey, Instant occurredAt);
}

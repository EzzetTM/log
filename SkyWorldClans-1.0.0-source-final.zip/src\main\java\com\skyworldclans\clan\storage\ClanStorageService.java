package com.skyworldclans.clan.storage;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Storage page metadata and bank-funded page purchases. Item GUI/transfer operations are a separate phase. */
public final class ClanStorageService {
    public static final int MAX_PAGES = 10;
    private final ClanCatalog catalog;
    private final SqliteClanStore store;

    public ClanStorageService(ClanCatalog catalog, SqliteClanStore store) {
        this.catalog = Objects.requireNonNull(catalog, "catalog");
        this.store = Objects.requireNonNull(store, "store");
    }

    public PurchaseResult purchasePage(UUID actorId, int pageNumber, Instant now) {
        try {
            Clan clan = catalog.findByPlayerId(actorId).orElse(null);
            if (clan == null) return new PurchaseResult(Status.NOT_IN_CLAN, null);
            if (clan.member(actorId).map(member -> member.role() == ClanRole.LEADER).orElse(false) == false)
                return new PurchaseResult(Status.LEADER_ONLY, null);
            SqliteClanStore.ClanStoragePurchaseResult result = store.purchaseClanStoragePage(clan.id(), actorId, pageNumber, now);
            return new PurchaseResult(map(result.status()), result);
        } catch (RuntimeException exception) {
            return new PurchaseResult(Status.STORAGE_ERROR, null);
        }
    }

    public AccountView accountFor(UUID playerId) {
        try {
            Clan clan = catalog.findByPlayerId(playerId).orElse(null);
            if (clan == null) return new AccountView(Status.NOT_IN_CLAN, null, 0, Optional.empty());
            int count = store.clanStoragePageCount(clan.id());
            if (count < 1) return new AccountView(Status.STORAGE_NOT_INITIALIZED, clan, 0, Optional.empty());
            return new AccountView(Status.READY, clan, count, store.findClanStoragePage(clan.id(), 1));
        } catch (RuntimeException exception) {
            return new AccountView(Status.STORAGE_ERROR, null, 0, Optional.empty());
        }
    }

    public SaveResult savePage(UUID playerId, int pageNumber, long expectedRevision, byte[] contents, Instant now) {
        try {
            Clan clan = catalog.findByPlayerId(playerId).orElse(null);
            if (clan == null) return new SaveResult(Status.NOT_IN_CLAN,
                    new SqliteClanStore.ClanStorageContentSaveResult(SqliteClanStore.ClanStorageContentSaveStatus.NOT_A_MEMBER, expectedRevision));
            SqliteClanStore.ClanStorageContentSaveResult result = store.saveClanStoragePageContents(
                    clan.id(), pageNumber, playerId, expectedRevision, contents, now);
            return new SaveResult(mapSaveStatus(result.status()), result);
        } catch (RuntimeException exception) {
            return new SaveResult(Status.STORAGE_ERROR, null);
        }
    }

    /** Creates durable PREPARED escrow before the Paper adapter changes PlayerInventory. */
    public SqliteClanStore.ClanStorageTransferResult prepareTransfer(UUID operationId, UUID playerId,
            int pageNumber, String movementType, String itemType, int amount, long expectedRevision,
            byte[] beforePlayerInventory, byte[] afterPlayerInventory, byte[] beforePageContents,
            byte[] afterPageContents, Instant now) {
        if (playerId == null) return new SqliteClanStore.ClanStorageTransferResult(
                SqliteClanStore.ClanStorageTransferStatus.INVALID_INPUT, null);
        Clan clan = catalog.findByPlayerId(playerId).orElse(null);
        if (clan == null) return new SqliteClanStore.ClanStorageTransferResult(
                SqliteClanStore.ClanStorageTransferStatus.NOT_A_MEMBER, null);
        return store.prepareClanStorageTransfer(operationId, clan.id(), pageNumber, playerId,
                movementType, itemType, amount, expectedRevision, beforePlayerInventory,
                afterPlayerInventory, beforePageContents, afterPageContents, now);
    }

    /** Resolves a pending transfer from the live, complete PlayerInventory snapshot. */
    public SqliteClanStore.ClanStorageTransferResult resolveTransfer(UUID operationId,
            UUID playerId, byte[] observedPlayerInventory, Instant now) {
        return store.resolveClanStorageTransfer(operationId, playerId, observedPlayerInventory, now);
    }

    public java.util.List<SqliteClanStore.ClanStorageTransferOperation> pendingTransfers(UUID playerId) {
        return store.pendingClanStorageTransfers(playerId);
    }

    /** Commits a complete serialized page snapshot and its movement receipt atomically. */
    public CommitResult commitMovement(UUID operationId, UUID playerId, int pageNumber,
            String movementType, String itemType, int amount, long expectedRevision,
            byte[] contents, Instant now) {
        try {
            Clan clan = catalog.findByPlayerId(playerId).orElse(null);
            if (clan == null) return new CommitResult(Status.NOT_IN_CLAN, null);
            SqliteClanStore.ClanStorageCommitResult result = store.commitClanStorageMovement(
                    operationId, clan.id(), pageNumber, playerId, movementType, itemType,
                    amount, expectedRevision, contents, now);
            return new CommitResult(mapCommitStatus(result.status()), result);
        } catch (RuntimeException exception) {
            return new CommitResult(Status.STORAGE_ERROR, null);
        }
    }

    private static Status mapCommitStatus(SqliteClanStore.ClanStorageCommitStatus status) {
        return switch (status) {
            case COMMITTED -> Status.COMMITTED;
            case DUPLICATE -> Status.DUPLICATE_OPERATION;
            case IDEMPOTENCY_CONFLICT -> Status.IDEMPOTENCY_CONFLICT;
            case INVALID_INPUT -> Status.INVALID_PAGE;
            case CLAN_NOT_FOUND, NOT_A_MEMBER -> Status.NOT_IN_CLAN;
            case PAGE_NOT_FOUND -> Status.PAGE_NOT_FOUND;
            case REVISION_CONFLICT -> Status.REVISION_CONFLICT;
            case TIMESTAMP_OUT_OF_ORDER -> Status.TIMESTAMP_OUT_OF_ORDER;
            case TRANSFER_PENDING -> Status.TRANSFER_PENDING;
        };
    }

    public Optional<SqliteClanStore.ClanStoragePage> pageFor(UUID playerId, int pageNumber) {
        Clan clan = catalog.findByPlayerId(playerId).orElse(null);
        if (clan == null || pageNumber < 1 || pageNumber > store.clanStoragePageCount(clan.id())) return Optional.empty();
        return store.findClanStoragePage(clan.id(), pageNumber);
    }

    private static Status mapSaveStatus(SqliteClanStore.ClanStorageContentSaveStatus status) {
        return switch (status) {
            case SAVED -> Status.SAVED;
            case UNCHANGED -> Status.UNCHANGED;
            case REVISION_CONFLICT -> Status.REVISION_CONFLICT;
            case INVALID_INPUT -> Status.INVALID_PAGE;
            case CLAN_NOT_FOUND -> Status.NOT_IN_CLAN;
            case NOT_A_MEMBER -> Status.NOT_IN_CLAN;
            case PAGE_NOT_FOUND -> Status.PAGE_NOT_FOUND;
            case HISTORY_MISSING -> Status.STORAGE_CORRUPT;
            case TIMESTAMP_OUT_OF_ORDER -> Status.TIMESTAMP_OUT_OF_ORDER;
            case TRANSFER_PENDING -> Status.TRANSFER_PENDING;
            case REVISION_EXHAUSTED -> Status.REVISION_EXHAUSTED;
        };
    }

    private static Status map(SqliteClanStore.ClanStoragePurchaseStatus status) {
        return switch (status) {
            case PURCHASED -> Status.PURCHASED;
            case DUPLICATE, ALREADY_PURCHASED -> Status.ALREADY_PURCHASED;
            case INVALID_INPUT, INVALID_PAGE_SEQUENCE -> Status.INVALID_PAGE;
            case CLAN_NOT_FOUND -> Status.NOT_IN_CLAN;
            case LEADER_ONLY -> Status.LEADER_ONLY;
            case STORAGE_NOT_INITIALIZED -> Status.STORAGE_NOT_INITIALIZED;
            case BANK_NOT_INITIALIZED -> Status.BANK_NOT_INITIALIZED;
            case MAX_PAGES -> Status.MAX_PAGES;
            case INSUFFICIENT_FUNDS -> Status.INSUFFICIENT_FUNDS;
            case IDEMPOTENCY_CONFLICT, STORAGE_CORRUPT -> Status.STORAGE_CORRUPT;
        };
    }

    public enum Status {
        READY, PURCHASED, ALREADY_PURCHASED, SAVED, UNCHANGED, REVISION_CONFLICT,
        TIMESTAMP_OUT_OF_ORDER, REVISION_EXHAUSTED, PAGE_NOT_FOUND,
        NOT_IN_CLAN, LEADER_ONLY, INVALID_PAGE, STORAGE_NOT_INITIALIZED, BANK_NOT_INITIALIZED,
        MAX_PAGES, INSUFFICIENT_FUNDS, STORAGE_CORRUPT, STORAGE_ERROR,
        COMMITTED, DUPLICATE_OPERATION, IDEMPOTENCY_CONFLICT, TRANSFER_PENDING
    }

    public record PurchaseResult(Status status, SqliteClanStore.ClanStoragePurchaseResult purchase) { }
    public record SaveResult(Status status, SqliteClanStore.ClanStorageContentSaveResult save) { }
    public record CommitResult(Status status, SqliteClanStore.ClanStorageCommitResult commit) { }
    public record AccountView(Status status, Clan clan, int pageCount,
            Optional<SqliteClanStore.ClanStoragePage> firstPage) { }
}

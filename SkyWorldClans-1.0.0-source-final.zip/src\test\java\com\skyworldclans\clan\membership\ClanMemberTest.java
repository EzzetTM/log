package com.skyworldclans.clan.membership;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ClanMemberTest {
    private static final UUID PLAYER_ID = UUID.fromString("00000000-0000-0000-0000-000000000001");
    private static final UUID DEPUTY_ID = UUID.fromString("00000000-0000-0000-0000-000000000002");
    private static final UUID OTHER_DEPUTY_ID = UUID.fromString("00000000-0000-0000-0000-000000000003");
    private static final Instant MEMBERSHIP_STARTED_AT = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    void createsMembersWithEachRoleAndValidAppointmentMetadata() {
        for (ClanRole role : ClanRole.values()) {
            UUID appointer = role == ClanRole.MODERATOR ? DEPUTY_ID : null;

            ClanMember member = new ClanMember(
                    PLAYER_ID, role, MEMBERSHIP_STARTED_AT, appointer);

            assertEquals(PLAYER_ID, member.playerId());
            assertEquals(role, member.role());
            assertEquals(MEMBERSHIP_STARTED_AT, member.membershipStartedAt());
            assertEquals(appointer, member.appointedByDeputyId());
        }
    }

    @Test
    void moderatorAppointedByLeaderHasNoDeputyId() {
        ClanMember member = new ClanMember(
                PLAYER_ID, ClanRole.MODERATOR, MEMBERSHIP_STARTED_AT, null);

        assertNull(member.appointedByDeputyId());
    }

    @Test
    void rejectsNullRequiredFields() {
        assertThrows(NullPointerException.class,
                () -> new ClanMember(null, ClanRole.MEMBER, MEMBERSHIP_STARTED_AT, null));
        assertThrows(NullPointerException.class,
                () -> new ClanMember(PLAYER_ID, null, MEMBERSHIP_STARTED_AT, null));
        assertThrows(NullPointerException.class,
                () -> new ClanMember(PLAYER_ID, ClanRole.MEMBER, null, null));
    }

    @Test
    void rejectsNullRoleWhenChangingRole() {
        ClanMember member = new ClanMember(
                PLAYER_ID, ClanRole.MEMBER, MEMBERSHIP_STARTED_AT, null);

        assertThrows(NullPointerException.class, () -> member.withRole(null, null));
    }

    @Test
    void rejectsDeputyAppointmentMetadataForNonModerators() {
        for (ClanRole role : ClanRole.values()) {
            if (role != ClanRole.MODERATOR) {
                assertThrows(IllegalArgumentException.class,
                        () -> new ClanMember(
                                PLAYER_ID, role, MEMBERSHIP_STARTED_AT, DEPUTY_ID));
            }
        }
    }

    @Test
    void permitsModeratorAppointmentMetadataWithoutValidatingDeputyExistence() {
        ClanMember member = new ClanMember(
                PLAYER_ID, ClanRole.MODERATOR, MEMBERSHIP_STARTED_AT, DEPUTY_ID);

        assertEquals(DEPUTY_ID, member.appointedByDeputyId());
    }

    @Test
    void supportsEveryRoleTransitionAndClearsAppointmentForNonModerators() {
        for (ClanRole originalRole : ClanRole.values()) {
            UUID originalAppointer = originalRole == ClanRole.MODERATOR ? DEPUTY_ID : null;
            ClanMember original = new ClanMember(
                    PLAYER_ID, originalRole, MEMBERSHIP_STARTED_AT, originalAppointer);

            for (ClanRole newRole : ClanRole.values()) {
                ClanMember changed = original.withRole(newRole, DEPUTY_ID);

                assertNotSame(original, changed);
                assertEquals(PLAYER_ID, changed.playerId());
                assertEquals(newRole, changed.role());
                assertEquals(MEMBERSHIP_STARTED_AT, changed.membershipStartedAt());
                assertEquals(
                        newRole == ClanRole.MODERATOR ? DEPUTY_ID : null,
                        changed.appointedByDeputyId());
            }
        }
    }

    @Test
    void demotingModeratorClearsCurrentAppointmentAndPreservesMembershipStart() {
        ClanMember moderator = new ClanMember(
                PLAYER_ID, ClanRole.MODERATOR, MEMBERSHIP_STARTED_AT, DEPUTY_ID);

        ClanMember member = moderator.withRole(ClanRole.MEMBER, DEPUTY_ID);

        assertEquals(ClanRole.MEMBER, member.role());
        assertNull(member.appointedByDeputyId());
        assertEquals(MEMBERSHIP_STARTED_AT, member.membershipStartedAt());
        assertEquals(ClanRole.MODERATOR, moderator.role());
        assertEquals(DEPUTY_ID, moderator.appointedByDeputyId());
    }

    @Test
    void reappointmentToModeratorUsesTheNewAppointer() {
        ClanMember member = new ClanMember(
                PLAYER_ID, ClanRole.MEMBER, MEMBERSHIP_STARTED_AT, null);

        ClanMember moderator = member.withRole(ClanRole.MODERATOR, OTHER_DEPUTY_ID);

        assertEquals(ClanRole.MODERATOR, moderator.role());
        assertEquals(OTHER_DEPUTY_ID, moderator.appointedByDeputyId());
        assertEquals(MEMBERSHIP_STARTED_AT, moderator.membershipStartedAt());
        assertNull(member.appointedByDeputyId());
    }

    @Test
    void roleChangesDoNotMutateOriginalMemberData() {
        ClanMember original = new ClanMember(
                PLAYER_ID, ClanRole.MODERATOR, MEMBERSHIP_STARTED_AT, DEPUTY_ID);

        original.withRole(ClanRole.DEPUTY, OTHER_DEPUTY_ID);

        assertEquals(PLAYER_ID, original.playerId());
        assertEquals(ClanRole.MODERATOR, original.role());
        assertEquals(MEMBERSHIP_STARTED_AT, original.membershipStartedAt());
        assertEquals(DEPUTY_ID, original.appointedByDeputyId());
        assertSame(MEMBERSHIP_STARTED_AT, original.membershipStartedAt());
    }

    @Test
    void repeatedRoleChangesKeepTheSameMembershipStart() {
        ClanMember original = new ClanMember(
                PLAYER_ID, ClanRole.MEMBER, MEMBERSHIP_STARTED_AT, null);

        ClanMember moderator = original.withRole(ClanRole.MODERATOR, DEPUTY_ID);
        ClanMember deputy = moderator.withRole(ClanRole.DEPUTY, null);
        ClanMember reassignedModerator = deputy.withRole(ClanRole.MODERATOR, OTHER_DEPUTY_ID);

        assertEquals(MEMBERSHIP_STARTED_AT, moderator.membershipStartedAt());
        assertEquals(MEMBERSHIP_STARTED_AT, deputy.membershipStartedAt());
        assertEquals(MEMBERSHIP_STARTED_AT, reassignedModerator.membershipStartedAt());
        assertEquals(OTHER_DEPUTY_ID, reassignedModerator.appointedByDeputyId());
    }
}

package com.skyworldclans.integration.worldguard;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.util.Location;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.entity.Player;

/** Optional WorldGuard adapter. It fails closed when region data is virtual or unavailable. */
public final class WorldGuardRegionAccess {
    public boolean canSetHome(Player player) {
        return player != null && test(player, player.getLocation(), Flags.BUILD);
    }

    public boolean canEnterHome(Player player, org.bukkit.Location destination) {
        return player != null && destination != null && test(player, destination, Flags.ENTRY);
    }

    private boolean test(Player player, org.bukkit.Location bukkitLocation, StateFlag flag) {
        try {
            LocalPlayer localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
            RegionQuery query = WorldGuard.getInstance().getPlatform().getRegionContainer().createQuery();
            Location location = BukkitAdapter.adapt(bukkitLocation);
            ApplicableRegionSet regions = query.getApplicableRegions(location);
            // A virtual set means protection is disabled or region data failed to load.
            if (regions.isVirtual()) return false;
            if (WorldGuard.getInstance().getPlatform().getSessionManager()
                    .hasBypass(localPlayer, localPlayer.getWorld())) return true;
            return regions.testState(localPlayer, flag);
        } catch (RuntimeException | LinkageError exception) {
            return false;
        }
    }
}

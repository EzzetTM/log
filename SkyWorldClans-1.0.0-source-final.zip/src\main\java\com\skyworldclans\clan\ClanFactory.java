package com.skyworldclans.clan;

import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

public final class ClanFactory {

    public Clan create(
            UUID clanId,
            String name,
            String tag,
            UUID creatorId,
            Instant createdAt,
            Instant membershipStartedAt) {
        return create(
                clanId, name, tag, creatorId, createdAt, membershipStartedAt, null);
    }

    public Clan create(
            UUID clanId,
            String name,
            String tag,
            UUID creatorId,
            Instant createdAt,
            Instant membershipStartedAt,
            String tagline) {
        ClanMember creator = new ClanMember(
                creatorId,
                ClanRole.LEADER,
                membershipStartedAt,
                null);
        return new Clan(
                clanId,
                name,
                tag,
                createdAt,
                ClanCapacityPolicy.initialCapacity(),
                Map.of(creatorId, creator),
                0,
                tagline);
    }
}

package com.skyworldclans.clan.storage;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanStorageServiceTest {
    @TempDir Path temporaryDirectory;

    @Test
    void freePageIsGrantedAndPurchaseUsesBankLedgerWithStableIdempotency() {
        Path database = temporaryDirectory.resolve("storage-pages.sqlite");
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        Clan clan = clan(now, leader, deputy, 22_000L); // level 4: 5% discount
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(1, store.clanStoragePageCount(clan.id()));
            assertTrue(store.findClanStoragePage(clan.id(), 1).isPresent());
            assertEquals(BigDecimal.ZERO, store.clanBankBalance(clan.id()));
            assertEquals(SqliteClanStore.ClanBankMovementStatus.APPLIED,
                    store.recordClanBankMovement(UUID.randomUUID(), "fund-storage", clan.id(), leader,
                            "DEPOSIT", new BigDecimal("100000"), "test funding", null, now).status());

            ClanStorageService service = new ClanStorageService(store, store);
            var purchase = service.purchasePage(leader, 2, now.plusSeconds(1));
            assertEquals(ClanStorageService.Status.PURCHASED, purchase.status());
            assertEquals(new BigDecimal("100000"), purchase.purchase().originalPrice());
            assertEquals(new BigDecimal("95000.00"), purchase.purchase().chargedPrice());
            assertEquals(5, purchase.purchase().discountPercent());
            assertEquals(new BigDecimal("5000"), store.clanBankBalance(clan.id()));
            assertEquals(2, store.clanStoragePageCount(clan.id()));

            byte[] firstContents = new byte[]{1, 2, 3};
            assertEquals(ClanStorageService.Status.SAVED,
                    service.savePage(leader, 2, 0, firstContents, now.plusSeconds(2)).status());
            assertEquals(ClanStorageService.Status.REVISION_CONFLICT,
                    service.savePage(deputy, 2, 0, new byte[]{9}, now.plusSeconds(3)).status());
            assertEquals(ClanStorageService.Status.UNCHANGED,
                    service.savePage(deputy, 2, 1, firstContents, now.plusSeconds(4)).status());
            assertEquals(ClanStorageService.Status.SAVED,
                    service.savePage(deputy, 2, 1, new byte[]{4, 5}, now.plusSeconds(5)).status());
            assertEquals(ClanStorageService.Status.TIMESTAMP_OUT_OF_ORDER,
                    service.savePage(deputy, 2, 2, new byte[]{6}, now.plusSeconds(4)).status());

            var duplicate = service.purchasePage(leader, 2, now.plusSeconds(6));
            assertEquals(ClanStorageService.Status.ALREADY_PURCHASED, duplicate.status());
            assertEquals(new BigDecimal("5000"), store.clanBankBalance(clan.id()));
            assertEquals(ClanStorageService.Status.INVALID_PAGE,
                    service.purchasePage(leader, 4, now.plusSeconds(7)).status());
            assertEquals(ClanStorageService.Status.INSUFFICIENT_FUNDS,
                    service.purchasePage(leader, 3, now.plusSeconds(8)).status());
            assertEquals(ClanStorageService.Status.LEADER_ONLY,
                    service.purchasePage(deputy, 3, now.plusSeconds(9)).status());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(2, reopened.clanStoragePageCount(clan.id()));
            var page = reopened.findClanStoragePage(clan.id(), 2).orElseThrow();
            assertEquals(new BigDecimal("95000.00"), page.chargedPrice());
            assertEquals(2, page.revision());
            assertTrue(java.util.Arrays.equals(new byte[]{4, 5}, page.contents()));
            assertEquals(new BigDecimal("5000"), reopened.clanBankBalance(clan.id()));
        }
    }

    @Test
    void serviceExposesAtomicMovementCommitAndChecksMembership() {
        Path database = temporaryDirectory.resolve("storage-atomic-service.sqlite");
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        Clan clan = clan(now, leader, deputy, 0L);
        UUID outsider = UUID.randomUUID();
        UUID operation = UUID.randomUUID();
        byte[] snapshot = new byte[] { 11, 12, 13 };
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            ClanStorageService service = new ClanStorageService(store, store);
            assertEquals(ClanStorageService.Status.NOT_IN_CLAN,
                    service.commitMovement(UUID.randomUUID(), outsider, 1, "DEPOSIT",
                            "minecraft:diamond", 3, 0, snapshot, now).status());
            var committed = service.commitMovement(operation, deputy, 1, "DEPOSIT",
                    "minecraft:diamond", 3, 0, snapshot, now);
            assertEquals(ClanStorageService.Status.COMMITTED, committed.status());
            assertEquals(1, committed.commit().currentRevision());
            assertEquals(ClanStorageService.Status.DUPLICATE_OPERATION,
                    service.commitMovement(operation, deputy, 1, "DEPOSIT",
                            "minecraft:diamond", 3, 0, snapshot, now).status());
            assertEquals(ClanStorageService.Status.IDEMPOTENCY_CONFLICT,
                    service.commitMovement(operation, deputy, 1, "DEPOSIT",
                            "minecraft:diamond", 3, 0, new byte[] { 1 }, now).status());
        }
    }

    @Test
    void pagePurchaseCannotConsumeFundsReservedForAnotherBankOperation() {
        Path database = temporaryDirectory.resolve("storage-reserved-funds.sqlite");
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        Clan clan = clan(now, leader, deputy, 0L);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.recordClanBankMovement(UUID.randomUUID(), "fund-storage", clan.id(), leader,
                    "DEPOSIT", new BigDecimal("100000"), "test funding", null, now);
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED,
                    store.prepareClanBankOperation(UUID.randomUUID(), "reserve-for-withdrawal", UUID.randomUUID(),
                            clan.id(), leader, leader, null, "LEADER_WITHDRAWAL", new BigDecimal("60000"), now).status());
            ClanStorageService service = new ClanStorageService(store, store);
            assertEquals(ClanStorageService.Status.INSUFFICIENT_FUNDS,
                    service.purchasePage(leader, 2, now.plusSeconds(1)).status());
            assertEquals(new BigDecimal("100000"), store.clanBankBalance(clan.id()));
            assertEquals(1, store.clanStoragePageCount(clan.id()));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(1, reopened.clanStoragePageCount(clan.id()));
            assertEquals(new BigDecimal("100000"), reopened.clanBankBalance(clan.id()));
        }
    }

    @Test
    void levelEightDiscountIsTenPercentAndPageTenIsTheLastPage() {
        Path database = temporaryDirectory.resolve("storage-level-eight.sqlite");
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        Clan clan = clan(now, leader, deputy, 130_000L); // level 8: 10% discount
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.recordClanBankMovement(UUID.randomUUID(), "fund-storage", clan.id(), leader,
                    "DEPOSIT", new BigDecimal("90000"), "test funding", null, now);
            ClanStorageService service = new ClanStorageService(store, store);
            var purchase = service.purchasePage(leader, 2, now.plusSeconds(1));
            assertEquals(ClanStorageService.Status.PURCHASED, purchase.status());
            assertEquals(new BigDecimal("90000.00"), purchase.purchase().chargedPrice());
            assertEquals(10, purchase.purchase().discountPercent());
            assertEquals(ClanStorageService.Status.INVALID_PAGE,
                    service.purchasePage(leader, 10, now.plusSeconds(2)).status());
        }
    }

    private static Clan clan(Instant createdAt, UUID leader, UUID deputy, long totalXp) {
        return new Clan(UUID.randomUUID(), "StorageClan", "ST01", createdAt, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, createdAt, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, createdAt, null)), totalXp, null);
    }
}

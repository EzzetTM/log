package com.skyworldclans.clan.filter;

import java.io.IOException;
import java.util.List;

public interface ForbiddenExpressionSource {
    List<String> readEntries() throws IOException;
}

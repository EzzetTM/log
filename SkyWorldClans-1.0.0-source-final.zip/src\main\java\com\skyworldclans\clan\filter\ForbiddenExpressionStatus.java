package com.skyworldclans.clan.filter;

public enum ForbiddenExpressionStatus {
    ALLOWED,
    FORBIDDEN_EXPRESSION,
    FILTER_UNAVAILABLE,
    INVALID_INPUT
}

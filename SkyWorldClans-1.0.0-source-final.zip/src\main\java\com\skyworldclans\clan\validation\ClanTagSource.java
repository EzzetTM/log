package com.skyworldclans.clan.validation;

public interface ClanTagSource {
    Iterable<String> getExistingTags();
}

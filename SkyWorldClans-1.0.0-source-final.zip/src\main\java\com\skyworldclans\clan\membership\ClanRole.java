package com.skyworldclans.clan.membership;

public enum ClanRole {
    LEADER,
    DEPUTY,
    MODERATOR,
    MEMBER
}

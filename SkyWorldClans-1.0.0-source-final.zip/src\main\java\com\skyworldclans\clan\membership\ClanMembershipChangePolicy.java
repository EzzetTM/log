package com.skyworldclans.clan.membership;

public final class ClanMembershipChangePolicy {
    private final ClanPermissionPolicy permissionPolicy = new ClanPermissionPolicy();

    public boolean canVoluntarilyLeave(ClanRole memberRole) {
        return memberRole != null;
    }

    public boolean canDemoteDeputy(ClanRole actorRole, ClanRole targetRole, boolean electionActive) {
        return !electionActive && actorRole == ClanRole.LEADER && targetRole == ClanRole.DEPUTY;
    }

    public boolean canDemoteModerator(ClanRole actorRole, ClanRole targetRole,
            java.util.UUID actorId, java.util.UUID appointedByDeputyId, boolean electionActive) {
        if (electionActive || actorRole == null || targetRole != ClanRole.MODERATOR || actorId == null) return false;
        return actorRole == ClanRole.LEADER
                || (actorRole == ClanRole.DEPUTY && actorId.equals(appointedByDeputyId));
    }

    public boolean canRemoveMember(
            ClanRole actorRole,
            ClanRole targetRole,
            boolean samePlayer,
            boolean electionActive) {
        if (actorRole == null || targetRole == null || samePlayer || electionActive
                || !permissionPolicy.hasPermission(actorRole, ClanPermission.MEMBER_REMOVE)) {
            return false;
        }

        return switch (actorRole) {
            case LEADER -> targetRole != ClanRole.LEADER;
            case DEPUTY -> targetRole == ClanRole.MODERATOR || targetRole == ClanRole.MEMBER;
            case MODERATOR, MEMBER -> false;
        };
    }
}

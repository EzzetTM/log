package com.skyworldclans.clan.election;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public record ClanElection(UUID id, UUID clanId, Type type, Phase phase, UUID startedBy,
        Instant startedAt, Instant closesAt, List<UUID> candidates, Optional<UUID> winner) {
    public ClanElection {
        Objects.requireNonNull(id); Objects.requireNonNull(clanId); Objects.requireNonNull(type);
        Objects.requireNonNull(phase); Objects.requireNonNull(startedBy); Objects.requireNonNull(startedAt);
        Objects.requireNonNull(closesAt); Objects.requireNonNull(candidates); Objects.requireNonNull(winner);
        candidates = List.copyOf(candidates);
        if (candidates.isEmpty() || candidates.stream().distinct().count() != candidates.size())
            throw new IllegalArgumentException("Election candidates must be non-empty and unique");
        if (!closesAt.isAfter(startedAt)) throw new IllegalArgumentException("Election close must follow start");
        if (winner.isPresent() && !candidates.contains(winner.get())) throw new IllegalArgumentException("Winner must be a candidate");
    }
    public enum Type { DEPARTURE, COUP }
    public enum Phase { LOCAL, GLOBAL_TIE_BREAK, COMPLETED, CANCELLED }
}

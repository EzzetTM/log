# Отчёт о реализованных функциях

Дата: 19.11.2026 (итерация после `SkyWorldClans-1.0.0-source-final.zip`). Платформа: Paper
1.21.11, Java 21. Схема SQLite: 28. Тесты: 450, 0 падений. JAR: 14,38 МиБ, 313 классов.

## 0. Закрыто в этой итерации

| Блок | Состав |
|---|---|
| Переименование клана (решение №1) | `/clan rename <тег> <название>`; название и тег меняются вместе, регистронезависимая уникальность тега, освобождение старого тега, CAS по revision; оплата 200 SWCoin заблокирована до подтверждения API SkyWorldCoins |
| Война → задание `WIN_WAR` | победа в войне начисляет прогресс кланового задания (`setWarWinListener`) |
| Жизненный цикл турнира | `/clan tournament state <ID>` — REGISTRATION_CLOSED / RUNNING / FINISHED / CANCELLED, только владелец, терминальные состояния неизменяемы |
| Достижения прогресса | `BANK_CONTRIBUTION_10M` (2 000 XP), `HUNDRED_TASKS_COMPLETED` (3 000 XP), `TEN_MEMBERS_COMPLETED_TASKS` (1 000 XP) — идемпотентный пересчёт |

## 0.1. Аудит: найдено и исправлено

1. Санкции не применялись к функциям — теперь `CLAN_CHAT`, `CLAN_BANK`, `CLAN_REQUESTS`,
   `CLAN_WARS` проверяются в `/cc`, банке, приглашениях/заявках, войнах.
2. Истечение заявок на крупные награды не планировалось — добавлен планировщик.
3. Квест `WIN_WAR` требовал несколько вкладчиков и был невыполним — для клановой метрики 1 вкладчик.
4. Заявки на награды дублировались при одинаковых параметрах — дедупликация через индекс PENDING.
5. Санкции не привязывались к клану, лидер не мог апеллировать — исправлено.
6. **Удаление клана отсутствовало** (§3 ТЗ). Реализовано `/clan delete --confirm`: только лидер,
   необратимо. Активные данные удаляются (участники, дома, банк, муты), открытые войны отменяются,
   задания и заявки истекают, тег освобождается, запись клана становится tombstone ради сохранения
   append-only истории и внешних ключей; публичные чтения его не видят. Действие пишется в
   `clan_admin_audit`.
7. `Class.forName`-рефлексия для Vault заменена на прямой вызов адаптера (Vault API подтверждён,
   зависимость `provided`); остаётся только `Class.forName("org.sqlite.JDBC")` для JDBC-драйвера.
8. Устаревший текст `/clan admin status` («войны/задания/турниры не реализованы») заменён на
   реальные счётчики.

## 1. Реализовано в этой итерации

### 1.1. Безопасность хранилища предметов (54 слота × 10 страниц)

- GUI-меню хранилища и страниц; открытие, переключение, покупка страницы лидером.
- Двухфазный протокол: durable `PREPARED` с before/after снимками инвентаря игрока и страницы,
  затем изменение живого инвентаря, затем сверка по SHA-256.
- Исходы: `COMMITTED` (снимок совпал с after), `ABORTED` (совпал с before), `MANUAL_REVIEW`
  (ни один не совпал). Автоматический повтор запрещён.
- Восстановление при входе, выходе и выключении сервера; блокировка параллельных операций по
  странице и по игроку; CAS по revision; неизменяемый журнал перемещений.
- Повреждённый снимок блокирует редактирование страницы и не приводит к выдаче предметов.

### 1.2. Главное GUI `/clan`

Разделы: информация о клане, участники (с ролями), банк (баланс, история, действия по роли),
хранилище, дом, войны, заявки/приглашения, управление кланом. Каждое действие повторно проверяет
роль и состояние на сервере; недоступные действия показываются серыми с пояснением.

### 1.3. Войны

- Объявление лидером (цель по убийствам, длительность), подтверждение лидером противника, отмена
  до подтверждения, капитуляция.
- Военный фонд: взнос только из банка клана и только лидером; средства зарезервированы на время
  войны и не могут быть потрачены иначе.
- Счёт убийств на PvP-смертях участников враждующих кланов.
- Завершение: достижение цели, капитуляция, истечение срока (больше убийств — победа, равенство —
  ничья). Победитель получает весь фонд; при ничьей каждый клан получает свой взнос.
- XP: победа +1 000, ничья +250, первая победа +500, 10 побед +2 000. Двойная выплата исключена
  идемпотентными ключами.

### 1.4. Модерация кланового чата

- `/ccmute` с лимитами: модератор ≤ 24 ч, заместитель ≤ 3 дней, лидер — бессрочно (`0`).
- `/ccmute list`, `/ccunmute` (лидер/заместитель).
- `/cwarn`, `/cwarn list` (видимость по роли), `/cunwarn` (лидер/заместитель).
- Дело создаётся при трёх активных предупреждениях в окне 12 часов; через 24 часа эскалируется
  лидеру. Автоматических наказаний и исключений нет.
- Мут и предупреждения снимаются при выходе/исключении и не восстанавливаются при повторном входе.
- `/cc` отказывает при активном муте.

### 1.5. Награды

- Личная выплата: с личного баланса выдающего, без лимитов (как требует ТЗ).
- Награда из банка: списание из банка клана, получатель — член клана не менее 7 полных дней;
  заместитель ограничен 100 000 и 3 наградами в день; лидер без этих лимитов.
- Durable-журнал: `PREPARED → DEBIT_CALLING → DEBIT_CONFIRMED → CREDIT_CALLING → COMPLETED`,
  с `FAILED_NO_EFFECT` и `MANUAL_REVIEW`. Неоднозначный результат не повторяется.
- `/clan reward history`.

## 2. Исправлено

| Проблема | Было | Стало |
|---|---|---|
| Компиляция WorldGuard | `cannot find symbol: ApplicableRegionSet` | корректный пакет + `worldguard-core` |
| Запуск тестов | `Tests run: 0` (JUnit 4 провайдер) | JUnit 5 Platform, 445 тестов |
| Открытие любой БД | `SQLite table has invalid definition` | валидатор соответствует DDL |
| Журнал перемещений хранилища | `no such column: event_id` | колонка добавлена в выборку |
| Идемпотентность банка | ложный конфликт при другой причине повтора | сравнение по сумме/типу/актору |
| Повторные выборы | `INVALID` вместо `ACTIVE_ELECTION_EXISTS` | корректный статус |
| Переворот при активных выборах | `STORAGE_ERROR` | `ACTIVE_ELECTION_EXISTS` |
| Выход участника во время выборов | запрещён | разрешён (заморожен только состав руководства) |
| Выплата военного фонда | `NOT NULL actor_id` | системный актор в журнале |
| Тестовые данные | невалидные имена/теги, испорченная кодировка | соответствует инвариантам, UTF-8 |

## 3. Остаточные блокеры и незавершённая приёмка

| Блокер | Текущее безопасное поведение | Что требуется |
|---|---|---|
| SWCoin | Все операции отключены; списания и начисления не имитируются | Подтверждённый публичный API SkyWorldCoins с атомарными операциями |
| Регистрация турниров | Создание и настройка доступны; открытие регистрации заблокировано | Утвердить цену и правила оплаты |
| Войны | Цель убийств; по таймеру — больший счёт, равенство — ничья; капитуляция лидера | Правило подтверждено владельцем 18.11.2026; остаётся runtime-приёмка |
| CombatLog после рестарта | INTERRUPTED_REVIEW, автоматических санкций нет | Решение владельца по вопросу №6 |
| Закрытие дела после предупреждений | Дело эскалируется лидеру через 24 часа; автоматического наказания нет | Решение владельца по вопросу №9 |
| Живой Paper 1.21.11 | Maven-сборка и unit-тесты пройдены; GUI и серверные события не принимались на живом сервере | Общая приёмка на отдельном тестовом сервере |
| Внешние интеграции | Контракты и fail-closed ветки проверены тестами | Runtime-проверка Vault, WorldGuard и FlectonePulse с реальными плагинами |

## 4. Внешние зависимости

| Зависимость | Роль | Обязательна | Состояние |
|---|---|---|---|
| Vault API 1.7.1 + провайдер экономики | обычная валюта | нет (денежные функции отключаются) | контракт проверен, runtime-приёмки нет |
| WorldGuard 7.0.16 + WorldEdit 7.4.2 | регионы для дома | нет (операции с домом fail-closed) | API подключено, runtime-приёмки нет |
| FlectonePulse API 1.15.0 | клановый чат | нет (`/cc` сообщает о недоступности) | API подключено, runtime-приёмки нет |
| SkyWorldCoins 1.0.0 | SWCoin | нет | **не подключено**: публичного API нет |
| sqlite-jdbc 3.49.1.0 | база | да | включён в JAR |

## 5. Файлы, добавленные в этой итерации

```
src/main/java/com/skyworldclans/gui/ClanStorageGui.java
src/main/java/com/skyworldclans/gui/ClanMainGui.java
src/main/java/com/skyworldclans/gui/ClanAdminGui.java
src/main/java/com/skyworldclans/storage/StorageSnapshotCodec.java
src/main/java/com/skyworldclans/clan/war/ClanWarService.java
src/main/java/com/skyworldclans/clan/war/ClanWarListener.java
src/main/java/com/skyworldclans/clan/moderation/ClanModerationService.java
src/main/java/com/skyworldclans/command/ClanModerationCommand.java
src/main/java/com/skyworldclans/clan/reward/ClanRewardCoordinator.java
src/main/java/com/skyworldclans/clan/reward/ClanRewardPolicy.java
src/main/java/com/skyworldclans/admin/ClanAdministrationService.java
src/main/java/com/skyworldclans/clan/quest/ClanQuestService.java
src/main/java/com/skyworldclans/clan/quest/ClanQuestListener.java
src/main/java/com/skyworldclans/clan/tournament/ClanTournamentService.java
src/main/java/com/skyworldclans/clan/service/ClanRenameService.java
src/test/java/com/skyworldclans/clan/storage/sqlite/ClanStorageTransferProtocolTest.java
src/test/java/com/skyworldclans/clan/storage/sqlite/ClanWarStoreTest.java
src/test/java/com/skyworldclans/clan/moderation/ClanModerationServiceTest.java
src/test/java/com/skyworldclans/clan/reward/ClanRewardCoordinatorTest.java
src/test/java/com/skyworldclans/clan/reward/ClanRewardRequestTest.java
src/test/java/com/skyworldclans/admin/ClanAdministrationServiceTest.java
src/test/java/com/skyworldclans/clan/quest/ClanQuestServiceTest.java
src/test/java/com/skyworldclans/clan/tournament/ClanTournamentServiceTest.java
src/test/java/com/skyworldclans/clan/service/ClanRenameServiceTest.java
src/test/java/com/skyworldclans/clan/storage/sqlite/ClanProgressAchievementTest.java
docs/INSTALLATION.md
docs/COMMANDS_AND_PERMISSIONS.md
docs/IMPLEMENTATION_REPORT.md
```
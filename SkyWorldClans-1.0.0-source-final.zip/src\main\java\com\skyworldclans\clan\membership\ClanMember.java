package com.skyworldclans.clan.membership;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

public record ClanMember(
        UUID playerId,
        ClanRole role,
        Instant membershipStartedAt,
        UUID appointedByDeputyId) {

    public ClanMember {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(role, "role");
        Objects.requireNonNull(membershipStartedAt, "membershipStartedAt");
        if (role != ClanRole.MODERATOR && appointedByDeputyId != null) {
            throw new IllegalArgumentException(
                    "appointedByDeputyId is only valid for a moderator");
        }
    }

    public ClanMember withRole(ClanRole newRole, UUID appointedByDeputyId) {
        UUID currentAppointer = newRole == ClanRole.MODERATOR ? appointedByDeputyId : null;
        return new ClanMember(playerId, newRole, membershipStartedAt, currentAppointer);
    }
}

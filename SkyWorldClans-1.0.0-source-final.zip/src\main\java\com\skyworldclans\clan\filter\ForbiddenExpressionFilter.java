package com.skyworldclans.clan.filter;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public final class ForbiddenExpressionFilter {
    private final ForbiddenExpressionValidator validator;
    private final FilterConfigurationFailure configurationFailure;

    private ForbiddenExpressionFilter(
            ForbiddenExpressionValidator validator,
            FilterConfigurationFailure configurationFailure) {
        this.validator = validator;
        this.configurationFailure = configurationFailure;
    }

    public static ForbiddenExpressionFilter load(ForbiddenExpressionSource source) {
        if (source == null) {
            return unavailable("Failed to load forbidden-expression list",
                    "Forbidden expression source must not be null", null);
        }

        try {
            List<String> entries = source.readEntries();
            ForbiddenExpressionValidator validator = new ForbiddenExpressionValidator(entries);
            return validator.isAvailable()
                    ? new ForbiddenExpressionFilter(validator, null)
                    : unavailable(
                            "Invalid forbidden-expression configuration",
                            validator.configurationError().orElse(
                                    "Forbidden expression configuration is invalid"),
                            null);
        } catch (IOException exception) {
            return unavailable("Failed to read forbidden-expression list", "", exception);
        }
    }

    public static ForbiddenExpressionFilter unavailable(
            String context,
            Throwable cause) {
        return unavailable(context, "", cause);
    }

    public ForbiddenExpressionResult check(ForbiddenExpressionField field, String value) {
        if (validator != null) {
            return validator.check(field, value);
        }
        return new ForbiddenExpressionResult(
                field == null
                        ? ForbiddenExpressionStatus.INVALID_INPUT
                        : ForbiddenExpressionStatus.FILTER_UNAVAILABLE,
                Optional.ofNullable(field));
    }

    public boolean isAvailable() {
        return validator != null;
    }

    public boolean emptyListWarningRequired() {
        return validator != null && validator.emptyListWarningRequired();
    }

    public Optional<String> configurationError() {
        if (validator != null) {
            return validator.configurationError();
        }
        return Optional.of(configurationFailure.diagnostic());
    }

    public Optional<FilterConfigurationFailure> configurationFailure() {
        return Optional.ofNullable(configurationFailure);
    }

    private static ForbiddenExpressionFilter unavailable(
            String context,
            String detail,
            Throwable cause) {
        return new ForbiddenExpressionFilter(
                null, new FilterConfigurationFailure(context, detail, cause));
    }
}

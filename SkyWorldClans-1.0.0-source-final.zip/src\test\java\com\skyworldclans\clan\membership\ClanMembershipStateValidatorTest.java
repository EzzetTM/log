package com.skyworldclans.clan.membership;

import com.skyworldclans.clan.Clan;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanMembershipStateValidatorTest {
    private static final Instant CREATED_AT = Instant.parse("2026-01-01T00:00:00Z");
    private final ClanMembershipStateValidator validator = new ClanMembershipStateValidator();

    @Test
    void reportsNullClanAsTheOnlyViolation() {
        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.CLAN_REQUIRED),
                validator.validate(null, false));
        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.CLAN_REQUIRED),
                validator.validate(null, true));
    }

    @Test
    void requiresLeaderOutsideElection() {
        Clan clanWithoutLeader = createClan(false, new int[0], 0);

        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.LEADER_REQUIRED_OUTSIDE_ELECTION),
                validator.validate(clanWithoutLeader, false));
    }

    @Test
    void allowsMissingLeaderDuringElection() {
        assertTrue(validator.validate(createClan(false, new int[0], 0), true).isEmpty());
    }

    @Test
    void acceptsExactlyFourDeputiesAndRejectsFive() {
        assertTrue(validator.validate(createClan(true, new int[4], 0), false).isEmpty());

        List<ClanMembershipStateValidator.Violation> violations =
                validator.validate(createClan(true, new int[5], 0), false);
        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.DEPUTY_LIMIT_EXCEEDED),
                violations);
    }

    @Test
    void acceptsTwoDeputyAppointedModeratorsAndRejectsThreeForOneDeputy() {
        assertTrue(validator.validate(createClan(true, new int[]{2}, 0), false).isEmpty());

        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.DEPUTY_MODERATOR_LIMIT_EXCEEDED),
                validator.validate(createClan(true, new int[]{3}, 0), false));
    }

    @Test
    void acceptsEightDeputyAppointedModeratorsAndReportsNine() {
        assertTrue(validator.validate(createClan(true, new int[]{2, 2, 2, 2}, 0), false).isEmpty());

        List<ClanMembershipStateValidator.Violation> violations =
                validator.validate(createClan(true, new int[]{3, 2, 2, 2}, 0), false);
        assertTrue(violations.contains(
                ClanMembershipStateValidator.Violation.DEPUTY_MODERATOR_LIMIT_EXCEEDED));
        assertTrue(violations.contains(
                ClanMembershipStateValidator.Violation.TOTAL_DEPUTY_MODERATOR_LIMIT_EXCEEDED));
    }

    @Test
    void countsModeratorAppointmentsSeparatelyForEachDeputy() {
        assertTrue(validator.validate(createClan(true, new int[]{2, 1, 0}, 0), false).isEmpty());
        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.DEPUTY_MODERATOR_LIMIT_EXCEEDED),
                validator.validate(createClan(true, new int[]{3, 1, 0}, 0), false));
    }

    @Test
    void doesNotCountLeaderAppointedModeratorsAgainstDeputyLimits() {
        assertTrue(
                validator.validate(createClan(true, new int[]{2, 2, 2, 2}, 5), false).isEmpty());
    }

    @Test
    void reportsAllApplicableViolationsTogether() {
        Clan clan = createClan(false, new int[]{3, 2, 2, 2, 0}, 0);

        assertEquals(
                List.of(
                        ClanMembershipStateValidator.Violation.LEADER_REQUIRED_OUTSIDE_ELECTION,
                        ClanMembershipStateValidator.Violation.DEPUTY_LIMIT_EXCEEDED,
                        ClanMembershipStateValidator.Violation.DEPUTY_MODERATOR_LIMIT_EXCEEDED,
                        ClanMembershipStateValidator.Violation.TOTAL_DEPUTY_MODERATOR_LIMIT_EXCEEDED),
                validator.validate(clan, false));
    }

    @Test
    void allowsSeveralDeputiesWithDifferentValidAppointmentCounts() {
        assertTrue(validator.validate(createClan(true, new int[]{2, 0, 1, 2}, 2), false).isEmpty());
    }

    @Test
    void returnsAnImmutableViolationList() {
        List<ClanMembershipStateValidator.Violation> violations =
                validator.validate(createClan(false, new int[0], 0), false);

        assertThrows(UnsupportedOperationException.class, violations::clear);
    }

    @Test
    void returnsTheSameOrderedResultForRepeatedValidation() {
        Clan clan = createClan(false, new int[]{3, 2, 2, 2, 0}, 0);

        List<ClanMembershipStateValidator.Violation> first = validator.validate(clan, false);
        List<ClanMembershipStateValidator.Violation> second = validator.validate(clan, false);

        assertEquals(first, second);
        assertFalse(first.isEmpty());
    }

    private static Clan createClan(
            boolean includeLeader,
            int[] moderatorCountsPerDeputy,
            int leaderAppointedModeratorCount) {
        Map<UUID, ClanMember> members = new HashMap<>();
        List<UUID> deputyIds = new ArrayList<>();
        long sequence = 1;

        if (includeLeader) {
            UUID leaderId = playerId(sequence++);
            members.put(leaderId, member(leaderId, ClanRole.LEADER, null));
        }

        for (int ignored : moderatorCountsPerDeputy) {
            UUID deputyId = playerId(sequence++);
            deputyIds.add(deputyId);
            members.put(deputyId, member(deputyId, ClanRole.DEPUTY, null));
        }

        for (int deputyIndex = 0; deputyIndex < moderatorCountsPerDeputy.length; deputyIndex++) {
            UUID deputyId = deputyIds.get(deputyIndex);
            for (int i = 0; i < moderatorCountsPerDeputy[deputyIndex]; i++) {
                UUID moderatorId = playerId(sequence++);
                members.put(moderatorId, member(moderatorId, ClanRole.MODERATOR, deputyId));
            }
        }

        for (int i = 0; i < leaderAppointedModeratorCount; i++) {
            UUID moderatorId = playerId(sequence++);
            members.put(moderatorId, member(moderatorId, ClanRole.MODERATOR, null));
        }

        if (members.isEmpty()) {
            UUID memberId = playerId(sequence);
            members.put(memberId, member(memberId, ClanRole.MEMBER, null));
        }

        return new Clan(
                UUID.fromString("10000000-0000-0000-0000-000000000001"),
                "SkyWorld",
                "SWC",
                CREATED_AT,
                50,
                members,
                0,
                null);
    }

    private static UUID playerId(long sequence) {
        return new UUID(2, sequence);
    }

    private static ClanMember member(
            UUID playerId,
            ClanRole role,
            UUID appointedByDeputyId) {
        return new ClanMember(playerId, role, CREATED_AT, appointedByDeputyId);
    }
}

package com.skyworldclans.clan.request;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/** Coordinates invitations and join applications using server time and durable storage. */
public final class ClanRequestService {
    public static final Duration INVITATION_LIFETIME = Duration.ofMinutes(2);
    public static final Duration APPLICATION_LIFETIME = Duration.ofHours(24);

    private final ClanCatalog clans;
    private final ClanRequestStore requests;
    private final Clock clock;
    private final Supplier<UUID> idSupplier;

    public ClanRequestService(ClanCatalog clans, ClanRequestStore requests,
            Clock clock, Supplier<UUID> idSupplier) {
        this.clans = Objects.requireNonNull(clans, "clans");
        this.requests = Objects.requireNonNull(requests, "requests");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.idSupplier = Objects.requireNonNull(idSupplier, "idSupplier");
    }

    public ClanRequestStore.CreateStatus invite(UUID clanId, UUID inviterId, UUID inviteeId) {
        if (clanId == null || inviterId == null || inviteeId == null || inviterId.equals(inviteeId)) {
            return ClanRequestStore.CreateStatus.INVALID_REQUEST;
        }
        Instant now = clock.instant();
        return requests.createRequest(new ClanRequest(idSupplier.get(), ClanRequest.Type.INVITATION,
                clanId, inviteeId, inviterId, now, now.plus(INVITATION_LIFETIME),
                ClanRequest.Status.PENDING));
    }

    public ClanRequestStore.CreateStatus apply(UUID applicantId, String clanTag) {
        if (applicantId == null || clanTag == null || clanTag.isBlank()) {
            return ClanRequestStore.CreateStatus.INVALID_REQUEST;
        }
        Optional<Clan> clan = clans.findByTag(clanTag);
        if (clan.isEmpty()) return ClanRequestStore.CreateStatus.CLAN_NOT_FOUND;
        Instant now = clock.instant();
        return requests.createRequest(new ClanRequest(idSupplier.get(), ClanRequest.Type.APPLICATION,
                clan.get().id(), applicantId, applicantId, now,
                now.plus(APPLICATION_LIFETIME), ClanRequest.Status.PENDING));
    }

    public ClanRequestStore.SettingStatus setPublicApplicationsOpen(
            UUID clanId, UUID actorId, boolean open) {
        return requests.setPublicApplicationsOpen(clanId, actorId, open);
    }

    public boolean arePublicApplicationsOpen(UUID clanId) {
        return requests.arePublicApplicationsOpen(clanId);
    }

    public List<ClanRequest> pendingForPlayer(UUID playerId, ClanRequest.Type type) {
        return requests.listPendingRequestsForPlayer(playerId, type, clock.instant());
    }

    public List<ClanRequest> pendingForClan(UUID clanId, ClanRequest.Type type) {
        return requests.listPendingRequests(clanId, type, clock.instant());
    }

    public ClanRequestStore.ResolveStatus accept(UUID requestId, UUID actorId) {
        return requests.resolveRequest(requestId, actorId, true, clock.instant());
    }

    public ClanRequestStore.ResolveStatus decline(UUID requestId, UUID actorId) {
        return requests.resolveRequest(requestId, actorId, false, clock.instant());
    }
}

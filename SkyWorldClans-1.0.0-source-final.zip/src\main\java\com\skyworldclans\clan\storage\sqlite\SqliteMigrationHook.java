package com.skyworldclans.clan.storage.sqlite;

@FunctionalInterface
interface SqliteMigrationHook {
    SqliteMigrationHook NONE = version -> { };

    void afterMigrationStep(int version);
}

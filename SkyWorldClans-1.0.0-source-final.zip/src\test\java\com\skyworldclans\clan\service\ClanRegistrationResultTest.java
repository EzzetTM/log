package com.skyworldclans.clan.service;

import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanRegistrationResultTest {

    @Test
    void acceptsInvalidMembershipResultOnlyWithAtLeastOneViolation() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new ClanRegistrationResult(
                        ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE,
                        List.of()));

        ClanRegistrationResult result = new ClanRegistrationResult(
                ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE,
                List.of(ClanMembershipStateValidator.Violation.LEADER_REQUIRED_OUTSIDE_ELECTION));

        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.LEADER_REQUIRED_OUTSIDE_ELECTION),
                result.validationViolations());
        assertFalse(result.registered());
    }

    @Test
    void rejectsMembershipViolationsForEveryOtherStatusIncludingSuccess() {
        for (ClanRegistrationResult.Status status : ClanRegistrationResult.Status.values()) {
            if (status == ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE) {
                continue;
            }
            assertThrows(
                    IllegalArgumentException.class,
                    () -> new ClanRegistrationResult(
                            status,
                            List.of(ClanMembershipStateValidator.Violation.CLAN_REQUIRED)));
        }
    }

    @Test
    void keepsViolationListImmutable() {
        List<ClanMembershipStateValidator.Violation> violations = new ArrayList<>();
        violations.add(ClanMembershipStateValidator.Violation.CLAN_REQUIRED);

        ClanRegistrationResult result = new ClanRegistrationResult(
                ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE,
                violations);
        violations.clear();

        assertEquals(
                List.of(ClanMembershipStateValidator.Violation.CLAN_REQUIRED),
                result.validationViolations());
        assertThrows(UnsupportedOperationException.class, () -> result.validationViolations().clear());
    }

    @Test
    void successfulResultHasNoFailureReason() {
        ClanRegistrationResult result = new ClanRegistrationResult(
                ClanRegistrationResult.Status.REGISTERED,
                List.of());

        assertTrue(result.registered());
        assertTrue(result.validationViolations().isEmpty());
    }
}

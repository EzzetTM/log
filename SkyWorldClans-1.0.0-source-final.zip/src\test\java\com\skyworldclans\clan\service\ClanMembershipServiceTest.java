package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.InMemoryClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanMembershipServiceTest {
    private static final UUID CLAN_ID = id(100);
    private static final UUID LEADER = id(1);
    private static final UUID DEPUTY = id(2);
    private static final UUID MEMBER_ONE = id(3);
    private static final UUID MEMBER_TWO = id(4);
    private static final UUID MEMBER_THREE = id(5);
    private static final UUID MEMBER_FOUR = id(6);

    @Test
    void leaderAppointsDeputyAndDeputyCanAppointOnlyTwoModerators() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        Clan initial = clan(Map.of(
                LEADER, member(LEADER, ClanRole.LEADER, null),
                MEMBER_ONE, member(MEMBER_ONE, ClanRole.MEMBER, null),
                MEMBER_TWO, member(MEMBER_TWO, ClanRole.MEMBER, null),
                MEMBER_THREE, member(MEMBER_THREE, ClanRole.MEMBER, null),
                MEMBER_FOUR, member(MEMBER_FOUR, ClanRole.MEMBER, null)));
        catalog.registerIfAvailable(initial);
        ClanMembershipService service = new ClanMembershipService(catalog);

        ClanMembershipChangeResult deputy = service.appointDeputy(CLAN_ID, LEADER, MEMBER_ONE, false);
        assertEquals(ClanMembershipChangeResult.Status.UPDATED, deputy.status());
        assertEquals(ClanRole.DEPUTY, deputy.clan().orElseThrow().member(MEMBER_ONE).orElseThrow().role());
        assertEquals(deputy.clan(), catalog.findByTag("MC100"));

        assertEquals(ClanMembershipChangeResult.Status.UPDATED,
                service.appointModerator(CLAN_ID, MEMBER_ONE, MEMBER_TWO).status());
        assertEquals(ClanMembershipChangeResult.Status.UPDATED,
                service.appointModerator(CLAN_ID, MEMBER_ONE, MEMBER_THREE).status());
        assertEquals(ClanMembershipChangeResult.Status.MODERATOR_LIMIT_REACHED,
                service.appointModerator(CLAN_ID, MEMBER_ONE, MEMBER_FOUR).status());
    }

    @Test
    void removingDeputyDemotesModeratorsAppointedByThatDeputy() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        Map<UUID, ClanMember> members = new HashMap<>();
        members.put(LEADER, member(LEADER, ClanRole.LEADER, null));
        members.put(DEPUTY, member(DEPUTY, ClanRole.DEPUTY, null));
        members.put(MEMBER_ONE, member(MEMBER_ONE, ClanRole.MODERATOR, DEPUTY));
        members.put(MEMBER_TWO, member(MEMBER_TWO, ClanRole.MODERATOR, DEPUTY));
        Clan initial = clan(members);
        catalog.registerIfAvailable(initial);
        ClanMembershipService service = new ClanMembershipService(catalog);

        ClanMembershipChangeResult result = service.removeMember(CLAN_ID, LEADER, DEPUTY, false);
        assertEquals(ClanMembershipChangeResult.Status.UPDATED, result.status());
        Clan updated = result.clan().orElseThrow();
        assertTrue(updated.member(DEPUTY).isEmpty());
        assertEquals(ClanRole.MEMBER, updated.member(MEMBER_ONE).orElseThrow().role());
        assertEquals(ClanRole.MEMBER, updated.member(MEMBER_TWO).orElseThrow().role());
        assertEquals(null, updated.member(MEMBER_ONE).orElseThrow().appointedByDeputyId());
    }

    @Test
    void leaderDemotesDeputyAndAllModeratorsAppointedByThatDeputy() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        Clan initial = clan(Map.of(
                LEADER, member(LEADER, ClanRole.LEADER, null),
                DEPUTY, member(DEPUTY, ClanRole.DEPUTY, null),
                MEMBER_ONE, member(MEMBER_ONE, ClanRole.MODERATOR, DEPUTY),
                MEMBER_TWO, member(MEMBER_TWO, ClanRole.MEMBER, null)));
        catalog.registerIfAvailable(initial);
        ClanMembershipService service = new ClanMembershipService(catalog);

        assertEquals(ClanMembershipChangeResult.Status.ELECTION_ACTIVE,
                service.demoteDeputy(CLAN_ID, LEADER, DEPUTY, true).status());
        ClanMembershipChangeResult result = service.demoteDeputy(CLAN_ID, LEADER, DEPUTY, false);
        assertEquals(ClanMembershipChangeResult.Status.UPDATED, result.status());
        Clan updated = result.clan().orElseThrow();
        assertEquals(ClanRole.MEMBER, updated.member(DEPUTY).orElseThrow().role());
        assertEquals(ClanRole.MEMBER, updated.member(MEMBER_ONE).orElseThrow().role());
        assertEquals(null, updated.member(MEMBER_ONE).orElseThrow().appointedByDeputyId());
    }

    @Test
    void deputyCanDemoteOnlyModeratorsTheyAppointed() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        UUID otherDeputy = id(7);
        Clan initial = clan(Map.of(
                LEADER, member(LEADER, ClanRole.LEADER, null),
                DEPUTY, member(DEPUTY, ClanRole.DEPUTY, null),
                otherDeputy, member(otherDeputy, ClanRole.DEPUTY, null),
                MEMBER_ONE, member(MEMBER_ONE, ClanRole.MODERATOR, DEPUTY),
                MEMBER_TWO, member(MEMBER_TWO, ClanRole.MODERATOR, otherDeputy)));
        catalog.registerIfAvailable(initial);
        ClanMembershipService service = new ClanMembershipService(catalog);

        assertEquals(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION,
                service.demoteModerator(CLAN_ID, DEPUTY, MEMBER_TWO, false).status());
        assertEquals(ClanMembershipChangeResult.Status.ELECTION_ACTIVE,
                service.demoteModerator(CLAN_ID, DEPUTY, MEMBER_ONE, true).status());
        ClanMembershipChangeResult result = service.demoteModerator(CLAN_ID, DEPUTY, MEMBER_ONE, false);
        assertEquals(ClanMembershipChangeResult.Status.UPDATED, result.status());
        assertEquals(ClanRole.MEMBER, result.clan().orElseThrow().member(MEMBER_ONE).orElseThrow().role());
        assertEquals(ClanRole.MODERATOR, result.clan().orElseThrow().member(MEMBER_TWO).orElseThrow().role());
    }

    @Test
    void leaderCanTransferLeadershipOnlyToDeputyOutsideElection() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        Clan initial = clan(Map.of(
                LEADER, member(LEADER, ClanRole.LEADER, null),
                DEPUTY, member(DEPUTY, ClanRole.DEPUTY, null),
                MEMBER_ONE, member(MEMBER_ONE, ClanRole.MODERATOR, DEPUTY),
                MEMBER_TWO, member(MEMBER_TWO, ClanRole.MEMBER, null)));
        catalog.registerIfAvailable(initial);
        ClanMembershipService service = new ClanMembershipService(catalog);

        assertEquals(ClanMembershipChangeResult.Status.ELECTION_ACTIVE,
                service.transferLeadership(CLAN_ID, LEADER, DEPUTY, true).status());
        assertEquals(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION,
                service.transferLeadership(CLAN_ID, DEPUTY, LEADER, false).status());

        ClanMembershipChangeResult result =
                service.transferLeadership(CLAN_ID, LEADER, DEPUTY, false);
        assertEquals(ClanMembershipChangeResult.Status.UPDATED, result.status());
        Clan updated = result.clan().orElseThrow();
        assertEquals(ClanRole.LEADER, updated.member(DEPUTY).orElseThrow().role());
        assertEquals(ClanRole.MEMBER, updated.member(LEADER).orElseThrow().role());
        assertEquals(ClanRole.MODERATOR, updated.member(MEMBER_ONE).orElseThrow().role());
        assertEquals(null, updated.member(MEMBER_ONE).orElseThrow().appointedByDeputyId());
        assertEquals(updated, catalog.findByTag("MC100").orElseThrow());
    }

    @Test
    void leaderDepartureAutomaticallyTransfersToSingleDeputy() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        Clan initial = clan(Map.of(
                LEADER, member(LEADER, ClanRole.LEADER, null),
                DEPUTY, member(DEPUTY, ClanRole.DEPUTY, null),
                MEMBER_ONE, member(MEMBER_ONE, ClanRole.MODERATOR, DEPUTY),
                MEMBER_TWO, member(MEMBER_TWO, ClanRole.MEMBER, null)));
        catalog.registerIfAvailable(initial);
        ClanMembershipService service = new ClanMembershipService(catalog);

        ClanMembershipChangeResult result = service.leaveClan(LEADER, false);
        assertEquals(ClanMembershipChangeResult.Status.UPDATED, result.status());
        Clan updated = result.clan().orElseThrow();
        assertTrue(updated.member(LEADER).isEmpty());
        assertEquals(ClanRole.LEADER, updated.member(DEPUTY).orElseThrow().role());
        assertEquals(ClanRole.MODERATOR, updated.member(MEMBER_ONE).orElseThrow().role());
        assertEquals(null, updated.member(MEMBER_ONE).orElseThrow().appointedByDeputyId());
    }

    @Test
    void leavingAsOnlyClanMemberReportsDeletionStorageBlocker() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        catalog.registerIfAvailable(clan(Map.of(LEADER, member(LEADER, ClanRole.LEADER, null))));
        ClanMembershipService service = new ClanMembershipService(catalog);

        assertEquals(ClanMembershipChangeResult.Status.EMPTY_CLAN_DELETION_REQUIRES_STORAGE_SUPPORT,
                service.leaveClan(LEADER, false).status());
        assertTrue(catalog.findById(CLAN_ID).isPresent());
    }

    @Test
    void deputyCannotKickAnotherDeputyAndLeaderDepartureRequiresElectionWorkflow() {
        InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        Clan initial = clan(Map.of(
                LEADER, member(LEADER, ClanRole.LEADER, null),
                DEPUTY, member(DEPUTY, ClanRole.DEPUTY, null),
                MEMBER_ONE, member(MEMBER_ONE, ClanRole.DEPUTY, null),
                MEMBER_TWO, member(MEMBER_TWO, ClanRole.MEMBER, null)));
        catalog.registerIfAvailable(initial);
        ClanMembershipService service = new ClanMembershipService(catalog);

        assertEquals(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION,
                service.removeMember(CLAN_ID, DEPUTY, MEMBER_ONE, false).status());
        assertEquals(ClanMembershipChangeResult.Status.LEADER_DEPARTURE_REQUIRES_ELECTION,
                service.leaveClan(LEADER, false).status());
        assertEquals(ClanMembershipChangeResult.Status.ELECTION_ACTIVE,
                service.leaveClan(DEPUTY, true).status());
        assertEquals(ClanMembershipChangeResult.Status.UPDATED,
                service.leaveClan(MEMBER_TWO, true).status());
        assertEquals(ClanMembershipChangeResult.Status.ELECTION_ACTIVE,
                service.appointDeputy(CLAN_ID, LEADER, MEMBER_TWO, true).status());
    }

    private static Clan clan(Map<UUID, ClanMember> members) {
        return new Clan(CLAN_ID, "Membership Clan", "MC100",
                Instant.parse("2025-01-01T00:00:00Z"), 10, members, 0, null);
    }

    private static ClanMember member(UUID id, ClanRole role, UUID appointer) {
        return new ClanMember(id, role, Instant.parse("2025-01-02T00:00:00Z"), appointer);
    }

    private static UUID id(long value) {
        return new UUID(0, value);
    }
}

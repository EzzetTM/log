package com.skyworldclans.clan.application;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.filter.ForbiddenExpressionField;

import java.util.Objects;
import java.util.Optional;

/** Validated immutable clan snapshot before any payment or persistent mutation. */
public record ClanCreationPreflightResult(Status status, Optional<Clan> clan,
        Optional<ForbiddenExpressionField> forbiddenField) {
    public ClanCreationPreflightResult {
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(clan, "clan");
        Objects.requireNonNull(forbiddenField, "forbiddenField");
        if ((status == Status.READY) != clan.isPresent())
            throw new IllegalArgumentException("Only READY preflight results contain a clan");
        if ((status == Status.FORBIDDEN_EXPRESSION) != forbiddenField.isPresent())
            throw new IllegalArgumentException("Only forbidden-expression results contain a field");
    }

    public enum Status { READY, INVALID_INPUT, INVALID_NAME_FORMAT, INVALID_TAG_FORMAT,
        FILTER_UNAVAILABLE, FORBIDDEN_EXPRESSION, CREATOR_ALREADY_IN_CLAN, TAG_TAKEN }
}

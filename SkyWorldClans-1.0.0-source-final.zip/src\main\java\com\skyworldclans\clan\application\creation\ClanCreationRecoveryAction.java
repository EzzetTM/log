package com.skyworldclans.clan.application.creation;

public enum ClanCreationRecoveryAction {
    SAFE_TO_ABORT_WITHOUT_PAYMENT,
    SAFE_TO_FINISH_REGISTRATION,
    REQUIRES_EXTERNAL_RECONCILIATION,
    COMPLETED
}

package com.skyworldclans.clan.filter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;
import static org.junit.jupiter.api.Assertions.assertTrue;

class Utf8FileForbiddenExpressionSourceTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void loadsUtf8EntriesWithCyrillicLatinCommentsAndBlankLines() throws IOException {
        Path file = write("entries.txt",
                "\uFEFF# comment\n"
                        + "\n"
                        + "   # indented comment\n"
                        + "Север\n"
                        + "north-star\n");

        ForbiddenExpressionFilter validator = load(file);

        assertTrue(validator.isAvailable());
        assertEquals(
                ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                validator.check(ForbiddenExpressionField.NAME, "sever").status());
        assertEquals(
                ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                validator.check(ForbiddenExpressionField.TAG, "NORTHSTAR").status());
    }

    @Test
    void deduplicatesEntriesAfterNormalization() throws IOException {
        Path file = write("duplicates.txt", "orbit\n0rbit\nORBIT\n");

        ForbiddenExpressionFilter validator = load(file);

        assertTrue(validator.isAvailable());
        assertFalse(validator.emptyListWarningRequired());
        assertEquals(
                ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                validator.check(ForbiddenExpressionField.NAME, "my-orbit-clan").status());
    }

    @Test
    void acceptsAValidEmptyFileAndRequestsWarning() throws IOException {
        Path file = write("empty.txt", " \n\t\n# only a comment\n");

        ForbiddenExpressionFilter validator = load(file);

        assertTrue(validator.isAvailable());
        assertTrue(validator.emptyListWarningRequired());
        assertEquals(
                ForbiddenExpressionStatus.ALLOWED,
                validator.check(ForbiddenExpressionField.NAME, "normal").status());
    }

    @Test
    void missingFileMakesFilterUnavailableAndPreservesDiagnostic() {
        Path missing = temporaryDirectory.resolve("missing.txt");

        ForbiddenExpressionFilter validator =
                ForbiddenExpressionFilter.load(new Utf8FileForbiddenExpressionSource(missing));

        assertUnavailable(validator);
        assertTrue(validator.configurationError().orElseThrow().contains("NoSuchFileException"));
    }

    @Test
    void sourceReadFailureMakesFilterUnavailableAndPreservesCause() {
        IOException original = new IOException("synthetic read failure");
        ForbiddenExpressionFilter validator = ForbiddenExpressionFilter.load(() -> {
            throw original;
        });

        assertUnavailable(validator);
        assertTrue(validator.configurationError().orElseThrow().contains("synthetic read failure"));
        assertSame(original, validator.configurationFailure().orElseThrow().cause());
    }

    @Test
    void rejectsMalformedUtf8AndDoesNotExposePartiallyReadEntries() throws IOException {
        Path file = temporaryDirectory.resolve("malformed.txt");
        Files.write(file, new byte[] {
                'o', 'r', 'b', 'i', 't', '\n',
                (byte) 0xC3, (byte) 0x28
        });

        ForbiddenExpressionFilter validator =
                ForbiddenExpressionFilter.load(new Utf8FileForbiddenExpressionSource(file));

        assertUnavailable(validator);
        assertTrue(validator.configurationError().orElseThrow().contains("MalformedInputException"));
        assertEquals(
                ForbiddenExpressionStatus.FILTER_UNAVAILABLE,
                validator.check(ForbiddenExpressionField.NAME, "orbit").status());
    }

    @Test
    void rejectsEntriesThatNormalizeToEmpty() throws IOException {
        Path file = write("empty-entry.txt", "orbit\n---\n");

        ForbiddenExpressionFilter validator = load(file);

        assertUnavailable(validator);
        assertTrue(validator.configurationError().orElseThrow()
                .contains("empty after normalization"));
    }

    @Test
    void rejectsNullSourceNullListAndNullEntry() {
        assertUnavailable(ForbiddenExpressionFilter.load(null));
        assertUnavailable(ForbiddenExpressionFilter.load(() -> null));
        assertUnavailable(ForbiddenExpressionFilter.load(() ->
                java.util.Arrays.asList("orbit", null)));
    }

    @Test
    void loadsLargeFileAndChecksLongTextWithoutPartialOrExponentialExpansion() throws IOException {
        List<String> entries = new ArrayList<>();
        for (int index = 0; index < 1_500; index++) {
            entries.add("entry" + index + "x");
        }
        entries.add("жюя".repeat(40) + "q");
        Path file = temporaryDirectory.resolve("large-list.txt");
        Files.write(file, entries, StandardCharsets.UTF_8);

        String text = ("жюя".repeat(40) + "x").repeat(60);
        ForbiddenExpressionFilter validator =
                ForbiddenExpressionFilter.load(new Utf8FileForbiddenExpressionSource(file));

        assertTimeoutPreemptively(Duration.ofSeconds(15), () -> {
            assertTrue(validator.isAvailable());
            assertEquals(
                    ForbiddenExpressionStatus.ALLOWED,
                    validator.check(ForbiddenExpressionField.SLOGAN, text).status());
        });
    }

    @Test
    void matchesLargeMixedTransliterationInputInBothDirections() {
        String cyrillic = "жюя".repeat(180);
        String latin = "jiuia".repeat(180);
        ForbiddenExpressionValidator cyrillicEntry = new ForbiddenExpressionValidator(
                List.of(cyrillic));
        ForbiddenExpressionValidator latinEntry = new ForbiddenExpressionValidator(List.of(latin));

        assertTimeoutPreemptively(Duration.ofSeconds(10), () -> {
            assertEquals(
                    ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                    cyrillicEntry.check(ForbiddenExpressionField.TAG, latin).status());
            assertEquals(
                    ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                    latinEntry.check(ForbiddenExpressionField.NAME, cyrillic).status());
        });
    }

    private Path write(String fileName, String contents) throws IOException {
        Path file = temporaryDirectory.resolve(fileName);
        Files.writeString(file, contents, StandardCharsets.UTF_8);
        return file;
    }

    private static ForbiddenExpressionFilter load(Path file) {
        return ForbiddenExpressionFilter.load(new Utf8FileForbiddenExpressionSource(file));
    }

    private static void assertUnavailable(ForbiddenExpressionFilter validator) {
        assertFalse(validator.isAvailable());
        assertFalse(validator.emptyListWarningRequired());
        assertTrue(validator.configurationError().isPresent());
        assertEquals(
                ForbiddenExpressionStatus.FILTER_UNAVAILABLE,
                validator.check(ForbiddenExpressionField.NAME, "normal").status());
    }
}

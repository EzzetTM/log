package com.skyworldclans.clan.reward;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ClanRewardPolicyTest {
    private final ClanRewardPolicy policy = new ClanRewardPolicy();

    @Test
    void personalPayoutsAreUnlimitedForLeaderAndDeputyAndDoNotRequireClanRecipient() {
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        UUID externalRecipient = UUID.randomUUID();
        UUID memberRecipient = UUID.randomUUID();
        Clan clan = clan(now, leader, deputy, memberRecipient, now.minusSeconds(60));
        assertEquals(ClanRewardPolicy.Decision.ALLOWED,
                policy.personalPayout(clan, leader, externalRecipient, new BigDecimal("999999999")));
        assertEquals(ClanRewardPolicy.Decision.ALLOWED,
                policy.personalPayout(clan, deputy, externalRecipient, new BigDecimal("0.00000001")));
        assertEquals(ClanRewardPolicy.Decision.ISSUER_NOT_AUTHORIZED,
                policy.personalPayout(clan, externalRecipient, leader, BigDecimal.ONE));
    }

    @Test
    void deputyOrdinaryRewardEnforcesInclusiveAmountAndThreePerDayLimits() {
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        UUID recipient = UUID.randomUUID();
        Clan clan = clan(now, leader, deputy, recipient, now.minusSeconds(7L * 86_400L));
        assertEquals(ClanRewardPolicy.Decision.ALLOWED,
                policy.ordinaryBankReward(clan, deputy, recipient, new BigDecimal("100000"), 2, now));
        assertEquals(ClanRewardPolicy.Decision.DEPUTY_AMOUNT_LIMIT,
                policy.ordinaryBankReward(clan, deputy, recipient, new BigDecimal("100000.01"), 0, now));
        assertEquals(ClanRewardPolicy.Decision.DEPUTY_DAILY_LIMIT,
                policy.ordinaryBankReward(clan, deputy, recipient, new BigDecimal("100"), 3, now));
        assertEquals(ClanRewardPolicy.Decision.ALLOWED,
                policy.ordinaryBankReward(clan, leader, recipient, new BigDecimal("999999999"), 100, now));
    }

    @Test
    void bankRewardRequiresSevenFullDaysAndRejoiningResetsTheTenure() {
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        UUID recipient = UUID.randomUUID();
        Clan exactlySevenDays = clan(now, leader, deputy, recipient, now.minusSeconds(7L * 86_400L));
        Clan rejoinedSixDaysAgo = clan(now, leader, deputy, recipient, now.minusSeconds(6L * 86_400L));
        assertEquals(ClanRewardPolicy.Decision.ALLOWED,
                policy.ordinaryBankReward(exactlySevenDays, deputy, recipient, new BigDecimal("1"), 0, now));
        assertEquals(ClanRewardPolicy.Decision.RECIPIENT_MEMBERSHIP_TOO_NEW,
                policy.ordinaryBankReward(rejoinedSixDaysAgo, deputy, recipient, new BigDecimal("1"), 0, now));
    }

    @Test
    void largeDeputyRewardIsNotEnabledUntilWeeklyQuotaConsumptionRuleIsDecided() {
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        UUID recipient = UUID.randomUUID();
        Clan clan = clan(now, leader, deputy, recipient, now.minusSeconds(7L * 86_400L));
        assertEquals(ClanRewardPolicy.Decision.WEEKLY_QUOTA_POLICY_UNRESOLVED,
                policy.largeBankRewardRequest(clan, deputy, recipient, new BigDecimal("100000.01"), now));
        assertEquals(ClanRewardPolicy.Decision.WEEKLY_QUOTA_POLICY_UNRESOLVED,
                policy.largeBankRewardRequest(clan, deputy, recipient, new BigDecimal("1000000"), now));
        assertEquals(ClanRewardPolicy.Decision.INVALID_LARGE_REWARD_AMOUNT,
                policy.largeBankRewardRequest(clan, deputy, recipient, new BigDecimal("1000000.01"), now));
    }

    private static Clan clan(Instant now, UUID leader, UUID deputy, UUID recipient, Instant recipientJoinedAt) {
        return new Clan(UUID.randomUUID(), "RewardClan", "RW01", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null),
                        recipient, new ClanMember(recipient, ClanRole.MEMBER, recipientJoinedAt, null)), 0, null);
    }
}

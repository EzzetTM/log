package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseIntent;
import com.skyworldclans.clan.membership.ClanMember;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;

final class CapacityPurchaseFingerprint {
    private CapacityPurchaseFingerprint() {
    }

    static String of(CapacityPurchaseIntent intent) {
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (DataOutputStream output = new DataOutputStream(bytes)) {
                writeUuid(output, intent.operationId());
                writeString(output, intent.idempotencyKey());
                writeString(output, intent.businessOperationId());
                writeClan(output, intent.expectedClan());
                writeUuid(output, intent.actorId());
                output.writeLong(intent.expectedRevision());
                output.writeInt(intent.targetCapacity());
                output.writeLong(intent.amount());
            }
            return HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-256").digest(bytes.toByteArray()));
        } catch (IOException | NoSuchAlgorithmException exception) {
            throw new IllegalStateException("Could not fingerprint capacity purchase intent", exception);
        }
    }

    private static void writeClan(DataOutputStream output, Clan clan) throws IOException {
        writeUuid(output, clan.id());
        writeString(output, clan.name());
        writeString(output, clan.tag());
        writeString(output, clan.createdAt().toString());
        output.writeInt(clan.capacity());
        output.writeLong(clan.totalXp());
        writeNullableString(output, clan.tagline());
        output.writeInt(clan.members().size());
        for (Map.Entry<UUID, ClanMember> entry : clan.members().entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .toList()) {
            writeMember(output, entry.getKey(), entry.getValue());
        }
    }

    private static void writeMember(
            DataOutputStream output,
            UUID mapPlayerId,
            ClanMember member) throws IOException {
        writeUuid(output, mapPlayerId);
        writeUuid(output, member.playerId());
        writeString(output, member.role().name());
        writeString(output, member.membershipStartedAt().toString());
        writeNullableUuid(output, member.appointedByDeputyId());
    }

    private static void writeUuid(DataOutputStream output, UUID value) throws IOException {
        output.writeLong(value.getMostSignificantBits());
        output.writeLong(value.getLeastSignificantBits());
    }

    private static void writeNullableUuid(DataOutputStream output, UUID value) throws IOException {
        output.writeBoolean(value != null);
        if (value != null) {
            writeUuid(output, value);
        }
    }

    private static void writeNullableString(DataOutputStream output, String value)
            throws IOException {
        output.writeBoolean(value != null);
        if (value != null) {
            writeString(output, value);
        }
    }

    private static void writeString(DataOutputStream output, String value) throws IOException {
        byte[] encoded = encodeString(value);
        output.writeInt(encoded.length);
        output.write(encoded);
    }

    static byte[] encodeString(String value) {
        try {
            ByteBuffer encoded = StandardCharsets.UTF_8.newEncoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .encode(CharBuffer.wrap(value));
            byte[] bytes = new byte[encoded.remaining()];
            encoded.get(bytes);
            return bytes;
        } catch (CharacterCodingException exception) {
            throw new IllegalArgumentException(
                    "Fingerprint strings must contain valid UTF-16 sequences", exception);
        }
    }
}

package com.skyworldclans.clan.bank;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.integration.EconomyOperations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ClanBankTransferCoordinatorTest {
    @TempDir Path temporaryDirectory;

    @Test
    void depositAndApprovedWithdrawalUseVaultOnceAndKeepUnknownReservation() {
        Path database = temporaryDirectory.resolve("bank-transfer.sqlite");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new Clan(UUID.randomUUID(), "TransferClan", "TC01", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null)), 0, null);
        FakeEconomy economy = new FakeEconomy();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            AtomicInteger ids = new AtomicInteger();
            ClanBankTransferCoordinator coordinator = new ClanBankTransferCoordinator(store, store, economy,
                    Runnable::run, Runnable::run, Clock.fixed(now, ZoneOffset.UTC),
                    () -> new UUID(0L, ids.incrementAndGet()));

            AtomicReference<ClanBankTransferCoordinator.Result> depositResult = new AtomicReference<>();
            coordinator.deposit(clan.id(), deputy, new BigDecimal("50"), depositResult::set);
            assertNotNull(depositResult.get());
            assertEquals(ClanBankTransferCoordinator.Status.SUCCESS, depositResult.get().status());
            assertEquals(1, economy.withdrawCalls.get());
            assertEquals(new BigDecimal("50"), store.clanBankBalance(clan.id()));

            economy.withdrawResult = new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN, "timeout");
            AtomicReference<ClanBankTransferCoordinator.Result> uncertainDeposit = new AtomicReference<>();
            coordinator.deposit(clan.id(), deputy, new BigDecimal("5"), uncertainDeposit::set);
            assertEquals(ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED, uncertainDeposit.get().status());
            AtomicReference<ClanBankTransferCoordinator.Result> repeatedDeposit = new AtomicReference<>();
            coordinator.deposit(clan.id(), deputy, new BigDecimal("5"), repeatedDeposit::set);
            assertEquals(ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED, repeatedDeposit.get().status());
            assertEquals(2, economy.withdrawCalls.get(), "an actor with an UNKNOWN deposit must not be able to trigger a second withdrawal");
            assertEquals(new BigDecimal("50"), store.clanBankBalance(clan.id()), "unknown deposit must not be credited locally");
            economy.withdrawResult = new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "");

            var request = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "request-key", clan.id(), deputy,
                    new BigDecimal("20"), "approved transfer", now, now.plusSeconds(86_400));
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED,
                    store.resolveClanBankWithdrawalRequest(request.request().requestId(), leader,
                            SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED, now.plusSeconds(1), "leader approved").status());
            economy.depositResult = new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN, "timeout");
            AtomicReference<ClanBankTransferCoordinator.Result> unknownResult = new AtomicReference<>();
            coordinator.payApprovedDeputyRequest(clan.id(), leader, request.request().requestId(), unknownResult::set);
            assertEquals(ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED, unknownResult.get().status());
            assertEquals(1, economy.depositCalls.get());
            assertEquals(new BigDecimal("30"), store.clanBankAvailableBalance(clan.id()));

            AtomicReference<ClanBankTransferCoordinator.Result> duplicateResult = new AtomicReference<>();
            coordinator.payApprovedDeputyRequest(clan.id(), leader, request.request().requestId(), duplicateResult::set);
            assertEquals(ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED, duplicateResult.get().status());
            assertEquals(1, economy.depositCalls.get(), "UNKNOWN operation must not repeat the Vault call");
        }
    }

    @Test
    void confirmedNoProviderCallCanBeRetriedWithANewTechnicalAttempt() {
        Path database = temporaryDirectory.resolve("bank-safe-retry.sqlite");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new Clan(UUID.randomUUID(), "RetryClan", "RC01", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null)), 0, null);
        FakeEconomy economy = new FakeEconomy();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            store.recordClanBankMovement(UUID.randomUUID(), "seed-bank", clan.id(), leader,
                    "QUEST_REWARD", new BigDecimal("10"), "seed", null, now);
            var request = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "retry-request", clan.id(), deputy,
                    new BigDecimal("10"), "retry-safe", now, now.plusSeconds(86_400));
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED,
                    store.resolveClanBankWithdrawalRequest(request.request().requestId(), leader,
                            SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED, now.plusSeconds(1), "approved").status());
            ClanBankTransferCoordinator failingDispatcher = new ClanBankTransferCoordinator(store, store, economy,
                    Runnable::run, task -> { throw new IllegalStateException("plugin scheduler unavailable"); },
                    Clock.fixed(now.plusSeconds(2), ZoneOffset.UTC), UUID::randomUUID);
            failingDispatcher.payApprovedDeputyRequest(clan.id(), leader, request.request().requestId(), ignored -> { });
            var failedAttempt = store.findClanBankWithdrawalRequests(clan.id(), false).get(0).paymentOperationId();
            assertNotNull(failedAttempt);
            assertEquals(SqliteClanStore.ClanBankOperationState.FAILED_NO_EFFECT,
                    store.findClanBankOperation(failedAttempt).orElseThrow().state());
            assertEquals(0, economy.depositCalls.get(), "provider must not run if main-thread dispatch failed");
            assertEquals(new BigDecimal("10"), store.clanBankAvailableBalance(clan.id()));

            ClanBankTransferCoordinator retryCoordinator = new ClanBankTransferCoordinator(store, store, economy,
                    Runnable::run, Runnable::run, Clock.fixed(now.plusSeconds(3), ZoneOffset.UTC), UUID::randomUUID);
            AtomicReference<ClanBankTransferCoordinator.Result> retried = new AtomicReference<>();
            retryCoordinator.payApprovedDeputyRequest(clan.id(), leader, request.request().requestId(), retried::set);
            assertEquals(ClanBankTransferCoordinator.Status.SUCCESS, retried.get().status());
            assertEquals(1, economy.depositCalls.get());
            assertEquals(BigDecimal.ZERO, store.clanBankBalance(clan.id()));
            assertEquals(SqliteClanStore.ClanBankOperationState.COMMITTED, retried.get().operation().state());
        }
    }

    @Test
    void insufficientPersonalFundsReleaseTheOperationWithoutCreditingTheBank() {
        Path database = temporaryDirectory.resolve("bank-insufficient.sqlite");
        UUID leader = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new Clan(UUID.randomUUID(), "InsufficientClan", "IC01", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null)), 0, null);
        FakeEconomy economy = new FakeEconomy();
        economy.withdrawResult = new EconomyOperations.OperationResult(EconomyOperations.Status.INSUFFICIENT_FUNDS, "insufficient");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            ClanBankTransferCoordinator coordinator = new ClanBankTransferCoordinator(store, store, economy,
                    Runnable::run, Runnable::run, Clock.fixed(now, ZoneOffset.UTC), UUID::randomUUID);
            AtomicReference<ClanBankTransferCoordinator.Result> result = new AtomicReference<>();
            coordinator.deposit(clan.id(), leader, new BigDecimal("10"), result::set);
            assertEquals(ClanBankTransferCoordinator.Status.INSUFFICIENT_PERSONAL_FUNDS, result.get().status());
            assertEquals(BigDecimal.ZERO, store.clanBankBalance(clan.id()));
            assertEquals(SqliteClanStore.ClanBankOperationState.FAILED_NO_EFFECT, result.get().operation().state());
        }
    }

    private static final class FakeEconomy implements EconomyOperations {
        private final AtomicInteger withdrawCalls = new AtomicInteger();
        private final AtomicInteger depositCalls = new AtomicInteger();
        private OperationResult withdrawResult = new OperationResult(Status.SUCCESS, "");
        private OperationResult depositResult = new OperationResult(Status.SUCCESS, "");

        @Override public BalanceResult balance(UUID playerId) { return new BalanceResult(Status.SUCCESS, 1_000_000, ""); }
        @Override public OperationResult withdraw(UUID playerId, double amount) { withdrawCalls.incrementAndGet(); return withdrawResult; }
        @Override public OperationResult deposit(UUID playerId, double amount) { depositCalls.incrementAndGet(); return depositResult; }
    }
}

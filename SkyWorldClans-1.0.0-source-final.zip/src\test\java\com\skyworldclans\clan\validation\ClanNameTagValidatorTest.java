package com.skyworldclans.clan.validation;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanNameTagValidatorTest {

    @Test
    void acceptsNameAtMinimumAndMaximumLength() {
        assertTrue(ClanNameTagValidator.isValidName("abc"));
        assertTrue(ClanNameTagValidator.isValidName("abcdefghijklmnop"));
    }

    @Test
    void rejectsNameOutsideAllowedLength() {
        assertFalse(ClanNameTagValidator.isValidName("ab"));
        assertFalse(ClanNameTagValidator.isValidName("abcdefghijklmnopq"));
    }

    @Test
    void rejectsNullAndEmptyName() {
        assertFalse(ClanNameTagValidator.isValidName(null));
        assertFalse(ClanNameTagValidator.isValidName(""));
    }

    @Test
    void countsNameLengthInUnicodeCodePoints() {
        assertTrue(ClanNameTagValidator.isValidName("𐐀𐐀a"));
    }

    @Test
    void acceptsNameWithSpacesAndDifferentCaseWhenLengthIsValid() {
        assertTrue(ClanNameTagValidator.isValidName("Sky World"));
        assertTrue(ClanNameTagValidator.isValidName("skyworld"));
        assertTrue(ClanNameTagValidator.isValidName("SKYWORLD"));
    }

    @Test
    void acceptsTagAtMinimumAndMaximumLength() {
        assertTrue(ClanNameTagValidator.isValidTag("A1"));
        assertTrue(ClanNameTagValidator.isValidTag("aB09Z"));
    }

    @Test
    void acceptsLatinLettersAndDigitsInTag() {
        assertTrue(ClanNameTagValidator.isValidTag("Az09"));
    }

    @Test
    void rejectsTagOutsideAllowedLength() {
        assertFalse(ClanNameTagValidator.isValidTag("A"));
        assertFalse(ClanNameTagValidator.isValidTag("A12345"));
    }

    @Test
    void rejectsNullAndEmptyTag() {
        assertFalse(ClanNameTagValidator.isValidTag(null));
        assertFalse(ClanNameTagValidator.isValidTag(""));
    }

    @Test
    void rejectsCyrillicWhitespaceAndSpecialCharactersInTag() {
        assertFalse(ClanNameTagValidator.isValidTag("АА"));
        assertFalse(ClanNameTagValidator.isValidTag("A B"));
        assertFalse(ClanNameTagValidator.isValidTag("A!"));
    }

    @Test
    void rejectsUnicodeDigitsInTag() {
        assertFalse(ClanNameTagValidator.isValidTag("A١"));
    }

    @Test
    void doesNotTreatRepeatedNamesAsInvalid() {
        assertTrue(ClanNameTagValidator.isValidName("Same"));
        assertTrue(ClanNameTagValidator.isValidName("Same"));
    }
}

package com.skyworldclans.command;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.clan.chat.ClanChatService;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;

public final class ClanChatCommand implements CommandExecutor {
    private final SkyWorldClansPlugin plugin;

    public ClanChatCommand(SkyWorldClansPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Клановый чат доступен только игроку.");
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(ChatColor.YELLOW + "Использование: /cc <сообщение>");
            return true;
        }
        String message = String.join(" ", Arrays.asList(args));
        ClanChatService.Result result = plugin.getClanChatService().send(player, message);
        switch (result) {
            case SENT -> { }
            case INVALID_MESSAGE -> player.sendMessage(ChatColor.RED + "Сообщение не может быть пустым.");
            case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            case MUTED -> player.sendMessage(ChatColor.RED + "Тебе запрещено писать в клановый чат (мут).");
            case FLECTONEPULSE_UNAVAILABLE -> player.sendMessage(ChatColor.RED + "Клановый чат временно недоступен: FlectonePulse не загружен или API не готов.");
            case DELIVERY_FAILED -> player.sendMessage(ChatColor.RED + "Не удалось отправить сообщение в клановый чат.");
            case STORAGE_ERROR -> player.sendMessage(ChatColor.RED + "Не удалось проверить состав клана.");
        }
        return true;
    }
}

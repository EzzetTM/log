package com.skyworldclans.clan.application.purchase;

import com.skyworldclans.clan.policy.ClanCapacityPolicy;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

public record CapacityPurchaseOperation(
        UUID operationId,
        String idempotencyKey,
        String businessOperationId,
        UUID clanId,
        UUID actorId,
        int expectedCapacity,
        int targetCapacity,
        long expectedRevision,
        long amount,
        CapacityPurchaseState state,
        String providerOperationId,
        Instant createdAt,
        Instant updatedAt) {

    public CapacityPurchaseOperation {
        Objects.requireNonNull(operationId, "operationId");
        if (idempotencyKey == null || idempotencyKey.isBlank()) {
            throw new IllegalArgumentException("idempotencyKey must not be blank");
        }
        if (businessOperationId == null || businessOperationId.isBlank()) {
            throw new IllegalArgumentException("businessOperationId must not be blank");
        }
        Objects.requireNonNull(clanId, "clanId");
        Objects.requireNonNull(actorId, "actorId");
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(updatedAt, "updatedAt");
        if (expectedRevision < 0) {
            throw new IllegalArgumentException("expectedRevision must not be negative");
        }
        if (!ClanCapacityPolicy.canExpandTo(expectedCapacity, targetCapacity)) {
            throw new IllegalArgumentException("Operation must request the next capacity level");
        }
        long expectedAmount = ClanCapacityPolicy.nextExpansionCost(expectedCapacity)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Operation has no next capacity level"));
        if (amount != expectedAmount) {
            throw new IllegalArgumentException("Operation amount does not match capacity price");
        }
        if (updatedAt.isBefore(createdAt)) {
            throw new IllegalArgumentException("updatedAt must not precede createdAt");
        }
        if (providerOperationId != null && providerOperationId.isBlank()) {
            throw new IllegalArgumentException("providerOperationId must not be blank");
        }
    }
}

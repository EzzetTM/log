package com.skyworldclans.clan.validation;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanTagUniquenessCheckerTest {

    @Test
    void acceptsTagWhenNoTagsExist() {
        ClanTagUniquenessChecker checker = checkerWithTags(List.of());

        assertTrue(checker.isUnique("Sky"));
    }

    @Test
    void rejectsFullyMatchingExistingTag() {
        ClanTagUniquenessChecker checker = checkerWithTags(List.of("Sky"));

        assertFalse(checker.isUnique("Sky"));
    }

    @Test
    void rejectsTagThatDiffersOnlyByCase() {
        ClanTagUniquenessChecker checker = checkerWithTags(List.of("Sky"));

        assertFalse(checker.isUnique("SKY"));
        assertFalse(checker.isUnique("sky"));
    }

    @Test
    void acceptsDifferentTag() {
        ClanTagUniquenessChecker checker = checkerWithTags(List.of("Sky"));

        assertTrue(checker.isUnique("Sun"));
    }

    @Test
    void rejectsTagMatchingAnyOfSeveralCaseVariants() {
        ClanTagUniquenessChecker checker = checkerWithTags(List.of("Other", "sKy", "Clan"));

        assertFalse(checker.isUnique("SkY"));
    }

    private ClanTagUniquenessChecker checkerWithTags(Iterable<String> tags) {
        return new ClanTagUniquenessChecker(() -> tags);
    }
}

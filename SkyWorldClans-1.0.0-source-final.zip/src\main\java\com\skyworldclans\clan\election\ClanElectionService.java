package com.skyworldclans.clan.election;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanElectionPolicy;
import com.skyworldclans.clan.service.ClanMembershipChangeResult;
import com.skyworldclans.clan.service.ClanMembershipService;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Clock;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/** Persistent election lifecycle. A tied global ballot remains active rather than inventing a winner. */
public final class ClanElectionService {
    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final ClanMembershipService memberships;
    private final ClanElectionPolicy policy;
    private final Clock clock;
    private final Supplier<UUID> ids;

    public ClanElectionService(ClanCatalog clans, SqliteClanStore store,
            ClanMembershipService memberships, Clock clock, Supplier<UUID> ids) {
        this.clans = Objects.requireNonNull(clans); this.store = Objects.requireNonNull(store);
        this.memberships = Objects.requireNonNull(memberships); this.clock = Objects.requireNonNull(clock);
        this.ids = Objects.requireNonNull(ids); this.policy = new ClanElectionPolicy();
    }

    public StartResult startDeparture(UUID clanId, UUID departingLeaderId) {
        if (store.findActiveElection(clanId).isPresent()) return StartResult.ACTIVE_ELECTION_EXISTS;
        Clan clan = clans.findById(clanId).orElse(null);
        if (clan == null || clan.leader().isEmpty()
                || !clan.leader().get().playerId().equals(departingLeaderId)) return StartResult.CLAN_OR_LEADER_NOT_FOUND;
        if (policy.automaticSuccessor(clan, departingLeaderId).isPresent()) {
            ClanMembershipChangeResult transfer = memberships.leaveClan(departingLeaderId, false);
            return transfer.status() == ClanMembershipChangeResult.Status.UPDATED
                    ? StartResult.AUTO_TRANSFERRED : StartResult.STORAGE_ERROR;
        }
        List<UUID> candidates = policy.departureCandidates(clan, departingLeaderId);
        if (candidates.isEmpty()) return StartResult.EMPTY_CLAN_REQUIRES_DELETION_SUPPORT;
        java.time.Instant now = clock.instant();
        SqliteClanStore.ElectionCreateStatus result = store.createElection(ids.get(), clanId,
                "DEPARTURE", departingLeaderId, now,
                now.plus(ClanElectionPolicy.DEPARTURE_ELECTION_DURATION), candidates);
        return switch (result) {
            case CREATED -> StartResult.STARTED;
            case ACTIVE_ELECTION_EXISTS -> StartResult.ACTIVE_ELECTION_EXISTS;
            case CLAN_NOT_FOUND -> StartResult.CLAN_OR_LEADER_NOT_FOUND;
            case INVALID -> StartResult.STORAGE_ERROR;
        };
    }

    public StartResult startCoup(UUID clanId, UUID initiatorId) {
        if (store.findActiveElection(clanId).isPresent()) return StartResult.ACTIVE_ELECTION_EXISTS;
        Clan clan = clans.findById(clanId).orElse(null);
        if (clan == null || clan.leader().isEmpty()) return StartResult.CLAN_OR_LEADER_NOT_FOUND;
        if (clan.member(initiatorId).filter(member -> member.role() == com.skyworldclans.clan.membership.ClanRole.DEPUTY).isEmpty()) {
            return StartResult.NOT_AUTHORIZED;
        }
        var lastActivity = store.lastPlayerActivity(clan.leader().orElseThrow().playerId());
        if (lastActivity.isEmpty() || clock.instant().isBefore(lastActivity.get().plus(ClanElectionPolicy.LEADER_INACTIVITY_REQUIRED))) {
            return StartResult.INACTIVITY_REQUIREMENT_NOT_MET;
        }
        var previousCoup = store.latestCompletedCoup(clanId);
        UUID currentLeader = clan.leader().orElseThrow().playerId();
        if (previousCoup.filter(previous -> previous.winnerId().equals(currentLeader)
                && clock.instant().isBefore(previous.completedAt().plus(ClanElectionPolicy.REPEAT_COUP_WAIT))).isPresent()) {
            return StartResult.COUP_COOLDOWN_ACTIVE;
        }
        List<UUID> candidates = policy.coupCandidates(clan);
        java.time.Instant now = clock.instant();
        SqliteClanStore.ElectionCreateStatus result = store.createElection(ids.get(), clanId,
                "COUP", initiatorId, now,
                now.plus(ClanElectionPolicy.COUP_ELECTION_DURATION), candidates);
        return switch (result) {
            case CREATED -> StartResult.STARTED;
            case ACTIVE_ELECTION_EXISTS -> StartResult.ACTIVE_ELECTION_EXISTS;
            case CLAN_NOT_FOUND -> StartResult.CLAN_OR_LEADER_NOT_FOUND;
            case INVALID -> StartResult.STORAGE_ERROR;
        };
    }

    public VoteResult vote(UUID clanId, UUID voterId, UUID candidateId, boolean globalPermission) {
        SqliteClanStore.ElectionSnapshot election = store.findActiveElection(clanId).orElse(null);
        if (election == null) return VoteResult.NO_ACTIVE_ELECTION;
        Clan clan = clans.findById(clanId).orElse(null);
        if (clan == null) return VoteResult.CLAN_NOT_FOUND;
        boolean allowed = election.phase().equals("LOCAL")
                ? policy.canVote(clan, voterId, election.candidates(), candidateId)
                : policy.canUseGlobalTieBreakPermission(globalPermission, voterId, election.candidates(), candidateId);
        if (!allowed) return VoteResult.NOT_ELIGIBLE;
        SqliteClanStore.ElectionVoteStatus result = store.castElectionVote(election.id(), election.phase(), voterId, candidateId, clock.instant());
        return switch (result) {
            case VOTED -> VoteResult.VOTED;
            case ALREADY_VOTED -> VoteResult.ALREADY_VOTED;
            case INVALID_CANDIDATE -> VoteResult.INVALID_CANDIDATE;
            case NOT_FOUND -> VoteResult.NO_ACTIVE_ELECTION;
            case PHASE_CHANGED -> VoteResult.PHASE_CHANGED;
            case PHASE_CLOSED -> VoteResult.PHASE_CLOSED;
            case INVALID -> VoteResult.INVALID;
        };
    }

    /** Processes a due election. A final global tie is recorded and held for an owner decision. */
    public ResolutionResult resolveIfDue(UUID clanId) {
        SqliteClanStore.ElectionSnapshot election = store.findActiveElection(clanId).orElse(null);
        if (election == null) return ResolutionResult.NO_ACTIVE_ELECTION;
        if (clock.instant().isBefore(election.closesAt())) return ResolutionResult.NOT_DUE;
        Map<UUID, Integer> tally = store.electionTally(election.id(), election.phase());
        List<UUID> tied = policy.tiedForFirst(election.candidates(), tally);
        if (tied.size() > 1) {
            if (election.phase().equals("LOCAL")) {
                java.time.Instant now = clock.instant();
                SqliteClanStore.ElectionTransitionStatus status = store.advanceElectionToTieBreak(
                        election.id(), tied, now, now.plus(ClanElectionPolicy.GLOBAL_TIE_BREAK_DURATION));
                return status == SqliteClanStore.ElectionTransitionStatus.UPDATED
                        ? ResolutionResult.GLOBAL_TIE_BREAK_STARTED : ResolutionResult.STORAGE_ERROR;
            }
            SqliteClanStore.ElectionTransitionStatus blocked = store.blockElectionForOwnerDecision(
                    election.id(), clock.instant());
            return blocked == SqliteClanStore.ElectionTransitionStatus.UPDATED
                    ? ResolutionResult.GLOBAL_TIE_REMAINS_TIED : ResolutionResult.STORAGE_ERROR;
        }
        if (tied.isEmpty()) return ResolutionResult.NO_CANDIDATES;
        UUID winner = tied.get(0);
        SqliteClanStore.ElectionTransitionStatus completed = store.completeElectionWithOutcome(
                election.id(), winner, clock.instant());
        return switch (completed) {
            case UPDATED -> ResolutionResult.COMPLETED;
            case CLAN_NOT_FOUND -> ResolutionResult.CLAN_NOT_FOUND;
            case MEMBERSHIP_CONFLICT -> ResolutionResult.MEMBERSHIP_UPDATE_FAILED;
            default -> ResolutionResult.STORAGE_ERROR;
        };
    }

    public boolean hasActiveElection(UUID clanId) { return store.findActiveElection(clanId).isPresent(); }
    public boolean isBlockedForOwnerDecision(UUID clanId) {
        return store.isElectionBlockedForOwnerDecision(clanId);
    }
    public Map<UUID, Integer> tally(UUID clanId) {
        return store.findActiveElection(clanId)
                .map(election -> store.electionTally(election.id(), election.phase()))
                .orElseGet(Map::of);
    }
    public Optional<ClanElection> activeElection(UUID clanId) {
        return store.findActiveElection(clanId).map(snapshot -> new ClanElection(
                snapshot.id(), snapshot.clanId(), ClanElection.Type.valueOf(snapshot.type()),
                ClanElection.Phase.valueOf(snapshot.phase()), snapshot.startedBy(),
                snapshot.startedAt(), snapshot.closesAt(), snapshot.candidates(), Optional.empty()));
    }

    public enum StartResult { STARTED, AUTO_TRANSFERRED, ACTIVE_ELECTION_EXISTS, CLAN_OR_LEADER_NOT_FOUND,
        EMPTY_CLAN_REQUIRES_DELETION_SUPPORT, INACTIVITY_REQUIREMENT_NOT_MET, COUP_COOLDOWN_ACTIVE, NOT_AUTHORIZED, STORAGE_ERROR }
    public enum VoteResult { VOTED, ALREADY_VOTED, NO_ACTIVE_ELECTION, CLAN_NOT_FOUND, NOT_ELIGIBLE,
        INVALID_CANDIDATE, PHASE_CHANGED, PHASE_CLOSED, INVALID }
    public enum ResolutionResult { COMPLETED, GLOBAL_TIE_BREAK_STARTED, GLOBAL_TIE_REMAINS_TIED,
        NO_ACTIVE_ELECTION, NOT_DUE, NO_CANDIDATES, CLAN_NOT_FOUND, MEMBERSHIP_UPDATE_FAILED, STORAGE_ERROR }
}

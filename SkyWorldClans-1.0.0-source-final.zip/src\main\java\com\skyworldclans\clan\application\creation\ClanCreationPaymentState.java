package com.skyworldclans.clan.application.creation;

/** Durable state of the ordinary-currency debit required to create a clan. */
public enum ClanCreationPaymentState {
    PREPARED,
    CALLING,
    DEBIT_CONFIRMED,
    COMMITTED,
    FAILED_NO_EFFECT,
    UNKNOWN
}

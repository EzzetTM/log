package com.skyworldclans.clan.membership;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanLeadershipPolicyTest {
    private static final Duration THIRTY_DAYS = Duration.ofDays(30);

    private final ClanLeadershipPolicy policy = new ClanLeadershipPolicy();

    @Test
    void determinesEmptyClanWhenNoMembersRemain() {
        assertEquals(
                Optional.of(LeaderDepartureOutcome.EMPTY_CLAN),
                policy.determineLeaderDeparture(0, 0));
    }

    @Test
    void transfersLeadershipToExactlyOneDeputy() {
        assertEquals(
                Optional.of(LeaderDepartureOutcome.TRANSFER_TO_DEPUTY),
                policy.determineLeaderDeparture(1, 1));
        assertEquals(
                Optional.of(LeaderDepartureOutcome.TRANSFER_TO_DEPUTY),
                policy.determineLeaderDeparture(5, 1));
    }

    @Test
    void startsDeputyElectionForTwoOrMoreDeputies() {
        assertEquals(
                Optional.of(LeaderDepartureOutcome.ELECTION_AMONG_DEPUTIES),
                policy.determineLeaderDeparture(2, 2));
        assertEquals(
                Optional.of(LeaderDepartureOutcome.ELECTION_AMONG_DEPUTIES),
                policy.determineLeaderDeparture(4, 4));
    }

    @Test
    void startsMemberElectionWhenMembersRemainWithoutDeputies() {
        assertEquals(
                Optional.of(LeaderDepartureOutcome.ELECTION_AMONG_MEMBERS),
                policy.determineLeaderDeparture(1, 0));
        assertEquals(
                Optional.of(LeaderDepartureOutcome.ELECTION_AMONG_MEMBERS),
                policy.determineLeaderDeparture(10, 0));
    }

    @Test
    void rejectsNegativeDepartureCounts() {
        assertEquals(Optional.empty(), policy.determineLeaderDeparture(-1, 0));
        assertEquals(Optional.empty(), policy.determineLeaderDeparture(0, -1));
        assertEquals(Optional.empty(), policy.determineLeaderDeparture(-1, -1));
    }

    @Test
    void rejectsDeputyCountsThatCannotFitInRemainingMembership() {
        assertEquals(Optional.empty(), policy.determineLeaderDeparture(0, 1));
        assertEquals(Optional.empty(), policy.determineLeaderDeparture(1, 2));
    }

    @Test
    void rejectsDeputyCountsAboveTheClanLimit() {
        assertEquals(Optional.empty(), policy.determineLeaderDeparture(5, 5));
    }

    @Test
    void allowsLeadershipTransferToDeputyOutsideElectionsOnly() {
        for (ClanRole role : ClanRole.values()) {
            assertEquals(
                    role == ClanRole.DEPUTY,
                    policy.canTransferLeadershipTo(role, false),
                    () -> "target role: " + role);
        }
    }

    @Test
    void deniesLeadershipTransferDuringElectionsForEveryRole() {
        for (ClanRole role : ClanRole.values()) {
            assertFalse(
                    policy.canTransferLeadershipTo(role, true),
                    () -> "target role: " + role);
        }
    }

    @Test
    void deniesLeadershipTransferToNullRole() {
        assertFalse(policy.canTransferLeadershipTo(null, false));
        assertFalse(policy.canTransferLeadershipTo(null, true));
    }

    @Test
    void onlyDeputiesCanInitiateCoupAtTheExactInactivityBoundary() {
        for (ClanRole role : ClanRole.values()) {
            assertEquals(
                    role == ClanRole.DEPUTY,
                    policy.canInitiateCoup(role, THIRTY_DAYS, false, Duration.ZERO),
                    () -> "actor role: " + role);
        }
    }

    @Test
    void inactivityBoundaryRejectsBeforeThirtyDaysAndAllowsAtOrAfterIt() {
        assertFalse(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS.minusNanos(1), false, Duration.ZERO));
        assertTrue(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS, false, Duration.ZERO));
        assertTrue(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS.plusNanos(1), false, Duration.ZERO));
    }

    @Test
    void requiresThirtyDaysAfterIncumbentWonPreviousCoup() {
        assertFalse(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS, true, THIRTY_DAYS.minusNanos(1)));
        assertTrue(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS, true, THIRTY_DAYS));
        assertTrue(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS, true, THIRTY_DAYS.plusNanos(1)));
    }

    @Test
    void doesNotApplyPostWinWaitWhenIncumbentDidNotWinPreviousCoup() {
        assertTrue(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS, false, Duration.ZERO));
    }

    @Test
    void rejectsNullOrNegativeCoupDurations() {
        assertFalse(policy.canInitiateCoup(
                ClanRole.DEPUTY, null, false, Duration.ZERO));
        assertFalse(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS, false, null));
        assertFalse(policy.canInitiateCoup(
                ClanRole.DEPUTY, Duration.ofNanos(-1), false, Duration.ZERO));
        assertFalse(policy.canInitiateCoup(
                ClanRole.DEPUTY, THIRTY_DAYS, false, Duration.ofNanos(-1)));
    }

    @Test
    void requiresGlobalTieBreakOnlyWhenRunoffIsTied() {
        assertTrue(policy.requiresGlobalTieBreak(true));
        assertFalse(policy.requiresGlobalTieBreak(false));
    }
}

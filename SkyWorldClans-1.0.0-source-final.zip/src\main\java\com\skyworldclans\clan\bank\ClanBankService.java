package com.skyworldclans.clan.bank;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Supplier;

/** Enforces deputy/leader permissions for bank withdrawal requests. It does not invoke Vault. */
public final class ClanBankService {
    private static final UUID SYSTEM_ACTOR_ID = new UUID(0L, 0L);
    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final Clock clock;
    private final Supplier<UUID> ids;

    public ClanBankService(ClanCatalog clans, SqliteClanStore store, Clock clock, Supplier<UUID> ids) {
        this.clans = Objects.requireNonNull(clans, "clans");
        this.store = Objects.requireNonNull(store, "store");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.ids = Objects.requireNonNull(ids, "ids");
    }

    public RequestResult requestWithdrawal(UUID clanId, UUID requesterId, BigDecimal amount, String reason) {
        if (clanId == null || requesterId == null || amount == null || amount.signum() <= 0
                || amount.stripTrailingZeros().scale() > 8
                || reason == null || reason.isBlank() || reason.trim().length() > 500)
            return new RequestResult(Status.INVALID_INPUT, null);
        Clan clan = clans.findById(clanId).orElse(null);
        if (clan == null) return new RequestResult(Status.CLAN_NOT_FOUND, null);
        ClanMember requester = clan.member(requesterId).orElse(null);
        if (requester == null) return new RequestResult(Status.NOT_MEMBER, null);
        if (requester.role() != ClanRole.DEPUTY) return new RequestResult(Status.DEPUTY_ONLY, null);
        var now = clock.instant();
        UUID requestId = Objects.requireNonNull(ids.get(), "generated request id");
        var stored = store.createClanBankWithdrawalRequest(requestId, "bank-withdraw-request:" + requestId,
                clanId, requesterId, amount, reason.trim(), now, now.plusSeconds(86_400));
        return switch (stored.status()) {
            case CREATED -> new RequestResult(Status.CREATED, stored.request());
            case DUPLICATE -> new RequestResult(Status.DUPLICATE, stored.request());
            case IDEMPOTENCY_CONFLICT -> new RequestResult(Status.STORAGE_CONFLICT, null);
            case CLAN_NOT_FOUND -> new RequestResult(Status.CLAN_NOT_FOUND, null);
            default -> new RequestResult(Status.STORAGE_ERROR, stored.request());
        };
    }

    public RequestResult resolveWithdrawal(UUID clanId, UUID actorId, UUID requestId, boolean approve) {
        if (clanId == null || actorId == null || requestId == null)
            return new RequestResult(Status.INVALID_INPUT, null);
        Clan clan = clans.findById(clanId).orElse(null);
        if (clan == null) return new RequestResult(Status.CLAN_NOT_FOUND, null);
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) return new RequestResult(Status.NOT_MEMBER, null);
        if (actor.role() != ClanRole.LEADER) return new RequestResult(Status.LEADER_ONLY, null);
        SqliteClanStore.ClanBankWithdrawalRequest existing = store.findClanBankWithdrawalRequests(clanId, false)
                .stream().filter(request -> request.requestId().equals(requestId)).findFirst().orElse(null);
        if (existing == null) return new RequestResult(Status.REQUEST_NOT_FOUND, null);
        var resolution = approve ? SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED
                : SqliteClanStore.ClanBankWithdrawalRequestStatus.DECLINED;
        var result = store.resolveClanBankWithdrawalRequest(requestId, actorId, resolution,
                clock.instant(), approve ? "APPROVED_BY_LEADER" : "DECLINED_BY_LEADER");
        return switch (result.status()) {
            case APPROVED -> new RequestResult(Status.APPROVED, result.request());
            case DECLINED -> new RequestResult(Status.DECLINED, result.request());
            case EXPIRED -> new RequestResult(Status.EXPIRED, result.request());
            case NOT_FOUND -> new RequestResult(Status.REQUEST_NOT_FOUND, null);
            case NOT_AUTHORIZED -> new RequestResult(Status.LEADER_ONLY, result.request());
            case ALREADY_RESOLVED -> new RequestResult(Status.ALREADY_RESOLVED, result.request());
            default -> new RequestResult(Status.STORAGE_ERROR, result.request());
        };
    }

    public List<SqliteClanStore.ClanBankWithdrawalRequest> requests(UUID clanId, UUID actorId, boolean pendingOnly) {
        if (clanId == null || actorId == null) return List.of();
        Clan clan = clans.findById(clanId).orElse(null);
        if (clan == null) return List.of();
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null || actor.role() != ClanRole.LEADER) return List.of();
        return store.findClanBankWithdrawalRequests(clanId, pendingOnly);
    }

    /** Called by a scheduler; expiry is a local state transition and never a payment. */
    public int expireDueRequests() {
        return expireDueRequestsDetailed().size();
    }

    public List<SqliteClanStore.ClanBankWithdrawalRequest> expireDueRequestsDetailed() {
        return store.expireDueClanBankWithdrawalRequestsDetailed(clock.instant(), SYSTEM_ACTOR_ID);
    }

    public enum Status {
        CREATED, DUPLICATE, APPROVED, DECLINED, EXPIRED, ALREADY_RESOLVED,
        INVALID_INPUT, CLAN_NOT_FOUND, NOT_MEMBER, DEPUTY_ONLY, LEADER_ONLY,
        REQUEST_NOT_FOUND, STORAGE_CONFLICT, STORAGE_ERROR
    }

    public record RequestResult(Status status, SqliteClanStore.ClanBankWithdrawalRequest request) { }
}

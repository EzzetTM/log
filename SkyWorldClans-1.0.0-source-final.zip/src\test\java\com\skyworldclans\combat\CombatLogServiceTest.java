package com.skyworldclans.combat;

import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CombatLogServiceTest {
    @TempDir Path temporaryDirectory;

    @Test
    void pvpHitTagsBothPlayersAndEveryNewHitResetsTheThirtySecondTimer() {
        Path database = temporaryDirectory.resolve("combat-reset.sqlite");
        UUID attacker = UUID.randomUUID();
        UUID victim = UUID.randomUUID();
        Instant start = Instant.parse("2026-11-15T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            CombatLogService service = new CombatLogService(store);
            service.recordPvpDamage(attacker, victim, start);
            assertEquals(start.plusSeconds(30), store.findCombatLogSession(attacker).orElseThrow().expiresAt());
            assertEquals(start.plusSeconds(30), store.findCombatLogSession(victim).orElseThrow().expiresAt());

            service.recordPvpDamage(victim, attacker, start.plusSeconds(20));
            assertEquals(start.plusSeconds(20), store.findCombatLogSession(attacker).orElseThrow().lastHitAt());
            assertEquals(start.plusSeconds(50), store.findCombatLogSession(attacker).orElseThrow().expiresAt());
            assertEquals(0, service.expireDue(start.plusSeconds(49)));
            assertEquals(2, service.expireDue(start.plusSeconds(50)));
            assertEquals(SqliteClanStore.CombatLogSessionStatus.EXPIRED,
                    store.findCombatLogSession(attacker).orElseThrow().status());
        }
    }

    @Test
    void logoutDuringCombatIsPunishedButLogoutAtDeadlineIsNot() {
        Path database = temporaryDirectory.resolve("combat-quit.sqlite");
        UUID attacker = UUID.randomUUID();
        UUID victim = UUID.randomUUID();
        UUID otherAttacker = UUID.randomUUID();
        UUID otherVictim = UUID.randomUUID();
        Instant start = Instant.parse("2026-11-15T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            CombatLogService service = new CombatLogService(store);
            service.recordPvpDamage(attacker, victim, start);
            assertTrue(service.onQuit(attacker, start.plusSeconds(29)));
            assertEquals(SqliteClanStore.CombatLogSessionStatus.LOGOUT_VIOLATION,
                    store.findCombatLogSession(attacker).orElseThrow().status());
            assertFalse(service.onDeath(attacker, start.plusSeconds(29)));

            service.recordPvpDamage(otherAttacker, otherVictim, start.plusSeconds(60));
            assertFalse(service.onQuit(otherAttacker, start.plusSeconds(90)));
            assertEquals(SqliteClanStore.CombatLogSessionStatus.EXPIRED,
                    store.findCombatLogSession(otherAttacker).orElseThrow().status());
        }
    }

    @Test
    void volatileFallbackStillEnforcesLogoutWhenSqliteWriteFails() {
        Path database = temporaryDirectory.resolve("combat-fallback.sqlite");
        UUID attacker = UUID.randomUUID();
        UUID victim = UUID.randomUUID();
        Instant start = Instant.parse("2026-11-15T12:00:00Z");
        SqliteClanStore store = SqliteClanStore.open(database);
        CombatLogService service = new CombatLogService(store);
        store.close();
        org.junit.jupiter.api.Assertions.assertThrows(RuntimeException.class,
                () -> service.recordPvpDamage(attacker, victim, start));
        assertTrue(service.onQuit(attacker, start.plusSeconds(10)));
        assertFalse(service.onQuit(attacker, start.plusSeconds(11)));
    }

    @Test
    void activeCombatInterruptedByRestartRequiresReviewAndNeverAutoPunishesQuit() {
        Path database = temporaryDirectory.resolve("combat-restart.sqlite");
        UUID attacker = UUID.randomUUID();
        UUID victim = UUID.randomUUID();
        Instant start = Instant.parse("2026-11-15T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            CombatLogService service = new CombatLogService(store);
            service.recordPvpDamage(attacker, victim, start);
            assertEquals(2, service.recoverAfterRestart(start.plusSeconds(10)));
            assertTrue(service.needsRestartReview(attacker));
            assertFalse(service.onQuit(attacker, start.plusSeconds(11)));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            CombatLogService service = new CombatLogService(reopened);
            assertTrue(service.needsRestartReview(attacker));
            assertEquals(SqliteClanStore.CombatLogSessionStatus.INTERRUPTED_REVIEW,
                    reopened.findCombatLogSession(attacker).orElseThrow().status());
            service.recordPvpDamage(attacker, victim, start.plusSeconds(12));
            assertEquals(SqliteClanStore.CombatLogSessionStatus.ACTIVE,
                    reopened.findCombatLogSession(attacker).orElseThrow().status());
        }
    }
}

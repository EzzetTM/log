package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.catalog.InMemoryClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.membership.ClanRole;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanServiceTest {
    private static final UUID CLAN_ID = UUID.fromString("10000000-0000-0000-0000-000000000001");
    private static final UUID OTHER_CLAN_ID = UUID.fromString("10000000-0000-0000-0000-000000000002");
    private static final UUID LEADER_ID = UUID.fromString("20000000-0000-0000-0000-000000000001");
    private static final UUID SHARED_MEMBER_ID =
            UUID.fromString("20000000-0000-0000-0000-000000000002");
    private static final Instant CREATED_AT = Instant.parse("2026-01-01T00:00:00Z");

    private final InMemoryClanCatalog catalog = new InMemoryClanCatalog();
    private final ClanService service = new ClanService(
            catalog, new ClanMembershipStateValidator());

    @Test
    void registersValidPreparedClanAndMakesItSearchable() {
        Clan clan = clan(CLAN_ID, "Sky", LEADER_ID);

        ClanRegistrationResult result = service.registerClan(clan);

        assertEquals(ClanRegistrationResult.Status.REGISTERED, result.status());
        assertTrue(result.registered());
        assertEquals(clan, catalog.findById(CLAN_ID).orElseThrow());
        assertEquals(clan, catalog.findByTag("sKy").orElseThrow());
        assertEquals(clan, catalog.findByPlayerId(LEADER_ID).orElseThrow());
    }

    @Test
    void rejectsDuplicateClanIdWithoutChangingCatalog() {
        Clan existingClan = clan(CLAN_ID, "First", LEADER_ID);
        Clan candidate = clan(CLAN_ID, "Other", SHARED_MEMBER_ID);
        assertEquals(
                ClanRegistrationResult.Status.REGISTERED,
                service.registerClan(existingClan).status());

        ClanRegistrationResult result = service.registerClan(candidate);

        assertEquals(ClanRegistrationResult.Status.CLAN_ID_CONFLICT, result.status());
        assertEquals(1, catalog.size());
        assertEquals(existingClan, catalog.findById(CLAN_ID).orElseThrow());
        assertEquals(existingClan, catalog.findByTag("First").orElseThrow());
        assertEquals(existingClan, catalog.findByPlayerId(LEADER_ID).orElseThrow());
        assertFalse(catalog.findByTag("Other").isPresent());
        assertFalse(catalog.findByPlayerId(SHARED_MEMBER_ID).isPresent());
    }

    @Test
    void rejectsDuplicateTagRegardlessOfCaseWithoutChangingCatalog() {
        Clan existingClan = clan(CLAN_ID, "Sky", LEADER_ID);
        Clan candidate = clan(OTHER_CLAN_ID, "sKY", SHARED_MEMBER_ID);
        assertEquals(
                ClanRegistrationResult.Status.REGISTERED,
                service.registerClan(existingClan).status());

        ClanRegistrationResult result = service.registerClan(candidate);

        assertEquals(ClanRegistrationResult.Status.TAG_CONFLICT, result.status());
        assertEquals(1, catalog.size());
        assertEquals(existingClan, catalog.findById(CLAN_ID).orElseThrow());
        assertEquals(existingClan, catalog.findByTag("Sky").orElseThrow());
        assertEquals(existingClan, catalog.findByPlayerId(LEADER_ID).orElseThrow());
        assertFalse(catalog.findById(OTHER_CLAN_ID).isPresent());
        assertEquals(existingClan, catalog.findByTag("sKY").orElseThrow());
        assertFalse(catalog.findByPlayerId(SHARED_MEMBER_ID).isPresent());
    }

    @Test
    void rejectsMemberAlreadyRegisteredInAnotherClanWithoutChangingCatalog() {
        Clan existingClan = clan(CLAN_ID, "First", SHARED_MEMBER_ID);
        Clan candidate = clan(OTHER_CLAN_ID, "Other", SHARED_MEMBER_ID);
        assertEquals(
                ClanRegistrationResult.Status.REGISTERED,
                service.registerClan(existingClan).status());

        ClanRegistrationResult result = service.registerClan(candidate);

        assertEquals(ClanRegistrationResult.Status.MEMBER_CONFLICT, result.status());
        assertEquals(1, catalog.size());
        assertEquals(existingClan, catalog.findById(CLAN_ID).orElseThrow());
        assertEquals(existingClan, catalog.findByTag("First").orElseThrow());
        assertFalse(catalog.findById(OTHER_CLAN_ID).isPresent());
        assertFalse(catalog.findByTag("Other").isPresent());
        assertEquals(existingClan, catalog.findByPlayerId(SHARED_MEMBER_ID).orElseThrow());
    }

    @Test
    void rejectsClanWithInvalidMembershipStateAndLeavesCatalogUnchanged() {
        Clan invalidClan = clanWithDeputies(CLAN_ID, "Oops", 5);

        ClanRegistrationResult result = service.registerClan(invalidClan);

        assertEquals(ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE, result.status());
        assertTrue(result.validationViolations().contains(
                ClanMembershipStateValidator.Violation.DEPUTY_LIMIT_EXCEEDED));
        assertTrue(result.validationViolations().contains(
                ClanMembershipStateValidator.Violation.LEADER_REQUIRED_OUTSIDE_ELECTION));
        assertEquals(0, catalog.size());
    }

    @Test
    void rejectsNullClanWithExplicitFailureAndDoesNotMutateCatalog() {
        ClanRegistrationResult result = service.registerClan(null);

        assertEquals(ClanRegistrationResult.Status.CLAN_REQUIRED, result.status());
        assertFalse(result.registered());
        assertEquals(0, catalog.size());
    }

    @Test
    void expandsCapacityThroughEveryAllowedStepAndPreservesClanState() {
        Clan initial = clan(CLAN_ID, "Sky", LEADER_ID);
        assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, catalog.registerIfAvailable(initial));

        for (int targetCapacity : new int[]{20, 30, 40, 50}) {
            Clan current = catalog.findById(CLAN_ID).orElseThrow();
            Clan expected = current.withExpandedCapacity(targetCapacity);

            ClanCapacityExpansionResult result =
                    service.expandCapacity(CLAN_ID, LEADER_ID, targetCapacity);

            assertEquals(ClanCapacityExpansionResult.Status.EXPANDED, result.status());
            assertTrue(result.expanded());
            assertEquals(java.util.Optional.of(expected), result.clan());
            assertEquals(expected, catalog.findById(CLAN_ID).orElseThrow());
        }
    }

    @Test
    void refusesCapacityExpansionForNonLeaderWithoutMutation() {
        Clan initial = clan(CLAN_ID, "Sky", LEADER_ID);
        assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, catalog.registerIfAvailable(initial));

        ClanCapacityExpansionResult result =
                service.expandCapacity(CLAN_ID, SHARED_MEMBER_ID, 20);

        assertEquals(ClanCapacityExpansionResult.Status.NOT_LEADER, result.status());
        assertEquals(initial, catalog.findById(CLAN_ID).orElseThrow());
    }

    @Test
    void refusesCapacityExpansionForMissingClan() {
        ClanCapacityExpansionResult result =
                service.expandCapacity(CLAN_ID, LEADER_ID, 20);

        assertEquals(ClanCapacityExpansionResult.Status.CLAN_NOT_FOUND, result.status());
        assertEquals(0, catalog.size());
    }

    @Test
    void refusesMaximumAndInvalidCapacityTransitionsWithoutMutation() {
        Clan atMaximum = new Clan(
                CLAN_ID,
                "Sky",
                "SW",
                CREATED_AT,
                50,
                Map.of(LEADER_ID, member(LEADER_ID, ClanRole.LEADER)),
                0,
                null);
        assertEquals(
                ClanCatalog.RegistrationStatus.REGISTERED,
                catalog.registerIfAvailable(atMaximum));

        ClanCapacityExpansionResult maximumResult =
                service.expandCapacity(CLAN_ID, LEADER_ID, 60);
        assertEquals(
                ClanCapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                maximumResult.status());
        assertEquals(atMaximum, catalog.findById(CLAN_ID).orElseThrow());

        InMemoryClanCatalog invalidTransitionCatalog = new InMemoryClanCatalog();
        Clan initial = clan(CLAN_ID, "Sky", LEADER_ID);
        assertEquals(
                ClanCatalog.RegistrationStatus.REGISTERED,
                invalidTransitionCatalog.registerIfAvailable(initial));
        ClanService invalidTransitionService =
                new ClanService(invalidTransitionCatalog, new ClanMembershipStateValidator());

        for (int invalidCapacity : new int[]{10, 30, 0, 11, 51}) {
            ClanCapacityExpansionResult result =
                    invalidTransitionService.expandCapacity(
                            CLAN_ID, LEADER_ID, invalidCapacity);
            assertEquals(
                    ClanCapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                    result.status());
            assertEquals(initial, invalidTransitionCatalog.findById(CLAN_ID).orElseThrow());
        }
    }

    @Test
    void detectsCapacityChangedAfterInitialReadAndPreservesNewerState() {
        InMemoryClanCatalog backing = new InMemoryClanCatalog();
        Clan initial = clan(CLAN_ID, "Sky", LEADER_ID);
        assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, backing.registerIfAvailable(initial));
        ClanCatalog racingCatalog = new RacingCatalog(backing, expected ->
                assertEquals(
                        ClanCatalog.CapacityUpdateStatus.UPDATED,
                        backing.updateCapacityIfUnchanged(
                                expected,
                                LEADER_ID,
                                expected.withExpandedCapacity(20))));
        ClanService racingService =
                new ClanService(racingCatalog, new ClanMembershipStateValidator());

        ClanCapacityExpansionResult result =
                racingService.expandCapacity(CLAN_ID, LEADER_ID, 20);

        assertEquals(
                ClanCapacityExpansionResult.Status.CONCURRENT_MODIFICATION,
                result.status());
        assertEquals(20, backing.findById(CLAN_ID).orElseThrow().capacity());
    }

    @Test
    void detectsLeaderChangedAfterInitialReadAndPreservesNewerState() {
        InMemoryClanCatalog backing = new InMemoryClanCatalog();
        Clan initial = clan(CLAN_ID, "Sky", LEADER_ID);
        assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, backing.registerIfAvailable(initial));
        ClanCatalog racingCatalog = new RacingCatalog(backing, expected ->
                backing.replaceForTest(expected, clan(CLAN_ID, "Sky", SHARED_MEMBER_ID)));
        ClanService racingService =
                new ClanService(racingCatalog, new ClanMembershipStateValidator());

        ClanCapacityExpansionResult result =
                racingService.expandCapacity(CLAN_ID, LEADER_ID, 20);

        assertEquals(
                ClanCapacityExpansionResult.Status.CONCURRENT_MODIFICATION,
                result.status());
        assertEquals(
                SHARED_MEMBER_ID,
                backing.findById(CLAN_ID).orElseThrow().leader().orElseThrow().playerId());
        assertEquals(10, backing.findById(CLAN_ID).orElseThrow().capacity());
    }

    @Test
    void concurrentCapacityExpansionAttemptsAllowOnlyOneUpdate() throws Exception {
        InMemoryClanCatalog backing = new InMemoryClanCatalog();
        Clan initial = clan(CLAN_ID, "Sky", LEADER_ID);
        assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, backing.registerIfAvailable(initial));
        ClanService concurrentService = new ClanService(
                new BarrierCatalog(backing, 2),
                new ClanMembershipStateValidator());
        ExecutorService executor = Executors.newFixedThreadPool(2);
        CyclicBarrier startBarrier = new CyclicBarrier(2);
        try {
            Future<ClanCapacityExpansionResult> first = executor.submit(() -> {
                startBarrier.await(5, TimeUnit.SECONDS);
                return concurrentService.expandCapacity(CLAN_ID, LEADER_ID, 20);
            });
            Future<ClanCapacityExpansionResult> second = executor.submit(() -> {
                startBarrier.await(5, TimeUnit.SECONDS);
                return concurrentService.expandCapacity(CLAN_ID, LEADER_ID, 20);
            });

            List<ClanCapacityExpansionResult.Status> statuses = List.of(
                    first.get(10, TimeUnit.SECONDS).status(),
                    second.get(10, TimeUnit.SECONDS).status());

            assertEquals(1, statuses.stream()
                    .filter(status -> status == ClanCapacityExpansionResult.Status.EXPANDED)
                    .count());
            assertEquals(1, statuses.stream()
                    .filter(status ->
                            status == ClanCapacityExpansionResult.Status.CONCURRENT_MODIFICATION)
                    .count());
            assertEquals(20, backing.findById(CLAN_ID).orElseThrow().capacity());
        } finally {
            executor.shutdownNow();
        }
    }

    @Test
    void doesNotRegisterSameClanTwice() {
        Clan clan = clan(CLAN_ID, "Sky", LEADER_ID);

        assertEquals(
                ClanRegistrationResult.Status.REGISTERED,
                service.registerClan(clan).status());
        assertEquals(
                ClanRegistrationResult.Status.CLAN_ID_CONFLICT,
                service.registerClan(clan).status());
        assertEquals(1, catalog.size());
        assertEquals(clan, catalog.findById(CLAN_ID).orElseThrow());
        assertEquals(clan, catalog.findByTag("Sky").orElseThrow());
        assertEquals(clan, catalog.findByPlayerId(LEADER_ID).orElseThrow());
    }

    @Test
    void preventsTwoDifferentClansFromRegisteringTheSameMember() {
        Clan existingClan = clan(CLAN_ID, "First", LEADER_ID);
        Clan candidate = clan(OTHER_CLAN_ID, "Other", LEADER_ID);
        assertEquals(
                ClanRegistrationResult.Status.REGISTERED,
                service.registerClan(existingClan).status());

        assertEquals(
                ClanRegistrationResult.Status.MEMBER_CONFLICT,
                service.registerClan(candidate).status());
        assertEquals(1, catalog.size());
        assertEquals(existingClan, catalog.findById(CLAN_ID).orElseThrow());
        assertEquals(existingClan, catalog.findByTag("First").orElseThrow());
        assertEquals(existingClan, catalog.findByPlayerId(LEADER_ID).orElseThrow());
        assertFalse(catalog.findById(OTHER_CLAN_ID).isPresent());
        assertFalse(catalog.findByTag("Other").isPresent());
    }

    @Test
    void preventsTwoDifferentClansFromRegisteringTheSameTagIgnoringCase() {
        Clan existingClan = clan(CLAN_ID, "Sky", LEADER_ID);
        Clan candidate = clan(OTHER_CLAN_ID, "SKY", SHARED_MEMBER_ID);
        assertEquals(
                ClanRegistrationResult.Status.REGISTERED,
                service.registerClan(existingClan).status());

        assertEquals(
                ClanRegistrationResult.Status.TAG_CONFLICT,
                service.registerClan(candidate).status());
        assertEquals(1, catalog.size());
        assertEquals(existingClan, catalog.findById(CLAN_ID).orElseThrow());
        assertEquals(existingClan, catalog.findByTag("Sky").orElseThrow());
        assertEquals(existingClan, catalog.findByPlayerId(LEADER_ID).orElseThrow());
        assertFalse(catalog.findById(OTHER_CLAN_ID).isPresent());
        assertEquals(existingClan, catalog.findByTag("SKY").orElseThrow());
        assertFalse(catalog.findByPlayerId(SHARED_MEMBER_ID).isPresent());
    }

    @Test
    void atomicallyRegistersOnlyOneOfSeveralConcurrentClansWithTheSameTag() throws Exception {
        List<Clan> candidates = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            candidates.add(clan(
                    new UUID(4, i + 1),
                    "SH",
                    new UUID(5, i + 1)));
        }

        List<ClanRegistrationResult> results = registerConcurrently(candidates);
        Clan winner = assertOneConcurrentRegistration(
                candidates, results, ClanRegistrationResult.Status.TAG_CONFLICT);

        assertConcurrentCatalogState(candidates, winner, true, false);
    }

    @Test
    void atomicallyRegistersOnlyOneOfSeveralConcurrentClansWithTheSameMember() throws Exception {
        List<Clan> candidates = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            candidates.add(clan(
                    new UUID(6, i + 1),
                    "T" + (i + 1),
                    SHARED_MEMBER_ID));
        }

        List<ClanRegistrationResult> results = registerConcurrently(candidates);
        Clan winner = assertOneConcurrentRegistration(
                candidates, results, ClanRegistrationResult.Status.MEMBER_CONFLICT);

        assertConcurrentCatalogState(candidates, winner, false, true);
    }

    @Test
    void publicCatalogLookupMethodsReturnEmptyForNullAndUnknownKeys() {
        ClanCatalog publicCatalog = catalog;

        assertTrue(publicCatalog.findById(null).isEmpty());
        assertTrue(publicCatalog.findByTag(null).isEmpty());
        assertTrue(publicCatalog.findByPlayerId(null).isEmpty());
        assertTrue(publicCatalog.findById(CLAN_ID).isEmpty());
        assertTrue(publicCatalog.findByTag("Unknown").isEmpty());
        assertTrue(publicCatalog.findByPlayerId(LEADER_ID).isEmpty());
    }

    @Test
    void publicCatalogRegistrationMethodReturnsClanRequiredForNull() {
        ClanCatalog publicCatalog = catalog;

        assertEquals(
                ClanCatalog.RegistrationStatus.CLAN_REQUIRED,
                publicCatalog.registerIfAvailable(null));
        assertEquals(0, catalog.size());
    }

    private List<ClanRegistrationResult> registerConcurrently(List<Clan> candidates)
            throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(candidates.size());
        CyclicBarrier startBarrier = new CyclicBarrier(candidates.size());
        try {
            List<Future<ClanRegistrationResult>> futures = new ArrayList<>();
            for (Clan candidate : candidates) {
                futures.add(executor.submit(() -> {
                    startBarrier.await(5, TimeUnit.SECONDS);
                    return service.registerClan(candidate);
                }));
            }

            List<ClanRegistrationResult> results = new ArrayList<>();
            for (Future<ClanRegistrationResult> future : futures) {
                results.add(future.get(10, TimeUnit.SECONDS));
            }
            return List.copyOf(results);
        } finally {
            executor.shutdownNow();
        }
    }

    private Clan assertOneConcurrentRegistration(
            List<Clan> candidates,
            List<ClanRegistrationResult> results,
            ClanRegistrationResult.Status expectedConflict) {
        assertEquals(candidates.size(), results.size());
        int registeredCount = 0;
        Clan winner = null;
        for (int i = 0; i < results.size(); i++) {
            ClanRegistrationResult result = results.get(i);
            if (result.registered()) {
                registeredCount++;
                winner = candidates.get(i);
            } else {
                assertEquals(expectedConflict, result.status());
            }
        }
        assertEquals(1, registeredCount);
        assertTrue(winner != null);
        assertEquals(1, catalog.size());
        return winner;
    }

    private void assertConcurrentCatalogState(
            List<Clan> candidates,
            Clan winner,
            boolean sharedTag,
            boolean sharedMember) {
        for (Clan candidate : candidates) {
            boolean isWinner = candidate.id().equals(winner.id());
            assertEquals(
                    isWinner ? java.util.Optional.of(winner) : java.util.Optional.empty(),
                    catalog.findById(candidate.id()));
            assertEquals(
                    sharedTag || isWinner
                            ? java.util.Optional.of(winner)
                            : java.util.Optional.empty(),
                    catalog.findByTag(candidate.tag()));
            assertEquals(
                    sharedMember || isWinner
                            ? java.util.Optional.of(winner)
                            : java.util.Optional.empty(),
                    catalog.findByPlayerId(candidate.members().keySet().iterator().next()));
        }
    }

    private static class DelegatingCatalog implements ClanCatalog {
        protected final ClanCatalog delegate;

        private DelegatingCatalog(ClanCatalog delegate) {
            this.delegate = delegate;
        }

        @Override
        public Optional<Clan> findById(UUID clanId) {
            return delegate.findById(clanId);
        }

        @Override
        public Optional<Clan> findByTag(String tag) {
            return delegate.findByTag(tag);
        }

        @Override
        public Optional<Clan> findByPlayerId(UUID playerId) {
            return delegate.findByPlayerId(playerId);
        }

        @Override
        public RegistrationStatus registerIfAvailable(Clan clan) {
            return delegate.registerIfAvailable(clan);
        }

        @Override
        public CapacityUpdateStatus updateCapacityIfUnchanged(
                Clan expectedClan,
                UUID leaderId,
                Clan updatedClan) {
            return delegate.updateCapacityIfUnchanged(expectedClan, leaderId, updatedClan);
        }

        @Override
        public MembershipUpdateStatus updateMembershipIfUnchanged(
                Clan expectedClan, Clan updatedClan) {
            return delegate.updateMembershipIfUnchanged(expectedClan, updatedClan);
        }

                @Override
                public Optional<Long> findRevision(UUID clanId) {
                    return delegate.findRevision(clanId);
                }
            }

            private static final class RacingCatalog extends DelegatingCatalog {
        private final InMemoryClanCatalog backing;
        private final Consumer<Clan> beforeUpdate;
        private final AtomicBoolean raced = new AtomicBoolean();

        private RacingCatalog(InMemoryClanCatalog backing, Consumer<Clan> beforeUpdate) {
            super(backing);
            this.backing = backing;
            this.beforeUpdate = beforeUpdate;
        }

        @Override
        public CapacityUpdateStatus updateCapacityIfUnchanged(
                Clan expectedClan,
                UUID leaderId,
                Clan updatedClan) {
            if (raced.compareAndSet(false, true)) {
                beforeUpdate.accept(expectedClan);
            }
            return backing.updateCapacityIfUnchanged(expectedClan, leaderId, updatedClan);
        }
    }

    private static final class BarrierCatalog extends DelegatingCatalog {
        private final CyclicBarrier updateBarrier;

        private BarrierCatalog(ClanCatalog delegate, int concurrentUpdates) {
            super(delegate);
            this.updateBarrier = new CyclicBarrier(concurrentUpdates);
        }

        @Override
        public CapacityUpdateStatus updateCapacityIfUnchanged(
                Clan expectedClan,
                UUID leaderId,
                Clan updatedClan) {
            try {
                updateBarrier.await(5, TimeUnit.SECONDS);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Concurrent update barrier failed", exception);
            } catch (BrokenBarrierException | TimeoutException exception) {
                throw new IllegalStateException("Concurrent update barrier failed", exception);
            }
            return delegate.updateCapacityIfUnchanged(expectedClan, leaderId, updatedClan);
        }
    }

    private static Clan clan(UUID clanId, String tag, UUID leaderId) {
        return new Clan(
                clanId,
                "Valid Clan",
                tag,
                CREATED_AT,
                10,
                Map.of(leaderId, member(leaderId, ClanRole.LEADER)),
                0,
                null);
    }

    private static Clan clanWithDeputies(UUID clanId, String tag, int deputyCount) {
        Map<UUID, ClanMember> members = new HashMap<>();
        for (int i = 0; i < deputyCount; i++) {
            UUID playerId = new UUID(3, i + 1);
            members.put(playerId, member(playerId, ClanRole.DEPUTY));
        }
        return new Clan(
                clanId,
                "Valid Clan",
                tag,
                CREATED_AT,
                10,
                members,
                0,
                null);
    }

    private static ClanMember member(UUID playerId, ClanRole role) {
        return new ClanMember(playerId, role, CREATED_AT, null);
    }
}

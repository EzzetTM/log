package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;

import java.util.Objects;
import java.util.Optional;

public record ClanCapacityExpansionResult(
        Status status,
        Optional<Clan> clan) {

    public ClanCapacityExpansionResult {
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(clan, "clan");
        if ((status == Status.EXPANDED) != clan.isPresent()) {
            throw new IllegalArgumentException(
                    "Only a successful capacity expansion may contain a clan");
        }
    }

    public boolean expanded() {
        return status == Status.EXPANDED;
    }

    public enum Status {
        EXPANDED,
        CLAN_NOT_FOUND,
        NOT_LEADER,
        INVALID_CAPACITY_TRANSITION,
        CONCURRENT_MODIFICATION,
        INVALID_INPUT
    }
}

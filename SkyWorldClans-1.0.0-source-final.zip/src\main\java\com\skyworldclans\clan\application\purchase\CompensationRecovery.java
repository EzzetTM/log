package com.skyworldclans.clan.application.purchase;

import com.skyworldclans.clan.storage.StorageException;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Recovers compensation operations left in COMPENSATION_CALLING after a restart.
 *
 * <p>Recovery only reconciles an already-started compensation. It never issues another refund.
 * The compensation identifier is deterministic, so the provider can identify the same operation
 * even when the application process has been replaced.
 */
public final class CompensationRecovery {

    private final CapacityPurchaseStore purchaseStore;
    private final PaymentPort paymentPort;

    public CompensationRecovery(CapacityPurchaseStore purchaseStore, PaymentPort paymentPort) {
        this.purchaseStore = Objects.requireNonNull(purchaseStore, "purchaseStore");
        this.paymentPort = Objects.requireNonNull(paymentPort, "paymentPort");
    }

    /**
     * Reconciles every operation currently in COMPENSATION_CALLING.
     *
     * @return one result for each operation that was selected for recovery
     * @throws StorageException if the journal cannot be read or a result cannot be persisted
     */
    public List<CapacityExpansionResult> recover() throws StorageException {
        List<CapacityPurchaseOperation> callingOperations =
                purchaseStore.findByState(CapacityPurchaseState.COMPENSATION_CALLING);
        List<CapacityExpansionResult> results = new ArrayList<>(callingOperations.size());

        for (CapacityPurchaseOperation operation : callingOperations) {
            results.add(recoverOperation(operation));
        }
        return List.copyOf(results);
    }

    private CapacityExpansionResult recoverOperation(CapacityPurchaseOperation operation)
            throws StorageException {
        String compensationId = compensationId(operation);
        String originalProviderOperationId = operation.providerOperationId();

        // Without the original debit reference there is no safe provider query to make.
        // Preserve the operation as unresolved; never interpret missing data as a failed refund.
        if (originalProviderOperationId == null || originalProviderOperationId.isBlank()) {
            return transitionTo(
                    operation,
                    CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId,
                    CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }

        final PaymentPort.CompensationResult reconciliation;
        try {
            reconciliation = paymentPort.reconcile(originalProviderOperationId, compensationId);
        } catch (PaymentPort.PaymentException | RuntimeException exception) {
            // Provider adapters are external boundaries. Even an unchecked adapter failure
            // cannot prove that the refund had no effect; keep the operation unresolved.
            return transitionTo(
                    operation,
                    CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId,
                    CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }

        // A null, mismatched, or contradictory provider response is not evidence of success
        // or of no effect. Record uncertainty and leave it for explicit/manual resolution.
        if (reconciliation == null
                || !compensationId.equals(reconciliation.compensationId())
                || !originalProviderOperationId.equals(reconciliation.originalProviderOperationId())
                || (reconciliation.success() && reconciliation.unknown())) {
            return transitionTo(
                    operation,
                    CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId,
                    CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }

        if (reconciliation.unknown()) {
            return transitionTo(
                    operation,
                    CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId,
                    CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }

        if (reconciliation.success()) {
            return transitionTo(
                    operation,
                    CapacityPurchaseState.COMPENSATED,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED,
                    compensationId,
                    CapacityExpansionResult.Status.COMPENSATED);
        }

        return transitionTo(
                operation,
                CapacityPurchaseState.COMPENSATION_FAILED,
                CapacityPurchaseTransitionEvidence.COMPENSATION_NO_EFFECT_REPORTED,
                compensationId,
                CapacityExpansionResult.Status.COMPENSATION_FAILED);
    }

    private CapacityExpansionResult transitionTo(
            CapacityPurchaseOperation operation,
            CapacityPurchaseState targetState,
            CapacityPurchaseTransitionEvidence evidence,
            String providerReference,
            CapacityExpansionResult.Status resultStatus) {
        CapacityPurchaseJournal.TransitionResult transition = purchaseStore.transition(
                operation.operationId(),
                CapacityPurchaseState.COMPENSATION_CALLING,
                targetState,
                evidence,
                providerReference);

        if (transition.status() != CapacityPurchaseJournal.TransitionStatus.UPDATED) {
            throw new StorageException(
                    "Could not persist compensation recovery for operation "
                            + operation.operationId() + ": " + transition.status());
        }

        return new CapacityExpansionResult(resultStatus, Optional.empty());
    }

    private static String compensationId(CapacityPurchaseOperation operation) {
        return "compensation-" + operation.operationId();
    }
}

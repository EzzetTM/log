package com.skyworldclans.storage;

import org.bukkit.inventory.ItemStack;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * Versioned, self-describing binary envelope for Bukkit item-array snapshots.
 *
 * <p>Every slot is encoded independently, so null slots and arbitrary item components are
 * preserved without relying on the null handling of any single Bukkit helper. Snapshots are
 * validated before use: unknown magic, unsupported version, an unexpected element count or a
 * malformed payload is reported as {@link CorruptSnapshotException} and the caller must fail
 * closed instead of guessing at contents.</p>
 */
public final class StorageSnapshotCodec {
    private static final byte[] MAGIC = "SWCSTOR1".getBytes(StandardCharsets.US_ASCII);
    private static final int FORMAT_VERSION = 1;
    private static final int MAX_PAYLOAD_BYTES = 2 * 1024 * 1024;

    private StorageSnapshotCodec() { }

    /** Encodes exactly {@code expectedSize} item slots; null slots are preserved. */
    public static byte[] encode(ItemStack[] items, int expectedSize) {
        Objects.requireNonNull(items, "items");
        if (items.length != expectedSize) {
            throw new IllegalArgumentException("Expected " + expectedSize + " slots, got " + items.length);
        }
        try {
            ByteArrayOutputStream payloadBuffer = new ByteArrayOutputStream();
            DataOutputStream payload = new DataOutputStream(payloadBuffer);
            for (ItemStack item : items) {
                if (item == null || item.getType().isAir()) {
                    payload.writeByte(0);
                } else {
                    payload.writeByte(1);
                    byte[] encoded = item.clone().serializeAsBytes();
                    payload.writeInt(encoded.length);
                    payload.write(encoded);
                }
            }
            payload.flush();
            byte[] payloadBytes = payloadBuffer.toByteArray();
            if (payloadBytes.length > MAX_PAYLOAD_BYTES) {
                throw new IllegalArgumentException("Serialized item snapshot is too large");
            }
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(payloadBytes.length + 20);
            DataOutputStream output = new DataOutputStream(buffer);
            output.write(MAGIC);
            output.writeInt(FORMAT_VERSION);
            output.writeInt(expectedSize);
            output.writeInt(payloadBytes.length);
            output.write(payloadBytes);
            output.flush();
            return buffer.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Could not encode item snapshot envelope", exception);
        }
    }

    /** Returns an empty (all null) snapshot without any Bukkit serialization. */
    public static byte[] empty(int expectedSize) {
        if (expectedSize < 0) throw new IllegalArgumentException("expectedSize must be non-negative");
        try {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(16);
            DataOutputStream output = new DataOutputStream(buffer);
            output.write(MAGIC);
            output.writeInt(FORMAT_VERSION);
            output.writeInt(expectedSize);
            output.writeInt(0);
            output.flush();
            return buffer.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Could not encode empty item snapshot", exception);
        }
    }

    /** Decodes and validates a snapshot with exactly {@code expectedSize} slots. */
    public static ItemStack[] decode(byte[] bytes, int expectedSize) {
        if (bytes == null) throw new CorruptSnapshotException("Snapshot bytes are missing");
        if (expectedSize < 0) throw new IllegalArgumentException("expectedSize must be non-negative");
        if (bytes.length == 0) {
            return new ItemStack[expectedSize];
        }
        if (bytes.length < MAGIC.length + 12 || bytes.length > MAX_PAYLOAD_BYTES + 32) {
            throw new CorruptSnapshotException("Snapshot envelope has an invalid length");
        }
        for (int index = 0; index < MAGIC.length; index++) {
            if (bytes[index] != MAGIC[index]) {
                throw new CorruptSnapshotException("Snapshot envelope magic is not recognized");
            }
        }
        int offset = MAGIC.length;
        int version = readInt(bytes, offset);
        offset += 4;
        if (version != FORMAT_VERSION) {
            throw new CorruptSnapshotException("Unsupported snapshot format version " + version);
        }
        int declaredSize = readInt(bytes, offset);
        offset += 4;
        if (declaredSize != expectedSize) {
            throw new CorruptSnapshotException(
                    "Snapshot declares " + declaredSize + " slots, expected " + expectedSize);
        }
        int payloadLength = readInt(bytes, offset);
        offset += 4;
        if (payloadLength < 0 || payloadLength > MAX_PAYLOAD_BYTES
                || bytes.length - offset != payloadLength) {
            throw new CorruptSnapshotException("Snapshot payload length does not match the envelope");
        }
        ItemStack[] decoded = new ItemStack[expectedSize];
        if (payloadLength == 0) return decoded;
        try (DataInputStream input = new DataInputStream(
                new ByteArrayInputStream(bytes, offset, payloadLength))) {
            for (int index = 0; index < expectedSize; index++) {
                int present = input.readUnsignedByte();
                if (present == 0) {
                    decoded[index] = null;
                } else if (present == 1) {
                    int length = input.readInt();
                    if (length < 1 || length > MAX_PAYLOAD_BYTES) {
                        throw new CorruptSnapshotException("Snapshot item length is invalid");
                    }
                    byte[] itemBytes = new byte[length];
                    input.readFully(itemBytes);
                    decoded[index] = ItemStack.deserializeBytes(itemBytes);
                } else {
                    throw new CorruptSnapshotException("Snapshot slot marker is invalid");
                }
            }
            if (input.available() != 0) {
                throw new CorruptSnapshotException("Snapshot payload contains trailing bytes");
            }
        } catch (IOException | RuntimeException exception) {
            if (exception instanceof CorruptSnapshotException corrupt) throw corrupt;
            throw new CorruptSnapshotException("Snapshot payload cannot be deserialized", exception);
        }
        return decoded;
    }

    private static int readInt(byte[] bytes, int offset) {
        return ((bytes[offset] & 0xff) << 24)
                | ((bytes[offset + 1] & 0xff) << 16)
                | ((bytes[offset + 2] & 0xff) << 8)
                | (bytes[offset + 3] & 0xff);
    }

    public static final class CorruptSnapshotException extends RuntimeException {
        public CorruptSnapshotException(String message) { super(message); }
        public CorruptSnapshotException(String message, Throwable cause) { super(message, cause); }
    }
}

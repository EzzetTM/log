package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Durable PREPARED/commit/abort/manual-review protocol for the 54-slot clan storage. */
class ClanStorageTransferProtocolTest {
    @TempDir Path temporaryDirectory;

    private static final Instant NOW = Instant.parse("2026-11-20T10:00:00Z");

    @Test
    void preparedEscrowCommitsExactAfterSnapshotAndIsIdempotent() {
        Path database = temporaryDirectory.resolve("escrow-commit.sqlite");
        Clan clan = clan(1, "EscrowClan", "ES1");
        UUID leader = clan.leader().orElseThrow().playerId();
        byte[] beforePlayer = bytes("before-player");
        byte[] afterPlayer = bytes("after-player");
        byte[] beforePage = bytes("before-page");
        byte[] afterPage = bytes("after-page");

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            // Seed a non-empty page snapshot so the before/after page hashes are meaningful.
            assertEquals(SqliteClanStore.ClanStorageContentSaveStatus.SAVED,
                    store.saveClanStoragePageContents(clan.id(), 1, leader, 0, beforePage, NOW).status());

            UUID operation = UUID.randomUUID();
            var prepared = store.prepareClanStorageTransfer(operation, clan.id(), 1, leader,
                    "DEPOSIT", "minecraft:stone", 32, 1,
                    beforePlayer, afterPlayer, beforePage, afterPage, NOW.plusSeconds(1));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.PREPARED, prepared.status());

            var duplicatePrepare = store.prepareClanStorageTransfer(operation, clan.id(), 1, leader,
                    "DEPOSIT", "minecraft:stone", 32, 1,
                    beforePlayer, afterPlayer, beforePage, afterPage, NOW.plusSeconds(2));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.DUPLICATE, duplicatePrepare.status());

            var committed = store.resolveClanStorageTransfer(operation, leader, afterPlayer, NOW.plusSeconds(3));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.COMMITTED, committed.status());

            var page = store.findClanStoragePage(clan.id(), 1).orElseThrow();
            assertEquals(2, page.revision());
            assertArrayEquals(afterPage, page.contents());
            assertEquals(1, store.findClanStorageMovements(clan.id(), 10).size());
            assertEquals("DEPOSIT", store.findClanStorageMovements(clan.id(), 10).get(0).movementType());

            var duplicateResolve = store.resolveClanStorageTransfer(operation, leader, afterPlayer, NOW.plusSeconds(4));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.DUPLICATE, duplicateResolve.status());
            assertEquals(2, store.findClanStoragePage(clan.id(), 1).orElseThrow().revision());
        }

        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(2, reopened.findClanStoragePage(clan.id(), 1).orElseThrow().revision());
            assertArrayEquals(afterPage, reopened.findClanStoragePage(clan.id(), 1).orElseThrow().contents());
        }
    }

    @Test
    void unchangedInventoryAbortsAndLeavesPageUntouched() {
        Path database = temporaryDirectory.resolve("escrow-abort.sqlite");
        Clan clan = clan(2, "AbortClan", "AB2");
        UUID leader = clan.leader().orElseThrow().playerId();
        byte[] beforePage = bytes("page-before");
        byte[] afterPage = bytes("page-after");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.saveClanStoragePageContents(clan.id(), 1, leader, 0, beforePage, NOW);
            UUID operation = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.PREPARED,
                    store.prepareClanStorageTransfer(operation, clan.id(), 1, leader,
                            "WITHDRAWAL", "minecraft:diamond", 1, 1,
                            bytes("p-before"), bytes("p-after"), beforePage, afterPage,
                            NOW.plusSeconds(1)).status());
            var aborted = store.resolveClanStorageTransfer(operation, leader, bytes("p-before"), NOW.plusSeconds(2));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.ABORTED, aborted.status());
            var page = store.findClanStoragePage(clan.id(), 1).orElseThrow();
            assertEquals(1, page.revision());
            assertArrayEquals(beforePage, page.contents());
            assertTrue(store.findClanStorageMovements(clan.id(), 10).isEmpty());
            assertTrue(store.pendingClanStorageTransfers(leader).isEmpty());
        }
    }

    @Test
    void unknownInventorySnapshotIsFrozenForManualReview() {
        Path database = temporaryDirectory.resolve("escrow-review.sqlite");
        Clan clan = clan(3, "ReviewClan", "RV3");
        UUID leader = clan.leader().orElseThrow().playerId();
        byte[] beforePage = bytes("review-before");
        byte[] afterPage = bytes("review-after");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.saveClanStoragePageContents(clan.id(), 1, leader, 0, beforePage, NOW);
            UUID operation = UUID.randomUUID();
            store.prepareClanStorageTransfer(operation, clan.id(), 1, leader,
                    "DEPOSIT", "minecraft:iron_ingot", 4, 1,
                    bytes("review-p-before"), bytes("review-p-after"), beforePage, afterPage,
                    NOW.plusSeconds(1));
            var review = store.resolveClanStorageTransfer(operation, leader, bytes("third-party-state"), NOW.plusSeconds(2));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.MANUAL_REVIEW, review.status());
            assertArrayEquals(beforePage, store.findClanStoragePage(clan.id(), 1).orElseThrow().contents());
            List<SqliteClanStore.ClanStorageTransferOperation> requiringReview =
                    store.clanStorageTransfersRequiringReview(10);
            assertEquals(1, requiringReview.size());
            assertEquals(operation, requiringReview.get(0).operationId());
            assertTrue(store.pendingClanStorageTransfers(leader).isEmpty());
        }
    }

    @Test
    void concurrentPageMutationCannotOverwriteNewerRevision() throws Exception {
        Path database = temporaryDirectory.resolve("escrow-race.sqlite");
        Clan clan = clan(4, "RaceClan", "RC4");
        UUID leader = clan.leader().orElseThrow().playerId();
        byte[] pageV1 = bytes("race-v1");
        byte[] pageV2 = bytes("race-v2");
        byte[] operationAfter = bytes("race-operation-after");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.saveClanStoragePageContents(clan.id(), 1, leader, 0, pageV1, NOW);
            UUID operation = UUID.randomUUID();
            store.prepareClanStorageTransfer(operation, clan.id(), 1, leader,
                    "DEPOSIT", "minecraft:gold_ingot", 8, 1,
                    bytes("race-player-before"), bytes("race-player-after"), pageV1, operationAfter,
                    NOW.plusSeconds(1));
            // Another writer replaces the page before this escrow resolves. The dedicated save
            // path intentionally refuses while a transfer is pending, so simulate the external
            // page mutation at SQL level to exercise the CAS guard.
            try (java.sql.Connection connection = java.sql.DriverManager.getConnection("jdbc:sqlite:" + database);
                 java.sql.PreparedStatement update = connection.prepareStatement(
                         "UPDATE clan_storage_pages SET contents = ?, revision = revision + 1 "
                                 + "WHERE clan_id = ? AND page_number = 1")) {
                update.setBytes(1, pageV2);
                update.setString(2, clan.id().toString());
                assertEquals(1, update.executeUpdate());
            }
            var review = store.resolveClanStorageTransfer(operation, leader,
                    bytes("race-player-after"), NOW.plusSeconds(3));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.MANUAL_REVIEW, review.status());
            var page = store.findClanStoragePage(clan.id(), 1).orElseThrow();
            assertEquals(2, page.revision());
            assertArrayEquals(pageV2, page.contents());
        }
    }

    @Test
    void pendingTransferSurvivesRestartAndResolvesFromAfterSnapshot() {
        Path database = temporaryDirectory.resolve("escrow-restart.sqlite");
        Clan clan = clan(5, "RestartClan", "RS5");
        UUID leader = clan.leader().orElseThrow().playerId();
        byte[] beforePage = bytes("restart-before");
        byte[] afterPage = bytes("restart-after");
        UUID operation = UUID.randomUUID();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.saveClanStoragePageContents(clan.id(), 1, leader, 0, beforePage, NOW);
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.PREPARED,
                    store.prepareClanStorageTransfer(operation, clan.id(), 1, leader,
                            "DEPOSIT", "minecraft:emerald", 2, 1,
                            bytes("restart-player-before"), bytes("restart-player-after"),
                            beforePage, afterPage, NOW.plusSeconds(1)).status());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(1, reopened.pendingClanStorageTransfers(leader).size());
            var recovered = reopened.resolveClanStorageTransfer(operation, leader,
                    bytes("restart-player-after"), NOW.plusSeconds(5));
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.COMMITTED, recovered.status());
            assertArrayEquals(afterPage, reopened.findClanStoragePage(clan.id(), 1).orElseThrow().contents());
        }
    }

    @Test
    void secondPrepareOnSamePageIsRejectedAsBusy() {
        Path database = temporaryDirectory.resolve("escrow-busy.sqlite");
        Clan clan = clan(6, "BusyClan", "BS6");
        UUID leader = clan.leader().orElseThrow().playerId();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            byte[] page = bytes("busy-page");
            store.saveClanStoragePageContents(clan.id(), 1, leader, 0, page, NOW);
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.PREPARED,
                    store.prepareClanStorageTransfer(UUID.randomUUID(), clan.id(), 1, leader,
                            "DEPOSIT", "minecraft:coal", 1, 1,
                            bytes("busy-p1"), bytes("busy-p2"), page, bytes("busy-page-2"),
                            NOW.plusSeconds(1)).status());
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.BUSY,
                    store.prepareClanStorageTransfer(UUID.randomUUID(), clan.id(), 1, leader,
                            "WITHDRAWAL", "minecraft:coal", 1, 1,
                            bytes("busy-p3"), bytes("busy-p4"), page, bytes("busy-page-3"),
                            NOW.plusSeconds(2)).status());
        }
    }

    private static Clan clan(int number, String name, String tag) {
        UUID clanId = new UUID(0, number);
        UUID leaderId = new UUID(1, number);
        return new Clan(clanId, name, tag, Instant.parse("2025-01-01T00:00:00Z"), 10,
                Map.of(leaderId, new ClanMember(leaderId, ClanRole.LEADER,
                        Instant.parse("2025-01-01T00:00:00Z"), null)), 0, null);
    }

    private static byte[] bytes(String value) {
        return value.getBytes(StandardCharsets.UTF_8);
    }
}

package com.skyworldclans.clan.filter;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTimeoutPreemptively;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ForbiddenExpressionValidatorTest {

    @Test
    void normalizesEveryApprovedDigitAndSymbolReplacement() {
        assertEquals(
                "oizeasgtbgsaie",
                ForbiddenExpressionNormalizer.normalize("0123456789$@!€"));

        assertBlocked("oizeasgtbgsaie", "0123456789$@!€");
        assertBlocked("0123456789$@!€", "oizeasgtbgsaie");
    }

    @Test
    void matchesEveryApprovedTransliterationVariantInBothDirections() {
        List<Transliteration> transliterations = List.of(
                new Transliteration("а", "a"),
                new Transliteration("б", "b"),
                new Transliteration("в", "v"),
                new Transliteration("г", "g"),
                new Transliteration("д", "d"),
                new Transliteration("е", "e"),
                new Transliteration("ё", "e"),
                new Transliteration("ё", "yo"),
                new Transliteration("ж", "zh"),
                new Transliteration("ж", "j"),
                new Transliteration("з", "z"),
                new Transliteration("и", "i"),
                new Transliteration("й", "y"),
                new Transliteration("й", "i"),
                new Transliteration("к", "k"),
                new Transliteration("л", "l"),
                new Transliteration("м", "m"),
                new Transliteration("н", "n"),
                new Transliteration("о", "o"),
                new Transliteration("п", "p"),
                new Transliteration("р", "r"),
                new Transliteration("с", "s"),
                new Transliteration("т", "t"),
                new Transliteration("у", "u"),
                new Transliteration("ф", "f"),
                new Transliteration("х", "kh"),
                new Transliteration("х", "x"),
                new Transliteration("ц", "ts"),
                new Transliteration("ц", "c"),
                new Transliteration("ч", "ch"),
                new Transliteration("ш", "sh"),
                new Transliteration("щ", "shch"),
                new Transliteration("щ", "sch"),
                new Transliteration("ы", "y"),
                new Transliteration("э", "e"),
                new Transliteration("э", "eh"),
                new Transliteration("ю", "yu"),
                new Transliteration("ю", "iu"),
                new Transliteration("я", "ya"),
                new Transliteration("я", "ia"));

        for (Transliteration transliteration : transliterations) {
            assertBlocked(transliteration.cyrillic(), transliteration.latin());
            assertBlocked(transliteration.latin(), transliteration.cyrillic());
        }
    }

    @Test
    void supportsMixedTransliterationVariantsWithoutExpandingTheirCombinations() {
        assertBlocked("жюя", "jiuia");
        assertBlocked("jiuia", "жюя");
        assertBlocked("щхц", "schxc");
    }

    @Test
    void removesWhitespacePunctuationAndZeroWidthFormattingCharacters() {
        assertBlocked("shch", "s h-c\u200Bh");
        assertBlocked("night", "n_i-g\u2060h.t");
    }

    @Test
    void appliesNfkcAndRootCaseFolding() {
        assertEquals("cafe", ForbiddenExpressionNormalizer.normalize("ＣＡＦＥ"));
        assertBlocked("cafe", "ＣＡＦＥ");
        assertBlocked("MiXeD", "mixed");
    }

    @Test
    void findsMatchesAtTheBeginningMiddleAndEnd() {
        assertBlocked("abc", "abcdef");
        assertBlocked("abc", "xabcx");
        assertBlocked("abc", "xyzabc");
    }

    @Test
    void findsMatchesInsideLongerWordsWithoutWordBoundaries() {
        assertBlocked("orbit", "myOrbitClan");
    }

    @Test
    void allowsTextThatDoesNotContainAnEquivalentForbiddenExpression() {
        assertEquals(
                ForbiddenExpressionStatus.ALLOWED,
                validator("nebula").check(ForbiddenExpressionField.NAME, "starlight").status());
    }

    @Test
    void checksNameTagAndSloganFields() {
        ForbiddenExpressionValidator validator = validator("clan");
        for (ForbiddenExpressionField field : ForbiddenExpressionField.values()) {
            ForbiddenExpressionResult result = validator.check(field, "my-clan-name");
            assertEquals(ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION, result.status());
            assertEquals(Optional.of(field), result.field());
        }
    }

    @Test
    void emptyListAllowsValidInputAndRequiresWarning() {
        ForbiddenExpressionValidator validator = new ForbiddenExpressionValidator(List.of());

        assertTrue(validator.isAvailable());
        assertTrue(validator.emptyListWarningRequired());
        assertTrue(validator.configurationError().isEmpty());
        assertEquals(
                ForbiddenExpressionStatus.ALLOWED,
                validator.check(ForbiddenExpressionField.NAME, "valid-clan").status());
    }

    @Test
    void nullEmptyAndFullyStrippedInputsAreInvalid() {
        ForbiddenExpressionValidator validator = validator("blocked");

        assertEquals(
                ForbiddenExpressionStatus.INVALID_INPUT,
                validator.check(ForbiddenExpressionField.NAME, null).status());
        assertEquals(
                ForbiddenExpressionStatus.INVALID_INPUT,
                validator.check(ForbiddenExpressionField.NAME, "").status());
        assertEquals(
                ForbiddenExpressionStatus.INVALID_INPUT,
                validator.check(ForbiddenExpressionField.NAME, " -_.\u200B ").status());
        assertEquals(
                ForbiddenExpressionStatus.INVALID_INPUT,
                validator.check(null, "valid").status());
        assertTrue(validator.check(null, "valid").field().isEmpty());
    }

    @Test
    void nullListNullEntryAndEmptyNormalizedEntryMakeFilterUnavailable() {
        ForbiddenExpressionValidator nullList = new ForbiddenExpressionValidator(null);
        assertUnavailable(nullList);

        ForbiddenExpressionValidator nullEntry =
                new ForbiddenExpressionValidator(Arrays.asList("valid", null));
        assertUnavailable(nullEntry);

        ForbiddenExpressionValidator emptyEntry = validator(" -_. ");
        assertUnavailable(emptyEntry);
    }

    @Test
    void reportsExpectedFalsePositivesFromApprovedAliasCollisions() {
        assertEquals(
                ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                validator("е").check(ForbiddenExpressionField.NAME, "э").status());
        assertEquals(
                ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                validator("и").check(ForbiddenExpressionField.NAME, "й").status());
    }

    @Test
    void mixedTransliterationMatchingHasBoundedRuntime() {
        String expression = "ж".repeat(80) + "q";
        String text = ("zh".repeat(80) + "x").repeat(3);
        ForbiddenExpressionValidator validator = validator(expression);

        assertTimeoutPreemptively(Duration.ofSeconds(2), () ->
                assertEquals(
                        ForbiddenExpressionStatus.ALLOWED,
                        validator.check(ForbiddenExpressionField.SLOGAN, text).status()));
    }

    @Test
    void removesRussianHardAndSoftSignsAsApproved() {
        assertEquals("ел", ForbiddenExpressionNormalizer.normalize("ъеьл"));
        assertBlocked("ел", "ъеьл");
    }

    private static void assertUnavailable(ForbiddenExpressionValidator validator) {
        assertFalse(validator.isAvailable());
        assertFalse(validator.emptyListWarningRequired());
        assertTrue(validator.configurationError().isPresent());
        assertEquals(
                ForbiddenExpressionStatus.FILTER_UNAVAILABLE,
                validator.check(ForbiddenExpressionField.NAME, "valid").status());
    }

    private static void assertBlocked(String expression, String input) {
        ForbiddenExpressionResult result = validator(expression)
                .check(ForbiddenExpressionField.NAME, input);
        assertEquals(ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION, result.status(),
                () -> "Expected [" + input + "] to match [" + expression + "]");
    }

    private static ForbiddenExpressionValidator validator(String expression) {
        return new ForbiddenExpressionValidator(List.of(expression));
    }

    private record Transliteration(String cyrillic, String latin) {
    }
}

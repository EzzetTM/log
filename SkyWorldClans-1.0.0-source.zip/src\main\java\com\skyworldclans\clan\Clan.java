package com.skyworldclans.clan;

import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;
import com.skyworldclans.clan.policy.ClanLevelPolicy;
import com.skyworldclans.clan.validation.ClanNameTagValidator;

import java.time.Instant;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public record Clan(
        UUID id,
        String name,
        String tag,
        Instant createdAt,
        int capacity,
        Map<UUID, ClanMember> members,
        long totalXp,
        String tagline) {

    public Clan {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(tag, "tag");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(members, "members");

        if (!ClanNameTagValidator.isValidName(name)) {
            throw new IllegalArgumentException("Invalid clan name");
        }
        if (!ClanNameTagValidator.isValidTag(tag)) {
            throw new IllegalArgumentException("Invalid clan tag");
        }
        if (!ClanCapacityPolicy.isValidCapacity(capacity)) {
            throw new IllegalArgumentException("Invalid clan capacity");
        }
        if (totalXp < 0) {
            throw new IllegalArgumentException("Clan XP cannot be negative");
        }

        members = Map.copyOf(members);
        if (members.isEmpty()) {
            throw new IllegalArgumentException("Clan must have at least one member");
        }
        if (members.size() > capacity) {
            throw new IllegalArgumentException("Member count exceeds clan capacity");
        }

        int leaderCount = 0;
        for (Map.Entry<UUID, ClanMember> entry : members.entrySet()) {
            ClanMember member = entry.getValue();
            if (!entry.getKey().equals(member.playerId())) {
                throw new IllegalArgumentException("Member map key must match playerId");
            }
            if (member.role() == ClanRole.LEADER) {
                leaderCount++;
                if (leaderCount > 1) {
                    throw new IllegalArgumentException("Clan cannot have multiple leaders");
                }
            }
            if (member.appointedByDeputyId() != null) {
                ClanMember appointer = members.get(member.appointedByDeputyId());
                if (appointer == null || appointer.role() != ClanRole.DEPUTY) {
                    throw new IllegalArgumentException(
                            "Moderator appointer must be a deputy in this clan");
                }
            }
        }
    }

    public Optional<ClanMember> member(UUID playerId) {
        return Optional.ofNullable(playerId == null ? null : members.get(playerId));
    }

    public Optional<ClanMember> leader() {
        return members.values().stream()
                .filter(member -> member.role() == ClanRole.LEADER)
                .findFirst();
    }

    public int memberCount() {
        return members.size();
    }

    public int level() {
        return ClanLevelPolicy.levelForXp(totalXp);
    }

    public Clan withTotalXp(long newTotalXp) {
        if (newTotalXp < totalXp) {
            throw new IllegalArgumentException("Clan XP cannot decrease");
        }
        return new Clan(id, name, tag, createdAt, capacity, members, newTotalXp, tagline);
    }

    public Clan withExpandedCapacity(int newCapacity) {
        if (!ClanCapacityPolicy.canExpandTo(capacity, newCapacity)) {
            throw new IllegalArgumentException("Capacity can only increase to the next valid step");
        }
        return new Clan(
                id,
                name,
                tag,
                createdAt,
                newCapacity,
                members,
                totalXp,
                tagline);
    }
}

package com.skyworldclans.clan.filter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Objects;

public final class ForbiddenExpressionConfiguration {
    public static final String FILE_NAME = "forbidden-expressions.txt";

    private static final String INITIAL_CONTENT = """
            # Forbidden expressions are checked in clan names, tags, and slogans.
            # Add one expression per line. Blank lines and lines beginning with # are ignored.
            # Entries are plain text, not regular expressions.
            """;

    private ForbiddenExpressionConfiguration() {
    }

    public static Path prepare(Path pluginDataFolder) throws IOException {
        Objects.requireNonNull(pluginDataFolder, "pluginDataFolder");
        Files.createDirectories(pluginDataFolder);

        Path configurationFile = pluginDataFolder.resolve(FILE_NAME);
        try {
            Files.writeString(
                    configurationFile,
                    INITIAL_CONTENT,
                    StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE_NEW,
                    StandardOpenOption.WRITE);
        } catch (FileAlreadyExistsException ignored) {
            // Preserve a file created by the owner or another startup process.
        }
        return configurationFile;
    }
}

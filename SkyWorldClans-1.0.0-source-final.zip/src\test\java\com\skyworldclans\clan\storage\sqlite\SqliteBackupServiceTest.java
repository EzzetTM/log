package com.skyworldclans.clan.storage.sqlite;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SqliteBackupServiceTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void createsBackupAndRetainsOnlyThirtyManagedFiles() throws Exception {
        Path database = temporaryDirectory.resolve("source.sqlite");
        Path backupDirectory = temporaryDirectory.resolve("backups");
        Files.createDirectories(backupDirectory);
        for (int index = 0; index < 31; index++) {
            Files.writeString(backupDirectory.resolve(
                    "skyworldclans-20250101-000000-000-" + index + ".sqlite"), "old");
        }
        Path unrelated = backupDirectory.resolve("do-not-delete.txt");
        Files.writeString(unrelated, "keep");

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            SqliteBackupService service = new SqliteBackupService(
                    store,
                    backupDirectory,
                    Clock.fixed(Instant.parse("2025-02-01T00:00:00Z"), ZoneOffset.UTC));
            SqliteBackupService.BackupResult result = service.createBackup();

            assertTrue(Files.isRegularFile(result.backup()));
            var latest = service.latestBackup().orElseThrow();
            assertEquals(result.backup(), latest.path());
            assertEquals(Instant.parse("2025-02-01T00:00:00Z"), latest.createdAt());
            assertEquals(2, result.removedOlderBackups().size());
            assertTrue(result.warnings().isEmpty());
            assertTrue(Files.exists(unrelated));
        }

        try (Stream<Path> files = Files.list(backupDirectory)) {
            List<Path> managed = files
                    .filter(path -> path.getFileName().toString().startsWith("skyworldclans-"))
                    .toList();
            assertEquals(30, managed.size());
        }
    }
}

package com.skyworldclans.clan.application.purchase;

public enum CapacityPurchaseState {
    PREPARED,
    CALLING,
    DEBIT_CONFIRMED,
    COMMITTED,
    FAILED_NO_EFFECT,
    UNKNOWN,
    COMPENSATION_PENDING,
    COMPENSATION_CALLING,
    COMPENSATION_UNKNOWN,
    COMPENSATED,
    COMPENSATION_FAILED
}

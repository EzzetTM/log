package com.skyworldclans.clan.reward;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.integration.EconomyOperations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanRewardCoordinatorTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-15T12:00:00Z");

    @Test
    void personalPayoutMovesMoneyOnceAndIsJournalled() {
        UUID leader = id(1), member = id(2);
        Clan clan = clan(leader, member);
        FakeEconomy economy = new FakeEconomy();
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reward-personal.sqlite"))) {
            store.registerIfAvailable(clan);
            ClanRewardCoordinator coordinator = new ClanRewardCoordinator(store, store, economy,
                    Clock.fixed(NOW, ZoneOffset.UTC), UUID::randomUUID);
            var result = coordinator.personalPayout(leader, member, new BigDecimal("5000"));
            assertEquals(ClanRewardCoordinator.Status.SUCCESS, result.status());
            assertEquals(List.of("withdraw:" + leader + ":5000.0", "deposit:" + member + ":5000.0"),
                    economy.calls);
            var history = coordinator.history(clan.id(), 10);
            assertEquals(1, history.size());
            assertEquals("COMPLETED", history.get(0).state());
            assertEquals("PERSONAL", history.get(0).source());
            // A repeated call is a new operation: the journal never coalesces distinct payouts.
            assertEquals(ClanRewardCoordinator.Status.SUCCESS,
                    coordinator.personalPayout(leader, member, new BigDecimal("5000")).status());
            assertEquals(2, coordinator.history(clan.id(), 10).size());
        }
    }

    @Test
    void unknownDebitIsFrozenAndNeverReplayed() {
        UUID leader = id(3), member = id(4);
        Clan clan = clan(leader, member);
        FakeEconomy economy = new FakeEconomy();
        economy.debitStatus = EconomyOperations.Status.UNKNOWN;
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reward-unknown.sqlite"))) {
            store.registerIfAvailable(clan);
            ClanRewardCoordinator coordinator = new ClanRewardCoordinator(store, store, economy,
                    Clock.fixed(NOW, ZoneOffset.UTC), UUID::randomUUID);
            var result = coordinator.personalPayout(leader, member, new BigDecimal("100"));
            assertEquals(ClanRewardCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED, result.status());
            assertEquals("MANUAL_REVIEW", result.operation().state());
            assertEquals(0, economy.deposits());
            assertTrue(coordinator.recoverAfterRestart().isEmpty(),
                    "a frozen operation is terminal and must not be re-processed");
            assertEquals(1, economy.calls.size());
        }
    }

    @Test
    void bankRewardDebitsTheClanBankAndRespectsMembershipAgeAndLimits() {
        UUID leader = id(5), deputy = id(6), veteran = id(7), newcomer = id(8);
        Clan clan = clan(leader, deputy, veteran, newcomer, NOW);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reward-bank.sqlite"))) {
            store.registerIfAvailable(clan);
            store.recordClanBankMovement(UUID.randomUUID(), "seed", clan.id(), leader, "DEPOSIT",
                    new BigDecimal("500000"), "seed", null, NOW);
            FakeEconomy economy = new FakeEconomy();
            ClanRewardCoordinator coordinator = new ClanRewardCoordinator(store, store, economy,
                    Clock.fixed(NOW, ZoneOffset.UTC), UUID::randomUUID);

            assertEquals(ClanRewardCoordinator.Status.RECIPIENT_MEMBERSHIP_TOO_NEW,
                    coordinator.bankReward(leader, newcomer, new BigDecimal("1000")).status());

            assertEquals(ClanRewardCoordinator.Status.SUCCESS,
                    coordinator.bankReward(leader, veteran, new BigDecimal("1000")).status());
            assertEquals(0, store.clanBankBalance(clan.id()).compareTo(new BigDecimal("499000")));

            // A deputy is limited to 100 000 and to three ordinary rewards per day.
            assertEquals(ClanRewardCoordinator.Status.DEPUTY_AMOUNT_LIMIT,
                    coordinator.bankReward(deputy, veteran, new BigDecimal("100001")).status());
            for (int index = 0; index < 3; index++) {
                assertEquals(ClanRewardCoordinator.Status.SUCCESS,
                        coordinator.bankReward(deputy, veteran, new BigDecimal("100")).status());
            }
            assertEquals(ClanRewardCoordinator.Status.DEPUTY_DAILY_LIMIT,
                    coordinator.bankReward(deputy, veteran, new BigDecimal("100")).status());

            // Insufficient bank funds are refused before any provider call.
            assertEquals(ClanRewardCoordinator.Status.INSUFFICIENT_BANK_FUNDS,
                    coordinator.bankReward(leader, veteran, new BigDecimal("999999999")).status());
        }
    }

    @Test
    void interruptedRewardIsFrozenOnRestart() {
        UUID leader = id(9), member = id(10);
        Clan clan = clan(leader, member);
        UUID operationId = UUID.randomUUID();
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reward-restart.sqlite"))) {
            store.registerIfAvailable(clan);
            store.prepareClanReward(operationId, "reward-9", clan.id(), leader, member, "PERSONAL",
                    new BigDecimal("50"), "test", NOW);
            store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.PREPARED,
                    SqliteClanStore.ClanRewardState.DEBIT_CALLING, leader, "call", NOW.plusSeconds(1));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(temporaryDirectory.resolve("reward-restart.sqlite"))) {
            var recovered = reopened.recoverClanRewardsAfterRestart(NOW.plusSeconds(60));
            assertEquals(1, recovered.size());
            assertEquals("MANUAL_REVIEW", recovered.get(0).state());
            assertTrue(reopened.recoverClanRewardsAfterRestart(NOW.plusSeconds(61)).isEmpty());
        }
    }

    private static Clan clan(UUID leader, UUID member) {
        return new Clan(new UUID(0, 500), "RewardClan", "RW500", NOW.minusSeconds(86_400L * 30), 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, NOW.minusSeconds(86_400L * 30), null),
                        member, new ClanMember(member, ClanRole.MEMBER, NOW.minusSeconds(86_400L * 30), null)),
                0, null);
    }

    private static Clan clan(UUID leader, UUID deputy, UUID veteran, UUID newcomer, Instant now) {
        return new Clan(new UUID(0, 501), "RewardBank", "RB501", now.minusSeconds(86_400L * 60), 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now.minusSeconds(86_400L * 60), null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now.minusSeconds(86_400L * 60), null),
                        veteran, new ClanMember(veteran, ClanRole.MEMBER, now.minusSeconds(86_400L * 30), null),
                        newcomer, new ClanMember(newcomer, ClanRole.MEMBER, now.minusSeconds(86_400L * 2), null)),
                0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }

    private static final class FakeEconomy implements EconomyOperations {
        private final List<String> calls = new ArrayList<>();
        private Status debitStatus = Status.SUCCESS;
        private Status creditStatus = Status.SUCCESS;

        @Override public BalanceResult balance(UUID playerId) {
            return new BalanceResult(Status.SUCCESS, 1_000_000, null);
        }
        @Override public OperationResult withdraw(UUID playerId, double amount) {
            calls.add("withdraw:" + playerId + ":" + amount);
            return new OperationResult(debitStatus, "fake");
        }
        @Override public OperationResult deposit(UUID playerId, double amount) {
            calls.add("deposit:" + playerId + ":" + amount);
            return new OperationResult(creditStatus, "fake");
        }
        long deposits() { return calls.stream().filter(call -> call.startsWith("deposit:")).count(); }
    }
}
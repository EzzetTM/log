package com.skyworldclans.clan.home;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Clan home points. Owner decision #2 (preliminary) allows at most two points per clan: the first
 * is free, the second is bought from the clan bank for the approved price of home point #2.
 * Teleport access is granted only after a successful WorldGuard {@code ENTRY} check in the Bukkit
 * layer (owner decision #3).
 */
public final class ClanHomeService {
    public static final String DEFAULT_HOME_NAME = "Основная";
    public static final String SECOND_HOME_NAME = "Вторая";
    public static final int MAX_HOME_POINTS = SqliteClanStore.MAX_HOME_POINTS;

    private final ClanCatalog catalog;
    private final SqliteClanStore store;

    public ClanHomeService(ClanCatalog catalog, SqliteClanStore store) {
        this.catalog = Objects.requireNonNull(catalog, "catalog");
        this.store = Objects.requireNonNull(store, "store");
    }

    public Result setHome(UUID actorId, int slot, UUID worldId, double x, double y, double z,
            float yaw, float pitch, Instant now) {
        try {
            Clan clan = catalog.findByPlayerId(actorId).orElse(null);
            if (clan == null) return new Result(Status.NOT_IN_CLAN, null, null);
            if (!canManage(clan.member(actorId).orElse(null))) return new Result(Status.NOT_AUTHORIZED, clan, null);
            SqliteClanStore.ClanHomeResult result = store.setClanHomePoint(clan.id(), actorId, slot,
                    slot == 1 ? DEFAULT_HOME_NAME : SECOND_HOME_NAME, worldId, x, y, z, yaw, pitch, now);
            return new Result(map(result.status()), clan, result.point());
        } catch (RuntimeException exception) {
            return new Result(Status.STORAGE_ERROR, null, null);
        }
    }

    public Result setHome(UUID actorId, UUID worldId, double x, double y, double z,
            float yaw, float pitch, Instant now) {
        return setHome(actorId, 1, worldId, x, y, z, yaw, pitch, now);
    }

    /** Buys the second point slot. Only the leader may pay from the clan bank. */
    public Result purchaseSecondHome(UUID actorId, Instant now) {
        try {
            Clan clan = catalog.findByPlayerId(actorId).orElse(null);
            if (clan == null) return new Result(Status.NOT_IN_CLAN, null, null);
            ClanMember member = clan.member(actorId).orElse(null);
            if (member == null) return new Result(Status.NOT_IN_CLAN, clan, null);
            if (member.role() != ClanRole.LEADER) return new Result(Status.LEADER_ONLY, clan, null);
            SqliteClanStore.ClanHomeResult result = store.purchaseSecondHomePoint(clan.id(), actorId, now);
            return new Result(map(result.status()), clan, result.point());
        } catch (RuntimeException exception) {
            return new Result(Status.STORAGE_ERROR, null, null);
        }
    }

    public Result renameHome(UUID actorId, int slot, String newName, Instant now) {
        try {
            Clan clan = catalog.findByPlayerId(actorId).orElse(null);
            if (clan == null) return new Result(Status.NOT_IN_CLAN, null, null);
            if (!canManage(clan.member(actorId).orElse(null))) return new Result(Status.NOT_AUTHORIZED, clan, null);
            SqliteClanStore.ClanHomeResult result = store.renameClanHomePoint(clan.id(), actorId, slot, newName, now);
            return new Result(map(result.status()), clan, result.point());
        } catch (RuntimeException exception) {
            return new Result(Status.STORAGE_ERROR, null, null);
        }
    }

    public Result renameHome(UUID actorId, String newName, Instant now) {
        return renameHome(actorId, 1, newName, now);
    }

    public Result deleteHome(UUID actorId, int slot, Instant now) {
        try {
            Clan clan = catalog.findByPlayerId(actorId).orElse(null);
            if (clan == null) return new Result(Status.NOT_IN_CLAN, null, null);
            ClanMember member = clan.member(actorId).orElse(null);
            if (member == null || member.role() != ClanRole.LEADER) return new Result(Status.LEADER_ONLY, clan, null);
            SqliteClanStore.ClanHomeResult result = store.deleteClanHomePoint(clan.id(), actorId, slot, now);
            return new Result(map(result.status()), clan, result.point());
        } catch (RuntimeException exception) {
            return new Result(Status.STORAGE_ERROR, null, null);
        }
    }

    public Result deleteHome(UUID actorId, Instant now) {
        return deleteHome(actorId, 1, now);
    }

    public Result homeFor(UUID playerId, int slot) {
        try {
            Clan clan = catalog.findByPlayerId(playerId).orElse(null);
            if (clan == null) return new Result(Status.NOT_IN_CLAN, null, null);
            Optional<SqliteClanStore.ClanHomePoint> point = store.findClanHomePoint(clan.id(), slot);
            return point.map(home -> new Result(Status.READY, clan, home))
                    .orElseGet(() -> new Result(Status.HOME_NOT_SET, clan, null));
        } catch (RuntimeException exception) {
            return new Result(Status.STORAGE_ERROR, null, null);
        }
    }

    public Result homeFor(UUID playerId) {
        return homeFor(playerId, 1);
    }

    /** All points the clan currently has, ordered by slot. */
    public List<SqliteClanStore.ClanHomePoint> pointsFor(UUID playerId) {
        Clan clan = catalog.findByPlayerId(playerId).orElse(null);
        return clan == null ? List.of() : store.findClanHomePoints(clan.id());
    }

    public boolean secondSlotOwned(UUID playerId) {
        Clan clan = catalog.findByPlayerId(playerId).orElse(null);
        return clan != null && store.homeSlotOwned(clan.id(), 2);
    }

    private static boolean canManage(ClanMember member) {
        return member != null && (member.role() == ClanRole.LEADER || member.role() == ClanRole.DEPUTY);
    }

    private static Status map(SqliteClanStore.ClanHomeStatus status) {
        return switch (status) {
            case SAVED -> Status.SAVED;
            case RENAMED -> Status.RENAMED;
            case DELETED -> Status.DELETED;
            case PURCHASED -> Status.PURCHASED;
            case ALREADY_PURCHASED -> Status.ALREADY_PURCHASED;
            case SLOT_NOT_PURCHASED -> Status.SLOT_NOT_PURCHASED;
            case INSUFFICIENT_BANK_FUNDS -> Status.INSUFFICIENT_BANK_FUNDS;
            case CLAN_NOT_FOUND -> Status.CLAN_NOT_FOUND;
            case HOME_NOT_SET -> Status.HOME_NOT_SET;
            case INVALID_INPUT -> Status.INVALID_INPUT;
            case NOT_AUTHORIZED -> Status.NOT_AUTHORIZED;
            case LEADER_ONLY -> Status.LEADER_ONLY;
        };
    }

    public enum Status {
        READY, SAVED, RENAMED, DELETED, PURCHASED, ALREADY_PURCHASED, SLOT_NOT_PURCHASED,
        INSUFFICIENT_BANK_FUNDS, NOT_IN_CLAN, NOT_AUTHORIZED, LEADER_ONLY,
        CLAN_NOT_FOUND, HOME_NOT_SET, INVALID_INPUT, STORAGE_ERROR
    }

    public record Result(Status status, Clan clan, SqliteClanStore.ClanHomePoint point) { }
}
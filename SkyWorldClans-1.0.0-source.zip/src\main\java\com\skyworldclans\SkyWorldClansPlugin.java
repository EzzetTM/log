package com.skyworldclans;

import com.skyworldclans.admin.ClanAdministrationService;
import com.skyworldclans.clan.quest.ClanQuestListener;
import com.skyworldclans.clan.quest.ClanQuestService;
import com.skyworldclans.clan.tournament.ClanTournamentService;
import com.skyworldclans.gui.ClanAdminGui;
import com.skyworldclans.gui.ClanStorageGui;
import com.skyworldclans.command.ClanCommand;
import com.skyworldclans.command.ClanChatCommand;
import com.skyworldclans.clan.moderation.ClanModerationService;
import com.skyworldclans.command.ClanModerationCommand;
import com.skyworldclans.clan.chat.ClanChatService;
import com.skyworldclans.integration.flectone.FlectonePulseBridge;
import com.skyworldclans.clan.filter.ForbiddenExpressionConfiguration;
import com.skyworldclans.clan.filter.ForbiddenExpressionFilter;
import com.skyworldclans.clan.filter.Utf8FileForbiddenExpressionSource;
import com.skyworldclans.clan.service.ClanService;
import com.skyworldclans.clan.service.ClanMembershipService;
import com.skyworldclans.clan.request.ClanRequestService;
import com.skyworldclans.clan.xp.ClanXpService;
import com.skyworldclans.clan.election.ClanElectionService;
import com.skyworldclans.clan.bank.ClanBankService;
import com.skyworldclans.clan.bank.ClanBankTransferCoordinator;
import com.skyworldclans.combat.CombatLogService;
import com.skyworldclans.clan.home.ClanHomeService;
import com.skyworldclans.clan.war.ClanWarService;
import com.skyworldclans.clan.war.ClanWarListener;
import com.skyworldclans.clan.reward.ClanRewardCoordinator;
import com.skyworldclans.clan.storage.ClanStorageService;
import com.skyworldclans.admin.ClanAdministrationService;
import com.skyworldclans.gui.ClanAdminGui;
import com.skyworldclans.gui.ClanMainGui;
import com.skyworldclans.combat.CombatLogListener;
import com.skyworldclans.integration.worldguard.WorldGuardRegionAccess;
import com.skyworldclans.clan.storage.StorageException;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.clan.storage.sqlite.SqliteBackupService;
import com.skyworldclans.integration.EconomyOperations;
import com.skyworldclans.clan.ClanFactory;
import com.skyworldclans.clan.application.CreateClanUseCase;
import com.skyworldclans.clan.application.creation.ClanCreationCoordinator;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.io.IOException;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public class SkyWorldClansPlugin extends JavaPlugin implements Listener {
    private static final long BACKUP_INTERVAL_HOURS = 6L;

    private ClanStorageRuntime clanRuntime;
    private volatile SqliteBackupService backupService;
    private volatile EconomyOperations vaultEconomyBridge;
    private volatile ClanCreationCoordinator clanCreationCoordinator;
    private ScheduledExecutorService backupExecutor;
    private java.util.concurrent.ExecutorService bankPersistenceExecutor;
    private volatile ClanBankTransferCoordinator clanBankTransferCoordinator;
    private volatile CombatLogService combatLogService;
    private volatile WorldGuardRegionAccess worldGuardRegionAccess;
    private volatile ClanHomeService clanHomeService;
    private volatile ClanStorageService clanStorageService;
    private volatile ClanStorageGui clanStorageGui;
    private volatile ClanMainGui clanMainGui;
    private volatile ClanWarService clanWarService;
    private volatile ClanWarListener clanWarListener;
    private volatile ClanModerationService clanModerationService;
    private volatile ClanRewardCoordinator clanRewardCoordinator;
    private volatile ClanAdministrationService clanAdministrationService;
    private volatile ClanAdminGui clanAdminGui;
    private volatile ClanQuestService clanQuestService;
    private volatile ClanQuestListener clanQuestListener;
    private volatile ClanTournamentService clanTournamentService;
    private volatile FlectonePulseBridge flectonePulseBridge;
    private volatile ClanChatService clanChatService;
    private ForbiddenExpressionFilter forbiddenExpressionFilter =
            ForbiddenExpressionFilter.unavailable(
                    "Forbidden-expression filter initialization has not completed", null);

    @Override
    public void onEnable() {
        initializeForbiddenExpressionFilter();
        try {
            clanRuntime = ClanStorageRuntime.open(
                    getDataFolder().toPath().resolve("data").resolve("skyworldclans.sqlite"));
            clanHomeService = new ClanHomeService(getClanStore(), getClanStore());
            clanStorageService = new ClanStorageService(getClanStore(), getClanStore());
            clanStorageGui = new ClanStorageGui(this, clanStorageService, getClanStore());
            clanMainGui = new ClanMainGui(this);
            clanWarService = new ClanWarService(getClanStore(), getClanStore(),
                    getClanXpService(), java.time.Clock.systemUTC());
            clanWarListener = new ClanWarListener(this, clanWarService);
            clanModerationService = new ClanModerationService(getClanStore(), getClanStore(),
                    java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
            clanRewardCoordinator = new ClanRewardCoordinator(getClanStore(), getClanStore(),
                    vaultEconomyBridge, java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
            clanAdministrationService = new ClanAdministrationService(getClanStore(), getClanStore(),
                    java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
            clanAdminGui = new ClanAdminGui(this, clanAdministrationService);
            clanQuestService = new ClanQuestService(getClanStore(), getClanStore(), getClanXpService(),
                    java.time.Clock.systemUTC());
            clanQuestListener = new ClanQuestListener(this, clanQuestService);
            clanTournamentService = new ClanTournamentService(getClanStore(), getClanStore(),
                    java.time.Clock.systemUTC(), java.util.UUID::randomUUID, playerId -> {
                        org.bukkit.entity.Player online = getServer().getPlayer(playerId);
                        return online != null && online.hasPermission("skyworldclans.tournament.vote");
                    });
            if (getServer().getPluginManager().isPluginEnabled("FlectonePulse")) {
                try {
                    flectonePulseBridge = FlectonePulseBridge.connectIfReady();
                    if (flectonePulseBridge == null) {
                        getLogger().warning("FlectonePulse is enabled but its API is not ready; /cc will remain disabled.");
                    } else {
                        getLogger().info("FlectonePulse API 1.15.x clan chat bridge connected.");
                    }
                } catch (RuntimeException | LinkageError integrationFailure) {
                    flectonePulseBridge = null;
                    getLogger().log(Level.SEVERE, "FlectonePulse is enabled but its API could not be initialized; /cc will remain disabled.", integrationFailure);
                }
            } else {
                flectonePulseBridge = null;
                getLogger().warning("FlectonePulse is not enabled; /cc will remain disabled.");
            }
            clanChatService = new ClanChatService(getClanStore(), flectonePulseBridge, this::isChatMuted);
            combatLogService = new CombatLogService(getClanStore());
            if (getServer().getPluginManager().isPluginEnabled("WorldGuard")) {
                try {
                    worldGuardRegionAccess = new WorldGuardRegionAccess();
                    getLogger().info("WorldGuard region checks enabled for clan home points.");
                } catch (LinkageError linkageError) {
                    worldGuardRegionAccess = null;
                    getLogger().log(Level.SEVERE, "WorldGuard is enabled but its API could not be loaded; clan home changes and teleports are disabled.", linkageError);
                }
            } else {
                worldGuardRegionAccess = null;
                getLogger().warning("WorldGuard is not enabled; clan home changes and teleports will fail closed.");
            }
            int interruptedCombatTags = combatLogService.recoverAfterRestart(java.time.Instant.now());
            if (interruptedCombatTags > 0) {
                getLogger().warning("Marked " + interruptedCombatTags
                        + " interrupted combat tag(s) for review; no restart-related logout penalties were applied.");
            }
            getClanStore().reconcileAllMembershipAchievements(java.time.Instant.now());
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Could not initialize SQLite clan storage.", exception);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        vaultEconomyBridge = discoverVaultEconomyBridge();
        clanCreationCoordinator = new ClanCreationCoordinator(
                new CreateClanUseCase(new ClanFactory(), getClanService(), forbiddenExpressionFilter,
                        java.util.UUID::randomUUID, java.time.Clock.systemUTC()),
                getClanStore(), java.util.Optional.ofNullable(vaultEconomyBridge),
                java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
        bankPersistenceExecutor = Executors.newSingleThreadExecutor(task -> {
            Thread thread = new Thread(task, "SkyWorldClans-BankPersistence");
            thread.setDaemon(true);
            return thread;
        });
        clanBankTransferCoordinator = new ClanBankTransferCoordinator(
                getClanStore(), getClanStore(), vaultEconomyBridge, bankPersistenceExecutor,
                task -> getServer().getScheduler().runTask(this, task),
                java.time.Clock.systemUTC(), java.util.UUID::randomUUID);
        try {
            for (ClanCreationCoordinator.Result recovery : clanCreationCoordinator.recoverAfterRestart()) {
                getLogger().warning("Clan creation recovery: " + recovery.status()
                        + ", operation " + recovery.operationId().map(java.util.UUID::toString).orElse("unknown"));
            }
            for (SqliteClanStore.ClanBankOperationResult recovery
                    : getClanStore().recoverClanBankOperationsAfterRestart(java.time.Instant.now())) {
                if (recovery.operation() != null && recovery.operation().state()
                        == SqliteClanStore.ClanBankOperationState.UNKNOWN) {
                    getLogger().severe("Clan bank operation requires manual reconciliation: "
                            + recovery.operation().operationId());
                } else {
                    getLogger().warning("Clan bank operation recovery: " + recovery.status()
                            + ", operation " + (recovery.operation() == null ? "unknown" : recovery.operation().operationId()));
                }
            }
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Could not safely recover pending clan creation or bank operations; disabling plugin.", exception);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        if (vaultEconomyBridge == null) {
            getLogger().warning("Vault Economy provider is unavailable; paid ordinary-currency operations will remain disabled.");
        } else {
            getLogger().info("Vault Economy provider detected.");
        }
        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(
                new CombatLogListener(getCombatLogService(), java.time.Clock.systemUTC(), getLogger()), this);
        getServer().getPluginManager().registerEvents(clanStorageGui, this);
        getServer().getPluginManager().registerEvents(clanMainGui, this);
        getServer().getPluginManager().registerEvents(clanAdminGui, this);
        getServer().getPluginManager().registerEvents(clanQuestListener, this);
        getServer().getPluginManager().registerEvents(clanWarListener, this);
        getServer().getScheduler().runTaskTimer(this, this::recordOnlinePlayerActivity, 1L, 20L * 60L * 5L);
        backupService = new SqliteBackupService(
                getClanStore(), getDataFolder().toPath().resolve("backups"));
        backupExecutor = Executors.newSingleThreadScheduledExecutor(task -> {
            Thread thread = new Thread(task, "SkyWorldClans-Background");
            thread.setDaemon(true);
            return thread;
        });
        backupExecutor.scheduleAtFixedRate(
                this::createScheduledBackup,
                BACKUP_INTERVAL_HOURS,
                BACKUP_INTERVAL_HOURS,
                TimeUnit.HOURS);
        backupExecutor.scheduleAtFixedRate(
                this::processDueElections, 1L, 1L, TimeUnit.MINUTES);
        backupExecutor.scheduleAtFixedRate(
                this::processDueBankWithdrawalRequests, 1L, 1L, TimeUnit.MINUTES);
        backupExecutor.scheduleAtFixedRate(
                this::processCombatLogExpiry, 1L, 1L, TimeUnit.SECONDS);
        backupExecutor.scheduleAtFixedRate(
                this::processDueWars, 15L, 30L, TimeUnit.SECONDS);
        backupExecutor.scheduleAtFixedRate(
                this::processDueWarningCases, 30L, 60L, TimeUnit.MINUTES);
        backupExecutor.scheduleAtFixedRate(
                this::rotateQuests, 60L, 300L, TimeUnit.SECONDS);
        backupExecutor.scheduleAtFixedRate(
                this::expireRewardRequests, 120L, 120L, TimeUnit.SECONDS);
        recoverRewardOperations();
        if (getCommand("clan") == null) {
            getLogger().severe("Required /clan command is missing from plugin.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        ClanCommand clanCommand = new ClanCommand(this);
        getCommand("clan").setExecutor(clanCommand);
        getCommand("clan").setTabCompleter(clanCommand);
        if (getCommand("cc") == null) {
            getLogger().severe("Required /cc command is missing from plugin.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getCommand("cc").setExecutor(new ClanChatCommand(this));
        registerModerationCommand("ccmute", ClanModerationCommand.Mode.MUTE);
        registerModerationCommand("ccunmute", ClanModerationCommand.Mode.UNMUTE);
        registerModerationCommand("cwarn", ClanModerationCommand.Mode.WARN);
        registerModerationCommand("cunwarn", ClanModerationCommand.Mode.UNWARN);
        getLogger().info("SkyWorldClans plugin enabled (v1.0.0-SNAPSHOT)");
    }

    @Override
    public void onDisable() {
        if (clanStorageGui != null) {
            try {
                clanStorageGui.shutdown();
            } catch (RuntimeException exception) {
                getLogger().log(Level.SEVERE, "Could not recover clan storage GUI operations during shutdown.", exception);
            }
            clanStorageGui = null;
        }
        if (bankPersistenceExecutor != null) {
            bankPersistenceExecutor.shutdown();
            try {
                if (!bankPersistenceExecutor.awaitTermination(30L, TimeUnit.SECONDS)) {
                    bankPersistenceExecutor.shutdownNow();
                }
            } catch (InterruptedException exception) {
                bankPersistenceExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
            bankPersistenceExecutor = null;
        }
        clanBankTransferCoordinator = null;
        combatLogService = null;
        worldGuardRegionAccess = null;
        clanHomeService = null;
        clanStorageService = null;
        flectonePulseBridge = null;
        clanChatService = null;
        if (backupExecutor != null) {
            backupExecutor.shutdown();
            try {
                if (!backupExecutor.awaitTermination(5L, TimeUnit.SECONDS)) {
                    backupExecutor.shutdownNow();
                }
            } catch (InterruptedException exception) {
                backupExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
            backupExecutor = null;
        }
        if (backupService != null) {
            try {
                SqliteBackupService.BackupResult result = backupService.createBackup();
                getLogger().info("Shutdown backup created: " + result.backup());
                result.warnings().forEach(getLogger()::warning);
            } catch (RuntimeException exception) {
                getLogger().log(Level.SEVERE, "Could not create shutdown SQLite backup.", exception);
            }
            backupService = null;
        }
        vaultEconomyBridge = null;
        clanCreationCoordinator = null;
        if (clanRuntime != null) {
            try {
                clanRuntime.close();
            } catch (StorageException exception) {
                getLogger().log(Level.SEVERE, "Could not close SQLite clan storage.", exception);
            }
            clanRuntime = null;
        }
        getLogger().info("SkyWorldClans plugin disabled");
    }

    public SqliteClanStore getClanStore() {
        if (clanRuntime == null) {
            throw new IllegalStateException("SQLite clan storage is not initialized");
        }
        return clanRuntime.store();
    }

    public ClanService getClanService() {
        if (clanRuntime == null) {
            throw new IllegalStateException("Clan service is not initialized");
        }
        return clanRuntime.service();
    }

    public ClanMembershipService getClanMembershipService() {
        if (clanRuntime == null) {
            throw new IllegalStateException("Clan membership service is not initialized");
        }
        return clanRuntime.membershipService();
    }

    public ClanXpService getClanXpService() {
        if (clanRuntime == null) {
            throw new IllegalStateException("Clan XP service is not initialized");
        }
        return clanRuntime.xpService();
    }

    private EconomyOperations discoverVaultEconomyBridge() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return null;
        try {
            // Vault is an optional `provided` dependency: the adapter is only loaded when the
            // plugin is actually present, and a missing/older API fails closed instead of guessing.
            java.util.Optional<com.skyworldclans.integration.vault.VaultEconomyBridge> discovered =
                    com.skyworldclans.integration.vault.VaultEconomyBridge.discover(
                            getServer(), getServer().getPluginManager());
            return discovered.orElse(null);
        } catch (RuntimeException | LinkageError exception) {
            getLogger().log(Level.WARNING, "Vault is present but its Economy provider could not be loaded.", exception);
            return null;
        }
    }

    public java.util.Optional<EconomyOperations> getVaultEconomyBridge() {
        return java.util.Optional.ofNullable(vaultEconomyBridge);
    }

    public ClanCreationCoordinator getClanCreationCoordinator() {
        if (clanCreationCoordinator == null) {
            throw new IllegalStateException("Clan creation coordinator is not initialized");
        }
        return clanCreationCoordinator;
    }

    public ClanElectionService getClanElectionService() {
        if (clanRuntime == null) {
            throw new IllegalStateException("Clan election service is not initialized");
        }
        return clanRuntime.electionService();
    }

    public ClanBankService getClanBankService() {
        if (clanRuntime == null) {
            throw new IllegalStateException("Clan bank service is not initialized");
        }
        return clanRuntime.bankService();
    }

    public ClanChatService getClanChatService() {
        if (clanChatService == null) throw new IllegalStateException("Clan chat service is not initialized");
        return clanChatService;
    }

    public ClanTournamentService getClanTournamentService() {
        if (clanTournamentService == null) throw new IllegalStateException("Clan tournament service is not initialized");
        return clanTournamentService;
    }

    public ClanQuestService getClanQuestService() {
        if (clanQuestService == null) throw new IllegalStateException("Clan quest service is not initialized");
        return clanQuestService;
    }

    public ClanAdministrationService getClanAdministrationService() {
        if (clanAdministrationService == null) throw new IllegalStateException("Clan administration service is not initialized");
        return clanAdministrationService;
    }

    public ClanAdminGui getClanAdminGui() {
        if (clanAdminGui == null) throw new IllegalStateException("Clan admin GUI is not initialized");
        return clanAdminGui;
    }

    /** Panel level of a sender: console is the owner; players need the documented permission nodes. */
    public ClanAdministrationService.Level resolveAdminLevel(org.bukkit.command.CommandSender sender) {
        if (!(sender instanceof org.bukkit.entity.Player player)) return ClanAdministrationService.Level.OWNER;
        if (player.hasPermission("skyworldclans.admin.owner")) return ClanAdministrationService.Level.OWNER;
        if (player.hasPermission("skyworldclans.admin")) return ClanAdministrationService.Level.ADMIN;
        if (player.hasPermission("skyworldclans.admin.moderator")) return ClanAdministrationService.Level.MODERATOR;
        return ClanAdministrationService.Level.NONE;
    }

    public ClanRewardCoordinator getClanRewardCoordinator() {
        if (clanRewardCoordinator == null) throw new IllegalStateException("Clan reward coordinator is not initialized");
        return clanRewardCoordinator;
    }

    public ClanModerationService getClanModerationService() {
        if (clanModerationService == null) throw new IllegalStateException("Clan moderation service is not initialized");
        return clanModerationService;
    }

    public boolean isChatMuted(java.util.UUID playerId) {
        if (clanRuntime == null || playerId == null) return false;
        try {
            // A clan chat mute and an administrative CLAN_CHAT function block are both enforced.
            ClanAdministrationService admin = clanAdministrationService;
            if (admin != null && admin.isFunctionBlocked(playerId, "CLAN_CHAT", java.time.Instant.now())) {
                return true;
            }
            if (clanModerationService == null) return false;
            var clan = getClanStore().findByPlayerId(playerId).orElse(null);
            return clan != null && clanModerationService.isChatMuted(clan.id(), playerId);
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Could not read clan chat mute for " + playerId, exception);
            return false;
        }
    }

    /** Administrative function blocks are also enforced for bank operations. */
    public boolean isBankBlocked(java.util.UUID playerId) {
        ClanAdministrationService admin = clanAdministrationService;
        return admin != null && admin.isFunctionBlocked(playerId, "CLAN_BANK", java.time.Instant.now());
    }

    /** Generic check used by request/war commands against an approved sanction scope. */
    public boolean isFunctionBlocked(java.util.UUID playerId, String scope) {
        ClanAdministrationService admin = clanAdministrationService;
        return admin != null && admin.isFunctionBlocked(playerId, scope, java.time.Instant.now());
    }

    private void registerModerationCommand(String name, ClanModerationCommand.Mode mode) {
        var command = getCommand(name);
        if (command == null) {
            getLogger().severe("Required /" + name + " command is missing from plugin.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        ClanModerationCommand executor = new ClanModerationCommand(this, mode);
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    public ClanStorageService getClanStorageService() {
        if (clanStorageService == null) throw new IllegalStateException("Clan storage service is not initialized");
        return clanStorageService;
    }

    public ClanStorageGui getClanStorageGui() {
        if (clanStorageGui == null) throw new IllegalStateException("Clan storage GUI is not initialized");
        return clanStorageGui;
    }

    public ClanMainGui getClanMainGui() {
        if (clanMainGui == null) throw new IllegalStateException("Clan main GUI is not initialized");
        return clanMainGui;
    }

    public ClanHomeService getClanHomeService() {
        if (clanHomeService == null) throw new IllegalStateException("Clan home service is not initialized");
        return clanHomeService;
    }

    public WorldGuardRegionAccess getWorldGuardRegionAccess() {
        return worldGuardRegionAccess;
    }

    public CombatLogService getCombatLogService() {
        if (combatLogService == null) throw new IllegalStateException("Combat log service is not initialized");
        return combatLogService;
    }

    public boolean isVaultEconomyAvailable() {
        return vaultEconomyBridge != null;
    }

    public ClanBankTransferCoordinator getClanBankTransferCoordinator() {
        if (clanBankTransferCoordinator == null) {
            throw new IllegalStateException("Clan bank transfer coordinator is not initialized");
        }
        return clanBankTransferCoordinator;
    }

    public ClanRequestService getClanRequestService() {
        if (clanRuntime == null) {
            throw new IllegalStateException("Clan request service is not initialized");
        }
        return clanRuntime.requestService();
    }

    public ForbiddenExpressionFilter getForbiddenExpressionFilter() {
        return forbiddenExpressionFilter;
    }

    public ClanWarService getClanWarService() {
        if (clanWarService == null) throw new IllegalStateException("Clan war service is not initialized");
        return clanWarService;
    }

    public ClanWarListener getClanWarListener() {
        if (clanWarListener == null) throw new IllegalStateException("Clan war listener is not initialized");
        return clanWarListener;
    }

    /** Interrupted rewards are frozen for review; nothing is re-paid automatically. */
    private void recoverRewardOperations() {
        ClanRewardCoordinator current = clanRewardCoordinator;
        if (current == null) return;
        try {
            for (var reward : current.recoverAfterRestart()) {
                getLogger().warning("Clan reward " + reward.operationId()
                        + " was frozen for manual review after restart (state=" + reward.state() + ")");
            }
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Could not recover interrupted clan rewards.", exception);
        }
    }

    /** Expired large-reward requests are closed without moving money. */
    private void expireRewardRequests() {
        var rewards = clanRewardCoordinator;
        if (rewards == null) return;
        try {
            for (java.util.UUID requestId : rewards.expireDueRequests()) {
                getLogger().info("Clan reward request " + requestId
                        + " expired without payment (24h deadline).");
            }
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled reward request expiry failed.", exception);
        }
    }

    private void rotateQuests() {
        ClanQuestService current = clanQuestService;
        if (current == null) return;
        try {
            current.expireDue();
            current.rotateAll();
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled clan quest rotation failed.", exception);
        }
    }

    private void processDueWarningCases() {
        ClanModerationService current = clanModerationService;
        if (current == null) return;
        try {
            for (java.util.UUID caseId : current.escalateDueCases()) {
                getLogger().warning("Clan warning case " + caseId
                        + " was escalated to the clan leader after 24 hours; no sanction was applied.");
            }
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled clan warning case escalation failed.", exception);
        }
    }

    private void processDueWars() {
        ClanWarService current = clanWarService;
        ClanWarListener listener = clanWarListener;
        if (current == null || listener == null) return;
        try {
            for (var war : current.resolveDue()) {
                getServer().getScheduler().runTask(this, () -> listener.announceFinished(war));
            }
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled clan war resolution failed.", exception);
        }
    }

    private void processCombatLogExpiry() {
        CombatLogService current = combatLogService;
        if (current == null) return;
        try {
            current.expireDue(java.time.Instant.now());
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled combat log expiry failed.", exception);
        }
    }

    private void processDueBankWithdrawalRequests() {
        if (clanRuntime == null) return;
        try {
            var expired = getClanBankService().expireDueRequestsDetailed();
            for (var request : expired) {
                getLogger().warning("Clan bank withdrawal request expired without payment: request="
                        + request.requestId() + ", clan=" + request.clanId() + ", amount=" + request.amount()
                        + ", deputy=" + request.requesterId());
                getServer().getScheduler().runTask(this, () -> {
                    org.bukkit.entity.Player deputy = getServer().getPlayer(request.requesterId());
                    if (deputy != null) deputy.sendMessage(org.bukkit.ChatColor.RED
                            + "Срок заявки на вывод средств истёк. Деньги не списывались.");
                });
            }
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled clan bank withdrawal request expiry failed.", exception);
        }
    }

    private void processDueElections() {
        if (clanRuntime == null) return;
        try {
            for (java.util.UUID clanId : getClanStore().dueElectionClanIds(java.time.Instant.now())) {
                var electionBefore = getClanElectionService().activeElection(clanId).orElse(null);
                var result = getClanElectionService().resolveIfDue(clanId);
                if (result == com.skyworldclans.clan.election.ClanElectionService.ResolutionResult.GLOBAL_TIE_REMAINS_TIED) {
                    getLogger().warning("Clan election remains tied after the global tie-break; owner decision is required for clan " + clanId);
                } else if (result == com.skyworldclans.clan.election.ClanElectionService.ResolutionResult.COMPLETED) {
                    getServer().getScheduler().runTask(this, () -> {
                        notifyClanMembers(clanId, org.bukkit.ChatColor.GREEN
                                + "Выборы завершены. Новый лидер назначен.");
                        if (electionBefore != null && electionBefore.type()
                                == com.skyworldclans.clan.election.ClanElection.Type.DEPARTURE) {
                            org.bukkit.entity.Player departing = getServer().getPlayer(electionBefore.startedBy());
                            if (departing != null) departing.sendMessage(org.bukkit.ChatColor.GREEN
                                    + "Выборы завершены: ты больше не состоишь в прежнем клане.");
                        }
                    });
                } else if (result == com.skyworldclans.clan.election.ClanElectionService.ResolutionResult.GLOBAL_TIE_BREAK_STARTED) {
                    getServer().getScheduler().runTask(this, () -> {
                        notifyClanMembers(clanId, org.bukkit.ChatColor.GOLD
                                + "Ничья сохраняется. Началось дополнительное глобальное голосование на 6 часов.");
                        for (org.bukkit.entity.Player online : getServer().getOnlinePlayers()) {
                            if (online.hasPermission("skyworldclans.election.vote.global")) {
                                online.sendMessage(org.bukkit.ChatColor.GOLD
                                        + "Доступно дополнительное голосование за лидера клана " + clanId
                                        + ". Используй /clan election vote <тег> <UUID кандидата>.");
                            }
                        }
                    });
                } else if (result == com.skyworldclans.clan.election.ClanElectionService.ResolutionResult.MEMBERSHIP_UPDATE_FAILED
                        || result == com.skyworldclans.clan.election.ClanElectionService.ResolutionResult.STORAGE_ERROR) {
                    getLogger().severe("Could not resolve clan election for " + clanId + ": " + result);
                }
            }
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled clan election processing failed.", exception);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (combatLogService != null) combatLogService.onRespawn(event.getPlayer().getUniqueId());
        recordClanMemberActivity(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        recordClanMemberActivity(event.getPlayer().getUniqueId());
    }

    private void recordOnlinePlayerActivity() {
        if (clanRuntime == null) return;
        try {
            java.util.List<java.util.UUID> onlineIds = getServer().getOnlinePlayers().stream()
                    .map(org.bukkit.entity.Player::getUniqueId).toList();
            getClanStore().recordOnlineMemberActivity(onlineIds, java.time.Instant.now());
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Could not record online clan member activity heartbeat.", exception);
        }
    }

    public void recordClanMemberActivity(java.util.UUID playerId) {
        if (clanRuntime == null || playerId == null) return;
        try {
            if (getClanStore().findByPlayerId(playerId).isEmpty()) return;
            getClanStore().recordPlayerActivity(playerId, java.time.Instant.now());
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Could not record player activity for " + playerId, exception);
        }
    }

    private void notifyClanMembers(java.util.UUID clanId, String message) {
        for (org.bukkit.entity.Player online : getServer().getOnlinePlayers()) {
            if (getClanStore().findByPlayerId(online.getUniqueId())
                    .map(clan -> clan.id().equals(clanId)).orElse(false)) {
                online.sendMessage(message);
            }
        }
    }

    /** Creates a manual backup away from the server thread and reports completion on the server thread. */
    public void createManualBackup(Consumer<SqliteBackupService.BackupResult> success,
            Consumer<RuntimeException> failure) {
        ScheduledExecutorService executor = backupExecutor;
        SqliteBackupService current = backupService;
        if (executor == null || current == null) {
            if (failure != null) failure.accept(new IllegalStateException("Backup service is not initialized"));
            return;
        }
        try {
            executor.execute(() -> {
                try {
                    SqliteBackupService.BackupResult result = current.createBackup();
                    getServer().getScheduler().runTask(this, () -> {
                        if (success != null) success.accept(result);
                    });
                } catch (RuntimeException exception) {
                    getServer().getScheduler().runTask(this, () -> {
                        if (failure != null) failure.accept(exception);
                    });
                }
            });
        } catch (RuntimeException exception) {
            if (failure != null) failure.accept(exception);
        }
    }

    public java.util.Optional<SqliteBackupService.BackupMetadata> latestBackup() {
        SqliteBackupService current = backupService;
        return current == null ? java.util.Optional.empty() : current.latestBackup();
    }

    private void createScheduledBackup() {
        SqliteBackupService current = backupService;
        if (current == null) {
            return;
        }
        try {
            SqliteBackupService.BackupResult result = current.createBackup();
            getLogger().info("Scheduled backup created: " + result.backup());
            result.warnings().forEach(getLogger()::warning);
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Scheduled SQLite backup failed.", exception);
        }
    }

    private void initializeForbiddenExpressionFilter() {
        try {
            Path configurationFile =
                    ForbiddenExpressionConfiguration.prepare(getDataFolder().toPath());
            forbiddenExpressionFilter = ForbiddenExpressionFilter.load(
                    new Utf8FileForbiddenExpressionSource(configurationFile));
        } catch (IOException | SecurityException exception) {
            forbiddenExpressionFilter = ForbiddenExpressionFilter.unavailable(
                    "Failed to prepare " + ForbiddenExpressionConfiguration.FILE_NAME,
                    exception);
        }

        if (!forbiddenExpressionFilter.isAvailable()) {
            getLogger().severe("Forbidden-expression filter is UNAVAILABLE: "
                    + forbiddenExpressionFilter.configurationError().orElse(
                            "No diagnostic information available"));
        } else if (forbiddenExpressionFilter.emptyListWarningRequired()) {
            getLogger().warning(
                    "Forbidden-expression filter is READY, but currently contains no forbidden expressions.");
        } else {
            getLogger().info("Forbidden-expression filter is READY.");
        }
    }

}
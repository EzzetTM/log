package com.skyworldclans.clan.filter;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermission;
import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

class ForbiddenExpressionConfigurationTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void createsCommentOnlyUtf8FileInPluginDataFolder() throws IOException {
        Path pluginDataFolder = temporaryDirectory.resolve("plugins").resolve("SkyWorldClans");

        Path file = ForbiddenExpressionConfiguration.prepare(pluginDataFolder);

        assertEquals(pluginDataFolder.resolve("forbidden-expressions.txt"), file);
        assertTrue(Files.isRegularFile(file));
        String content = Files.readString(file, StandardCharsets.UTF_8);
        assertTrue(content.contains("#"));
        assertTrue(content.contains("one expression per line"));
        assertFalse(content.contains("\uFFFD"));
    }

    @Test
    void neverOverwritesAnExistingFile() throws IOException {
        Path pluginDataFolder = Files.createDirectory(temporaryDirectory.resolve("plugin-data"));
        Path file = pluginDataFolder.resolve(ForbiddenExpressionConfiguration.FILE_NAME);
        byte[] ownerContent = "owner content\nСохранить без изменений\n"
                .getBytes(StandardCharsets.UTF_8);
        Files.write(file, ownerContent);

        Path prepared = ForbiddenExpressionConfiguration.prepare(pluginDataFolder);

        assertEquals(file, prepared);
        assertArrayEquals(ownerContent, Files.readAllBytes(file));
    }

    @Test
    void repeatedInitializationPreservesUserContentAndLoadsIt() throws IOException {
        Path pluginDataFolder = Files.createDirectory(temporaryDirectory.resolve("repeat"));
        Path file = ForbiddenExpressionConfiguration.prepare(pluginDataFolder);
        Files.writeString(file, "клан\n", StandardCharsets.UTF_8);

        Path secondPreparation = ForbiddenExpressionConfiguration.prepare(pluginDataFolder);
        ForbiddenExpressionFilter filter = ForbiddenExpressionFilter.load(
                new Utf8FileForbiddenExpressionSource(secondPreparation));

        assertEquals(file, secondPreparation);
        assertEquals("клан\n", Files.readString(file, StandardCharsets.UTF_8));
        assertTrue(filter.isAvailable());
        assertFalse(filter.emptyListWarningRequired());
        assertEquals(
                ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                filter.check(ForbiddenExpressionField.NAME, "klan").status());
    }

    @Test
    void validEmptyFileRemainsReadyAndSignalsWarning() throws IOException {
        Path pluginDataFolder = Files.createDirectory(temporaryDirectory.resolve("empty"));
        Path file = ForbiddenExpressionConfiguration.prepare(pluginDataFolder);
        Files.writeString(file, " \n# no entries\n", StandardCharsets.UTF_8);

        ForbiddenExpressionFilter filter = ForbiddenExpressionFilter.load(
                new Utf8FileForbiddenExpressionSource(
                        ForbiddenExpressionConfiguration.prepare(pluginDataFolder)));

        assertTrue(filter.isAvailable());
        assertTrue(filter.emptyListWarningRequired());
        assertEquals(
                ForbiddenExpressionStatus.ALLOWED,
                filter.check(ForbiddenExpressionField.NAME, "ordinary").status());
    }

    @Test
    void validNonEmptyFileLoadsReadyFilter() throws IOException {
        Path pluginDataFolder = Files.createDirectory(temporaryDirectory.resolve("non-empty"));
        Path file = ForbiddenExpressionConfiguration.prepare(pluginDataFolder);
        Files.writeString(file, "orbit\n", StandardCharsets.UTF_8);

        ForbiddenExpressionFilter filter = ForbiddenExpressionFilter.load(
                new Utf8FileForbiddenExpressionSource(file));

        assertTrue(filter.isAvailable());
        assertFalse(filter.emptyListWarningRequired());
        assertEquals(
                ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION,
                filter.check(ForbiddenExpressionField.SLOGAN, "my-orbit").status());
    }

    @Test
    void preparationFailureDoesNotFallBackToAnEmptyAvailableFilter() throws IOException {
        Path dataFolderThatIsAFile = temporaryDirectory.resolve("not-a-directory");
        Files.writeString(dataFolderThatIsAFile, "block directory creation");

        assertThrows(
                IOException.class,
                () -> ForbiddenExpressionConfiguration.prepare(dataFolderThatIsAFile));

        ForbiddenExpressionFilter unavailable = ForbiddenExpressionFilter.load(() -> {
            throw new IOException("Could not prepare configuration");
        });
        assertFalse(unavailable.isAvailable());
        assertFalse(unavailable.emptyListWarningRequired());
        assertTrue(unavailable.configurationError().orElseThrow()
                .contains("Could not prepare configuration"));
        assertEquals(
                ForbiddenExpressionStatus.FILTER_UNAVAILABLE,
                unavailable.check(ForbiddenExpressionField.NAME, "ordinary").status());
    }

    @Test
    void preservesOriginalPreparationFailureAsCauseAndInDiagnostic() {
        SecurityException original =
                new SecurityException("permission denied while creating configuration");

        ForbiddenExpressionFilter unavailable = ForbiddenExpressionFilter.unavailable(
                "Failed to prepare forbidden-expressions.txt", original);

        assertFalse(unavailable.isAvailable());
        FilterConfigurationFailure failure = unavailable.configurationFailure().orElseThrow();
        assertSame(original, failure.cause());
        assertTrue(failure.diagnostic().contains("Failed to prepare forbidden-expressions.txt"));
        assertTrue(failure.diagnostic().contains("SecurityException"));
        assertTrue(failure.diagnostic().contains("permission denied"));
        assertEquals(
                failure.diagnostic(),
                unavailable.configurationError().orElseThrow());
    }

    @Test
    void existingDirectoryWithoutWritePermissionRemainsUnavailable() throws IOException {
        Path pluginDataFolder =
                Files.createDirectory(temporaryDirectory.resolve("read-only-data"));
        var view = Files.getFileAttributeView(
                pluginDataFolder,
                java.nio.file.attribute.PosixFileAttributeView.class);
        assumeTrue(view != null, "POSIX permissions are unavailable on this filesystem");

        var originalPermissions = Files.getPosixFilePermissions(pluginDataFolder);
        var readAndExecuteOnly = EnumSet.of(
                PosixFilePermission.OWNER_READ,
                PosixFilePermission.OWNER_EXECUTE,
                PosixFilePermission.GROUP_READ,
                PosixFilePermission.GROUP_EXECUTE,
                PosixFilePermission.OTHERS_READ,
                PosixFilePermission.OTHERS_EXECUTE);
        Files.setPosixFilePermissions(pluginDataFolder, readAndExecuteOnly);

        Throwable preparationFailure = null;
        try {
            try {
                ForbiddenExpressionConfiguration.prepare(pluginDataFolder);
            } catch (IOException | SecurityException exception) {
                preparationFailure = exception;
            }
        } finally {
            Files.setPosixFilePermissions(pluginDataFolder, originalPermissions);
        }

        assumeTrue(preparationFailure != null,
                "The test process can write despite removed POSIX write bits; "
                        + "permission denial cannot be reliably exercised as this user");

        ForbiddenExpressionFilter unavailable = ForbiddenExpressionFilter.unavailable(
                "Failed to prepare forbidden-expressions.txt", preparationFailure);
        assertFalse(unavailable.isAvailable());
        assertSame(preparationFailure,
                unavailable.configurationFailure().orElseThrow().cause());
        assertEquals(
                ForbiddenExpressionStatus.FILTER_UNAVAILABLE,
                unavailable.check(ForbiddenExpressionField.NAME, "ordinary").status());
    }

    @Test
    void existingUnreadableConfigurationPathDoesNotBecomeEmptyFilter() throws IOException {
        Path pluginDataFolder = Files.createDirectory(temporaryDirectory.resolve("directory-file"));
        Files.createDirectory(pluginDataFolder.resolve(ForbiddenExpressionConfiguration.FILE_NAME));

        Path configuration =
                pluginDataFolder.resolve(ForbiddenExpressionConfiguration.FILE_NAME);
        ForbiddenExpressionFilter filter = ForbiddenExpressionFilter.load(
                new Utf8FileForbiddenExpressionSource(configuration));

        assertFalse(filter.isAvailable());
        assertFalse(filter.emptyListWarningRequired());
        assertTrue(filter.configurationError().orElseThrow().length() > 0);
        assertEquals(
                ForbiddenExpressionStatus.FILTER_UNAVAILABLE,
                filter.check(ForbiddenExpressionField.NAME, "anything").status());
    }
}

package com.skyworldclans;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.service.ClanRegistrationResult;
import com.skyworldclans.clan.service.ClanService;
import com.skyworldclans.clan.storage.StorageException;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanStorageRuntimeTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void serviceUsesTheSingleOwnedStoreAndCannotOperateAfterClose() {
        AtomicReference<SqliteClanStore> openedStore = new AtomicReference<>();
        ClanStorageRuntime runtime = ClanStorageRuntime.open(
                temporaryDirectory.resolve("runtime.sqlite"),
                path -> {
                    SqliteClanStore store = SqliteClanStore.open(path);
                    openedStore.set(store);
                    return store;
                },
                catalog -> {
                    assertSame(openedStore.get(), catalog);
                    return new ClanService(catalog, new ClanMembershipStateValidator());
                });

        assertSame(openedStore.get(), runtime.store());
        ClanService savedService = runtime.service();
        Clan clan = clan();
        try {
            assertEquals(ClanRegistrationResult.Status.REGISTERED,
                    savedService.registerClan(clan).status());
            assertEquals(clan, runtime.store().findById(clan.id()).orElseThrow());
        } finally {
            runtime.close();
        }
        assertThrows(IllegalStateException.class, runtime::service);
        assertThrows(StorageException.class, () -> savedService.isTagAvailable(clan.tag()));
    }

    @Test
    void closesStoreIfServiceConstructionFailsDuringPartialStartup() {
        AtomicReference<SqliteClanStore> openedStore = new AtomicReference<>();
        RuntimeException startupFailure = new IllegalStateException(
                "injected service construction failure");
        RuntimeException closeFailure = new IllegalStateException("injected close failure");
        RuntimeException thrown = assertThrows(IllegalStateException.class,
                () -> ClanStorageRuntime.open(
                temporaryDirectory.resolve("partial-startup.sqlite"),
                path -> {
                    SqliteClanStore store = SqliteClanStore.open(path);
                    openedStore.set(store);
                    return store;
                },
                ignored -> {
                    throw startupFailure;
                },
                store -> {
                    store.close();
                    throw closeFailure;
                }));

        assertSame(startupFailure, thrown);
        assertEquals(1, thrown.getSuppressed().length);
        assertSame(closeFailure, thrown.getSuppressed()[0]);
        assertTrue(openedStore.get() != null);
        assertThrows(StorageException.class,
                () -> openedStore.get().findById(UUID.randomUUID()));
    }

    @Test
    void reportsCloseFailureAndDoesNotRetryOrAllowFurtherOperations() {
        AtomicReference<SqliteClanStore> openedStore = new AtomicReference<>();
        AtomicInteger closeCalls = new AtomicInteger();
        RuntimeException closeFailure = new IllegalStateException("injected close failure");
        ClanStorageRuntime runtime = ClanStorageRuntime.open(
                temporaryDirectory.resolve("close-failure.sqlite"),
                path -> {
                    SqliteClanStore store = SqliteClanStore.open(path);
                    openedStore.set(store);
                    return store;
                },
                catalog -> new ClanService(catalog, new ClanMembershipStateValidator()),
                store -> {
                    closeCalls.incrementAndGet();
                    store.close();
                    throw closeFailure;
                });
        ClanService savedService = runtime.service();

        RuntimeException thrown = assertThrows(RuntimeException.class, runtime::close);
        assertSame(closeFailure, thrown);
        assertEquals(1, closeCalls.get());
        assertThrows(IllegalStateException.class, runtime::service);
        assertThrows(IllegalStateException.class, runtime::store);
        assertThrows(StorageException.class,
                () -> savedService.isTagAvailable("RC1"));

        runtime.close();
        assertEquals(1, closeCalls.get());
        assertThrows(StorageException.class,
                () -> openedStore.get().findById(UUID.randomUUID()));
    }

    private static Clan clan() {
        UUID leaderId = UUID.fromString("00000000-0000-0000-0000-000000000101");
        ClanMember leader = new ClanMember(
                leaderId,
                ClanRole.LEADER,
                Instant.parse("2025-01-01T00:00:00Z"),
                null);
        return new Clan(
                UUID.fromString("00000000-0000-0000-0000-000000000201"),
                "Runtime Clan",
                "RC1",
                Instant.parse("2025-01-01T00:00:00Z"),
                10,
                Map.of(leaderId, leader),
                0,
                null);
    }
}

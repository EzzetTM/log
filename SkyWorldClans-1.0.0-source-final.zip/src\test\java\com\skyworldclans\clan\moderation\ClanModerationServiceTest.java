package com.skyworldclans.clan.moderation;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanModerationServiceTest {
    @TempDir Path temporaryDirectory;
    private static final Instant START = Instant.parse("2026-12-10T09:00:00Z");

    @Test
    void moderatorsAreLimitedToTwentyFourHoursAndCannotTouchSeniors() {
        UUID leader = id(1), deputy = id(2), moderator = id(3), member = id(4);
        Clan clan = clan(leader, deputy, moderator, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("mute-limits.sqlite"))) {
            store.registerIfAvailable(clan);
            MutableClock clock = new MutableClock(START);
            ClanModerationService service = new ClanModerationService(store, store, clock, UUID::randomUUID);

            assertEquals(ClanModerationService.Result.DURATION_EXCEEDS_ROLE_LIMIT,
                    service.mute(moderator, member, Duration.ofHours(25), "spam"));
            assertEquals(ClanModerationService.Result.INSUFFICIENT_PERMISSION,
                    service.mute(moderator, deputy, Duration.ofHours(1), "spam"));
            assertEquals(ClanModerationService.Result.INSUFFICIENT_PERMISSION,
                    service.mute(deputy, leader, Duration.ofHours(1), "spam"));
            assertEquals(ClanModerationService.Result.APPLIED,
                    service.mute(moderator, member, Duration.ofHours(24), "caps"));
            assertTrue(service.isChatMuted(clan.id(), member));
            clock.set(START.plus(Duration.ofHours(24)));
            assertFalse(service.isChatMuted(clan.id(), member));

            assertEquals(ClanModerationService.Result.APPLIED,
                    service.mute(deputy, member, Duration.ofDays(3), "flood"));
            assertEquals(ClanModerationService.Result.DURATION_EXCEEDS_ROLE_LIMIT,
                    service.mute(deputy, member, Duration.ofDays(4), "flood"));
            assertEquals(ClanModerationService.Result.INSUFFICIENT_PERMISSION,
                    service.unmute(moderator, member));
            assertEquals(ClanModerationService.Result.APPLIED, service.unmute(deputy, member));

            assertEquals(ClanModerationService.Result.APPLIED,
                    service.mute(leader, deputy, null, "leader decision"));
            assertTrue(service.isChatMuted(clan.id(), deputy));
            assertTrue(store.findClanChatMute(clan.id(), deputy).orElseThrow().expiresAt() == null,
                    "an indefinite mute must store no expiry");
        }
    }

    @Test
    void threeWarningsInsideTwelveHoursOpenACaseOnceAndEscalateAfterADay() {
        UUID leader = id(11), deputy = id(12), moderator = id(13), member = id(14);
        Clan clan = clan(leader, deputy, moderator, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("warn-case.sqlite"))) {
            store.registerIfAvailable(clan);
            MutableClock clock = new MutableClock(START);
            ClanModerationService service = new ClanModerationService(store, store, clock, UUID::randomUUID);

            assertEquals(ClanModerationService.Result.APPLIED, service.warn(moderator, member, "first"));
            clock.set(START.plus(Duration.ofHours(3)));
            assertEquals(ClanModerationService.Result.APPLIED, service.warn(deputy, member, "second"));
            assertTrue(service.cases(deputy).isEmpty(), "a case needs three active warnings");
            clock.set(START.plus(Duration.ofHours(6)));
            assertEquals(ClanModerationService.Result.APPLIED, service.warn(moderator, member, "third"));

            List<SqliteClanStore.ClanWarningCase> cases = service.cases(leader);
            assertEquals(1, cases.size());
            assertEquals(SqliteClanStore.ClanWarningCaseStatus.OPEN, cases.get(0).status());
            assertEquals(3, cases.get(0).warningIds().size());

            // A fourth warning does not open a second case.
            clock.set(START.plus(Duration.ofHours(7)));
            assertEquals(ClanModerationService.Result.APPLIED, service.warn(moderator, member, "fourth"));
            assertEquals(1, service.cases(leader).size());

            // Removing warnings never closes an existing case.
            assertEquals(ClanModerationService.Result.APPLIED, service.removeWarning(leader, member));
            assertEquals(1, service.cases(leader).size());

            clock.set(START.plus(Duration.ofHours(31)));
            assertEquals(1, service.escalateDueCases().size());
            assertEquals(SqliteClanStore.ClanWarningCaseStatus.ESCALATED_TO_LEADER,
                    service.cases(leader).get(0).status());
            // Escalation is a notification, never an automatic removal from the clan.
            assertEquals(4, store.findById(clan.id()).orElseThrow().memberCount());
        }
    }

    @Test
    void warningsOutsideTheWindowDoNotEscalate() {
        UUID leader = id(21), deputy = id(22), moderator = id(23), member = id(24);
        Clan clan = clan(leader, deputy, moderator, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("warn-window.sqlite"))) {
            store.registerIfAvailable(clan);
            MutableClock clock = new MutableClock(START);
            ClanModerationService service = new ClanModerationService(store, store, clock, UUID::randomUUID);
            service.warn(moderator, member, "old");
            clock.set(START.plus(Duration.ofHours(20)));
            service.warn(moderator, member, "later");
            clock.set(START.plus(Duration.ofHours(25)));
            service.warn(moderator, member, "later still");
            assertTrue(service.cases(leader).isEmpty(),
                    "three warnings spread beyond 12 hours must not open a case");
        }
    }

    @Test
    void warningVisibilityFollowsTheViewerRole() {
        UUID leader = id(31), deputy = id(32), moderator = id(33), member = id(34);
        Clan clan = clan(leader, deputy, moderator, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("warn-visibility.sqlite"))) {
            store.registerIfAvailable(clan);
            MutableClock clock = new MutableClock(START);
            ClanModerationService service = new ClanModerationService(store, store, clock, UUID::randomUUID);
            service.warn(moderator, member, "by moderator");
            service.warn(deputy, member, "by deputy");

            assertEquals(2, service.warnings(leader, null).size());
            assertEquals(2, service.warnings(deputy, null).size());
            assertEquals(1, service.warnings(moderator, null).size());
            assertEquals(0, service.warnings(member, null).size());
            assertEquals(ClanModerationService.Result.INSUFFICIENT_PERMISSION, service.unmute(member, moderator));
        }
    }
    private static Clan clan(UUID leader, UUID deputy, UUID moderator, UUID member) {
        return new Clan(new UUID(0, 900), "ModerationClan", "MD900",
                Instant.parse("2025-01-01T00:00:00Z"), 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, START, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, START, null),
                        moderator, new ClanMember(moderator, ClanRole.MODERATOR, START, deputy),
                        member, new ClanMember(member, ClanRole.MEMBER, START, null)),
                0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }

    private static final class MutableClock extends Clock {
        private Instant current;
        private MutableClock(Instant start) { this.current = start; }
        void set(Instant value) { current = value; }
        @Override public ZoneId getZone() { return ZoneOffset.UTC; }
        @Override public Clock withZone(ZoneId zone) { return this; }
        @Override public Instant instant() { return current; }
    }
}
package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanMembershipChangePolicy;
import com.skyworldclans.clan.membership.ClanLeadershipPolicy;
import com.skyworldclans.clan.membership.ClanMembershipPolicy;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.membership.ClanRole;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Applies approved role, demotion and membership-removal rules to immutable clan snapshots. */
public final class ClanMembershipService {
    private final ClanCatalog catalog;
    private final ClanMembershipStateValidator stateValidator;
    private final ClanMembershipChangePolicy changePolicy;
    private final ClanLeadershipPolicy leadershipPolicy;

    public ClanMembershipService(ClanCatalog catalog) {
        this(catalog, new ClanMembershipStateValidator(),
                new ClanMembershipChangePolicy(), new ClanLeadershipPolicy());
    }

    ClanMembershipService(
            ClanCatalog catalog,
            ClanMembershipStateValidator stateValidator,
            ClanMembershipChangePolicy changePolicy,
            ClanLeadershipPolicy leadershipPolicy) {
        this.catalog = Objects.requireNonNull(catalog, "catalog");
        this.stateValidator = Objects.requireNonNull(stateValidator, "stateValidator");
        this.changePolicy = Objects.requireNonNull(changePolicy, "changePolicy");
        this.leadershipPolicy = Objects.requireNonNull(leadershipPolicy, "leadershipPolicy");
    }

    public ClanMembershipChangeResult appointDeputy(
            UUID clanId, UUID actorId, UUID targetId, boolean electionActive) {
        if (clanId == null || actorId == null || targetId == null) {
            return result(ClanMembershipChangeResult.Status.INVALID_INPUT);
        }
        if (electionActive) {
            return result(ClanMembershipChangeResult.Status.ELECTION_ACTIVE);
        }
        Clan clan = catalog.findById(clanId).orElse(null);
        if (clan == null) {
            return result(ClanMembershipChangeResult.Status.CLAN_NOT_FOUND);
        }
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) {
            return result(ClanMembershipChangeResult.Status.ACTOR_NOT_MEMBER);
        }
        if (actor.role() != ClanRole.LEADER) {
            return result(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION);
        }
        ClanMember target = clan.member(targetId).orElse(null);
        if (target == null) {
            return result(ClanMembershipChangeResult.Status.TARGET_NOT_MEMBER);
        }
        if (target.role() != ClanRole.MEMBER) {
            return result(ClanMembershipChangeResult.Status.TARGET_NOT_ELIGIBLE);
        }
        int deputyCount = (int) clan.members().values().stream()
                .filter(member -> member.role() == ClanRole.DEPUTY).count();
        if (!ClanMembershipPolicy.canAssignDeputy(actor.role(), deputyCount)) {
            return result(ClanMembershipChangeResult.Status.DEPUTY_LIMIT_REACHED);
        }
        Map<UUID, ClanMember> members = new HashMap<>(clan.members());
        members.put(targetId, target.withRole(ClanRole.DEPUTY, null));
        return save(clan, copyWithMembers(clan, members));
    }

    public ClanMembershipChangeResult appointModerator(
            UUID clanId, UUID actorId, UUID targetId) {
        return appointModerator(clanId, actorId, targetId, false);
    }

    public ClanMembershipChangeResult appointModerator(
            UUID clanId, UUID actorId, UUID targetId, boolean electionActive) {
        if (clanId == null || actorId == null || targetId == null) {
            return result(ClanMembershipChangeResult.Status.INVALID_INPUT);
        }
        if (electionActive) return result(ClanMembershipChangeResult.Status.ELECTION_ACTIVE);
        Clan clan = catalog.findById(clanId).orElse(null);
        if (clan == null) {
            return result(ClanMembershipChangeResult.Status.CLAN_NOT_FOUND);
        }
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) {
            return result(ClanMembershipChangeResult.Status.ACTOR_NOT_MEMBER);
        }
        if (actor.role() != ClanRole.LEADER && actor.role() != ClanRole.DEPUTY) {
            return result(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION);
        }
        ClanMember target = clan.member(targetId).orElse(null);
        if (target == null) {
            return result(ClanMembershipChangeResult.Status.TARGET_NOT_MEMBER);
        }
        if (target.role() != ClanRole.MEMBER) {
            return result(ClanMembershipChangeResult.Status.TARGET_NOT_ELIGIBLE);
        }
        int ownDeputyModerators = actor.role() == ClanRole.DEPUTY
                ? countDeputyModerators(clan, actorId) : 0;
        int totalDeputyModerators = (int) clan.members().values().stream()
                .filter(member -> member.role() == ClanRole.MODERATOR
                        && member.appointedByDeputyId() != null).count();
        if (!ClanMembershipPolicy.canAssignModerator(
                actor.role(), ownDeputyModerators, totalDeputyModerators)) {
            return result(ClanMembershipChangeResult.Status.MODERATOR_LIMIT_REACHED);
        }
        UUID appointer = actor.role() == ClanRole.DEPUTY ? actorId : null;
        Map<UUID, ClanMember> members = new HashMap<>(clan.members());
        members.put(targetId, target.withRole(ClanRole.MODERATOR, appointer));
        return save(clan, copyWithMembers(clan, members));
    }

    public ClanMembershipChangeResult transferLeadership(
            UUID clanId, UUID actorId, UUID targetId, boolean electionActive) {
        if (clanId == null || actorId == null || targetId == null) {
            return result(ClanMembershipChangeResult.Status.INVALID_INPUT);
        }
        if (electionActive) {
            return result(ClanMembershipChangeResult.Status.ELECTION_ACTIVE);
        }
        Clan clan = catalog.findById(clanId).orElse(null);
        if (clan == null) {
            return result(ClanMembershipChangeResult.Status.CLAN_NOT_FOUND);
        }
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) {
            return result(ClanMembershipChangeResult.Status.ACTOR_NOT_MEMBER);
        }
        if (actor.role() != ClanRole.LEADER) {
            return result(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION);
        }
        ClanMember target = clan.member(targetId).orElse(null);
        if (target == null) {
            return result(ClanMembershipChangeResult.Status.TARGET_NOT_MEMBER);
        }
        if (!leadershipPolicy.canTransferLeadershipTo(target.role(), false)) {
            return result(ClanMembershipChangeResult.Status.TARGET_NOT_ELIGIBLE);
        }

        Map<UUID, ClanMember> members = new HashMap<>(clan.members());
        members.put(actorId, actor.withRole(ClanRole.MEMBER, null));
        members.put(targetId, target.withRole(ClanRole.LEADER, null));
        // Moderators appointed by the new leader remain moderators; their appointment is now
        // treated as leader-appointed because the appointer no longer has the DEPUTY role.
        for (Map.Entry<UUID, ClanMember> entry : new HashMap<>(members).entrySet()) {
            ClanMember member = entry.getValue();
            if (member.role() == ClanRole.MODERATOR
                    && targetId.equals(member.appointedByDeputyId())) {
                members.put(entry.getKey(), member.withRole(ClanRole.MODERATOR, null));
            }
        }
        return save(clan, copyWithMembers(clan, members));
    }

    public ClanMembershipChangeResult demoteDeputy(
            UUID clanId, UUID actorId, UUID targetId, boolean electionActive) {
        if (clanId == null || actorId == null || targetId == null)
            return result(ClanMembershipChangeResult.Status.INVALID_INPUT);
        if (electionActive) return result(ClanMembershipChangeResult.Status.ELECTION_ACTIVE);
        Clan clan = catalog.findById(clanId).orElse(null);
        if (clan == null) return result(ClanMembershipChangeResult.Status.CLAN_NOT_FOUND);
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) return result(ClanMembershipChangeResult.Status.ACTOR_NOT_MEMBER);
        ClanMember target = clan.member(targetId).orElse(null);
        if (target == null) return result(ClanMembershipChangeResult.Status.TARGET_NOT_MEMBER);
        if (target.role() != ClanRole.DEPUTY) return result(ClanMembershipChangeResult.Status.TARGET_NOT_ELIGIBLE);
        if (!changePolicy.canDemoteDeputy(actor.role(), target.role(), false))
            return result(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION);
        Map<UUID, ClanMember> members = new HashMap<>(clan.members());
        members.put(targetId, target.withRole(ClanRole.MEMBER, null));
        for (Map.Entry<UUID, ClanMember> entry : new HashMap<>(members).entrySet()) {
            ClanMember member = entry.getValue();
            if (member.role() == ClanRole.MODERATOR && targetId.equals(member.appointedByDeputyId())) {
                members.put(entry.getKey(), member.withRole(ClanRole.MEMBER, null));
            }
        }
        return save(clan, copyWithMembers(clan, members));
    }

    public ClanMembershipChangeResult demoteModerator(
            UUID clanId, UUID actorId, UUID targetId, boolean electionActive) {
        if (clanId == null || actorId == null || targetId == null)
            return result(ClanMembershipChangeResult.Status.INVALID_INPUT);
        if (electionActive) return result(ClanMembershipChangeResult.Status.ELECTION_ACTIVE);
        Clan clan = catalog.findById(clanId).orElse(null);
        if (clan == null) return result(ClanMembershipChangeResult.Status.CLAN_NOT_FOUND);
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) return result(ClanMembershipChangeResult.Status.ACTOR_NOT_MEMBER);
        ClanMember target = clan.member(targetId).orElse(null);
        if (target == null) return result(ClanMembershipChangeResult.Status.TARGET_NOT_MEMBER);
        if (target.role() != ClanRole.MODERATOR) return result(ClanMembershipChangeResult.Status.TARGET_NOT_ELIGIBLE);
        if (!changePolicy.canDemoteModerator(actor.role(), target.role(), actorId,
                target.appointedByDeputyId(), false))
            return result(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION);
        Map<UUID, ClanMember> members = new HashMap<>(clan.members());
        members.put(targetId, target.withRole(ClanRole.MEMBER, null));
        return save(clan, copyWithMembers(clan, members));
    }

    public ClanMembershipChangeResult removeMember(
            UUID clanId, UUID actorId, UUID targetId, boolean electionActive) {
        if (clanId == null || actorId == null || targetId == null) {
            return result(ClanMembershipChangeResult.Status.INVALID_INPUT);
        }
        if (electionActive) {
            return result(ClanMembershipChangeResult.Status.ELECTION_ACTIVE);
        }
        Clan clan = catalog.findById(clanId).orElse(null);
        if (clan == null) {
            return result(ClanMembershipChangeResult.Status.CLAN_NOT_FOUND);
        }
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) {
            return result(ClanMembershipChangeResult.Status.ACTOR_NOT_MEMBER);
        }
        ClanMember target = clan.member(targetId).orElse(null);
        if (target == null) {
            return result(ClanMembershipChangeResult.Status.TARGET_NOT_MEMBER);
        }
        if (!changePolicy.canRemoveMember(
                actor.role(), target.role(), actorId.equals(targetId), false)) {
            return result(ClanMembershipChangeResult.Status.INSUFFICIENT_PERMISSION);
        }
        return removeAndDemote(clan, targetId, target.role());
    }

    public ClanMembershipChangeResult leaveClan(UUID playerId, boolean electionActive) {
        if (playerId == null) {
            return result(ClanMembershipChangeResult.Status.INVALID_INPUT);
        }
        Clan clan = catalog.findByPlayerId(playerId).orElse(null);
        if (clan == null) {
            return result(ClanMembershipChangeResult.Status.ACTOR_NOT_MEMBER);
        }
        ClanMember member = clan.member(playerId).orElse(null);
        if (member == null) {
            return result(ClanMembershipChangeResult.Status.INVALID_MEMBERSHIP_STATE);
        }
        // Elections only freeze leader/deputy composition. Ordinary members may still leave.
        if (electionActive && member.role() != ClanRole.MEMBER) {
            return result(ClanMembershipChangeResult.Status.ELECTION_ACTIVE);
        }
        if (member.role() == ClanRole.LEADER) {
            int remainingCount = clan.memberCount() - 1;
            int deputyCount = (int) clan.members().values().stream()
                    .filter(candidate -> candidate.role() == ClanRole.DEPUTY).count();
            return switch (leadershipPolicy.determineLeaderDeparture(remainingCount, deputyCount)
                    .orElseThrow()) {
                case TRANSFER_TO_DEPUTY -> transferOnLeaderDeparture(clan, playerId);
                case ELECTION_AMONG_DEPUTIES, ELECTION_AMONG_MEMBERS ->
                        result(ClanMembershipChangeResult.Status.LEADER_DEPARTURE_REQUIRES_ELECTION);
                case EMPTY_CLAN -> result(
                        ClanMembershipChangeResult.Status.EMPTY_CLAN_DELETION_REQUIRES_STORAGE_SUPPORT);
            };
        }
        return removeAndDemote(clan, playerId, member.role());
    }

    private ClanMembershipChangeResult transferOnLeaderDeparture(Clan clan, UUID leavingLeaderId) {
        ClanMember deputy = clan.members().values().stream()
                .filter(member -> member.role() == ClanRole.DEPUTY)
                .findFirst()
                .orElse(null);
        if (deputy == null) {
            return result(ClanMembershipChangeResult.Status.INVALID_MEMBERSHIP_STATE);
        }
        Map<UUID, ClanMember> members = new HashMap<>(clan.members());
        members.remove(leavingLeaderId);
        members.put(deputy.playerId(), deputy.withRole(ClanRole.LEADER, null));
        for (Map.Entry<UUID, ClanMember> entry : new HashMap<>(members).entrySet()) {
            ClanMember member = entry.getValue();
            if (member.role() == ClanRole.MODERATOR
                    && deputy.playerId().equals(member.appointedByDeputyId())) {
                members.put(entry.getKey(), member.withRole(ClanRole.MODERATOR, null));
            }
        }
        return save(clan, copyWithMembers(clan, members));
    }

    private ClanMembershipChangeResult removeAndDemote(
            Clan clan, UUID removedPlayerId, ClanRole removedRole) {
        Map<UUID, ClanMember> members = new HashMap<>(clan.members());
        members.remove(removedPlayerId);
        if (removedRole == ClanRole.DEPUTY) {
            for (Map.Entry<UUID, ClanMember> entry : new HashMap<>(members).entrySet()) {
                ClanMember member = entry.getValue();
                if (member.role() == ClanRole.MODERATOR
                        && removedPlayerId.equals(member.appointedByDeputyId())) {
                    members.put(entry.getKey(), member.withRole(ClanRole.MEMBER, null));
                }
            }
        }
        return save(clan, copyWithMembers(clan, members));
    }

    private ClanMembershipChangeResult save(Clan expected, Clan updated) {
        if (!stateValidator.validate(updated, false).isEmpty()) {
            return result(ClanMembershipChangeResult.Status.INVALID_MEMBERSHIP_STATE);
        }
        return switch (catalog.updateMembershipIfUnchanged(expected, updated)) {
            case UPDATED -> new ClanMembershipChangeResult(
                    ClanMembershipChangeResult.Status.UPDATED, Optional.of(updated));
            case CLAN_NOT_FOUND -> result(ClanMembershipChangeResult.Status.CLAN_NOT_FOUND);
            case STATE_CONFLICT -> result(ClanMembershipChangeResult.Status.CONCURRENT_MODIFICATION);
            case MEMBER_CONFLICT, INVALID_UPDATE ->
                    result(ClanMembershipChangeResult.Status.INVALID_MEMBERSHIP_STATE);
        };
    }

    private static int countDeputyModerators(Clan clan, UUID deputyId) {
        return (int) clan.members().values().stream()
                .filter(member -> member.role() == ClanRole.MODERATOR
                        && deputyId.equals(member.appointedByDeputyId())).count();
    }

    private static Clan copyWithMembers(Clan clan, Map<UUID, ClanMember> members) {
        return new Clan(clan.id(), clan.name(), clan.tag(), clan.createdAt(),
                clan.capacity(), members, clan.totalXp(), clan.tagline());
    }

    private static ClanMembershipChangeResult result(ClanMembershipChangeResult.Status status) {
        return new ClanMembershipChangeResult(status, Optional.empty());
    }
}

package com.skyworldclans.clan.policy;

import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanRequestExpiryPolicyTest {

    private static final Instant CREATED_AT = Instant.parse("2026-01-01T00:00:00Z");

    @Test
    void invitationIsActiveOneSecondBeforeExpiry() {
        Instant oneSecondBeforeExpiry = CREATED_AT.plusSeconds(119);

        assertTrue(ClanRequestExpiryPolicy.isInvitationActive(CREATED_AT, oneSecondBeforeExpiry));
    }

    @Test
    void invitationIsInactiveAtExpiry() {
        Instant expiry = CREATED_AT.plusSeconds(120);

        assertFalse(ClanRequestExpiryPolicy.isInvitationActive(CREATED_AT, expiry));
    }

    @Test
    void invitationIsInactiveAfterExpiry() {
        Instant afterExpiry = CREATED_AT.plusSeconds(121);

        assertFalse(ClanRequestExpiryPolicy.isInvitationActive(CREATED_AT, afterExpiry));
    }

    @Test
    void applicationIsActiveOneSecondBeforeExpiry() {
        Instant oneSecondBeforeExpiry = CREATED_AT.plusSeconds(86_399);

        assertTrue(ClanRequestExpiryPolicy.isApplicationActive(CREATED_AT, oneSecondBeforeExpiry));
    }

    @Test
    void applicationIsInactiveAtExpiry() {
        Instant expiry = CREATED_AT.plusSeconds(86_400);

        assertFalse(ClanRequestExpiryPolicy.isApplicationActive(CREATED_AT, expiry));
    }

    @Test
    void applicationIsInactiveAfterExpiry() {
        Instant afterExpiry = CREATED_AT.plusSeconds(86_401);

        assertFalse(ClanRequestExpiryPolicy.isApplicationActive(CREATED_AT, afterExpiry));
    }

    @Test
    void invitationAndApplicationUseIndependentLifetimes() {
        Instant twoMinutesAfterCreation = CREATED_AT.plusSeconds(120);

        assertFalse(ClanRequestExpiryPolicy.isInvitationActive(CREATED_AT, twoMinutesAfterCreation));
        assertTrue(ClanRequestExpiryPolicy.isApplicationActive(CREATED_AT, twoMinutesAfterCreation));
    }

    @Test
    void rejectsNullCreatedAtForBothRequestTypes() {
        assertFalse(ClanRequestExpiryPolicy.isInvitationActive(null, CREATED_AT));
        assertFalse(ClanRequestExpiryPolicy.isApplicationActive(null, CREATED_AT));
    }

    @Test
    void rejectsNullCurrentTimeForBothRequestTypes() {
        assertFalse(ClanRequestExpiryPolicy.isInvitationActive(CREATED_AT, null));
        assertFalse(ClanRequestExpiryPolicy.isApplicationActive(CREATED_AT, null));
    }

    @Test
    void evaluatesUsingTheInstantsProvidedByTheCaller() {
        Instant firstCreation = Instant.parse("2020-05-10T12:00:00Z");
        Instant secondCreation = Instant.parse("2035-09-20T08:30:00Z");

        assertTrue(ClanRequestExpiryPolicy.isInvitationActive(
                firstCreation, firstCreation.plusSeconds(119)));
        assertTrue(ClanRequestExpiryPolicy.isInvitationActive(
                secondCreation, secondCreation.plusSeconds(119)));
        assertFalse(ClanRequestExpiryPolicy.isApplicationActive(
                firstCreation, firstCreation.plusSeconds(86_400)));
        assertFalse(ClanRequestExpiryPolicy.isApplicationActive(
                secondCreation, secondCreation.plusSeconds(86_400)));
    }
}

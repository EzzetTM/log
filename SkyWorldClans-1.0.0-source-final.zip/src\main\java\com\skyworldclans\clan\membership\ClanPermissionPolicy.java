package com.skyworldclans.clan.membership;

public final class ClanPermissionPolicy {

    public boolean hasPermission(ClanRole role, ClanPermission permission) {
        if (role == null || permission == null) {
            return false;
        }

        return switch (permission) {
            case BANK_DEPOSIT, HOME_TELEPORT, STORAGE_USE, TASK_CONTRIBUTE ->
                    true;
            case BANK_WITHDRAW, BANK_REVIEW_WITHDRAWAL, STORAGE_BUY_PAGE ->
                    role == ClanRole.LEADER;
            case BANK_REQUEST_WITHDRAWAL ->
                    role == ClanRole.DEPUTY;
            case BANK_PERSONAL_PAYOUT, BANK_CLAN_REWARD, HOME_SET_OR_RENAME, HOME_DELETE,
                    CHAT_UNMUTE, WARNING_DELETE, TOURNAMENT_REGISTER, MEMBER_REMOVE ->
                    role == ClanRole.LEADER || role == ClanRole.DEPUTY;
            case CHAT_MUTE, CHAT_VIEW_ACTIVE_MUTES ->
                    role == ClanRole.LEADER || role == ClanRole.DEPUTY || role == ClanRole.MODERATOR;
        };
    }
}

package com.skyworldclans.clan.election;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.service.ClanMembershipService;
import com.skyworldclans.clan.service.ClanMembershipChangeResult;
import com.skyworldclans.clan.request.ClanRequest;
import com.skyworldclans.clan.request.ClanRequestStore;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanElectionServiceTest {
    @TempDir Path temporaryDirectory;

    @Test
    void deputyCannotStartCoupBeforeThirtyFullDaysOfInactivity() {
        UUID leader = id(701), deputy = id(702), member = id(703);
        Clan clan = clan(701, Map.of(
                leader, member(leader, ClanRole.LEADER),
                deputy, member(deputy, ClanRole.DEPUTY),
                member, member(member, ClanRole.MEMBER)));
        Instant now = Instant.parse("2026-03-01T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("coup-too-early.sqlite"))) {
            assertEquals(com.skyworldclans.clan.catalog.ClanCatalog.RegistrationStatus.REGISTERED,
                    store.registerIfAvailable(clan));
            store.recordPlayerActivity(leader, now.minusSeconds(29L * 24 * 60 * 60));
            ClanElectionService service = new ClanElectionService(store, store,
                    new ClanMembershipService(store), java.time.Clock.fixed(now, java.time.ZoneId.of("UTC")), UUID::randomUUID);
            assertEquals(ClanElectionService.StartResult.INACTIVITY_REQUIREMENT_NOT_MET,
                    service.startCoup(clan.id(), deputy));
            assertTrue(service.activeElection(clan.id()).isEmpty());
        }
    }

    @Test
    void coupCandidatesArePersistedAndOnlyDeputiesMayInitiate() {
        UUID leader = id(711), deputy = id(712), member = id(713);
        Clan clan = clan(711, Map.of(
                leader, member(leader, ClanRole.LEADER),
                deputy, member(deputy, ClanRole.DEPUTY),
                member, member(member, ClanRole.MEMBER)));
        Instant now = Instant.parse("2026-04-01T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("coup-success.sqlite"))) {
            assertEquals(com.skyworldclans.clan.catalog.ClanCatalog.RegistrationStatus.REGISTERED,
                    store.registerIfAvailable(clan));
            store.recordPlayerActivity(leader, now.minusSeconds(31L * 24 * 60 * 60));
            ClanElectionService service = new ClanElectionService(store, store,
                    new ClanMembershipService(store), java.time.Clock.fixed(now, java.time.ZoneId.of("UTC")), UUID::randomUUID);
            assertEquals(ClanElectionService.StartResult.NOT_AUTHORIZED, service.startCoup(clan.id(), member));
            assertEquals(ClanElectionService.StartResult.STARTED, service.startCoup(clan.id(), deputy));
            var election = service.activeElection(clan.id()).orElseThrow();
            assertEquals(ClanElection.Type.COUP, election.type());
            assertTrue(election.candidates().contains(leader));
            assertTrue(election.candidates().contains(deputy));
            assertEquals(ClanElectionService.StartResult.ACTIVE_ELECTION_EXISTS,
                    service.startCoup(clan.id(), deputy));
        }
    }

    @Test
    void leaderWhoWinsCoupMustWaitAnotherThirtyDaysBeforeNextCoup() {
        UUID leader = id(721), deputy = id(722);
        Clan clan = clan(721, Map.of(leader, member(leader, ClanRole.LEADER),
                deputy, member(deputy, ClanRole.DEPUTY)));
        Instant start = Instant.parse("2026-05-01T00:00:00Z");
        MutableClock clock = new MutableClock(start);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("coup-cooldown.sqlite"))) {
            assertEquals(com.skyworldclans.clan.catalog.ClanCatalog.RegistrationStatus.REGISTERED,
                    store.registerIfAvailable(clan));
            store.recordPlayerActivity(leader, start.minusSeconds(31L * 24 * 60 * 60));
            ClanElectionService service = new ClanElectionService(store, store,
                    new ClanMembershipService(store), clock, UUID::randomUUID);
            assertEquals(ClanElectionService.StartResult.STARTED, service.startCoup(clan.id(), deputy));
            var election = service.activeElection(clan.id()).orElseThrow();
            assertEquals(SqliteClanStore.ElectionVoteStatus.VOTED, store.castElectionVote(
                    election.id(), "LOCAL", leader, leader, start.plusSeconds(1)));
            Instant completedAt = start.plus(java.time.Duration.ofHours(25));
            clock.set(completedAt);
            assertEquals(ClanElectionService.ResolutionResult.COMPLETED, service.resolveIfDue(clan.id()));
            clock.set(completedAt.plus(java.time.Duration.ofDays(29)));
            assertEquals(ClanElectionService.StartResult.COUP_COOLDOWN_ACTIVE,
                    service.startCoup(clan.id(), deputy));
            clock.set(completedAt.plus(java.time.Duration.ofDays(30)));
            assertEquals(ClanElectionService.StartResult.STARTED, service.startCoup(clan.id(), deputy));
        }
    }

    @Test
    void aTieAfterGlobalBallotRemainsActiveWithoutInventingAWinner() {
        UUID leader = id(731), deputyA = id(732), deputyB = id(733);
        UUID globalA = id(734), globalB = id(735);
        Clan clan = clan(731, Map.of(leader, member(leader, ClanRole.LEADER),
                deputyA, member(deputyA, ClanRole.DEPUTY),
                deputyB, member(deputyB, ClanRole.DEPUTY)));
        Instant start = Instant.parse("2026-06-01T00:00:00Z");
        MutableClock clock = new MutableClock(start);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("election-final-tie.sqlite"))) {
            assertEquals(com.skyworldclans.clan.catalog.ClanCatalog.RegistrationStatus.REGISTERED,
                    store.registerIfAvailable(clan));
            ClanElectionService service = new ClanElectionService(store, store,
                    new ClanMembershipService(store), clock, UUID::randomUUID);
            assertEquals(ClanElectionService.StartResult.STARTED, service.startDeparture(clan.id(), leader));
            var election = service.activeElection(clan.id()).orElseThrow();
            assertEquals(ClanElectionService.VoteResult.VOTED,
                    service.vote(clan.id(), deputyA, deputyA, false));
            assertEquals(ClanElectionService.VoteResult.VOTED,
                    service.vote(clan.id(), deputyB, deputyB, false));
            clock.set(start.plus(java.time.Duration.ofHours(24)));
            assertEquals(ClanElectionService.ResolutionResult.GLOBAL_TIE_BREAK_STARTED,
                    service.resolveIfDue(clan.id()));
            assertEquals(ClanElectionService.VoteResult.VOTED,
                    service.vote(clan.id(), globalA, deputyA, true));
            assertEquals(ClanElectionService.VoteResult.VOTED,
                    service.vote(clan.id(), globalB, deputyB, true));
            clock.set(start.plus(java.time.Duration.ofHours(30)));
            assertEquals(ClanElectionService.ResolutionResult.GLOBAL_TIE_REMAINS_TIED,
                    service.resolveIfDue(clan.id()));
            assertEquals(ClanElection.Phase.GLOBAL_TIE_BREAK,
                    service.activeElection(clan.id()).orElseThrow().phase());
            assertTrue(store.findById(clan.id()).orElseThrow().member(leader).isPresent());
            assertTrue(service.hasActiveElection(clan.id()));
            assertTrue(service.isBlockedForOwnerDecision(clan.id()));
            assertEquals(ClanElectionService.VoteResult.PHASE_CLOSED,
                    service.vote(clan.id(), globalA, deputyA, true));
            assertTrue(store.dueElectionClanIds(clock.instant()).isEmpty());
            assertEquals(ClanMembershipChangeResult.Status.ELECTION_ACTIVE,
                    new ClanMembershipService(store).leaveClan(deputyA, true).status());
            assertEquals(ClanRequestStore.CreateStatus.ELECTION_ACTIVE, store.createRequest(new ClanRequest(
                    id(736), ClanRequest.Type.INVITATION, clan.id(), id(737), deputyA,
                    clock.instant(), clock.instant().plusSeconds(120), ClanRequest.Status.PENDING)));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(temporaryDirectory.resolve("election-final-tie.sqlite"))) {
            assertTrue(reopened.isElectionBlockedForOwnerDecision(clan.id()));
            assertTrue(reopened.findActiveElection(clan.id()).isPresent());
            assertTrue(reopened.dueElectionClanIds(clock.instant()).isEmpty());
        }
    }

    private static Clan clan(int number, Map<UUID, ClanMember> members) {
        return new Clan(id(number), "CoupClan" + number, "CC" + number,
                Instant.parse("2025-01-01T00:00:00Z"), 10, members, 0, null);
    }

    private static ClanMember member(UUID id, ClanRole role) {
        return new ClanMember(id, role, Instant.parse("2025-01-01T00:00:00Z"), null);
    }

    private static UUID id(long value) { return new UUID(0, value); }


    private static final class MutableClock extends java.time.Clock {
        private Instant current;
        private MutableClock(Instant current) { this.current = current; }
        void set(Instant instant) { this.current = instant; }
        @Override public java.time.ZoneId getZone() { return java.time.ZoneId.of("UTC"); }
        @Override public java.time.Clock withZone(java.time.ZoneId zone) { return this; }
        @Override public Instant instant() { return current; }
    }

}

package com.skyworldclans.gui;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.ClanStorageService;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.storage.StorageSnapshotCodec;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * 54-slot clan storage GUI backed by the durable escrow protocol in {@link SqliteClanStore}.
 *
 * <p>The page inventory is virtual and the database page is authoritative. Every deposit or
 * withdrawal follows the same order: persist a PREPARED operation with before/after player and
 * page snapshots, mutate the live inventory, then resolve the operation by comparing the live
 * inventory with the persisted snapshot. A crash between the two durable steps is recovered on
 * join: an unchanged inventory aborts the operation, the exact after snapshot commits it, and
 * anything else is frozen for manual review. Items are never re-issued automatically.</p>
 */
public final class ClanStorageGui implements Listener {
    public static final int PAGE_SLOTS = 54;
    public static final int PLAYER_STORAGE_SLOTS = 36;
    public static final int MENU_SIZE = 27;

    private final SkyWorldClansPlugin plugin;
    private final ClanStorageService storage;
    private final SqliteClanStore store;
    private final Map<UUID, OpenPage> openPages = new ConcurrentHashMap<>();

    public ClanStorageGui(SkyWorldClansPlugin plugin, ClanStorageService storage, SqliteClanStore store) {
        this.plugin = plugin;
        this.storage = storage;
        this.store = store;
    }

    public boolean openMenu(Player player) {
        Clan clan = store.findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            player.sendMessage(prefix().append(Component.text("Ты не состоишь в клане.", NamedTextColor.RED)));
            return false;
        }
        int pageCount;
        try {
            pageCount = store.clanStoragePageCount(clan.id());
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Could not read clan storage menu for " + clan.id(), exception);
            player.sendMessage(prefix().append(Component.text("Хранилище временно недоступно.", NamedTextColor.RED)));
            return false;
        }
        if (pageCount < 1) {
            player.sendMessage(prefix().append(Component.text("Хранилище клана ещё не инициализировано.", NamedTextColor.RED)));
            return false;
        }
        MenuHolder holder = new MenuHolder(clan.id());
        Inventory inventory = Bukkit.createInventory(holder, MENU_SIZE,
                Component.text("Хранилище " + clan.tag(), NamedTextColor.DARK_AQUA));
        holder.inventory = inventory;
        for (int page = 1; page <= Math.min(pageCount, 10); page++) {
            inventory.setItem(page - 1, button(Material.BOOK, "Страница " + page,
                    List.of("Открыть страницу хранилища", "54 слота"), NamedTextColor.AQUA));
        }
        boolean leader = clan.member(player.getUniqueId())
                .map(member -> member.role() == ClanRole.LEADER).orElse(false);
        if (pageCount < ClanStorageService.MAX_PAGES) {
            List<String> lore = new ArrayList<>();
            lore.add("Следующая страница: " + (pageCount + 1));
            lore.add("Покупка списывается из банка клана");
            lore.add(leader ? "Нажми, чтобы купить" : "Покупать может только лидер");
            inventory.setItem(22, button(Material.EMERALD, "Купить страницу " + (pageCount + 1),
                    lore, leader ? NamedTextColor.GREEN : NamedTextColor.GRAY));
        } else {
            inventory.setItem(22, button(Material.BARRIER, "Все страницы куплены",
                    List.of("Максимум: " + ClanStorageService.MAX_PAGES), NamedTextColor.GRAY));
        }
        inventory.setItem(23, button(Material.CHEST, "Информация",
                List.of("Страниц: " + pageCount + "/" + ClanStorageService.MAX_PAGES,
                        "Каждая страница: 54 слота",
                        "Предметы хранятся в SQLite"), NamedTextColor.YELLOW));
        inventory.setItem(26, button(Material.OAK_DOOR, "Закрыть", List.of(), NamedTextColor.RED));
        player.openInventory(inventory);
        return true;
    }

    public boolean openPage(Player player, int pageNumber) {
        Clan clan = store.findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            player.sendMessage(prefix().append(Component.text("Ты не состоишь в клане.", NamedTextColor.RED)));
            return false;
        }
        int count;
        try {
            count = store.clanStoragePageCount(clan.id());
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Could not read clan storage page count for " + clan.id(), exception);
            player.sendMessage(prefix().append(Component.text("Хранилище временно недоступно.", NamedTextColor.RED)));
            return false;
        }
        if (pageNumber < 1 || pageNumber > count) {
            player.sendMessage(prefix().append(Component.text(
                    "Страница " + pageNumber + " не куплена. Открыто страниц: " + count + ".", NamedTextColor.RED)));
            return false;
        }
        SqliteClanStore.ClanStoragePage page;
        try {
            page = store.findClanStoragePage(clan.id(), pageNumber).orElse(null);
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Could not read clan storage page " + pageNumber
                    + " for " + clan.id(), exception);
            player.sendMessage(prefix().append(Component.text("Не удалось прочитать страницу.", NamedTextColor.RED)));
            return false;
        }
        if (page == null) {
            player.sendMessage(prefix().append(Component.text("Страница не найдена.", NamedTextColor.RED)));
            return false;
        }
        ItemStack[] items;
        try {
            items = StorageSnapshotCodec.decode(page.contents(), PAGE_SLOTS);
        } catch (StorageSnapshotCodec.CorruptSnapshotException exception) {
            plugin.getLogger().log(Level.SEVERE, "Clan storage page " + pageNumber + " of clan "
                    + clan.id() + " has a corrupt snapshot; editing blocked", exception);
            player.sendMessage(prefix().append(Component.text(
                    "Содержимое страницы повреждено. Редактирование заблокировано, обратись к администрации.",
                    NamedTextColor.RED)));
            return false;
        }
        PageHolder holder = new PageHolder(clan.id(), pageNumber, page.revision());
        Inventory inventory = Bukkit.createInventory(holder, PAGE_SLOTS,
                Component.text("Хранилище " + clan.tag() + " — стр. " + pageNumber + "/" + count,
                        NamedTextColor.DARK_AQUA));
        holder.inventory = inventory;
        inventory.setContents(items);
        openPages.put(player.getUniqueId(), new OpenPage(clan.id(), pageNumber));
        player.openInventory(inventory);
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory top = event.getView().getTopInventory();
        if (top.getHolder() instanceof MenuHolder menu) {
            event.setCancelled(true);
            handleMenuClick(player, menu, event);
            return;
        }
        if (!(top.getHolder() instanceof PageHolder pageHolder)) return;
        if (pageHolder.clanId == null || !player.getUniqueId().equals(player.getUniqueId())) return;
        Inventory clicked = event.getClickedInventory();
        if (clicked == null) {
            event.setCancelled(true);
            return;
        }
        if (clicked.equals(top)) {
            event.setCancelled(true);
            handleWithdrawal(player, pageHolder, event);
            return;
        }
        // Clicks in the player's own inventory are only intercepted for deposits.
        if (event.isShiftClick() || event.getClick() == ClickType.SWAP_OFFHAND) {
            event.setCancelled(true);
            handleDeposit(player, pageHolder, event);
        }
    }

    private void handleMenuClick(Player player, MenuHolder menu, InventoryClickEvent event) {
        int slot = event.getSlot();
        if (slot == 26) {
            player.closeInventory();
            return;
        }
        int pageCount;
        try {
            pageCount = store.clanStoragePageCount(menu.clanId);
        } catch (RuntimeException exception) {
            player.sendMessage(prefix().append(Component.text("Хранилище временно недоступно.", NamedTextColor.RED)));
            return;
        }
        if (slot >= 0 && slot < 10 && slot + 1 <= pageCount) {
            openPage(player, slot + 1);
            return;
        }
        if (slot == 22) {
            if (pageCount >= ClanStorageService.MAX_PAGES) {
                player.sendMessage(prefix().append(Component.text("Все 10 страниц уже куплены.", NamedTextColor.YELLOW)));
                return;
            }
            ClanStorageService.PurchaseResult result = storage.purchasePage(
                    player.getUniqueId(), pageCount + 1, Instant.now());
            switch (result.status()) {
                case PURCHASED -> {
                    player.sendMessage(prefix().append(Component.text("Страница " + (pageCount + 1)
                            + " куплена за " + result.purchase().chargedPrice().toPlainString()
                            + " (скидка " + result.purchase().discountPercent() + "%).", NamedTextColor.GREEN)));
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
                    openMenu(player);
                }
                case LEADER_ONLY -> player.sendMessage(prefix().append(Component.text(
                        "Покупать страницы может только лидер.", NamedTextColor.RED)));
                case INSUFFICIENT_FUNDS -> player.sendMessage(prefix().append(Component.text(
                        "В банке клана недостаточно средств.", NamedTextColor.RED)));
                case MAX_PAGES -> player.sendMessage(prefix().append(Component.text(
                        "Достигнут максимум: 10 страниц.", NamedTextColor.RED)));
                case ALREADY_PURCHASED -> player.sendMessage(prefix().append(Component.text(
                        "Эта страница уже куплена.", NamedTextColor.YELLOW)));
                case INVALID_PAGE -> player.sendMessage(prefix().append(Component.text(
                        "Страницы покупаются последовательно.", NamedTextColor.RED)));
                case STORAGE_ERROR, STORAGE_CORRUPT, BANK_NOT_INITIALIZED -> player.sendMessage(prefix().append(
                        Component.text("Покупка не выполнена: " + result.status() + ".", NamedTextColor.RED)));
                default -> player.sendMessage(prefix().append(Component.text(
                        "Покупка не выполнена: " + result.status() + ".", NamedTextColor.RED)));
            }
        }
    }

    private void handleWithdrawal(Player player, PageHolder holder, InventoryClickEvent event) {
        ItemStack displayed = event.getCurrentItem();
        if (displayed == null || displayed.getType().isAir()) return;
        int amount = event.getClick().isRightClick()
                ? Math.max(1, (displayed.getAmount() + 1) / 2) : displayed.getAmount();
        Instant now = Instant.now().plusMillis(1);

        SqliteClanStore.ClanStoragePage page;
        ItemStack[] pageItems;
        ItemStack[] beforeFull;
        ItemStack[] afterFull;
        try {
            page = store.findClanStoragePage(holder.clanId, holder.pageNumber).orElse(null);
            if (page == null) {
                player.sendMessage(prefix().append(Component.text("Страница больше не существует.", NamedTextColor.RED)));
                player.closeInventory();
                return;
            }
            pageItems = StorageSnapshotCodec.decode(page.contents(), PAGE_SLOTS);
            if (pageItems[event.getSlot()] == null) {
                refresh(player, holder);
                return;
            }
            beforeFull = player.getInventory().getContents();
            afterFull = cloneContents(beforeFull);
            ItemStack moving = pageItems[event.getSlot()].clone();
            moving.setAmount(amount);
            if (!canAddToPlayerStorage(afterFull, moving)) {
                player.sendMessage(prefix().append(Component.text(
                        "В инвентаре недостаточно места для этого предмета.", NamedTextColor.RED)));
                return;
            }
            addToPlayerStorage(afterFull, moving);
            ItemStack remaining = pageItems[event.getSlot()].clone();
            int remainingAmount = remaining.getAmount() - amount;
            if (remainingAmount <= 0) {
                pageItems[event.getSlot()] = null;
            } else {
                remaining.setAmount(remainingAmount);
                pageItems[event.getSlot()] = remaining;
            }
            executeTransfer(player, holder, page, pageItems, beforeFull, afterFull,
                    moving, amount, "WITHDRAWAL", now);
        } catch (StorageSnapshotCodec.CorruptSnapshotException exception) {
            plugin.getLogger().log(Level.SEVERE, "Corrupt storage page during withdrawal for " + holder.clanId, exception);
            player.sendMessage(prefix().append(Component.text(
                    "Содержимое страницы повреждено; операция отменена.", NamedTextColor.RED)));
            player.closeInventory();
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Clan storage withdrawal failed for " + player.getUniqueId(), exception);
            player.sendMessage(prefix().append(Component.text(
                    "Ошибка хранилища; операция не выполнена.", NamedTextColor.RED)));
        }
    }

    private void handleDeposit(Player player, PageHolder holder, InventoryClickEvent event) {
        if (event.getClickedInventory() == null
                || event.getClickedInventory().equals(event.getView().getTopInventory())) return;
        int rawSlot = event.getRawSlot();
        int playerSlot = rawSlot - PAGE_SLOTS;
        if (playerSlot < 0 || playerSlot >= PLAYER_STORAGE_SLOTS) {
            player.sendMessage(prefix().append(Component.text(
                    "Складывать можно только предметы из основного инвентаря.", NamedTextColor.RED)));
            return;
        }
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return;
        boolean one = event.getClick() == ClickType.SHIFT_RIGHT;
        int amount = one ? 1 : clicked.getAmount();
        Instant now = Instant.now().plusMillis(1);
        try {
            SqliteClanStore.ClanStoragePage page = store.findClanStoragePage(holder.clanId, holder.pageNumber)
                    .orElse(null);
            if (page == null) {
                player.sendMessage(prefix().append(Component.text("Страница больше не существует.", NamedTextColor.RED)));
                player.closeInventory();
                return;
            }
            ItemStack[] pageItems = StorageSnapshotCodec.decode(page.contents(), PAGE_SLOTS);
            ItemStack moving = clicked.clone();
            moving.setAmount(amount);
            ItemStack[] afterPageItems = cloneContents(pageItems);
            if (!addToPageStorage(afterPageItems, moving)) {
                player.sendMessage(prefix().append(Component.text(
                        "На этой странице нет места для предмета.", NamedTextColor.RED)));
                return;
            }
            ItemStack[] beforeFull = player.getInventory().getContents();
            ItemStack[] afterFull = cloneContents(beforeFull);
            ItemStack stackInSlot = afterFull[playerSlot];
            if (stackInSlot == null || !stackInSlot.isSimilar(clicked)) {
                refresh(player, holder);
                return;
            }
            int remaining = stackInSlot.getAmount() - amount;
            if (remaining <= 0) {
                afterFull[playerSlot] = null;
            } else {
                ItemStack reduced = stackInSlot.clone();
                reduced.setAmount(remaining);
                afterFull[playerSlot] = reduced;
            }
            executeTransfer(player, holder, page, afterPageItems, beforeFull, afterFull,
                    moving, amount, "DEPOSIT", now);
        } catch (StorageSnapshotCodec.CorruptSnapshotException exception) {
            plugin.getLogger().log(Level.SEVERE, "Corrupt storage page during deposit for " + holder.clanId, exception);
            player.sendMessage(prefix().append(Component.text(
                    "Содержимое страницы повреждено; операция отменена.", NamedTextColor.RED)));
            player.closeInventory();
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Clan storage deposit failed for " + player.getUniqueId(), exception);
            player.sendMessage(prefix().append(Component.text(
                    "Ошибка хранилища; операция не выполнена.", NamedTextColor.RED)));
        }
    }

    /**
     * Runs the durable two-phase item transfer. The player inventory must not be changed before
     * the PREPARED escrow row is committed by SQLite.
     */
    private void executeTransfer(Player player, PageHolder holder, SqliteClanStore.ClanStoragePage page,
            ItemStack[] afterPageItems, ItemStack[] beforeFull, ItemStack[] afterFull,
            ItemStack moving, int amount, String movementType, Instant now) {
        byte[] beforePlayerBytes = StorageSnapshotCodec.encode(beforeFull, beforeFull.length);
        byte[] afterPlayerBytes = StorageSnapshotCodec.encode(afterFull, afterFull.length);
        byte[] afterPageBytes = StorageSnapshotCodec.encode(afterPageItems, PAGE_SLOTS);
        UUID operationId = UUID.randomUUID();
        String itemType = moving.getType().getKey().toString();

        SqliteClanStore.ClanStorageTransferResult prepared = storage.prepareTransfer(
                operationId, player.getUniqueId(), holder.pageNumber, movementType, itemType, amount,
                page.revision(), beforePlayerBytes, afterPlayerBytes, page.contents(), afterPageBytes, now);
        switch (prepared.status()) {
            case PREPARED -> { }
            case REVISION_CONFLICT, PAGE_CONTENT_CONFLICT -> {
                player.sendMessage(prefix().append(Component.text(
                        "Страница изменилась другим игроком. Открой её заново.", NamedTextColor.YELLOW)));
                refresh(player, holder);
                return;
            }
            case BUSY -> {
                player.sendMessage(prefix().append(Component.text(
                        "По этой странице уже выполняется операция. Повтори через секунду.", NamedTextColor.YELLOW)));
                return;
            }
            case NOT_A_MEMBER, CLAN_NOT_FOUND -> {
                player.sendMessage(prefix().append(Component.text("Ты больше не состоишь в клане.", NamedTextColor.RED)));
                player.closeInventory();
                return;
            }
            default -> {
                player.sendMessage(prefix().append(Component.text(
                        "Операция отклонена: " + prepared.status() + ".", NamedTextColor.RED)));
                return;
            }
        }

        // Durable intent exists. Apply the exact after snapshot to the live inventory, then
        // resolve using the live snapshot. Any failure here is recoverable on the next join.
        try {
            player.getInventory().setContents(afterFull);
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Could not apply after-inventory snapshot for operation "
                    + operationId + "; leaving it PREPARED for recovery", exception);
            player.sendMessage(prefix().append(Component.text(
                    "Не удалось применить изменение инвентаря. Операция будет восстановлена при входе.",
                    NamedTextColor.RED)));
            player.closeInventory();
            return;
        }

        SqliteClanStore.ClanStorageTransferResult resolved;
        try {
            byte[] observed = StorageSnapshotCodec.encode(player.getInventory().getContents(),
                    player.getInventory().getContents().length);
            resolved = storage.resolveTransfer(operationId, player.getUniqueId(),
                    observed, now.plusMillis(1));
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Clan storage operation " + operationId
                    + " could not be resolved; it remains durably PREPARED and will be recovered on join", exception);
            player.sendMessage(prefix().append(Component.text(
                    "Операция сохранена, но подтверждение не получено. Не повторяй её; состояние будет восстановлено при входе.",
                    NamedTextColor.RED)));
            player.closeInventory();
            return;
        }

        switch (resolved.status()) {
            case COMMITTED -> {
                player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.6f, 1.2f);
                refresh(player, holder);
                player.sendMessage(prefix().append(Component.text(
                        movementType.equals("DEPOSIT")
                                ? "Предметы помещены в хранилище клана."
                                : "Предметы выданы из хранилища клана.", NamedTextColor.GREEN)));
            }
            case ABORTED -> {
                // Defensive: resolve only aborts when the live inventory still matches BEFORE.
                player.getInventory().setContents(beforeFull);
                refresh(player, holder);
                player.sendMessage(prefix().append(Component.text(
                        "Операция отменена; предметы не перемещены.", NamedTextColor.YELLOW)));
            }
            case MANUAL_REVIEW -> {
                plugin.getLogger().severe("Clan storage operation " + operationId
                        + " requires MANUAL REVIEW; actor=" + player.getUniqueId()
                        + ", clan=" + holder.clanId + ", page=" + holder.pageNumber);
                player.closeInventory();
                player.sendMessage(prefix().append(Component.text(
                        "Операция требует проверки администрацией. Не повторяй её.", NamedTextColor.RED)));
                notifyAdministrators("Операция хранилища " + operationId + " требует ручной проверки.");
            }
            default -> {
                plugin.getLogger().severe("Clan storage operation " + operationId
                        + " resolved with " + resolved.status() + "; leaving state for review");
                player.closeInventory();
                player.sendMessage(prefix().append(Component.text(
                        "Операция не подтверждена. Не повторяй её; обратись к администрации.", NamedTextColor.RED)));
            }
        }
    }

    private void refresh(Player player, PageHolder holder) {
        try {
            SqliteClanStore.ClanStoragePage page = store.findClanStoragePage(holder.clanId, holder.pageNumber)
                    .orElse(null);
            if (page == null) {
                player.closeInventory();
                return;
            }
            ItemStack[] items = StorageSnapshotCodec.decode(page.contents(), PAGE_SLOTS);
            Inventory top = player.getOpenInventory().getTopInventory();
            if (top.getHolder() instanceof PageHolder current && current.clanId.equals(holder.clanId)
                    && current.pageNumber == holder.pageNumber) {
                top.setContents(items);
                current.revision = page.revision();
                openPages.put(player.getUniqueId(), new OpenPage(holder.clanId, holder.pageNumber));
            }
            closeOtherViewers(player, holder.clanId, holder.pageNumber);
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Could not refresh clan storage page for " + player.getUniqueId(), exception);
        }
    }

    private void closeOtherViewers(Player actor, UUID clanId, int pageNumber) {
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.getUniqueId().equals(actor.getUniqueId())) continue;
            OpenPage open = openPages.get(online.getUniqueId());
            if (open == null || !open.clanId.equals(clanId) || open.pageNumber != pageNumber) continue;
            if (online.getOpenInventory().getTopInventory().getHolder() instanceof PageHolder) {
                online.closeInventory();
                online.sendMessage(prefix().append(Component.text(
                        "Содержимое страницы хранилища изменилось. Открой её заново.", NamedTextColor.YELLOW)));
            }
            openPages.remove(online.getUniqueId());
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            openPages.remove(player.getUniqueId());
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        openPages.remove(event.getEntity().getUniqueId());
        event.getEntity().closeInventory();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        recoverPendingFor(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        openPages.remove(event.getPlayer().getUniqueId());
        recoverPendingFor(event.getPlayer());
    }

    /** Resolves PREPARED escrow rows before the player is allowed to use the storage again. */
    public void recoverPendingFor(Player player) {
        List<SqliteClanStore.ClanStorageTransferOperation> pending;
        try {
            pending = store.pendingClanStorageTransfers(player.getUniqueId());
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Could not read pending storage transfers for "
                    + player.getUniqueId(), exception);
            return;
        }
        for (SqliteClanStore.ClanStorageTransferOperation operation : pending) {
            try {
                byte[] observed = StorageSnapshotCodec.encode(player.getInventory().getContents(),
                        player.getInventory().getContents().length);
                SqliteClanStore.ClanStorageTransferResult result = storage.resolveTransfer(
                        operation.operationId(), player.getUniqueId(), observed, Instant.now());
                switch (result.status()) {
                    case COMMITTED -> player.sendMessage(prefix().append(Component.text(
                            "Незавершённая операция хранилища подтверждена и завершена.", NamedTextColor.GREEN)));
                    case ABORTED -> player.sendMessage(prefix().append(Component.text(
                            "Незавершённая операция хранилища отменена без перемещения предметов.",
                            NamedTextColor.YELLOW)));
                    case MANUAL_REVIEW -> {
                        plugin.getLogger().severe("Storage transfer " + operation.operationId()
                                + " requires manual review for " + player.getUniqueId());
                        notifyAdministrators("Операция хранилища " + operation.operationId()
                                + " требует ручной проверки (" + player.getName() + ").");
                        player.sendMessage(prefix().append(Component.text(
                                "Незавершённая операция хранилища требует проверки администрацией.",
                                NamedTextColor.RED)));
                    }
                    default -> plugin.getLogger().warning("Storage transfer recovery for "
                            + operation.operationId() + " returned " + result.status());
                }
            } catch (RuntimeException exception) {
                plugin.getLogger().log(Level.SEVERE, "Could not recover storage transfer "
                        + operation.operationId(), exception);
            }
        }
    }

    /** Called during plugin shutdown, while players and the database are still available. */
    public void shutdown() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            recoverPendingFor(player);
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof PageHolder) {
                player.closeInventory();
            }
        }
        openPages.clear();
    }

    public List<SqliteClanStore.ClanStorageTransferOperation> transfersForReview(int limit) {
        return store.clanStorageTransfersRequiringReview(limit);
    }

    private void notifyAdministrators(String message) {
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.hasPermission("skyworldclans.admin")) {
                online.sendMessage(prefix().append(Component.text(message, NamedTextColor.RED)));
            }
        }
    }

    private static boolean canAddToPlayerStorage(ItemStack[] contents, ItemStack item) {
        int remaining = item.getAmount();
        int max = Math.max(1, item.getMaxStackSize());
        for (int index = 0; index < PLAYER_STORAGE_SLOTS && remaining > 0; index++) {
            ItemStack slot = contents[index];
            if (slot == null || slot.getType().isAir()) {
                remaining -= Math.min(max, remaining);
            } else if (slot.isSimilar(item) && slot.getAmount() < max) {
                remaining -= Math.min(max - slot.getAmount(), remaining);
            }
        }
        return remaining <= 0;
    }

    private static void addToPlayerStorage(ItemStack[] contents, ItemStack item) {
        int remaining = item.getAmount();
        int max = Math.max(1, item.getMaxStackSize());
        for (int index = 0; index < PLAYER_STORAGE_SLOTS && remaining > 0; index++) {
            ItemStack slot = contents[index];
            if (slot == null || slot.getType().isAir()) {
                ItemStack placed = item.clone();
                placed.setAmount(Math.min(max, remaining));
                contents[index] = placed;
                remaining -= placed.getAmount();
            } else if (slot.isSimilar(item) && slot.getAmount() < max) {
                int moved = Math.min(max - slot.getAmount(), remaining);
                ItemStack merged = slot.clone();
                merged.setAmount(slot.getAmount() + moved);
                contents[index] = merged;
                remaining -= moved;
            }
        }
        if (remaining > 0) throw new IllegalStateException("Player storage simulation lost items");
    }

    private static boolean addToPageStorage(ItemStack[] contents, ItemStack item) {
        int remaining = item.getAmount();
        int max = Math.max(1, item.getMaxStackSize());
        for (int index = 0; index < PAGE_SLOTS && remaining > 0; index++) {
            ItemStack slot = contents[index];
            if (slot == null || slot.getType().isAir()) {
                ItemStack placed = item.clone();
                placed.setAmount(Math.min(max, remaining));
                contents[index] = placed;
                remaining -= placed.getAmount();
            } else if (slot.isSimilar(item) && slot.getAmount() < max) {
                int moved = Math.min(max - slot.getAmount(), remaining);
                ItemStack merged = slot.clone();
                merged.setAmount(slot.getAmount() + moved);
                contents[index] = merged;
                remaining -= moved;
            }
        }
        return remaining <= 0;
    }

    private static ItemStack[] cloneContents(ItemStack[] source) {
        ItemStack[] copy = new ItemStack[source.length];
        for (int index = 0; index < source.length; index++) {
            copy[index] = source[index] == null ? null : source[index].clone();
        }
        return copy;
    }

    private static ItemStack button(Material material, String name, List<String> lore, NamedTextColor color) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        if (!lore.isEmpty()) {
            List<Component> lines = new ArrayList<>();
            for (String line : lore) {
                lines.add(Component.text(line, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(lines);
        }
        item.setItemMeta(meta);
        return item;
    }

    private static Component prefix() {
        return Component.text("[Кланы] ", NamedTextColor.DARK_AQUA);
    }

    private record OpenPage(UUID clanId, int pageNumber) { }

    private static final class MenuHolder implements InventoryHolder {
        private final UUID clanId;
        private Inventory inventory;
        private MenuHolder(UUID clanId) { this.clanId = clanId; }
        @Override public Inventory getInventory() { return inventory; }
    }

    private static final class PageHolder implements InventoryHolder {
        private final UUID clanId;
        private final int pageNumber;
        private long revision;
        private Inventory inventory;
        private PageHolder(UUID clanId, int pageNumber, long revision) {
            this.clanId = clanId;
            this.pageNumber = pageNumber;
            this.revision = revision;
        }
        @Override public Inventory getInventory() { return inventory; }
    }
}

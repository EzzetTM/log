package com.skyworldclans.clan.application.purchase;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Shared local transaction boundary for the clan catalog and capacity-purchase journal.
 */
public interface CapacityPurchaseStore extends CapacityPurchaseJournal {
    /**
     * Commits clan capacity, applied business marker, state, and event together.
     * This method never calls an external economy provider.
     */
    CommitResult commitCapacityPurchase(UUID operationId);

    Optional<UUID> findAppliedOperationId(String businessOperationId);

    /**
     * Finds all operations in the given state.
     * Used by compensation recovery to find operations left in COMPENSATION_CALLING state.
     *
     * @param state the state to search for
     * @return list of operations in the given state, empty list if none found
     */
    List<CapacityPurchaseOperation> findByState(CapacityPurchaseState state);

    enum CommitStatus {
        COMMITTED,
        ALREADY_COMMITTED,
        OPERATION_NOT_FOUND,
        WRONG_STATE,
        CLAN_NOT_FOUND,
        LEADER_CHANGED,
        STATE_CONFLICT,
        BUSINESS_OPERATION_CONFLICT,
        HISTORY_EVIDENCE_UNVERIFIABLE
    }

    record CommitResult(CommitStatus status, Optional<CapacityPurchaseOperation> operation) {
        public CommitResult {
            if (status == null || operation == null) {
                throw new NullPointerException("status and operation are required");
            }
        }
    }
}

package com.skyworldclans.clan.filter;

import java.text.Normalizer;
import java.util.Locale;

public final class ForbiddenExpressionNormalizer {
    private ForbiddenExpressionNormalizer() {
    }

    public static String normalize(String value) {
        if (value == null) {
            return "";
        }

        String normalized = Normalizer.normalize(value, Normalizer.Form.NFKC)
                .toLowerCase(Locale.ROOT);
        StringBuilder compact = new StringBuilder(normalized.length());
        normalized.codePoints().forEach(codePoint -> appendNormalized(compact, codePoint));
        return compact.toString();
    }

    private static void appendNormalized(StringBuilder target, int codePoint) {
        int replacement = replacementFor(codePoint);
        if (replacement >= 0) {
            target.appendCodePoint(replacement);
            return;
        }

        if (isDiscarded(codePoint)) {
            return;
        }
        target.appendCodePoint(codePoint);
    }

    private static int replacementFor(int codePoint) {
        return switch (codePoint) {
            case '0' -> 'o';
            case '1' -> 'i';
            case '2' -> 'z';
            case '3' -> 'e';
            case '4' -> 'a';
            case '5' -> 's';
            case '6', '9' -> 'g';
            case '7' -> 't';
            case '8' -> 'b';
            case '$' -> 's';
            case '@' -> 'a';
            case '!' -> 'i';
            case 0x20AC -> 'e';
            default -> -1;
        };
    }

    private static boolean isDiscarded(int codePoint) {
        int type = Character.getType(codePoint);
        return codePoint == 'ъ'
                || codePoint == 'ь'
                || Character.isWhitespace(codePoint)
                || Character.isSpaceChar(codePoint)
                || type == Character.CONTROL
                || type == Character.FORMAT
                || type == Character.NON_SPACING_MARK
                || type == Character.COMBINING_SPACING_MARK
                || type == Character.ENCLOSING_MARK
                || type == Character.CONNECTOR_PUNCTUATION
                || type == Character.DASH_PUNCTUATION
                || type == Character.START_PUNCTUATION
                || type == Character.END_PUNCTUATION
                || type == Character.INITIAL_QUOTE_PUNCTUATION
                || type == Character.FINAL_QUOTE_PUNCTUATION
                || type == Character.OTHER_PUNCTUATION
                || type == Character.MATH_SYMBOL
                || type == Character.CURRENCY_SYMBOL
                || type == Character.MODIFIER_SYMBOL
                || type == Character.OTHER_SYMBOL;
    }
}

package com.skyworldclans.clan.request;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/** Durable invitation or join application. */
public record ClanRequest(
        UUID id,
        Type type,
        UUID clanId,
        UUID playerId,
        UUID actorId,
        Instant createdAt,
        Instant expiresAt,
        Status status) {

    public ClanRequest {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(clanId, "clanId");
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(actorId, "actorId");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(expiresAt, "expiresAt");
        Objects.requireNonNull(status, "status");
        if (!expiresAt.isAfter(createdAt)) {
            throw new IllegalArgumentException("Request expiry must be after creation");
        }
        if (type == Type.APPLICATION && !actorId.equals(playerId)) {
            throw new IllegalArgumentException("Application actor must be its applicant");
        }
    }

    public enum Type { INVITATION, APPLICATION }
    public enum Status { PENDING, ACCEPTED, DECLINED, EXPIRED, CANCELLED }
}

package com.skyworldclans.clan.application;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.ClanFactory;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.catalog.InMemoryClanCatalog;
import com.skyworldclans.clan.filter.ForbiddenExpressionField;
import com.skyworldclans.clan.filter.ForbiddenExpressionFilter;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.service.ClanRegistrationResult;
import com.skyworldclans.clan.service.ClanService;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CreateClanUseCaseTest {
    private static final UUID CREATOR_ID =
            UUID.fromString("20000000-0000-0000-0000-000000000001");
    private static final UUID CLAN_ID =
            UUID.fromString("10000000-0000-0000-0000-000000000001");
    private static final Instant NOW = Instant.parse("2026-02-01T10:15:30Z");
    private static final Clock CLOCK = Clock.fixed(NOW, ZoneOffset.UTC);

    @Test
    void preflightBuildsValidatedClanWithoutRegisteringOrMutatingCatalog() {
        Harness harness = new Harness(List.of());

        ClanCreationPreflightResult result = harness.useCase.prepare(command("Sky World", "SW1", null));

        assertEquals(ClanCreationPreflightResult.Status.READY, result.status());
        assertTrue(result.clan().isPresent());
        assertEquals(0, harness.catalog.size());
        assertEquals(0, harness.registerCalls.get());
        assertEquals(1, harness.clanIdRequests.get());
    }

    @Test
    void createsClanWithoutSlogan() {
        Harness harness = new Harness(List.of());

        CreateClanResult result = harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.CREATED, result.status());
        assertTrue(result.created());
        assertNull(result.clan().orElseThrow().tagline());
        assertEquals(1, harness.catalog.size());
        assertEquals(1, harness.registerCalls.get());
    }

    @Test
    void createsClanWithSloganAfterCheckingIt() {
        Harness harness = new Harness(List.of());

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", "Together"));

        assertEquals(CreateClanResult.Status.CREATED, result.status());
        assertEquals("Together", result.clan().orElseThrow().tagline());
        assertEquals(1, harness.catalog.size());
    }

    @Test
    void rejectsForbiddenNameBeforeRegistration() {
        assertForbidden("bad-clan", "SW1", null, ForbiddenExpressionField.NAME);
    }

    @Test
    void rejectsForbiddenTagBeforeRegistration() {
        assertForbidden("Sky World", "bad", null, ForbiddenExpressionField.TAG);
    }

    @Test
    void rejectsForbiddenSloganBeforeRegistration() {
        assertForbidden("Sky World", "SW1", "a bad slogan", ForbiddenExpressionField.SLOGAN);
    }

    @Test
    void rejectsUnavailableFilterWithoutChangingCatalog() {
        Harness harness = new Harness(null);

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.FILTER_UNAVAILABLE, result.status());
        assertNoRegistrationOrMutation(harness);
    }

    @Test
    void emptyReadyFilterAllowsCreation() {
        Harness harness = new Harness(List.of());

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.CREATED, result.status());
    }

    @Test
    void rejectsInvalidNameAndTagBeforeFilterOrRegistration() {
        Harness invalidName = new Harness(List.of("bad"));
        assertEquals(
                CreateClanResult.Status.INVALID_NAME_FORMAT,
                invalidName.useCase.create(command("ab", "SW1", null)).status());
        assertNoRegistrationOrMutation(invalidName);

        Harness invalidTag = new Harness(List.of("bad"));
        assertEquals(
                CreateClanResult.Status.INVALID_TAG_FORMAT,
                invalidTag.useCase.create(command("Sky World", "S!", null)).status());
        assertNoRegistrationOrMutation(invalidTag);
    }

    @Test
    void rejectsMissingRequiredInputsBeforeRegistration() {
        Harness harness = new Harness(List.of());

        assertEquals(
                CreateClanResult.Status.INVALID_INPUT,
                harness.useCase.create(null).status());
        assertEquals(
                CreateClanResult.Status.INVALID_INPUT,
                harness.useCase.create(new CreateClanCommand(null, "Sky World", "SW1", null))
                        .status());
        assertEquals(
                CreateClanResult.Status.INVALID_INPUT,
                harness.useCase.create(new CreateClanCommand(CREATOR_ID, null, "SW1", null))
                        .status());
        assertEquals(
                CreateClanResult.Status.INVALID_INPUT,
                harness.useCase.create(new CreateClanCommand(CREATOR_ID, "Sky World", null, null))
                        .status());
        assertNoRegistrationOrMutation(harness);
    }

    @Test
    void rejectsEmptyAndWhitespaceNameTagAndSlogan() {
        Harness harness = new Harness(List.of());

        assertEquals(
                CreateClanResult.Status.INVALID_NAME_FORMAT,
                harness.useCase.create(command("", "SW1", null)).status());
        assertEquals(
                CreateClanResult.Status.INVALID_INPUT,
                harness.useCase.create(command("   ", "SW1", null)).status());
        assertEquals(
                CreateClanResult.Status.INVALID_TAG_FORMAT,
                harness.useCase.create(command("Sky World", "", null)).status());
        assertEquals(
                CreateClanResult.Status.INVALID_TAG_FORMAT,
                harness.useCase.create(command("Sky World", "  ", null)).status());
        assertEquals(
                CreateClanResult.Status.INVALID_INPUT,
                harness.useCase.create(command("Sky World", "SW1", "")).status());
        assertEquals(
                CreateClanResult.Status.INVALID_INPUT,
                harness.useCase.create(command("Sky World", "SW1", "   ")).status());
        assertNoRegistrationOrMutation(harness);
    }

    @Test
    void rejectsCaseInsensitiveTakenTagBeforeRegistration() {
        Harness harness = new Harness(List.of());
        harness.registerExistingClan(
                UUID.randomUUID(), "Existing", "sw1", UUID.randomUUID());
        int catalogSize = harness.catalog.size();

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.TAG_TAKEN, result.status());
        assertEquals(0, harness.registerCalls.get());
        assertEquals(0, harness.clanIdRequests.get());
        assertEquals(catalogSize, harness.catalog.size());
    }

    @Test
    void rejectsCreatorAlreadyInClanBeforeRegistration() {
        Harness harness = new Harness(List.of());
        harness.registerExistingClan(UUID.randomUUID(), "Existing", "OLD", CREATOR_ID);
        int catalogSize = harness.catalog.size();

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.CREATOR_ALREADY_IN_CLAN, result.status());
        assertEquals(0, harness.registerCalls.get());
        assertEquals(0, harness.clanIdRequests.get());
        assertEquals(catalogSize, harness.catalog.size());
    }

    @Test
    void usesServiceOwnedCatalogForPrechecksAndRegistration() {
        Harness harness = new Harness(List.of());

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.CREATED, result.status());
        assertEquals(1, harness.trackingCatalog.playerLookupCalls);
        assertEquals(1, harness.trackingCatalog.tagLookupCalls);
        assertEquals(1, harness.registerCalls.get());
        assertEquals(1, harness.catalog.size());
    }

    @Test
    void reportsAtomicRegistrationConflictAfterPrechecks() {
        Harness harness = new Harness(List.of());
        harness.registrationOverride = ClanCatalog.RegistrationStatus.TAG_CONFLICT;

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.REGISTRATION_FAILED, result.status());
        assertEquals(
                Optional.of(ClanRegistrationResult.Status.TAG_CONFLICT),
                result.registrationStatus());
        assertEquals(1, harness.registerCalls.get());
        assertEquals(0, harness.catalog.size());
    }

    @Test
    void reportsAtomicIdAndMemberConflictsAfterPrechecks() {
        assertRegistrationConflict(
                ClanCatalog.RegistrationStatus.CLAN_ID_CONFLICT,
                ClanRegistrationResult.Status.CLAN_ID_CONFLICT);
        assertRegistrationConflict(
                ClanCatalog.RegistrationStatus.MEMBER_CONFLICT,
                ClanRegistrationResult.Status.MEMBER_CONFLICT);
    }

    @Test
    void preRegistrationFailuresDoNotMutateCatalogOrAttemptRegistration() {
        List<CreateClanCommand> commands = List.of(
                command("bad name", "SW1", null),
                command("Sky World", "bad", null),
                command("Sky World", "SW1", "bad"));
        List<List<String>> blockedEntries = List.of(
                List.of("bad"),
                List.of("bad"),
                List.of("bad"));

        for (int index = 0; index < commands.size(); index++) {
            Harness harness = new Harness(blockedEntries.get(index));
            CreateClanResult result = harness.useCase.create(commands.get(index));
            assertFalse(result.created());
            assertNoRegistrationOrMutation(harness);
        }
    }

    @Test
    void prechecksNameAndTagWithoutRequiringNameUniqueness() {
        Harness harness = new Harness(List.of());
        harness.registerExistingClan(UUID.randomUUID(), "Sky World", "OTHER", UUID.randomUUID());

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.CREATED, result.status());
        assertEquals(2, harness.catalog.size());
    }

    @Test
    void resultNeverContainsForbiddenExpressionText() {
        Harness harness = new Harness(List.of("bad"));

        CreateClanResult result =
                harness.useCase.create(command("bad-clan", "SW1", null));

        assertEquals(CreateClanResult.Status.FORBIDDEN_EXPRESSION, result.status());
        assertEquals(Optional.of(ForbiddenExpressionField.NAME), result.forbiddenField());
        assertFalse(result.toString().contains("bad"));
    }

    @Test
    void preservesRegistrationValidationViolationsInUseCaseResultShape() {
        List<ClanMembershipStateValidator.Violation> violations = List.of(
                ClanMembershipStateValidator.Violation.LEADER_REQUIRED_OUTSIDE_ELECTION,
                ClanMembershipStateValidator.Violation.DEPUTY_LIMIT_EXCEEDED);
        ClanRegistrationResult registration = new ClanRegistrationResult(
                ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE, violations);
        CreateClanResult result = CreateClanUseCase.registrationFailure(registration);

        assertEquals(
                Optional.of(ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE),
                result.registrationStatus());
        assertEquals(violations, result.validationViolations());
        assertThrows(UnsupportedOperationException.class,
                () -> result.validationViolations().add(
                        ClanMembershipStateValidator.Violation.CLAN_REQUIRED));
    }

    @Test
    void legacyConstructorAcceptsPreviouslyValidResults() {
        CreateClanResult membershipFailure = new CreateClanResult(
                CreateClanResult.Status.REGISTRATION_FAILED,
                Optional.empty(),
                Optional.of(ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE),
                Optional.empty());
        CreateClanResult otherRegistrationFailure = new CreateClanResult(
                CreateClanResult.Status.REGISTRATION_FAILED,
                Optional.empty(),
                Optional.of(ClanRegistrationResult.Status.TAG_CONFLICT),
                Optional.empty());
        Clan clan = new ClanFactory().create(
                CLAN_ID, "Sky World", "SW1", CREATOR_ID, NOW, NOW);
        CreateClanResult created = new CreateClanResult(
                CreateClanResult.Status.CREATED,
                Optional.empty(),
                Optional.empty(),
                Optional.of(clan));
        CreateClanResult invalidInput = new CreateClanResult(
                CreateClanResult.Status.INVALID_INPUT,
                Optional.empty(),
                Optional.empty(),
                Optional.empty());

        assertEquals(
                CreateClanResult.Status.REGISTRATION_FAILED, membershipFailure.status());
        assertTrue(membershipFailure.validationViolations().isEmpty());
        assertEquals(
                Optional.of(ClanRegistrationResult.Status.TAG_CONFLICT),
                otherRegistrationFailure.registrationStatus());
        assertEquals(Optional.of(clan), created.clan());
        assertEquals(CreateClanResult.Status.INVALID_INPUT, invalidInput.status());
    }

    @Test
    void fullConstructorRequiresViolationsForInvalidMembershipRegistration() {
        assertThrows(IllegalArgumentException.class,
                () -> new CreateClanResult(
                        CreateClanResult.Status.REGISTRATION_FAILED,
                        Optional.empty(),
                        Optional.of(ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE),
                        List.of(),
                        Optional.empty()));
    }

    private static void assertRegistrationConflict(
            ClanCatalog.RegistrationStatus catalogStatus,
            ClanRegistrationResult.Status expectedStatus) {
        Harness harness = new Harness(List.of());
        harness.registrationOverride = catalogStatus;

        CreateClanResult result =
                harness.useCase.create(command("Sky World", "SW1", null));

        assertEquals(CreateClanResult.Status.REGISTRATION_FAILED, result.status());
        assertEquals(Optional.of(expectedStatus), result.registrationStatus());
        assertEquals(1, harness.registerCalls.get());
        assertEquals(1, harness.clanIdRequests.get());
        assertEquals(0, harness.catalog.size());
    }

    private static void assertForbidden(
            String name,
            String tag,
            String slogan,
            ForbiddenExpressionField field) {
        Harness harness = new Harness(List.of("bad"));

        CreateClanResult result = harness.useCase.create(command(name, tag, slogan));

        assertEquals(CreateClanResult.Status.FORBIDDEN_EXPRESSION, result.status());
        assertEquals(Optional.of(field), result.forbiddenField());
        assertNoRegistrationOrMutation(harness);
    }

    private static void assertNoRegistrationOrMutation(Harness harness) {
        assertEquals(0, harness.registerCalls.get());
        assertEquals(0, harness.clanIdRequests.get());
        assertEquals(0, harness.catalog.size());
    }

    private static CreateClanCommand command(String name, String tag, String slogan) {
        return new CreateClanCommand(CREATOR_ID, name, tag, slogan);
    }

    private static final class Harness {
        private final InMemoryClanCatalog catalog = new InMemoryClanCatalog();
        private final AtomicInteger registerCalls = new AtomicInteger();
        private final AtomicInteger clanIdRequests = new AtomicInteger();
        private final TrackingCatalog trackingCatalog = new TrackingCatalog(this);
        private final ClanService clanService = new ClanService(
                trackingCatalog, new ClanMembershipStateValidator());
        private final CreateClanUseCase useCase;
        private ClanCatalog.RegistrationStatus registrationOverride;
        private UUID nextClanId = CLAN_ID;

        private Harness(List<String> forbiddenExpressions) {
            ForbiddenExpressionFilter filter = forbiddenExpressions == null
                    ? ForbiddenExpressionFilter.load(null)
                    : ForbiddenExpressionFilter.load(() -> forbiddenExpressions);
            this.useCase = new CreateClanUseCase(
                    new ClanFactory(),
                    clanService,
                    filter,
                    () -> {
                        clanIdRequests.incrementAndGet();
                        return nextClanId;
                    },
                    CLOCK);
        }

        private void registerExistingClan(
                UUID clanId,
                String name,
                String tag,
                UUID creatorId) {
            Clan existing = new ClanFactory().create(
                    clanId, name, tag, creatorId, NOW, NOW);
            assertEquals(
                    ClanRegistrationResult.Status.REGISTERED,
                    clanService.registerClan(existing).status());
            registerCalls.set(0);
        }
    }

    private static final class TrackingCatalog implements ClanCatalog {
        private final Harness harness;
        private int playerLookupCalls;
        private int tagLookupCalls;

        private TrackingCatalog(Harness harness) {
            this.harness = harness;
        }

        @Override
        public Optional<Clan> findById(UUID clanId) {
            return harness.catalog.findById(clanId);
        }

        @Override
        public Optional<Clan> findByTag(String tag) {
            tagLookupCalls++;
            return harness.catalog.findByTag(tag);
        }

        @Override
        public Optional<Clan> findByPlayerId(UUID playerId) {
            playerLookupCalls++;
            return harness.catalog.findByPlayerId(playerId);
        }

        @Override
                public Optional<Long> findRevision(UUID clanId) {
                    return harness.catalog.findRevision(clanId);
                }

            @Override
            public RegistrationStatus registerIfAvailable(Clan clan) {
                harness.registerCalls.incrementAndGet();
                if (harness.registrationOverride != null) {
                    return harness.registrationOverride;
                }
                return harness.catalog.registerIfAvailable(clan);
            }

            @Override
            public CapacityUpdateStatus updateCapacityIfUnchanged(
                    Clan expectedClan,
                    UUID leaderId,
                    Clan updatedClan) {
                return harness.catalog.updateCapacityIfUnchanged(
                        expectedClan, leaderId, updatedClan);
            }

            @Override
            public MembershipUpdateStatus updateMembershipIfUnchanged(
                    Clan expectedClan, Clan updatedClan) {
                return harness.catalog.updateMembershipIfUnchanged(expectedClan, updatedClan);
            }
        }
}

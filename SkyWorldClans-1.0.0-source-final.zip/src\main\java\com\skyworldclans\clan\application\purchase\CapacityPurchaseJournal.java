package com.skyworldclans.clan.application.purchase;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Durable local journal for capacity-purchase intents; it does not execute payments.
 */
public interface CapacityPurchaseJournal {
    /**
     * Registers an intent with unique request/business identifiers after rechecking its clan snapshot.
     */
    PrepareResult prepare(CapacityPurchaseIntent intent);

    Optional<CapacityPurchaseOperation> findByIdempotencyKey(String idempotencyKey);

    Optional<CapacityPurchaseOperation> findByBusinessOperationId(String businessOperationId);

    List<CapacityPurchaseOperation> findUnresolved();

    List<CapacityPurchaseEvent> listEvents(UUID operationId);

    /**
     * Applies a durable compare-and-transition and appends the matching journal event.
     */
    TransitionResult transition(
            UUID operationId,
            CapacityPurchaseState expectedState,
            CapacityPurchaseState nextState,
            CapacityPurchaseTransitionEvidence evidence,
            String providerOperationId);

    enum PrepareStatus {
        CREATED,
        DUPLICATE_REQUEST,
        IDEMPOTENCY_KEY_CONFLICT,
        OPERATION_ID_CONFLICT,
        BUSINESS_OPERATION_CONFLICT,
        CLAN_NOT_FOUND,
        LEADER_CHANGED,
        STATE_CONFLICT
    }

    record PrepareResult(PrepareStatus status, Optional<CapacityPurchaseOperation> operation) {
        public PrepareResult {
            if (status == null || operation == null) {
                throw new NullPointerException("status and operation are required");
            }
        }
    }

    enum TransitionStatus {
        UPDATED,
        OPERATION_NOT_FOUND,
        STATE_CONFLICT,
        INVALID_TRANSITION,
        EVIDENCE_REQUIRED,
        UNEXPECTED_EVIDENCE
    }

    record TransitionResult(
            TransitionStatus status,
            Optional<CapacityPurchaseOperation> operation) {
        public TransitionResult {
            if (status == null || operation == null) {
                throw new NullPointerException("status and operation are required");
            }
        }
    }
}

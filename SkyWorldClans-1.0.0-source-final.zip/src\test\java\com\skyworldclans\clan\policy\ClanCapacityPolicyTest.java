package com.skyworldclans.clan.policy;

import org.junit.jupiter.api.Test;

import java.util.OptionalInt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanCapacityPolicyTest {

    @Test
    void startsAtTenPlayersIncludingTheLeader() {
        assertEquals(10, ClanCapacityPolicy.initialCapacity());
        assertTrue(ClanCapacityPolicy.isValidCapacity(10));
    }

    @Test
    void reportsSpaceForAnEmptyClanAndAClanWithOnlyItsLeader() {
        assertTrue(ClanCapacityPolicy.hasAvailableSpace(10, 0));
        assertTrue(ClanCapacityPolicy.hasAvailableSpace(10, 1));
        assertFalse(ClanCapacityPolicy.isFull(10, 0));
        assertFalse(ClanCapacityPolicy.isFull(10, 1));
    }

    @Test
    void reportsTheLastFreeSlot() {
        assertTrue(ClanCapacityPolicy.hasAvailableSpace(10, 9));
        assertFalse(ClanCapacityPolicy.isFull(10, 9));
    }

    @Test
    void reportsAFullClan() {
        assertFalse(ClanCapacityPolicy.hasAvailableSpace(10, 10));
        assertTrue(ClanCapacityPolicy.isFull(10, 10));
    }

    @Test
    void checksSpaceAtBoundariesForEveryValidCapacity() {
        for (int capacity : new int[]{10, 20, 30, 40, 50}) {
            assertTrue(ClanCapacityPolicy.hasAvailableSpace(capacity, 0));
            assertTrue(ClanCapacityPolicy.hasAvailableSpace(capacity, capacity - 1));
            assertFalse(ClanCapacityPolicy.hasAvailableSpace(capacity, capacity));
            assertFalse(ClanCapacityPolicy.hasAvailableSpace(capacity, capacity + 1));

            assertFalse(ClanCapacityPolicy.isFull(capacity, 0));
            assertFalse(ClanCapacityPolicy.isFull(capacity, capacity - 1));
            assertTrue(ClanCapacityPolicy.isFull(capacity, capacity));
            assertTrue(ClanCapacityPolicy.isFull(capacity, capacity + 1));
        }
    }

    @Test
    void allowsEverySequentialCapacityExpansion() {
        assertEquals(OptionalInt.of(20), ClanCapacityPolicy.nextCapacity(10));
        assertEquals(OptionalInt.of(30), ClanCapacityPolicy.nextCapacity(20));
        assertEquals(OptionalInt.of(40), ClanCapacityPolicy.nextCapacity(30));
        assertEquals(OptionalInt.of(50), ClanCapacityPolicy.nextCapacity(40));

        assertTrue(ClanCapacityPolicy.canExpandTo(10, 20));
        assertTrue(ClanCapacityPolicy.canExpandTo(20, 30));
        assertTrue(ClanCapacityPolicy.canExpandTo(30, 40));
        assertTrue(ClanCapacityPolicy.canExpandTo(40, 50));
    }

    @Test
    void returnsTheCostForEverySequentialExpansion() {
        assertEquals(OptionalInt.of(100), ClanCapacityPolicy.nextExpansionCost(10));
        assertEquals(OptionalInt.of(200), ClanCapacityPolicy.nextExpansionCost(20));
        assertEquals(OptionalInt.of(300), ClanCapacityPolicy.nextExpansionCost(30));
        assertEquals(OptionalInt.of(400), ClanCapacityPolicy.nextExpansionCost(40));
    }

    @Test
    void refusesExpansionAtMaximumCapacity() {
        assertEquals(OptionalInt.empty(), ClanCapacityPolicy.nextCapacity(50));
        assertEquals(OptionalInt.empty(), ClanCapacityPolicy.nextExpansionCost(50));
        assertTrue(ClanCapacityPolicy.isValidCapacity(50));
    }

    @Test
    void rejectsInvalidCapacitiesAndRefusesTheirExpansion() {
        for (int capacity : new int[]{0, 9, 11, 15, 51}) {
            assertFalse(ClanCapacityPolicy.isValidCapacity(capacity));
            assertFalse(ClanCapacityPolicy.hasAvailableSpace(capacity, 0));
            assertFalse(ClanCapacityPolicy.isFull(capacity, capacity));
            assertEquals(OptionalInt.empty(), ClanCapacityPolicy.nextCapacity(capacity));
            assertEquals(OptionalInt.empty(), ClanCapacityPolicy.nextExpansionCost(capacity));
        }
    }

    @Test
    void doesNotAllowSkippingAnExpansionStep() {
        assertTrue(ClanCapacityPolicy.canExpandTo(10, 20));
        assertFalse(ClanCapacityPolicy.canExpandTo(10, 30));
        assertFalse(ClanCapacityPolicy.canExpandTo(20, 40));
        assertFalse(ClanCapacityPolicy.canExpandTo(50, 60));
        assertFalse(ClanCapacityPolicy.canExpandTo(15, 20));
    }

    @Test
    void doesNotReportSpaceForNegativeMemberCount() {
        assertFalse(ClanCapacityPolicy.hasAvailableSpace(10, -1));
        assertFalse(ClanCapacityPolicy.isFull(10, -1));
    }

    @Test
    void doesNotReportFullForInvalidCapacity() {
        assertFalse(ClanCapacityPolicy.isFull(9, 9));
        assertFalse(ClanCapacityPolicy.isFull(0, 0));
        assertFalse(ClanCapacityPolicy.isFull(51, 100));
    }

    @Test
    void doesNotReportFullForNegativeMemberCountAtMinimumCapacity() {
        assertFalse(ClanCapacityPolicy.isFull(10, -1));
    }

    @Test
    void treatsMemberCountAboveCapacityAsFullButWithoutAvailableSpace() {
        assertTrue(ClanCapacityPolicy.isFull(10, 11));
        assertFalse(ClanCapacityPolicy.hasAvailableSpace(10, 11));
    }
}

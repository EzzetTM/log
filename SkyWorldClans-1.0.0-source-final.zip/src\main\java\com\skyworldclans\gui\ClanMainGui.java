package com.skyworldclans.gui;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Main {@code /clan} inventory menu. Every action is re-validated on the server before it is
 * applied; the menu only reflects what the viewer's role currently allows.
 */
public final class ClanMainGui implements Listener {
    private static final int SIZE = 54;
    private static final int MEMBERS_SIZE = 54;

    private final SkyWorldClansPlugin plugin;

    public ClanMainGui(SkyWorldClansPlugin plugin) { this.plugin = plugin; }

    public void open(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        MenuHolder holder = new MenuHolder(clan == null ? null : clan.id(), Screen.MAIN);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text(clan == null ? "Кланы" : "Клан " + clan.tag(), NamedTextColor.DARK_AQUA));
        holder.inventory = inventory;
        if (clan == null) {
            inventory.setItem(22, item(Material.WRITABLE_BOOK, "Создать клан",
                    List.of("Стоимость: 1 000 000 обычной валюты",
                            "Команда: /clan create <тег> <название>"), NamedTextColor.GREEN));
            inventory.setItem(24, item(Material.PAPER, "Мои приглашения",
                    List.of("Команда: /clan requests"), NamedTextColor.YELLOW));
            fill(inventory);
            player.openInventory(inventory);
            return;
        }
        ClanRole role = clan.member(player.getUniqueId()).map(ClanMember::role).orElse(ClanRole.MEMBER);
        boolean leader = role == ClanRole.LEADER;
        boolean officer = leader || role == ClanRole.DEPUTY;

        inventory.setItem(4, item(Material.BOOK, clan.name() + " [" + clan.tag() + "]",
                List.of("Уровень: " + clan.level() + " (XP " + clan.totalXp() + ")",
                        "Участники: " + clan.memberCount() + "/" + clan.capacity(),
                        "Твоя роль: " + roleName(role),
                        clan.tagline() == null || clan.tagline().isBlank() ? "Девиз не задан" : "Девиз: " + clan.tagline()),
                NamedTextColor.AQUA));
        inventory.setItem(16, item(Material.WRITABLE_BOOK, "Задания",
                List.of("Ежедневные, еженедельные и специальные", "Нажми, чтобы увидеть прогресс"),
                NamedTextColor.YELLOW));
        inventory.setItem(17, item(Material.BEACON, "Турниры",
                List.of("Дисциплины и голосование", "Нажми, чтобы увидеть список"),
                NamedTextColor.AQUA));
        inventory.setItem(19, item(Material.PLAYER_HEAD, "Участники",
                List.of("Состав клана и роли", "Открыть"), NamedTextColor.GREEN));
        inventory.setItem(20, item(Material.GOLD_INGOT, "Банк",
                List.of("Баланс: " + balance(clan), "Пополнение и заявки на вывод"), NamedTextColor.GOLD));
        inventory.setItem(21, item(Material.CHEST, "Хранилище",
                List.of("Страниц: " + pages(clan) + "/10", "54 слота на страницу"), NamedTextColor.AQUA));
        inventory.setItem(22, item(Material.RED_BED, "Домашняя точка",
                List.of("Телепорт, установка и переименование"), NamedTextColor.LIGHT_PURPLE));
        inventory.setItem(23, item(Material.IRON_SWORD, "Войны",
                List.of("Объявление, взносы и капитуляция"), NamedTextColor.RED));
        inventory.setItem(24, item(Material.PAPER, "Заявки и приглашения",
                List.of("Публичные заявки: " + (applicationsOpen(clan) ? "открыты" : "закрыты")),
                NamedTextColor.YELLOW));
        inventory.setItem(25, item(Material.NAME_TAG, leader ? "Управление кланом" : "Настройки",
                leader ? List.of("Приглашения, заявки, исключение, роли") : List.of("Доступно только лидеру"),
                leader ? NamedTextColor.GREEN : NamedTextColor.GRAY));
        inventory.setItem(31, item(Material.BARRIER, "Закрыть", List.of(), NamedTextColor.RED));
        fill(inventory);
        player.openInventory(inventory);
    }

    public void openMembers(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            player.sendMessage(Component.text("[Кланы] Ты не состоишь в клане.", NamedTextColor.RED));
            return;
        }
        MenuHolder holder = new MenuHolder(clan.id(), Screen.MEMBERS);
        Inventory inventory = Bukkit.createInventory(holder, MEMBERS_SIZE,
                Component.text("Участники " + clan.tag(), NamedTextColor.DARK_AQUA));
        holder.inventory = inventory;
        List<ClanMember> members = new ArrayList<>(clan.members().values());
        members.sort(Comparator.comparing((ClanMember member) -> member.role().ordinal())
                .thenComparing(member -> member.playerId().toString()));
        for (int index = 0; index < Math.min(members.size(), 45); index++) {
            ClanMember member = members.get(index);
            inventory.setItem(index, memberItem(member));
        }
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of("Главное меню"), NamedTextColor.YELLOW));
        inventory.setItem(45, item(Material.BARRIER, "Закрыть", List.of(), NamedTextColor.RED));
        fill(inventory);
        player.openInventory(inventory);
    }

    private ItemStack memberItem(ClanMember member) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        OfflinePlayer offline = Bukkit.getOfflinePlayer(member.playerId());
        meta.setOwningPlayer(offline);
        meta.displayName(Component.text(offline.getName() == null
                        ? member.playerId().toString() : offline.getName(), roleColor(member.role()))
                .decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(line("Роль: " + roleName(member.role())));
        lore.add(line("В клане с: " + member.membershipStartedAt()));
        meta.lore(lore);
        head.setItemMeta(meta);
        return head;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null
                || !event.getClickedInventory().equals(event.getView().getTopInventory())) return;
        int slot = event.getSlot();
        if (holder.screen == Screen.MEMBERS) {
            if (slot == 45) player.closeInventory();
            else if (slot == 49) open(player);
            return;
        }
        switch (slot) {
            case 16 -> openQuests(player);
            case 17 -> openTournaments(player);
            case 31 -> player.closeInventory();
            case 19 -> openMembers(player);
            case 20 -> openBank(player);
            case 21 -> {
                if (plugin.getClanStore().findByPlayerId(player.getUniqueId()).isPresent()) {
                    plugin.getClanStorageGui().openMenu(player);
                }
            }
            case 22 -> openHome(player);
            case 23 -> openWar(player);
            case 24 -> openRequests(player);
            case 25 -> openSettings(player);
            default -> { }
        }
    }

    public void openBank(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) return;
        MenuHolder holder = new MenuHolder(clan.id(), Screen.BANK);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Банк " + clan.tag(), NamedTextColor.GOLD));
        holder.inventory = inventory;
        BigDecimal balance = plugin.getClanStore().clanBankBalance(clan.id());
        BigDecimal available = plugin.getClanStore().clanBankAvailableBalance(clan.id());
        inventory.setItem(4, item(Material.GOLD_BLOCK, "Баланс клана",
                List.of("Баланс: " + balance.toPlainString(),
                        "Доступно: " + available.toPlainString(),
                        "Валюта: обычная игровая (Vault)"), NamedTextColor.GOLD));
        var history = plugin.getClanStore().findClanBankTransactions(clan.id(), 21);
        for (int index = 0; index < history.size() && index < 21; index++) {
            var transaction = history.get(index);
            inventory.setItem(9 + index, item(Material.PAPER,
                    transaction.transactionType() + " " + transaction.amount().toPlainString(),
                    List.of("После: " + transaction.balanceAfter().toPlainString(),
                            "Время: " + transaction.occurredAt(),
                            transaction.reason() == null ? "" : "Причина: " + transaction.reason()),
                    transaction.amount().signum() < 0 ? NamedTextColor.RED : NamedTextColor.GREEN));
        }
        ClanRole role = clan.member(player.getUniqueId()).map(ClanMember::role).orElse(ClanRole.MEMBER);
        if (role == ClanRole.LEADER) {
            inventory.setItem(40, item(Material.EMERALD, "Вывод средств",
                    List.of("Команда: /clan bank withdraw <сумма>"), NamedTextColor.GREEN));
            inventory.setItem(41, item(Material.WRITABLE_BOOK, "Заявки на вывод",
                    List.of("Команда: /clan bank requests"), NamedTextColor.YELLOW));
        } else if (role == ClanRole.DEPUTY) {
            inventory.setItem(40, item(Material.WRITABLE_BOOK, "Создать заявку на вывод",
                    List.of("Команда: /clan bank request <сумма> <причина>"), NamedTextColor.YELLOW));
        }
        inventory.setItem(42, item(Material.CHEST, "Пополнить банк",
                List.of("Команда: /clan bank deposit <сумма>"), NamedTextColor.AQUA));
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of("Главное меню"), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    public void openHome(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) return;
        MenuHolder holder = new MenuHolder(clan.id(), Screen.HOME);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Дом " + clan.tag(), NamedTextColor.LIGHT_PURPLE));
        holder.inventory = inventory;
        var point = plugin.getClanHomeService().homeFor(player.getUniqueId());
        if (point.status() == com.skyworldclans.clan.home.ClanHomeService.Status.READY && point.point() != null) {
            var home = point.point();
            inventory.setItem(22, item(Material.RED_BED, home.name(),
                    List.of("Мир: " + home.worldId(),
                            "X: " + Math.round(home.x()) + " Y: " + Math.round(home.y()) + " Z: " + Math.round(home.z()),
                            "Нажми, чтобы телепортироваться"), NamedTextColor.LIGHT_PURPLE));
        } else {
            inventory.setItem(22, item(Material.GRAY_BED, "Точка не установлена",
                    List.of("Лидер или заместитель может установить её"),
                    NamedTextColor.GRAY));
        }
        ClanRole role = clan.member(player.getUniqueId()).map(ClanMember::role).orElse(ClanRole.MEMBER);
        boolean officer = role == ClanRole.LEADER || role == ClanRole.DEPUTY;
        inventory.setItem(29, item(Material.COMPASS, "Установить точку",
                List.of(officer ? "Нажми, чтобы установить здесь" : "Только лидер и заместители"),
                officer ? NamedTextColor.GREEN : NamedTextColor.GRAY));
        inventory.setItem(31, item(Material.NAME_TAG, "Переименовать",
                List.of(officer ? "Команда: /clan home rename <название>" : "Только лидер и заместители"),
                officer ? NamedTextColor.YELLOW : NamedTextColor.GRAY));
        inventory.setItem(33, item(Material.BARRIER, "Удалить точку",
                List.of(role == ClanRole.LEADER ? "Нажми, чтобы удалить" : "Только лидер"),
                role == ClanRole.LEADER ? NamedTextColor.RED : NamedTextColor.GRAY));
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    public void openWar(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) return;
        MenuHolder holder = new MenuHolder(clan.id(), Screen.WAR);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Войны " + clan.tag(), NamedTextColor.RED));
        holder.inventory = inventory;
        var open = plugin.getClanStore().findOpenClanWar(clan.id());
        if (open.isPresent()) {
            var war = open.get();
            inventory.setItem(13, item(Material.IRON_SWORD, "Война " + war.warId(),
                    List.of("Состояние: " + war.state(),
                            "Счёт: " + war.attackerKills() + " : " + war.defenderKills(),
                            "Цель: " + war.targetKills() + " убийств",
                            "Команда: /clan war info " + war.warId()), NamedTextColor.RED));
        } else {
            inventory.setItem(13, item(Material.SHIELD, "Активной войны нет",
                    List.of("Объявить: /clan war declare <тег> <убийства> <часы> --confirm"),
                    NamedTextColor.GRAY));
        }
        inventory.setItem(29, item(Material.WRITABLE_BOOK, "Внести в фонд",
                List.of("Команда: /clan war fund <ID> <сумма>"), NamedTextColor.GOLD));
        inventory.setItem(31, item(Material.WHITE_BANNER, "Капитуляция",
                List.of("Команда: /clan war surrender <ID> --confirm"), NamedTextColor.YELLOW));
        inventory.setItem(33, item(Material.PAPER, "История войн",
                List.of("Команда: /clan war"), NamedTextColor.GRAY));
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    public void openRequests(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) return;
        MenuHolder holder = new MenuHolder(clan.id(), Screen.REQUESTS);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Заявки " + clan.tag(), NamedTextColor.YELLOW));
        holder.inventory = inventory;
        var invitations = plugin.getClanRequestService().pendingForPlayer(
                player.getUniqueId(), com.skyworldclans.clan.request.ClanRequest.Type.INVITATION);
        int slot = 0;
        for (var invitation : invitations) {
            if (slot >= 18) break;
            String tag = plugin.getClanStore().findById(invitation.clanId())
                    .map(Clan::tag).orElse("?");
            inventory.setItem(slot++, item(Material.PAPER, "Приглашение в [" + tag + "]",
                    List.of("Принять: /clan accept " + invitation.id(),
                            "Отклонить: /clan decline " + invitation.id()), NamedTextColor.GREEN));
        }
        ClanRole role = clan.member(player.getUniqueId()).map(ClanMember::role).orElse(ClanRole.MEMBER);
        if (role == ClanRole.LEADER || role == ClanRole.DEPUTY) {
            var applications = plugin.getClanRequestService().pendingForClan(
                    clan.id(), com.skyworldclans.clan.request.ClanRequest.Type.APPLICATION);
            int appSlot = 18;
            for (var application : applications) {
                if (appSlot >= 36) break;
                OfflinePlayer applicant = Bukkit.getOfflinePlayer(application.playerId());
                inventory.setItem(appSlot++, item(Material.PLAYER_HEAD,
                        "Заявка: " + (applicant.getName() == null ? application.playerId() : applicant.getName()),
                        List.of("Принять: /clan accept " + application.id(),
                                "Отклонить: /clan decline " + application.id()), NamedTextColor.AQUA));
            }
        }
        inventory.setItem(40, item(Material.NAME_TAG, "Публичные заявки",
                List.of(applicationsOpen(clan) ? "Сейчас открыты" : "Сейчас закрыты",
                        role == ClanRole.LEADER ? "Переключить: /clan applications open|close" : "Управляет лидер"),
                NamedTextColor.YELLOW));
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    private void openSettings(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) return;
        MenuHolder holder = new MenuHolder(clan.id(), Screen.SETTINGS);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Управление " + clan.tag(), NamedTextColor.DARK_GREEN));
        holder.inventory = inventory;
        ClanRole role = clan.member(player.getUniqueId()).map(ClanMember::role).orElse(ClanRole.MEMBER);
        if (role != ClanRole.LEADER) {
            inventory.setItem(22, item(Material.BARRIER, "Доступно только лидеру", List.of(), NamedTextColor.RED));
            inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
            fill(inventory);
            player.openInventory(inventory);
            return;
        }
        inventory.setItem(10, item(Material.WRITABLE_BOOK, "Пригласить игрока",
                List.of("Команда: /clan invite <ник>"), NamedTextColor.GREEN));
        inventory.setItem(11, item(Material.IRON_DOOR, "Исключить участника",
                List.of("Команда: /clan kick <ник>"), NamedTextColor.RED));
        inventory.setItem(12, item(Material.GOLDEN_HELMET, "Назначить заместителя",
                List.of("Команда: /clan deputy add <ник>"), NamedTextColor.GOLD));
        inventory.setItem(13, item(Material.LEATHER_HELMET, "Назначить модератора",
                List.of("Команда: /clan moderator add <ник>"), NamedTextColor.YELLOW));
        inventory.setItem(14, item(Material.NETHER_STAR, "Передать лидерство",
                List.of("Команда: /clan leader transfer <ник>"), NamedTextColor.LIGHT_PURPLE));
        inventory.setItem(15, item(Material.NAME_TAG, "Публичные заявки",
                List.of(applicationsOpen(clan) ? "Открыты" : "Закрыты",
                        "Команда: /clan applications open|close"), NamedTextColor.AQUA));
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    private void openQuests(Player player) {
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) return;
        var quests = plugin.getClanQuestService().quests(clan.id());
        player.closeInventory();
        player.sendMessage(Component.text("Задания клана [" + clan.tag() + "]:", NamedTextColor.GOLD));
        if (quests.isEmpty()) {
            player.sendMessage(Component.text("Активных заданий нет.", NamedTextColor.GRAY));
            return;
        }
        for (var quest : quests) {
            player.sendMessage(Component.text(quest.category() + "/" + quest.difficulty()
                    + " — " + quest.progress() + "/" + quest.targetAmount()
                    + " (XP " + com.skyworldclans.clan.quest.ClanQuestService.xpFor(
                            quest.category(), quest.difficulty()) + ")", NamedTextColor.YELLOW));
        }
    }

    private void openTournaments(Player player) {
        var tournaments = plugin.getClanTournamentService().list(10);
        player.closeInventory();
        player.sendMessage(Component.text("Турниры:", NamedTextColor.GOLD));
        if (tournaments.isEmpty()) {
            player.sendMessage(Component.text("Турниров пока нет.", NamedTextColor.GRAY));
        }
        for (var tournament : tournaments) {
            player.sendMessage(Component.text(tournament.discipline() + " — " + tournament.name()
                    + " | " + tournament.state(), NamedTextColor.AQUA));
        }
        player.sendMessage(Component.text("Регистрация откроется после утверждения условий оплаты владельцем.",
                NamedTextColor.GRAY));
    }

    private BigDecimal balance(Clan clan) {
        try { return plugin.getClanStore().clanBankBalance(clan.id()); }
        catch (RuntimeException exception) { return BigDecimal.ZERO; }
    }

    private int pages(Clan clan) {
        try { return plugin.getClanStore().clanStoragePageCount(clan.id()); }
        catch (RuntimeException exception) { return 0; }
    }

    private boolean applicationsOpen(Clan clan) {
        try { return plugin.getClanRequestService().arePublicApplicationsOpen(clan.id()); }
        catch (RuntimeException exception) { return false; }
    }

    private static String roleName(ClanRole role) {
        return switch (role) {
            case LEADER -> "Лидер";
            case DEPUTY -> "Заместитель";
            case MODERATOR -> "Модератор";
            default -> "Участник";
        };
    }

    private static NamedTextColor roleColor(ClanRole role) {
        return switch (role) {
            case LEADER -> NamedTextColor.GOLD;
            case DEPUTY -> NamedTextColor.YELLOW;
            case MODERATOR -> NamedTextColor.AQUA;
            default -> NamedTextColor.GRAY;
        };
    }

    private static Component line(String text) {
        return Component.text(text, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack item(Material material, String name, List<String> lore, NamedTextColor color) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        if (!lore.isEmpty()) {
            List<Component> lines = new ArrayList<>();
            for (String value : lore) {
                if (value != null && !value.isBlank()) lines.add(line(value));
            }
            meta.lore(lines);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private static void fill(Inventory inventory) {
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        filler.setItemMeta(meta);
        for (int index = 0; index < inventory.getSize(); index++) {
            if (inventory.getItem(index) == null) inventory.setItem(index, filler.clone());
        }
    }

    private enum Screen { MAIN, MEMBERS, BANK, HOME, WAR, REQUESTS, SETTINGS }

    private static final class MenuHolder implements InventoryHolder {
        private final UUID clanId;
        private final Screen screen;
        private Inventory inventory;
        private MenuHolder(UUID clanId, Screen screen) { this.clanId = clanId; this.screen = screen; }
        @Override public Inventory getInventory() { return inventory; }
    }
}
package com.skyworldclans.clan.filter;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public final class ForbiddenExpressionValidator {
    private static final int RAW_TOKEN = 0;
    private static final int CYRILLIC_TOKEN = 1;
    private static final int ALIAS_TOKEN = 2;
    private static final Map<Integer, List<String>> TRANSLITERATION = createTransliteration();
    private static final Map<String, Integer> ALIAS_IDS = createAliasIds();
    private static final AliasTrie ALIAS_TRIE = createAliasTrie();

    private final List<CompiledExpression> expressions;
    private final String configurationError;
    private final boolean emptyListWarningRequired;

    public ForbiddenExpressionValidator(List<String> forbiddenExpressions) {
        List<CompiledExpression> compiled = new ArrayList<>();
        String failure = null;

        if (forbiddenExpressions == null) {
            failure = "Forbidden expression list must not be null";
        } else {
            for (int index = 0; index < forbiddenExpressions.size(); index++) {
                String expression = forbiddenExpressions.get(index);
                if (expression == null) {
                    failure = "Forbidden expression at index " + index + " must not be null";
                    break;
                }

                String normalized = ForbiddenExpressionNormalizer.normalize(expression);
                if (normalized.isEmpty()) {
                    failure = "Forbidden expression at index " + index
                            + " is empty after normalization";
                    break;
                }

                int[] codePoints = normalized.codePoints().toArray();
                compiled.add(new CompiledExpression(codePoints, candidatesAtEachPosition(codePoints)));
            }
        }

        this.configurationError = failure;
        this.expressions = failure == null ? List.copyOf(compiled) : List.of();
        this.emptyListWarningRequired = failure == null && compiled.isEmpty();
    }

    public ForbiddenExpressionResult check(ForbiddenExpressionField field, String value) {
        if (field == null) {
            return result(ForbiddenExpressionStatus.INVALID_INPUT, null);
        }
        if (configurationError != null) {
            return result(ForbiddenExpressionStatus.FILTER_UNAVAILABLE, field);
        }
        if (value == null) {
            return result(ForbiddenExpressionStatus.INVALID_INPUT, field);
        }

        String normalized = ForbiddenExpressionNormalizer.normalize(value);
        if (normalized.isEmpty()) {
            return result(ForbiddenExpressionStatus.INVALID_INPUT, field);
        }

        int[] codePoints = normalized.codePoints().toArray();
        List<List<TokenCandidate>> candidates = candidatesAtEachPosition(codePoints);
        for (CompiledExpression expression : expressions) {
            if (containsEquivalentSubsequence(expression, codePoints, candidates)) {
                return result(ForbiddenExpressionStatus.FORBIDDEN_EXPRESSION, field);
            }
        }
        return result(ForbiddenExpressionStatus.ALLOWED, field);
    }

    public boolean isAvailable() {
        return configurationError == null;
    }

    public Optional<String> configurationError() {
        return Optional.ofNullable(configurationError);
    }

    public boolean emptyListWarningRequired() {
        return emptyListWarningRequired;
    }

    private static ForbiddenExpressionResult result(
            ForbiddenExpressionStatus status,
            ForbiddenExpressionField field) {
        return new ForbiddenExpressionResult(status, Optional.ofNullable(field));
    }

    private static boolean containsEquivalentSubsequence(
            CompiledExpression expression,
            int[] text,
            List<List<TokenCandidate>> textCandidates) {
        int patternLength = expression.codePoints().length;
        BitSet[] reachableTextPositions = new BitSet[patternLength + 1];
        for (int index = 0; index <= patternLength; index++) {
            reachableTextPositions[index] = new BitSet(text.length + 1);
        }
        reachableTextPositions[0].set(0, text.length);

        for (int patternPosition = 0; patternPosition < patternLength; patternPosition++) {
            BitSet reachable = reachableTextPositions[patternPosition];
            for (int textPosition = reachable.nextSetBit(0);
                    textPosition >= 0 && textPosition < text.length;
                    textPosition = reachable.nextSetBit(textPosition + 1)) {
                for (TokenCandidate patternCandidate :
                        expression.candidates().get(patternPosition)) {
                    for (TokenCandidate textCandidate : textCandidates.get(textPosition)) {
                        if (!patternCandidate.token().equals(textCandidate.token())) {
                            continue;
                        }

                        int nextPatternPosition = patternPosition + patternCandidate.length();
                        int nextTextPosition = textPosition + textCandidate.length();
                        if (nextPatternPosition == patternLength) {
                            return true;
                        }
                        reachableTextPositions[nextPatternPosition].set(nextTextPosition);
                    }
                }
            }
        }
        return false;
    }

    private static List<List<TokenCandidate>> candidatesAtEachPosition(int[] codePoints) {
        List<List<TokenCandidate>> candidates = new ArrayList<>(codePoints.length);
        for (int index = 0; index < codePoints.length; index++) {
            candidates.add(candidatesAt(codePoints, index));
        }
        return List.copyOf(candidates);
    }

    private static List<TokenCandidate> candidatesAt(int[] codePoints, int position) {
        int codePoint = codePoints[position];
        LinkedHashSet<TokenCandidate> candidates = new LinkedHashSet<>();
        candidates.add(new TokenCandidate(new Token(RAW_TOKEN, codePoint), 1));

        List<String> cyrillicAliases = TRANSLITERATION.get(codePoint);
        if (cyrillicAliases != null) {
            candidates.add(new TokenCandidate(new Token(CYRILLIC_TOKEN, codePoint), 1));
            for (String alias : cyrillicAliases) {
                candidates.add(new TokenCandidate(
                        new Token(ALIAS_TOKEN, ALIAS_IDS.get(alias)), 1));
            }
        }

        AliasTrie.Node node = ALIAS_TRIE.root();
        for (int index = position; index < codePoints.length; index++) {
            node = node.children().get(codePoints[index]);
            if (node == null) {
                break;
            }
            int consumed = index - position + 1;
            for (AliasOutput output : node.outputs()) {
                candidates.add(new TokenCandidate(
                        new Token(CYRILLIC_TOKEN, output.cyrillicCodePoint()), consumed));
                candidates.add(new TokenCandidate(
                        new Token(ALIAS_TOKEN, output.aliasId()), consumed));
            }
        }
        return List.copyOf(candidates);
    }

    private static Map<Integer, List<String>> createTransliteration() {
        Map<Integer, List<String>> mappings = new LinkedHashMap<>();
        addMapping(mappings, 'а', "a");
        addMapping(mappings, 'б', "b");
        addMapping(mappings, 'в', "v");
        addMapping(mappings, 'г', "g");
        addMapping(mappings, 'д', "d");
        addMapping(mappings, 'е', "e");
        addMapping(mappings, 'ё', "e", "yo");
        addMapping(mappings, 'ж', "zh", "j");
        addMapping(mappings, 'з', "z");
        addMapping(mappings, 'и', "i");
        addMapping(mappings, 'й', "y", "i");
        addMapping(mappings, 'к', "k");
        addMapping(mappings, 'л', "l");
        addMapping(mappings, 'м', "m");
        addMapping(mappings, 'н', "n");
        addMapping(mappings, 'о', "o");
        addMapping(mappings, 'п', "p");
        addMapping(mappings, 'р', "r");
        addMapping(mappings, 'с', "s");
        addMapping(mappings, 'т', "t");
        addMapping(mappings, 'у', "u");
        addMapping(mappings, 'ф', "f");
        addMapping(mappings, 'х', "kh", "x");
        addMapping(mappings, 'ц', "ts", "c");
        addMapping(mappings, 'ч', "ch");
        addMapping(mappings, 'ш', "sh");
        addMapping(mappings, 'щ', "shch", "sch");
        addMapping(mappings, 'ы', "y");
        addMapping(mappings, 'э', "e", "eh");
        addMapping(mappings, 'ю', "yu", "iu");
        addMapping(mappings, 'я', "ya", "ia");
        return Collections.unmodifiableMap(mappings);
    }

    private static void addMapping(
            Map<Integer, List<String>> mappings,
            int cyrillicCodePoint,
            String... aliases) {
        mappings.put(cyrillicCodePoint, List.of(aliases));
    }

    private static Map<String, Integer> createAliasIds() {
        Map<String, Integer> ids = new LinkedHashMap<>();
        for (List<String> aliases : TRANSLITERATION.values()) {
            for (String alias : aliases) {
                ids.computeIfAbsent(alias, ignored -> ids.size());
            }
        }
        return Collections.unmodifiableMap(ids);
    }

    private static AliasTrie createAliasTrie() {
        AliasTrie.Node root = new AliasTrie.Node();
        for (Map.Entry<Integer, List<String>> entry : TRANSLITERATION.entrySet()) {
            for (String alias : entry.getValue()) {
                AliasTrie.Node node = root;
                for (int codePoint : alias.codePoints().toArray()) {
                    node = node.children().computeIfAbsent(codePoint, ignored -> new AliasTrie.Node());
                }
                node.outputs().add(new AliasOutput(
                        entry.getKey(),
                        Objects.requireNonNull(ALIAS_IDS.get(alias), "alias id")));
            }
        }
        return new AliasTrie(root);
    }

    private record CompiledExpression(
            int[] codePoints,
            List<List<TokenCandidate>> candidates) {
    }

    private record Token(int type, int value) {
    }

    private record TokenCandidate(Token token, int length) {
    }

    private record AliasOutput(int cyrillicCodePoint, int aliasId) {
    }

    private record AliasTrie(Node root) {
        private static final class Node {
            private final Map<Integer, Node> children = new LinkedHashMap<>();
            private final List<AliasOutput> outputs = new ArrayList<>();

            private Map<Integer, Node> children() {
                return children;
            }

            private List<AliasOutput> outputs() {
                return outputs;
            }
        }
    }
}

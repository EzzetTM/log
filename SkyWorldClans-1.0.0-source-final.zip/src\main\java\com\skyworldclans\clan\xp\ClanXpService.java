package com.skyworldclans.clan.xp;

import java.time.Clock;
import java.util.Objects;
import java.util.UUID;

/** Applies only XP amounts approved by the technical specification. */
public final class ClanXpService {
    private final ClanXpStore store;
    private final Clock clock;

    public ClanXpService(ClanXpStore store, Clock clock) {
        this.store = Objects.requireNonNull(store, "store");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    public ClanXpAwardResult award(UUID clanId, ClanXpEventType type,
            UUID actorId, String idempotencyKey) {
        if (clanId == null || type == null || idempotencyKey == null || idempotencyKey.isBlank()) {
            return new ClanXpAwardResult(ClanXpAwardResult.Status.INVALID_INPUT,
                    java.util.OptionalLong.empty(), 0);
        }
        return store.awardClanXp(clanId, type, actorId, idempotencyKey, clock.instant());
    }
}

package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;

import java.util.Objects;
import java.util.Optional;

public record ClanMembershipChangeResult(Status status, Optional<Clan> clan) {
    public ClanMembershipChangeResult {
        Objects.requireNonNull(status, "status");
        clan = Objects.requireNonNull(clan, "clan");
        if ((status == Status.UPDATED) != clan.isPresent()) {
            throw new IllegalArgumentException("Only UPDATED results may contain a clan");
        }
    }

    public enum Status {
        UPDATED,
        INVALID_INPUT,
        CLAN_NOT_FOUND,
        ACTOR_NOT_MEMBER,
        TARGET_NOT_MEMBER,
        INSUFFICIENT_PERMISSION,
        TARGET_NOT_ELIGIBLE,
        DEPUTY_LIMIT_REACHED,
        MODERATOR_LIMIT_REACHED,
        ELECTION_ACTIVE,
        LEADER_DEPARTURE_REQUIRES_ELECTION,
        EMPTY_CLAN_DELETION_REQUIRES_STORAGE_SUPPORT,
        CONCURRENT_MODIFICATION,
        INVALID_MEMBERSHIP_STATE
    }
}

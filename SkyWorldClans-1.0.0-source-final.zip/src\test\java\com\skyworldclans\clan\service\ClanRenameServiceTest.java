package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Owner decision #1: renaming changes the clan name and tag together. */
class ClanRenameServiceTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-11T12:00:00Z");

    @Test
    void renameChangesNameAndTagTogetherAndFreesTheOldTag() {
        UUID leader = id(1), deputy = id(2);
        Clan clan = clan("Old Clan", "OLD1", leader, deputy);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("rename.sqlite"))) {
            store.registerIfAvailable(clan);
            var service = new ClanRenameService(store, store, Clock.fixed(NOW, ZoneOffset.UTC));

            assertEquals(ClanRenameService.Status.RENAMED,
                    service.renameWithoutCharge(leader, "New Clan", "NEW1").status());
            var renamed = store.findById(clan.id()).orElseThrow();
            assertEquals("New Clan", renamed.name());
            assertEquals("NEW1", renamed.tag());
            // The old tag is free again and the new one resolves.
            assertTrue(store.findByTag("OLD1").isEmpty());
            assertEquals(clan.id(), store.findByTag("NEW1").orElseThrow().id());
            // Membership, capacity and XP are untouched by a rename.
            assertEquals(2, renamed.memberCount());
            assertEquals(clan.capacity(), renamed.capacity());
            assertEquals(clan.totalXp(), renamed.totalXp());
        }
    }

    @Test
    void renameRequiresLeaderAndCaseInsensitiveUniqueTag() {
        UUID leader = id(11), deputy = id(12), otherLeader = id(13);
        Clan clan = clan("Alpha Clan", "AL11", leader, deputy);
        Clan other = new Clan(new UUID(0, 22), "Beta Clan", "BE22", NOW, 10,
                Map.of(otherLeader, new ClanMember(otherLeader, ClanRole.LEADER, NOW, null)), 0, null);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("rename-rules.sqlite"))) {
            store.registerIfAvailable(clan);
            store.registerIfAvailable(other);
            var service = new ClanRenameService(store, store, Clock.fixed(NOW, ZoneOffset.UTC));

            assertEquals(ClanRenameService.Status.LEADER_ONLY,
                    service.renameWithoutCharge(deputy, "Gamma", "GM11").status());
            assertEquals(ClanRenameService.Status.TAG_TAKEN,
                    service.renameWithoutCharge(leader, "Gamma", "be22").status());
            // Renaming to the same values is a no-op rather than a conflict.
            assertEquals(ClanRenameService.Status.UNCHANGED,
                    service.renameWithoutCharge(leader, "Alpha Clan", "AL11").status());
            assertEquals(ClanRenameService.Status.INVALID_INPUT,
                    service.renameWithoutCharge(leader, "ab", "XX11").status());
            assertEquals(ClanRenameService.Status.INVALID_INPUT,
                    service.renameWithoutCharge(leader, "Valid Name", "TOOLONGTAG").status());
            assertEquals("Alpha Clan", store.findById(clan.id()).orElseThrow().name());
        }
    }

    @Test
    void paidRenameStaysBlockedWhileSwcoinApiIsUnconfirmed() {
        UUID leader = id(21), deputy = id(22);
        Clan clan = clan("Paid Clan", "PD21", leader, deputy);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("rename-paid.sqlite"))) {
            store.registerIfAvailable(clan);
            var service = new ClanRenameService(store, store, Clock.fixed(NOW, ZoneOffset.UTC));
            var result = service.rename(leader, "Paid Clan Renamed", "PR21");
            assertEquals(ClanRenameService.Status.SWCOIN_UNAVAILABLE, result.status());
            assertNotNull(result.clan());
            // Nothing changed: no free rename and no invented charge.
            assertEquals("Paid Clan", store.findById(clan.id()).orElseThrow().name());
            assertEquals("PD21", store.findById(clan.id()).orElseThrow().tag());
        }
    }

    private static Clan clan(String name, String tag, UUID leader, UUID deputy) {
        return new Clan(new UUID(0, 11), name, tag, NOW, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, NOW, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, NOW, null)), 0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }
}
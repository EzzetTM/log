package com.skyworldclans.clan;

import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanFactoryTest {
    private static final UUID CLAN_ID =
            UUID.fromString("10000000-0000-0000-0000-000000000001");
    private static final UUID CREATOR_ID =
            UUID.fromString("20000000-0000-0000-0000-000000000001");
    private static final Instant CREATED_AT = Instant.parse("2026-02-01T10:15:30Z");
    private static final Instant MEMBERSHIP_STARTED_AT =
            Instant.parse("2026-02-01T10:17:45.123456789Z");

    private final ClanFactory factory = new ClanFactory();

    @Test
    void createsClanWithConfirmedInitialState() {
        Clan clan = createClan();

        assertEquals(CLAN_ID, clan.id());
        assertEquals("Sky World", clan.name());
        assertEquals("SW1", clan.tag());
        assertEquals(CREATED_AT, clan.createdAt());
        assertEquals(ClanCapacityPolicy.initialCapacity(), clan.capacity());
        assertEquals(0, clan.totalXp());
        assertNull(clan.tagline());
        assertEquals(1, clan.memberCount());
    }

    @Test
    void createsOnlyTheCreatorAsLeaderWithoutDeputyAppointer() {
        Clan clan = createClan();

        assertEquals(1, clan.members().size());
        assertTrue(clan.member(CREATOR_ID).isPresent());
        assertEquals(CREATOR_ID, clan.leader().orElseThrow().playerId());
        assertEquals(ClanRole.LEADER, clan.leader().orElseThrow().role());
        assertNull(clan.leader().orElseThrow().appointedByDeputyId());
        assertEquals(MEMBERSHIP_STARTED_AT, clan.leader().orElseThrow().membershipStartedAt());
    }

    @Test
    void preservesCreationAndMembershipTimestampsIndependently() {
        Clan clan = createClan();

        assertEquals(CREATED_AT, clan.createdAt());
        assertEquals(MEMBERSHIP_STARTED_AT, clan.leader().orElseThrow().membershipStartedAt());
        assertNotEquals(CREATED_AT, clan.leader().orElseThrow().membershipStartedAt());
    }

    @Test
    void producesSameClanForRepeatedCallsWithSameInputsWithoutGeneratingValues() {
        Clan first = createClan();
        Clan second = createClan();

        assertEquals(first, second);
        assertEquals(CLAN_ID, second.id());
        assertEquals(CREATED_AT, second.createdAt());
        assertEquals(MEMBERSHIP_STARTED_AT, second.leader().orElseThrow().membershipStartedAt());
    }

    @Test
    void createsClanThatPassesMembershipStateValidationOutsideElection() {
        ClanMembershipStateValidator validator = new ClanMembershipStateValidator();

        assertTrue(validator.validate(createClan(), false).isEmpty());
    }

    @Test
    void rejectsNullRequiredInputsUsingExistingModelValidation() {
        assertThrows(NullPointerException.class,
                () -> factory.create(null, "Sky", "SW", CREATOR_ID,
                        CREATED_AT, MEMBERSHIP_STARTED_AT));
        assertThrows(NullPointerException.class,
                () -> factory.create(CLAN_ID, null, "SW", CREATOR_ID,
                        CREATED_AT, MEMBERSHIP_STARTED_AT));
        assertThrows(NullPointerException.class,
                () -> factory.create(CLAN_ID, "Sky", null, CREATOR_ID,
                        CREATED_AT, MEMBERSHIP_STARTED_AT));
        assertThrows(NullPointerException.class,
                () -> factory.create(CLAN_ID, "Sky", "SW", null,
                        CREATED_AT, MEMBERSHIP_STARTED_AT));
        assertThrows(NullPointerException.class,
                () -> factory.create(CLAN_ID, "Sky", "SW", CREATOR_ID,
                        null, MEMBERSHIP_STARTED_AT));
        assertThrows(NullPointerException.class,
                () -> factory.create(CLAN_ID, "Sky", "SW", CREATOR_ID,
                        CREATED_AT, null));
    }

    @Test
    void rejectsInvalidNameAndTagThroughClanValidation() {
        assertThrows(IllegalArgumentException.class,
                () -> factory.create(CLAN_ID, "ab", "SW", CREATOR_ID,
                        CREATED_AT, MEMBERSHIP_STARTED_AT));
        assertThrows(IllegalArgumentException.class,
                () -> factory.create(CLAN_ID, "Sky", "S!", CREATOR_ID,
                        CREATED_AT, MEMBERSHIP_STARTED_AT));
    }

    @Test
    void createsClanWithOptionalSloganUsingOverload() {
        Clan clan = factory.create(
                CLAN_ID,
                "Sky World",
                "SW1",
                CREATOR_ID,
                CREATED_AT,
                MEMBERSHIP_STARTED_AT,
                "Found together");

        assertEquals("Found together", clan.tagline());
    }

    private Clan createClan() {
        return factory.create(
                CLAN_ID,
                "Sky World",
                "SW1",
                CREATOR_ID,
                CREATED_AT,
                MEMBERSHIP_STARTED_AT);
    }
}

package com.skyworldclans.clan.war;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.clan.xp.ClanXpEventType;
import com.skyworldclans.clan.xp.ClanXpService;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * War lifecycle and war-fund rules. A war is declared by a leader, accepted by the opposing
 * leader, then ends by reaching the configured kill target, by leader capitulation, or when its
 * duration expires (higher score wins; equal score is a draw). The fund is debited from the clan
 * bank atomically and settled exactly once by the SQLite state transition.
 */
public final class ClanWarService {
    public static final int DEFAULT_TARGET_KILLS = 50;
    public static final long DEFAULT_DURATION_HOURS = 24;
    public static final int MAX_TARGET_KILLS = 100_000;
    public static final long MIN_DURATION_HOURS = 1;
    public static final long MAX_DURATION_HOURS = 720;

    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final ClanXpService xpService;
    private final Clock clock;

    public ClanWarService(ClanCatalog clans, SqliteClanStore store, ClanXpService xpService, Clock clock) {
        this.clans = Objects.requireNonNull(clans); this.store = Objects.requireNonNull(store);
        this.xpService = Objects.requireNonNull(xpService); this.clock = Objects.requireNonNull(clock);
    }

    public Declaration declare(UUID actorId, String targetTag, int targetKills, long durationHours) {
        if (actorId == null || targetTag == null || targetTag.isBlank()) return Declaration.INVALID;
        Clan attacker = clans.findByPlayerId(actorId).orElse(null);
        if (attacker == null) return Declaration.NOT_IN_CLAN;
        if (attacker.member(actorId).map(member -> member.role() != ClanRole.LEADER).orElse(true))
            return Declaration.LEADER_ONLY;
        Clan defender = clans.findByTag(targetTag).orElse(null);
        if (defender == null) return Declaration.TARGET_NOT_FOUND;
        if (defender.id().equals(attacker.id())) return Declaration.SAME_CLAN;
        int kills = targetKills <= 0 ? DEFAULT_TARGET_KILLS : targetKills;
        long hours = durationHours <= 0 ? DEFAULT_DURATION_HOURS : durationHours;
        if (kills > MAX_TARGET_KILLS || hours < MIN_DURATION_HOURS || hours > MAX_DURATION_HOURS)
            return Declaration.INVALID;
        SqliteClanStore.ClanWarResult result = store.declareClanWar(UUID.randomUUID(), attacker.id(),
                defender.id(), actorId, kills, hours * 3600L, clock.instant());
        return switch (result.status()) {
            case CREATED -> new Declaration(DeclarationStatus.CREATED, result.war(), defender.tag());
            case OPEN_WAR_EXISTS -> Declaration.OPEN_WAR_EXISTS;
            case CLAN_NOT_FOUND -> Declaration.TARGET_NOT_FOUND;
            case NOT_LEADER -> Declaration.LEADER_ONLY;
            case SAME_CLAN -> Declaration.SAME_CLAN;
            case INVALID_INPUT -> Declaration.INVALID;
            default -> Declaration.STORAGE_ERROR;
        };
    }

    public SqliteClanStore.ClanWarResult accept(UUID actorId, UUID warId) {
        return store.acceptClanWar(warId, actorId, clock.instant());
    }

    public SqliteClanStore.ClanWarResult cancel(UUID actorId, UUID warId) {
        return store.cancelClanWar(warId, actorId, clock.instant());
    }

    public SqliteClanStore.ClanWarResult contribute(UUID actorId, UUID warId, BigDecimal amount) {
        return store.contributeToWarFund(warId, UUID.randomUUID(), actorId, amount, clock.instant());
    }

    public SqliteClanStore.ClanWarResult surrender(UUID actorId, UUID warId) {
        SqliteClanStore.ClanWarResult result = store.surrenderClanWar(warId, actorId, clock.instant());
        if (result.war() != null && result.war().state() == SqliteClanStore.ClanWarStatus.FINISHED) {
            awardWarXp(result.war());
        }
        return result;
    }

    /** Called for every PvP death; records a score only when both players belong to the war. */
    public Optional<SqliteClanStore.ClanWarResult> onPvpKill(UUID killerId, UUID victimId) {
        if (killerId == null || victimId == null || killerId.equals(victimId)) return Optional.empty();
        Clan killerClan = clans.findByPlayerId(killerId).orElse(null);
        Clan victimClan = clans.findByPlayerId(victimId).orElse(null);
        if (killerClan == null || victimClan == null || killerClan.id().equals(victimClan.id()))
            return Optional.empty();
        SqliteClanStore.ClanWar war = store.findOpenClanWar(killerClan.id()).orElse(null);
        if (war == null || war.state() != SqliteClanStore.ClanWarStatus.ACTIVE) return Optional.empty();
        if (!war.involves(killerClan.id()) || !war.involves(victimClan.id())) return Optional.empty();
        SqliteClanStore.ClanWarResult result = store.recordClanWarKill(
                war.warId(), killerClan.id(), killerId, clock.instant());
        if (result.war() != null && result.war().state() == SqliteClanStore.ClanWarStatus.FINISHED) {
            awardWarXp(result.war());
        }
        return Optional.of(result);
    }

    /** Scheduler entry point. Returns resolved wars so the caller can notify participants. */
    public List<SqliteClanStore.ClanWar> resolveDue() {
        List<SqliteClanStore.ClanWar> resolved = store.resolveDueClanWars(clock.instant());
        for (SqliteClanStore.ClanWar war : resolved) awardWarXp(war);
        return resolved;
    }

    public Optional<SqliteClanStore.ClanWar> openWar(UUID clanId) {
        return store.findOpenClanWar(clanId);
    }

    public List<SqliteClanStore.ClanWar> history(UUID clanId, int limit) {
        return store.findClanWars(clanId, limit);
    }

    private void awardWarXp(SqliteClanStore.ClanWar war) {
        if (war == null || war.state() != SqliteClanStore.ClanWarStatus.FINISHED) return;
        String id = war.warId().toString();
        if ("WIN".equals(war.outcome()) && war.winnerClanId() != null) {
            UUID winner = war.winnerClanId();
            xpService.award(winner, ClanXpEventType.WAR_WIN, null, "war-win:" + id);
            int wins = store.countClanWarWins(winner);
            if (wins >= 1) {
                xpService.award(winner, ClanXpEventType.FIRST_WAR_WIN, null,
                        "war-first-win:" + winner);
            }
            if (wins >= 10) {
                xpService.award(winner, ClanXpEventType.TEN_WAR_WINS, null,
                        "war-ten-wins:" + winner);
            }
        } else if ("DRAW".equals(war.outcome())) {
            xpService.award(war.attackerClanId(), ClanXpEventType.WAR_DRAW, null,
                    "war-draw:" + id + ":" + war.attackerClanId());
            xpService.award(war.defenderClanId(), ClanXpEventType.WAR_DRAW, null,
                    "war-draw:" + id + ":" + war.defenderClanId());
        }
    }

    public enum DeclarationStatus {
        CREATED, INVALID, NOT_IN_CLAN, LEADER_ONLY, TARGET_NOT_FOUND, SAME_CLAN,
        OPEN_WAR_EXISTS, STORAGE_ERROR
    }

    public record Declaration(DeclarationStatus status, SqliteClanStore.ClanWar war, String defenderTag) {
        public static final Declaration INVALID = new Declaration(DeclarationStatus.INVALID, null, null);
        public static final Declaration NOT_IN_CLAN = new Declaration(DeclarationStatus.NOT_IN_CLAN, null, null);
        public static final Declaration LEADER_ONLY = new Declaration(DeclarationStatus.LEADER_ONLY, null, null);
        public static final Declaration TARGET_NOT_FOUND = new Declaration(DeclarationStatus.TARGET_NOT_FOUND, null, null);
        public static final Declaration SAME_CLAN = new Declaration(DeclarationStatus.SAME_CLAN, null, null);
        public static final Declaration OPEN_WAR_EXISTS = new Declaration(DeclarationStatus.OPEN_WAR_EXISTS, null, null);
        public static final Declaration STORAGE_ERROR = new Declaration(DeclarationStatus.STORAGE_ERROR, null, null);
        public Declaration(DeclarationStatus status, SqliteClanStore.ClanWar war, String defenderTag) {
            this.status = status; this.war = war; this.defenderTag = defenderTag;
        }
    }
}

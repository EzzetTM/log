package com.skyworldclans.integration;

import java.util.UUID;

/** API-neutral boundary for the optional ordinary-currency provider. */
public interface EconomyOperations {
    BalanceResult balance(UUID playerId);
    OperationResult withdraw(UUID playerId, double amount);
    OperationResult deposit(UUID playerId, double amount);

    enum Status { SUCCESS, INSUFFICIENT_FUNDS, PROVIDER_FAILURE, UNKNOWN, INVALID_INPUT }
    record BalanceResult(Status status, double balance, String diagnostic) { }
    record OperationResult(Status status, String diagnostic) { }
}

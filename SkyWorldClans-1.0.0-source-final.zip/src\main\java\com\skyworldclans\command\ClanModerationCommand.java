package com.skyworldclans.command;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.moderation.ClanModerationService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** {@code /ccmute}, {@code /ccunmute}, {@code /cwarn} and {@code /cunwarn}. */
public final class ClanModerationCommand implements CommandExecutor, TabCompleter {
    public enum Mode { MUTE, UNMUTE, WARN, UNWARN }

    private final SkyWorldClansPlugin plugin;
    private final Mode mode;

    public ClanModerationCommand(SkyWorldClansPlugin plugin, Mode mode) {
        this.plugin = plugin; this.mode = mode;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player actor)) {
            sender.sendMessage(ChatColor.RED + "Команда доступна только игроку.");
            return true;
        }
        return switch (mode) {
            case MUTE -> mute(actor, args);
            case UNMUTE -> unmute(actor, args);
            case WARN -> warn(actor, args);
            case UNWARN -> unwarn(actor, args);
        };
    }

    private boolean mute(Player actor, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("list")) {
            List<com.skyworldclans.clan.storage.sqlite.SqliteClanStore.ClanChatMute> mutes =
                    plugin.getClanModerationService().mutes(actor.getUniqueId());
            actor.sendMessage(ChatColor.GOLD + "Активные муты кланового чата (" + mutes.size() + "):");
            if (mutes.isEmpty()) actor.sendMessage(ChatColor.GRAY + "Муты отсутствуют.");
            for (var mute : mutes) {
                actor.sendMessage(ChatColor.YELLOW + playerName(mute.playerId()) + ChatColor.GRAY
                        + " | до: " + (mute.expiresAt() == null ? "бессрочно" : mute.expiresAt())
                        + " | выдал: " + playerName(mute.mutedBy()) + " | причина: " + mute.reason());
            }
            return true;
        }
        if (args.length < 3) {
            actor.sendMessage(ChatColor.RED + "Использование: /ccmute <ник> <время> <причина>");
            actor.sendMessage(ChatColor.GRAY + "Время: например 30m, 2h, 3d; лидер может указать 0 для бессрочного мута.");
            actor.sendMessage(ChatColor.GRAY + "Список активных мутов: /ccmute list");
            return true;
        }
        Player target = plugin.getServer().getPlayerExact(args[0]);
        if (target == null) {
            actor.sendMessage(ChatColor.RED + "Игрок должен быть онлайн.");
            return true;
        }
        Duration duration = parseDuration(args[1]);
        if (duration == null && !args[1].equals("0")) {
            actor.sendMessage(ChatColor.RED + "Некорректная длительность. Примеры: 30m, 2h, 3d.");
            return true;
        }
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        if (reason.isBlank() || reason.length() > 200) {
            actor.sendMessage(ChatColor.RED + "Причина обязательна (до 200 символов).");
            return true;
        }
        var result = plugin.getClanModerationService().mute(actor.getUniqueId(), target.getUniqueId(),
                args[1].equals("0") ? null : duration, reason);
        switch (result) {
            case APPLIED -> {
                actor.sendMessage(ChatColor.GREEN + "Мут кланового чата выдан игроку " + target.getName() + ".");
                target.sendMessage(ChatColor.RED + "Ты не можешь писать в клановый чат. Причина: " + reason);
            }
            case INSUFFICIENT_PERMISSION -> actor.sendMessage(ChatColor.RED
                    + "Нельзя модерировать равного или старшего по роли, а также самого себя.");
            case DURATION_EXCEEDS_ROLE_LIMIT -> actor.sendMessage(ChatColor.RED
                    + "Срок превышает предел твоей роли: модератор — 24 часа, заместитель — 3 дня.");
            case TARGET_NOT_IN_CLAN -> actor.sendMessage(ChatColor.RED + "Игрок не состоит в твоём клане.");
            case NOT_IN_CLAN -> actor.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            case INVALID_INPUT -> actor.sendMessage(ChatColor.RED + "Проверь длительность и причину.");
            default -> actor.sendMessage(ChatColor.RED + "Мут не выдан: " + result + ".");
        }
        return true;
    }

    private boolean unmute(Player actor, String[] args) {
        if (args.length != 1) {
            actor.sendMessage(ChatColor.RED + "Использование: /ccunmute <ник>");
            return true;
        }
        OfflinePlayer target = findPlayer(args[0]);
        if (target == null) {
            actor.sendMessage(ChatColor.RED + "Игрок не найден.");
            return true;
        }
        var result = plugin.getClanModerationService().unmute(actor.getUniqueId(), target.getUniqueId());
        switch (result) {
            case APPLIED -> {
                actor.sendMessage(ChatColor.GREEN + "Мут снят.");
                Player online = plugin.getServer().getPlayer(target.getUniqueId());
                if (online != null) online.sendMessage(ChatColor.GREEN + "С тебя снят мут кланового чата.");
            }
            case NOT_MUTED -> actor.sendMessage(ChatColor.YELLOW + "У игрока нет активного мута.");
            case INSUFFICIENT_PERMISSION -> actor.sendMessage(ChatColor.RED
                    + "Снимать мут могут только лидер и заместитель.");
            case NOT_IN_CLAN -> actor.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            default -> actor.sendMessage(ChatColor.RED + "Мут не снят: " + result + ".");
        }
        return true;
    }

    private boolean warn(Player actor, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("list")) {
            showWarnings(actor, args);
            return true;
        }
        if (args.length < 2) {
            actor.sendMessage(ChatColor.RED + "Использование: /cwarn <ник> <причина>");
            actor.sendMessage(ChatColor.GRAY + "История: /cwarn list [ник]");
            return true;
        }
        OfflinePlayer target = findPlayer(args[0]);
        if (target == null) {
            actor.sendMessage(ChatColor.RED + "Игрок не найден.");
            return true;
        }
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        if (reason.isBlank() || reason.length() > 200) {
            actor.sendMessage(ChatColor.RED + "Причина обязательна (до 200 символов).");
            return true;
        }
        var result = plugin.getClanModerationService().warn(actor.getUniqueId(), target.getUniqueId(), reason);
        switch (result) {
            case APPLIED -> {
                actor.sendMessage(ChatColor.GREEN + "Предупреждение выдано игроку " + displayName(target) + ".");
                Player online = plugin.getServer().getPlayer(target.getUniqueId());
                if (online != null) online.sendMessage(ChatColor.RED + "Ты получил предупреждение в клане. Причина: " + reason);
            }
            case INSUFFICIENT_PERMISSION -> actor.sendMessage(ChatColor.RED
                    + "Нельзя предупреждать равного или старшего по роли, а также самого себя.");
            case TARGET_NOT_IN_CLAN -> actor.sendMessage(ChatColor.RED + "Игрок не состоит в твоём клане.");
            case NOT_IN_CLAN -> actor.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            default -> actor.sendMessage(ChatColor.RED + "Предупреждение не выдано: " + result + ".");
        }
        return true;
    }

    private void showWarnings(Player actor, String[] args) {
        java.util.UUID targetId = null;
        if (args.length >= 2) {
            OfflinePlayer target = findPlayer(args[1]);
            if (target == null) {
                actor.sendMessage(ChatColor.RED + "Игрок не найден.");
                return;
            }
            targetId = target.getUniqueId();
        }
        List<com.skyworldclans.clan.storage.sqlite.SqliteClanStore.ClanWarning> warnings =
                plugin.getClanModerationService().warnings(actor.getUniqueId(), targetId);
        actor.sendMessage(ChatColor.GOLD + "Предупреждения (" + warnings.size() + "):");
        if (warnings.isEmpty()) actor.sendMessage(ChatColor.GRAY + "Записей нет.");
        for (var warning : warnings) {
            actor.sendMessage(ChatColor.YELLOW + playerName(warning.playerId()) + ChatColor.GRAY
                    + " | " + warning.issuedAt() + " | выдал: " + playerName(warning.issuedBy())
                    + " | " + warning.reason()
                    + (warning.active() ? "" : " | снято: " + warning.removedAt()));
        }
        Clan clan = plugin.getClanStore().findByPlayerId(actor.getUniqueId()).orElse(null);
        if (clan != null) {
            var cases = plugin.getClanModerationService().cases(actor.getUniqueId());
            if (!cases.isEmpty()) {
                actor.sendMessage(ChatColor.GOLD + "Дела по предупреждениям (" + cases.size() + "):");
                for (var warningCase : cases) {
                    actor.sendMessage(ChatColor.YELLOW + warningCase.caseId().toString() + ChatColor.GRAY
                            + " | игрок: " + playerName(warningCase.playerId())
                            + " | статус: " + warningCase.status()
                            + " | решение до: " + warningCase.deadlineAt());
                }
            }
        }
    }

    private boolean unwarn(Player actor, String[] args) {
        if (args.length != 1) {
            actor.sendMessage(ChatColor.RED + "Использование: /cunwarn <ник>");
            return true;
        }
        OfflinePlayer target = findPlayer(args[0]);
        if (target == null) {
            actor.sendMessage(ChatColor.RED + "Игрок не найден.");
            return true;
        }
        var result = plugin.getClanModerationService().removeWarning(actor.getUniqueId(), target.getUniqueId());
        switch (result) {
            case APPLIED -> actor.sendMessage(ChatColor.GREEN + "Последнее активное предупреждение снято.");
            case NO_ACTIVE_WARNING -> actor.sendMessage(ChatColor.YELLOW + "У игрока нет активных предупреждений.");
            case INSUFFICIENT_PERMISSION -> actor.sendMessage(ChatColor.RED
                    + "Снимать предупреждения могут только лидер и заместитель.");
            case NOT_IN_CLAN -> actor.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            default -> actor.sendMessage(ChatColor.RED + "Предупреждение не снято: " + result + ".");
        }
        return true;
    }

    private static Duration parseDuration(String raw) {
        String value = raw.toLowerCase(Locale.ROOT).trim();
        try {
            if (value.endsWith("m")) return Duration.ofMinutes(Long.parseLong(value.substring(0, value.length() - 1)));
            if (value.endsWith("h")) return Duration.ofHours(Long.parseLong(value.substring(0, value.length() - 1)));
            if (value.endsWith("d")) return Duration.ofDays(Long.parseLong(value.substring(0, value.length() - 1)));
            return Duration.ofMinutes(Long.parseLong(value));
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = plugin.getServer().getPlayerExact(name);
        if (online != null) return online;
        for (OfflinePlayer offline : plugin.getServer().getOfflinePlayers()) {
            if (name.equalsIgnoreCase(offline.getName())) return offline;
        }
        return null;
    }

    private static String displayName(OfflinePlayer player) {
        return player.getName() == null ? player.getUniqueId().toString() : player.getName();
    }

    private String playerName(java.util.UUID id) {
        if (id == null) return "система";
        OfflinePlayer player = plugin.getServer().getOfflinePlayer(id);
        return player.getName() == null ? id.toString() : player.getName();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (mode == Mode.MUTE && args.length == 1) {
            List<String> values = new ArrayList<>();
            values.add("list");
            plugin.getServer().getOnlinePlayers().forEach(player -> values.add(player.getName()));
            return partial(values, args[0]);
        }
        if (mode == Mode.WARN && args.length == 1) {
            List<String> values = new ArrayList<>();
            values.add("list");
            plugin.getServer().getOnlinePlayers().forEach(player -> values.add(player.getName()));
            return partial(values, args[0]);
        }
        if ((mode == Mode.UNMUTE || mode == Mode.UNWARN) && args.length == 1) {
            return partial(plugin.getServer().getOnlinePlayers().stream().map(Player::getName).toList(), args[0]);
        }
        return List.of();
    }

    private static List<String> partial(List<String> values, String prefix) {
        String normalized = prefix.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(normalized)).toList();
    }
}
package com.skyworldclans.clan.application.purchase;

import com.skyworldclans.clan.Clan;
import java.util.Optional;

/**
 * Result of a capacity expansion attempt through the application-layer coordinator.
 * This is separate from ClanCapacityExpansionResult which is used by the lower-level
 * ClanService.expandCapacity() method.
 */
public record CapacityExpansionResult(
        Status status,
        Optional<Clan> clan) {

    public CapacityExpansionResult {
        if (status == null) {
            throw new NullPointerException("status");
        }
        if (clan == null) {
            throw new NullPointerException("clan");
        }
        if ((status == Status.EXPANDED) != clan.isPresent()) {
            throw new IllegalArgumentException(
                    "Only a successful expansion may contain a clan");
        }
    }

    public enum Status {
            EXPANDED,
            CLAN_NOT_FOUND,
            NOT_LEADER,
            INVALID_CAPACITY_TRANSITION,
            CONCURRENT_MODIFICATION,
            INVALID_INPUT,
            PENDING_EXPANSION,
            EXPANSION_IN_PROGRESS,
            EXPANSION_FAILED,
            UNKNOWN_RESULT,
            PAYMENT_PROVIDER_ERROR,
            TRANSITION_FAILED,
            COMMIT_FAILED,
            WRONG_STATE,
            LEADER_CHANGED,
            STATE_CONFLICT,
            BUSINESS_OPERATION_CONFLICT,
            HISTORY_EVIDENCE_UNVERIFIABLE,
            HISTORY_CORRUPTED,
            OPERATION_ID_CONFLICT,
            IDEMPOTENCY_KEY_CONFLICT,
            DEBIT_CONFIRMED,
            COMPENSATION_REQUIRED,
            COMPENSATED,
                        COMPENSATION_FAILED,
                        COMPENSATION_UNKNOWN
        }
}
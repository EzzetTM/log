package com.skyworldclans.clan.application.creation;

import java.util.Objects;

/** Fail-closed recovery policy: a possibly executed Vault debit is never retried automatically. */
public final class ClanCreationRecoveryPolicy {
    private ClanCreationRecoveryPolicy() { }

    public static ClanCreationRecoveryAction classify(ClanCreationPaymentOperation operation) {
        Objects.requireNonNull(operation, "operation");
        return switch (operation.state()) {
            case PREPARED -> ClanCreationRecoveryAction.SAFE_TO_ABORT_WITHOUT_PAYMENT;
            case DEBIT_CONFIRMED -> ClanCreationRecoveryAction.SAFE_TO_FINISH_REGISTRATION;
            case CALLING, UNKNOWN -> ClanCreationRecoveryAction.REQUIRES_EXTERNAL_RECONCILIATION;
            case COMMITTED, FAILED_NO_EFFECT -> ClanCreationRecoveryAction.COMPLETED;
        };
    }
}

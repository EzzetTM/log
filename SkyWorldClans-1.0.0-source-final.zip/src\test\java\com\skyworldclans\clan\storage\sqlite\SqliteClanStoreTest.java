package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.bank.ClanBankService;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseEvidenceProvenance;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseIntent;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseEvent;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseJournal;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseOperation;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseState;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseStore;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseTransitionEvidence;
import com.skyworldclans.clan.application.creation.ClanCreationPaymentOperation;
import com.skyworldclans.clan.application.creation.ClanCreationPaymentState;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.StorageException;
import com.skyworldclans.clan.request.ClanRequest;
import com.skyworldclans.clan.request.ClanRequestStore;
import com.skyworldclans.clan.xp.ClanXpAwardResult;
import com.skyworldclans.clan.xp.ClanXpEventType;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SqliteClanStoreTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void operationalStatusCountersReflectTheCurrentSchemaAndRegisteredClan() {
        Path database = temporaryDirectory.resolve("operational-status.sqlite");
        Clan clan = simpleClan(900, "StatusClan", "ST900", memberId(900));
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(28, store.schemaVersion());
            assertEquals(0, store.countClans());
            assertEquals(0, store.countMembers());
            assertEquals(0, store.countActiveElections());
            assertEquals(0, store.countUnresolvedBankOperations());
            assertEquals(0, store.countUnknownBankOperations());
            assertEquals(0, store.countInterruptedCombatLogSessions());
            assertEquals(0, store.countStoragePages());
            assertEquals(0, store.countUnresolvedCreationPayments());

            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(1, store.countClans());
            assertEquals(1, store.countMembers());
            assertEquals(1, store.countStoragePages());
        }
    }

    @Test
    void clanStorageMovementLedgerIsIdempotentAndAppendOnly() {
        Path database = temporaryDirectory.resolve("clan-storage-movements.sqlite");
        Clan clan = simpleClan(899, "StorageClan", "ST899", memberId(899));
        UUID actor = memberId(899);
        UUID operation = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            var recorded = store.recordClanStorageMovement(operation, clan.id(), 1, actor,
                    "DEPOSIT", "minecraft:diamond", 32, now);
            assertEquals(SqliteClanStore.ClanStorageMovementStatus.RECORDED, recorded.status());
            var duplicate = store.recordClanStorageMovement(operation, clan.id(), 1, actor,
                    "DEPOSIT", "minecraft:diamond", 32, now);
            assertEquals(SqliteClanStore.ClanStorageMovementStatus.DUPLICATE, duplicate.status());
            var conflict = store.recordClanStorageMovement(operation, clan.id(), 1, actor,
                    "WITHDRAWAL", "minecraft:diamond", 32, now);
            assertEquals(SqliteClanStore.ClanStorageMovementStatus.IDEMPOTENCY_CONFLICT, conflict.status());
            var invalid = store.recordClanStorageMovement(UUID.randomUUID(), clan.id(), 1, actor,
                    "DEPOSIT", "minecraft:diamond; DROP TABLE clans", 1, now);
            assertEquals(SqliteClanStore.ClanStorageMovementStatus.INVALID_INPUT, invalid.status());
        }
        assertThrows(SQLException.class, () -> executeSql(database,
                "UPDATE clan_storage_item_movements SET amount = 1 WHERE operation_id = '" + operation + "'"));
    }


    @Test
    void clanStorageSnapshotAndMovementReceiptCommitAtomicallyAndAreIdempotent() {
        Path database = temporaryDirectory.resolve("clan-storage-atomic-movement.sqlite");
        Clan clan = simpleClan(898, "AtomicStorage", "AS898", memberId(898));
        UUID actor = memberId(898);
        UUID operation = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        byte[] snapshot = new byte[] { 1, 2, 3, 4, 5 };
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            var committed = store.commitClanStorageMovement(operation, clan.id(), 1, actor,
                    "DEPOSIT", "minecraft:diamond", 5, 0, snapshot, now);
            assertEquals(SqliteClanStore.ClanStorageCommitStatus.COMMITTED, committed.status());
            assertEquals(1, committed.currentRevision());
            assertTrue(java.util.Arrays.equals(snapshot, store.findClanStoragePage(clan.id(), 1).orElseThrow().contents()));

            var duplicate = store.commitClanStorageMovement(operation, clan.id(), 1, actor,
                    "DEPOSIT", "minecraft:diamond", 5, 0, snapshot, now);
            assertEquals(SqliteClanStore.ClanStorageCommitStatus.DUPLICATE, duplicate.status());
            assertEquals(1, duplicate.currentRevision());

            var conflictingRetry = store.commitClanStorageMovement(operation, clan.id(), 1, actor,
                    "DEPOSIT", "minecraft:diamond", 5, 0, new byte[] { 9 }, now);
            assertEquals(SqliteClanStore.ClanStorageCommitStatus.IDEMPOTENCY_CONFLICT, conflictingRetry.status());
            assertEquals(1, store.findClanStoragePage(clan.id(), 1).orElseThrow().revision());
        }
        assertThrows(SQLException.class, () -> executeSql(database,
                "UPDATE clan_storage_committed_operations SET amount = 1 WHERE operation_id = '" + operation + "'"));
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(1, reopened.findClanStoragePage(clan.id(), 1).orElseThrow().revision());
            assertTrue(java.util.Arrays.equals(snapshot, reopened.findClanStoragePage(clan.id(), 1).orElseThrow().contents()));
        }
    }

    @Test
    void clanBankMovementIsAtomicAndIdempotentAcrossReopen() {
        Path database = temporaryDirectory.resolve("clan-bank.sqlite");
        Clan clan = simpleClan(901, "BankClan", "BK901", memberId(901));
        UUID actor = memberId(901);
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(BigDecimal.ZERO, store.clanBankBalance(clan.id()));
            var deposit = store.recordClanBankMovement(UUID.randomUUID(), "bank-deposit-1", clan.id(), actor,
                    "DEPOSIT", new BigDecimal("1250.75"), "member contribution", null, now);
            assertEquals(SqliteClanStore.ClanBankMovementStatus.APPLIED, deposit.status());
            assertEquals(new BigDecimal("1250.75"), deposit.balance());
            var duplicate = store.recordClanBankMovement(UUID.randomUUID(), "bank-deposit-1", clan.id(), actor,
                    "DEPOSIT", new BigDecimal("1250.750"), "retry", null, now.plusSeconds(1));
            assertEquals(SqliteClanStore.ClanBankMovementStatus.DUPLICATE, duplicate.status());
            var conflict = store.recordClanBankMovement(UUID.randomUUID(), "bank-deposit-1", clan.id(), actor,
                    "DEPOSIT", new BigDecimal("1251"), null, null, now.plusSeconds(2));
            assertEquals(SqliteClanStore.ClanBankMovementStatus.IDEMPOTENCY_CONFLICT, conflict.status());
            var overdraft = store.recordClanBankMovement(UUID.randomUUID(), "bank-withdrawal-overdraft", clan.id(), actor,
                    "WITHDRAWAL", new BigDecimal("-2000"), null, null, now.plusSeconds(3));
            assertEquals(SqliteClanStore.ClanBankMovementStatus.INSUFFICIENT_BANK_FUNDS, overdraft.status());
            assertEquals(new BigDecimal("1250.75"), store.clanBankBalance(clan.id()));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(new BigDecimal("1250.75"), reopened.clanBankBalance(clan.id()));
            var withdrawal = reopened.recordClanBankMovement(UUID.randomUUID(), "bank-withdrawal-1", clan.id(), actor,
                    "WITHDRAWAL", new BigDecimal("-250.75"), "approved withdrawal", actor, now.plusSeconds(4));
            assertEquals(SqliteClanStore.ClanBankMovementStatus.APPLIED, withdrawal.status());
            assertEquals(new BigDecimal("1000"), reopened.clanBankBalance(clan.id()));
        }
    }

    @Test
    void bankWithdrawalRequestsAreIdempotentExpireAndNeverMoveFundsOnApproval() {
        Path database = temporaryDirectory.resolve("bank-withdrawal-requests.sqlite");
        UUID deputy = memberId(903);
        UUID leader = memberId(902);
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new Clan(UUID.randomUUID(), "RequestClan", "RQ902", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null)), 0, null);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            var created = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "withdraw-request-1",
                    clan.id(), deputy, new BigDecimal("250.50"), "Нужно оплатить аренду", now, now.plusSeconds(86_400));
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.CREATED, created.status());
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.PENDING, created.request().status());
            var duplicate = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "withdraw-request-1",
                    clan.id(), deputy, new BigDecimal("250.500"), "Нужно оплатить аренду", now, now.plusSeconds(86_400));
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.DUPLICATE, duplicate.status());
            assertEquals(created.request().requestId(), duplicate.request().requestId());
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.IDEMPOTENCY_CONFLICT,
                    store.createClanBankWithdrawalRequest(UUID.randomUUID(), "withdraw-request-1", clan.id(),
                            deputy, new BigDecimal("251"), "Нужно оплатить аренду", now, now.plusSeconds(86_400)).status());
            var approved = store.resolveClanBankWithdrawalRequest(created.request().requestId(), leader,
                    SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED, now.plusSeconds(10), "approved by leader");
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED, approved.status());
            assertEquals(BigDecimal.ZERO, store.clanBankBalance(clan.id()), "approval must not debit the bank");
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.ALREADY_RESOLVED,
                    store.resolveClanBankWithdrawalRequest(created.request().requestId(), leader,
                            SqliteClanStore.ClanBankWithdrawalRequestStatus.DECLINED, now.plusSeconds(20), "late decline").status());

            Instant secondCreated = now.plusSeconds(60);
            var expiring = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "withdraw-request-2",
                    clan.id(), deputy, new BigDecimal("10"), "test expiry", secondCreated, secondCreated.plusSeconds(86_400));
            int expiredCount = store.expireDueClanBankWithdrawalRequests(secondCreated.plusSeconds(86_400), UUID.fromString("00000000-0000-0000-0000-000000000000"));
            assertEquals(1, expiredCount);
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.EXPIRED,
                    store.findClanBankWithdrawalRequests(clan.id(), false).stream()
                            .filter(request -> request.requestId().equals(expiring.request().requestId()))
                            .findFirst().orElseThrow().status());
            assertEquals(BigDecimal.ZERO, store.clanBankBalance(clan.id()));
            assertEquals(0, store.findClanBankWithdrawalRequests(clan.id(), true).size(), "only approved/expired requests should be excluded from pending list");
        }
    }

    @Test
    void bankServiceEnforcesDeputyRequestAndLeaderApprovalWithinTheSameClan() {
        Path database = temporaryDirectory.resolve("bank-service.sqlite");
        UUID leader = memberId(910);
        UUID deputy = memberId(911);
        UUID member = memberId(912);
        UUID otherLeader = memberId(913);
        UUID otherDeputy = memberId(914);
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new Clan(UUID.randomUUID(), "ServiceClan", "SC910", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null),
                        member, new ClanMember(member, ClanRole.MEMBER, now, null)), 0, null);
        Clan otherClan = new Clan(UUID.randomUUID(), "OtherServiceClan", "OSC13", now, 10,
                Map.of(otherLeader, new ClanMember(otherLeader, ClanRole.LEADER, now, null),
                        otherDeputy, new ClanMember(otherDeputy, ClanRole.DEPUTY, now, null)), 0, null);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(otherClan));
            ClanBankService service = new ClanBankService(store, store, java.time.Clock.fixed(now, java.time.ZoneOffset.UTC), UUID::randomUUID);
            assertEquals(ClanBankService.Status.DEPUTY_ONLY,
                    service.requestWithdrawal(clan.id(), member, new BigDecimal("10"), "no").status());
            var request = service.requestWithdrawal(clan.id(), deputy, new BigDecimal("10"), "approved cost");
            assertEquals(ClanBankService.Status.CREATED, request.status());
            assertEquals(ClanBankService.Status.LEADER_ONLY,
                    service.resolveWithdrawal(clan.id(), deputy, request.request().requestId(), true).status());
            var otherRequest = service.requestWithdrawal(otherClan.id(), otherDeputy, new BigDecimal("5"), "other clan");
            assertEquals(ClanBankService.Status.CREATED, otherRequest.status());
            assertEquals(ClanBankService.Status.REQUEST_NOT_FOUND,
                    service.resolveWithdrawal(clan.id(), leader, otherRequest.request().requestId(), true).status());
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.PENDING,
                    store.findClanBankWithdrawalRequests(otherClan.id(), false).get(0).status());
            assertEquals(ClanBankService.Status.APPROVED,
                    service.resolveWithdrawal(clan.id(), leader, request.request().requestId(), true).status());
            assertEquals(BigDecimal.ZERO, store.clanBankBalance(clan.id()));
        }
    }

    @Test
    void bankOperationJournalReservesFundsAndReconcilesUnknownWithoutRepeatingProviderCall() {
        Path database = temporaryDirectory.resolve("bank-operations.sqlite");
        UUID leader = memberId(920);
        UUID deputy = memberId(921);
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new Clan(UUID.randomUUID(), "OperationClan", "OP920", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null)), 0, null);
        UUID depositOperationId = UUID.randomUUID();
        UUID depositBusinessId = UUID.randomUUID();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            var preparedDeposit = store.prepareClanBankOperation(depositOperationId, "bank-deposit-op-1",
                    depositBusinessId, clan.id(), leader, leader, null, "DEPOSIT", new BigDecimal("100"), now);
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED, preparedDeposit.status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.DUPLICATE,
                    store.prepareClanBankOperation(UUID.randomUUID(), "bank-deposit-op-duplicate",
                            depositBusinessId, clan.id(), leader, leader, null, "DEPOSIT", new BigDecimal("100"), now).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.BUSINESS_OPERATION_CONFLICT,
                    store.prepareClanBankOperation(UUID.randomUUID(), "bank-deposit-op-conflict",
                            depositBusinessId, clan.id(), leader, leader, null, "DEPOSIT", new BigDecimal("101"), now).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(depositOperationId, SqliteClanStore.ClanBankOperationState.PREPARED,
                            SqliteClanStore.ClanBankOperationState.CALLING, "CALL_INTENT_PERSISTED", now.plusSeconds(1)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(depositOperationId, SqliteClanStore.ClanBankOperationState.CALLING,
                            SqliteClanStore.ClanBankOperationState.EXTERNAL_CONFIRMED, "PROVIDER_SUCCESS_RESPONSE", now.plusSeconds(2)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.COMMITTED,
                    store.commitConfirmedClanBankOperation(depositOperationId, now.plusSeconds(3)).status());
            assertEquals(new BigDecimal("100"), store.clanBankBalance(clan.id()));

            var request = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "bank-op-request-1", clan.id(),
                    deputy, new BigDecimal("70"), "approved expense", now.plusSeconds(4), now.plusSeconds(86_404));
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.CREATED, request.status());
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED,
                    store.resolveClanBankWithdrawalRequest(request.request().requestId(), leader,
                            SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED, now.plusSeconds(5), "leader approved").status());
            UUID withdrawalOperationId = UUID.randomUUID();
            var withdrawal = store.prepareClanBankOperation(withdrawalOperationId, "bank-withdraw-op-1",
                    UUID.randomUUID(), clan.id(), leader, deputy, request.request().requestId(),
                    "WITHDRAWAL", new BigDecimal("70"), now.plusSeconds(6));
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED, withdrawal.status());
            assertEquals(withdrawalOperationId, store.findClanBankWithdrawalRequests(clan.id(), false).stream()
                    .filter(value -> value.requestId().equals(request.request().requestId()))
                    .findFirst().orElseThrow().paymentOperationId());
            assertEquals(new BigDecimal("30"), store.clanBankAvailableBalance(clan.id()));
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(withdrawalOperationId, SqliteClanStore.ClanBankOperationState.PREPARED,
                            SqliteClanStore.ClanBankOperationState.CALLING, "CALL_INTENT_PERSISTED", now.plusSeconds(7)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(withdrawalOperationId, SqliteClanStore.ClanBankOperationState.CALLING,
                            SqliteClanStore.ClanBankOperationState.UNKNOWN, "PROVIDER_RESULT_UNKNOWN", now.plusSeconds(8)).status());
            assertEquals(new BigDecimal("30"), store.clanBankAvailableBalance(clan.id()), "unknown payout must keep its reservation");
            assertEquals(SqliteClanStore.ClanBankMovementStatus.INSUFFICIENT_BANK_FUNDS,
                    store.recordClanBankMovement(UUID.randomUUID(), "cannot-spend-reserved", clan.id(), leader,
                            "WITHDRAWAL", new BigDecimal("-40"), null, null, now.plusSeconds(9)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.COMMITTED,
                    store.reconcileUnknownClanBankOperation(withdrawalOperationId, true,
                            "provider ledger entry checked by operator", now.plusSeconds(10)).status());
            assertEquals(new BigDecimal("30"), store.clanBankBalance(clan.id()));
            assertEquals(new BigDecimal("30"), store.clanBankAvailableBalance(clan.id()));
            var bankHistory = store.findClanBankTransactions(clan.id(), 10);
            assertEquals(2, bankHistory.size());
            assertEquals("WITHDRAWAL", bankHistory.get(0).transactionType());
            assertEquals(new BigDecimal("-70"), bankHistory.get(0).amount());
            assertEquals("DEPOSIT", bankHistory.get(1).transactionType());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.DUPLICATE,
                    store.commitConfirmedClanBankOperation(withdrawalOperationId, now.plusSeconds(11)).status());

            UUID preparedOnly = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED,
                    store.prepareClanBankOperation(preparedOnly, "leader-withdraw-prepared", UUID.randomUUID(),
                            clan.id(), leader, leader, null, "LEADER_WITHDRAWAL", new BigDecimal("10"), now.plusSeconds(12)).status());
            var recovered = store.recoverClanBankOperationsAfterRestart(now.plusSeconds(13));
            assertTrue(recovered.stream().anyMatch(result -> result.operation() != null
                    && result.operation().operationId().equals(preparedOnly)
                    && result.operation().state() == SqliteClanStore.ClanBankOperationState.FAILED_NO_EFFECT));
            assertEquals(new BigDecimal("30"), store.clanBankAvailableBalance(clan.id()));

            UUID interruptedCall = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED,
                    store.prepareClanBankOperation(interruptedCall, "deposit-interrupted-call", UUID.randomUUID(),
                            clan.id(), deputy, deputy, null, "DEPOSIT", new BigDecimal("20"), now.plusSeconds(14)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(interruptedCall, SqliteClanStore.ClanBankOperationState.PREPARED,
                            SqliteClanStore.ClanBankOperationState.CALLING, "CALL_INTENT_PERSISTED", now.plusSeconds(15)).status());
            var restartResults = store.recoverClanBankOperationsAfterRestart(now.plusSeconds(16));
            assertTrue(restartResults.stream().anyMatch(result -> result.operation() != null
                    && result.operation().operationId().equals(interruptedCall)
                    && result.operation().state() == SqliteClanStore.ClanBankOperationState.UNKNOWN));
            assertEquals(SqliteClanStore.ClanBankOperationStatus.MANUAL_RECONCILIATION_REQUIRED,
                    store.recoverClanBankOperationsAfterRestart(now.plusSeconds(17)).stream()
                            .filter(result -> result.operation() != null && result.operation().operationId().equals(interruptedCall))
                            .findFirst().orElseThrow().status());
            assertEquals(new BigDecimal("30"), store.clanBankBalance(clan.id()), "recovery must not repeat or invent the external deposit");

            Instant finalRequestAt = now.plusSeconds(18);
            var unresolvedRequest = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "bank-op-request-unknown",
                    clan.id(), deputy, new BigDecimal("5"), "unresolved payout", finalRequestAt, finalRequestAt.plusSeconds(86_400));
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED,
                    store.resolveClanBankWithdrawalRequest(unresolvedRequest.request().requestId(), leader,
                            SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED, finalRequestAt.plusSeconds(1), "approved").status());
            UUID unknownWithdrawal = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED,
                    store.prepareClanBankOperation(unknownWithdrawal, "unknown-withdrawal-op", UUID.randomUUID(),
                            clan.id(), leader, deputy, unresolvedRequest.request().requestId(),
                            "WITHDRAWAL", new BigDecimal("5"), finalRequestAt.plusSeconds(2)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(unknownWithdrawal, SqliteClanStore.ClanBankOperationState.PREPARED,
                            SqliteClanStore.ClanBankOperationState.CALLING, "CALL_INTENT_PERSISTED", finalRequestAt.plusSeconds(3)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(unknownWithdrawal, SqliteClanStore.ClanBankOperationState.CALLING,
                            SqliteClanStore.ClanBankOperationState.UNKNOWN, "PROVIDER_RESULT_UNKNOWN", finalRequestAt.plusSeconds(4)).status());
            assertEquals(new BigDecimal("25"), store.clanBankAvailableBalance(clan.id()));

            Instant retryRequestAt = now.plusSeconds(23);
            var retryRequest = store.createClanBankWithdrawalRequest(UUID.randomUUID(), "retry-after-no-effect",
                    clan.id(), deputy, new BigDecimal("3"), "retry after confirmed no effect",
                    retryRequestAt, retryRequestAt.plusSeconds(86_400));
            assertEquals(SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED,
                    store.resolveClanBankWithdrawalRequest(retryRequest.request().requestId(), leader,
                            SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED, retryRequestAt.plusSeconds(1), "approved").status());
            UUID firstAttempt = UUID.randomUUID();
            UUID retryBusinessId = UUID.nameUUIDFromBytes(("SkyWorldClans:bank-withdrawal:" + retryRequest.request().requestId()).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED,
                    store.prepareClanBankOperation(firstAttempt, "retry-attempt-1", retryBusinessId,
                            clan.id(), leader, deputy, retryRequest.request().requestId(), "WITHDRAWAL",
                            new BigDecimal("3"), retryRequestAt.plusSeconds(2)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(firstAttempt, SqliteClanStore.ClanBankOperationState.PREPARED,
                            SqliteClanStore.ClanBankOperationState.CALLING, "CALL_INTENT", retryRequestAt.plusSeconds(3)).status());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(firstAttempt, SqliteClanStore.ClanBankOperationState.CALLING,
                            SqliteClanStore.ClanBankOperationState.FAILED_NO_EFFECT, "PROVIDER_NOT_CALLED", retryRequestAt.plusSeconds(4)).status());
            UUID secondAttempt = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanBankOperationStatus.PREPARED,
                    store.prepareClanBankOperation(secondAttempt, "retry-attempt-2", retryBusinessId,
                            clan.id(), leader, deputy, retryRequest.request().requestId(), "WITHDRAWAL",
                            new BigDecimal("3"), retryRequestAt.plusSeconds(5)).status());
            assertEquals(secondAttempt, store.findClanBankWithdrawalRequests(clan.id(), false).stream()
                    .filter(value -> value.requestId().equals(retryRequest.request().requestId()))
                    .findFirst().orElseThrow().paymentOperationId());
            assertEquals(SqliteClanStore.ClanBankOperationStatus.UPDATED,
                    store.transitionClanBankOperation(secondAttempt, SqliteClanStore.ClanBankOperationState.PREPARED,
                            SqliteClanStore.ClanBankOperationState.FAILED_NO_EFFECT, "PROVIDER_NOT_CALLED", retryRequestAt.plusSeconds(6)).status());
            assertEquals(new BigDecimal("25"), store.clanBankAvailableBalance(clan.id()));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(new BigDecimal("30"), reopened.clanBankBalance(clan.id()));
            assertEquals(new BigDecimal("25"), reopened.clanBankAvailableBalance(clan.id()));
            var recovery = reopened.recoverClanBankOperationsAfterRestart(now.plusSeconds(40));
            assertTrue(recovery.stream().anyMatch(result -> result.status()
                    == SqliteClanStore.ClanBankOperationStatus.MANUAL_RECONCILIATION_REQUIRED));
            assertEquals(new BigDecimal("25"), reopened.clanBankAvailableBalance(clan.id()),
                    "unknown withdrawal reservation must remain held after restart");
        }
    }

    /**
     * Builds a genuine schema snapshot at {@code version} by letting the real migrator apply
     * versions 1..version and aborting the next step. The abort rolls that step back, so the file
     * is a valid historical snapshot without any hand-written DROP surgery.
     */
    private void buildSchemaAtVersion(Path database, int version) throws Exception {
        try {
            SqliteClanStore.open(database, SqliteTransactionControl.JDBC, applied -> {
                if (applied == version + 1) throw new StopAtVersion();
            });
            throw new IllegalStateException("Migrator did not reach version " + (version + 1));
        } catch (StopAtVersion expected) {
            assertEquals(version, pragmaInt(database, "PRAGMA user_version"));
        }
    }

    private static final class StopAtVersion extends RuntimeException {
        private StopAtVersion() { super(null, null, false, false); }
    }

    private void downgradeClanHomeToLegacyShape(Path database) throws Exception {
        // A genuine pre-v24 snapshot has one home point per clan and no purchase state.
        executeSql(database, "DROP TABLE IF EXISTS clan_home_slots");
        executeSql(database, "DROP TRIGGER IF EXISTS clan_home_events_no_update");
        executeSql(database, "DROP TRIGGER IF EXISTS clan_home_events_no_delete");
        executeSql(database, "DROP TABLE IF EXISTS clan_home_events");
        executeSql(database, "DROP TABLE IF EXISTS clan_home_points");
        executeSql(database, """
                CREATE TABLE clan_home_points (
                    clan_id TEXT PRIMARY KEY NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 32),
                    world_id TEXT NOT NULL,
                    x REAL NOT NULL, y REAL NOT NULL, z REAL NOT NULL,
                    yaw REAL NOT NULL, pitch REAL NOT NULL,
                    created_by TEXT NOT NULL, created_at TEXT NOT NULL,
                    updated_by TEXT NOT NULL, updated_at TEXT NOT NULL
                )
                """);
        executeSql(database, """
                CREATE TABLE clan_home_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    clan_id TEXT NOT NULL,
                    actor_id TEXT NOT NULL,
                    event_type TEXT NOT NULL CHECK (event_type IN ('SET', 'RENAME', 'DELETE')),
                    home_name TEXT NOT NULL,
                    world_id TEXT NOT NULL,
                    x REAL NOT NULL, y REAL NOT NULL, z REAL NOT NULL,
                    yaw REAL NOT NULL, pitch REAL NOT NULL,
                    occurred_at TEXT NOT NULL
                )
                """);
        executeSql(database, "CREATE INDEX clan_home_events_clan_idx ON clan_home_events(clan_id, event_id)");
        executeSql(database, """
                CREATE TRIGGER clan_home_events_no_update
                BEFORE UPDATE ON clan_home_events
                BEGIN SELECT RAISE(ABORT, 'clan home events are append-only'); END
                """);
        executeSql(database, """
                CREATE TRIGGER clan_home_events_no_delete
                BEFORE DELETE ON clan_home_events
                BEGIN SELECT RAISE(ABORT, 'clan home events are append-only'); END
                """);
    }

    @Test
    void migrationToVersionNineteenRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v19-rollback.sqlite");
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 19) throw new IllegalStateException("injected v19 failure");
                }));
        assertEquals(18, pragmaInt(database, "PRAGMA user_version"));
        assertTrue(tableExists(database, "clan_bank_withdrawal_requests"));
        assertTrue(tableExists(database, "clan_bank_operations"));
        assertTrue(tableExists(database, "clan_combat_log_sessions"));
        assertTrue(tableExists(database, "clan_home_points"));
        assertTrue(tableExists(database, "clan_storage_accounts"));
        assertTrue(tableExists(database, "clan_storage_content_events"));
        assertTrue(tableExists(database, "clan_storage_item_movements"));
        assertFalse(tableExists(database, "clan_storage_committed_operations"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertTrue(tableExists(database, "clan_bank_accounts"));
            assertTrue(tableExists(database, "clan_bank_transactions"));
            assertTrue(tableExists(database, "clan_bank_withdrawal_requests"));
            assertTrue(tableExists(database, "clan_bank_operations"));
            assertTrue(tableExists(database, "clan_bank_reservations"));
            assertTrue(tableExists(database, "clan_combat_log_sessions"));
            assertTrue(tableExists(database, "clan_combat_log_events"));
            assertTrue(tableExists(database, "clan_home_points"));
            assertTrue(tableExists(database, "clan_home_events"));
            assertTrue(tableExists(database, "clan_storage_accounts"));
            assertTrue(tableExists(database, "clan_storage_pages"));
            assertTrue(tableExists(database, "clan_storage_events"));
            assertTrue(tableExists(database, "clan_storage_content_events"));
            assertTrue(tableExists(database, "clan_storage_item_movements"));
            assertTrue(tableExists(database, "clan_storage_committed_operations"));
            assertTrue(tableExists(database, "clan_storage_transfer_operations"));
            assertTrue(tableExists(database, "clan_storage_transfer_events"));
        }
    }

    @Test
    void migrationToVersionTwentyRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v20-rollback.sqlite");
        buildSchemaAtVersion(database, 19);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 20) throw new IllegalStateException("injected v20 failure");
                }));
        assertEquals(19, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_storage_transfer_operations"));
        assertFalse(tableExists(database, "clan_storage_transfer_events"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_storage_transfer_operations"));
            assertTrue(tableExists(database, "clan_storage_transfer_events"));
        }
    }

    @Test
    void migrationToVersionTwentyTwoRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v22-rollback.sqlite");
        buildSchemaAtVersion(database, 21);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 22) throw new IllegalStateException("injected v22 failure");
                }));
        assertEquals(21, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_chat_mutes"));
        assertFalse(tableExists(database, "clan_warnings"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_chat_mutes"));
            assertTrue(tableExists(database, "clan_warnings"));
            assertTrue(tableExists(database, "clan_warning_cases"));
        }
    }

    @Test
    void migrationToVersionTwentyThreeRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v23-rollback.sqlite");
        buildSchemaAtVersion(database, 22);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 23) throw new IllegalStateException("injected v23 failure");
                }));
        assertEquals(22, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_reward_operations"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_reward_operations"));
            assertTrue(tableExists(database, "clan_reward_events"));
        }
    }

    @Test
    void migrationToVersionTwentyFourRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v24-rollback.sqlite");
        buildSchemaAtVersion(database, 23);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 24) throw new IllegalStateException("injected v24 failure");
                }));
        assertEquals(23, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_home_slots"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_home_slots"));
            assertTrue(recovered.homeSlotOwned(new UUID(0, 1), 1));
        }
    }

    @Test
    void migrationToVersionTwentyFiveRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v25-rollback.sqlite");
        buildSchemaAtVersion(database, 24);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 25) throw new IllegalStateException("injected v25 failure");
                }));
        assertEquals(24, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_reward_requests"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_reward_requests"));
            assertTrue(tableExists(database, "clan_reward_request_events"));
        }
    }

    @Test
    void migrationToVersionTwentySixRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v26-rollback.sqlite");
        buildSchemaAtVersion(database, 25);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 26) throw new IllegalStateException("injected v26 failure");
                }));
        assertEquals(25, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_reports"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_reports"));
            assertTrue(tableExists(database, "clan_sanctions"));
            assertTrue(tableExists(database, "clan_appeals"));
        }
    }

    @Test
    void migrationToVersionTwentySevenRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v27-rollback.sqlite");
        buildSchemaAtVersion(database, 26);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 27) throw new IllegalStateException("injected v27 failure");
                }));
        assertEquals(26, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_quests"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_quests"));
            assertTrue(tableExists(database, "clan_quest_contributors"));
        }
    }

    @Test
    void migrationToVersionTwentyEightRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v28-rollback.sqlite");
        buildSchemaAtVersion(database, 27);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 28) throw new IllegalStateException("injected v28 failure");
                }));
        assertEquals(27, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_tournaments"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, recovered.schemaVersion());
            assertTrue(tableExists(database, "clan_tournaments"));
            assertTrue(tableExists(database, "clan_tournament_votes"));
        }
    }

    @Test
    void clanStorageEscrowRecoversBeforeAfterAndUnknownPlayerSnapshots() {
        Path database = temporaryDirectory.resolve("clan-storage-escrow.sqlite");
        Clan clan = simpleClan(897, "EscrowClan", "ES897", memberId(897));
        UUID actor = memberId(897);
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        byte[] playerBefore = new byte[] { 1, 2 };
        byte[] playerAfter = new byte[] { 3, 4 };
        byte[] pageBefore = new byte[0];
        byte[] pageAfter = new byte[] { 5, 6 };
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            UUID abortedId = UUID.randomUUID();
            var prepared = store.prepareClanStorageTransfer(abortedId, clan.id(), 1, actor,
                    "DEPOSIT", "minecraft:diamond", 2, 0, playerBefore, playerAfter,
                    pageBefore, pageAfter, now);
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.PREPARED, prepared.status());
            assertEquals(1, store.pendingClanStorageTransfers(actor).size());
            assertEquals(SqliteClanStore.ClanStorageContentSaveStatus.TRANSFER_PENDING,
                    store.saveClanStoragePageContents(clan.id(), 1, actor, 0, new byte[] { 9 }, now).status());
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.BUSY,
                    store.prepareClanStorageTransfer(UUID.randomUUID(), clan.id(), 1, actor,
                            "DEPOSIT", "minecraft:diamond", 2, 0, playerBefore, playerAfter,
                            pageBefore, pageAfter, now).status());
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.ABORTED,
                    store.resolveClanStorageTransfer(abortedId, actor, playerBefore, now.plusSeconds(1)).status());
            assertEquals(0, store.findClanStoragePage(clan.id(), 1).orElseThrow().revision());

            UUID committedId = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.PREPARED,
                    store.prepareClanStorageTransfer(committedId, clan.id(), 1, actor,
                            "DEPOSIT", "minecraft:diamond", 2, 0, playerBefore, playerAfter,
                            pageBefore, pageAfter, now.plusSeconds(2)).status());
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.COMMITTED,
                    store.resolveClanStorageTransfer(committedId, actor, playerAfter, now.plusSeconds(3)).status());
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.DUPLICATE,
                    store.resolveClanStorageTransfer(committedId, actor, playerAfter, now.plusSeconds(4)).status());
            assertEquals(1, store.findClanStoragePage(clan.id(), 1).orElseThrow().revision());
            assertTrue(java.util.Arrays.equals(pageAfter, store.findClanStoragePage(clan.id(), 1).orElseThrow().contents()));

            UUID reviewId = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.PREPARED,
                    store.prepareClanStorageTransfer(reviewId, clan.id(), 1, actor,
                            "WITHDRAWAL", "minecraft:diamond", 2, 1, playerBefore, playerAfter,
                            pageAfter, new byte[] { 7, 8 }, now.plusSeconds(5)).status());
            assertEquals(SqliteClanStore.ClanStorageTransferStatus.MANUAL_REVIEW,
                    store.resolveClanStorageTransfer(reviewId, actor, new byte[] { 9 }, now.plusSeconds(6)).status());
            assertEquals(0, store.pendingClanStorageTransfers(actor).size());
            assertEquals(1, store.clanStorageTransfersRequiringReview(20).size());
        }
    }

    @Test
    void createsAndReopensDatabaseAndPreservesClanAndMemberFields() {
        Path database = temporaryDirectory.resolve("clans.sqlite");
        Clan expected = completeClan();

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(expected));
            assertEquals(Optional.of(expected), store.findById(expected.id()));
            assertEquals(Optional.of(expected), store.findByTag(expected.tag().toLowerCase()));
            assertEquals(Optional.of(expected), store.findByPlayerId(memberId(3)));
        }

        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(Optional.of(expected), reopened.findById(expected.id()));
        }
    }

    @Test
    void backupToCreatesVerifiedStandaloneSnapshotWithQuotedPath() {
        Path database = temporaryDirectory.resolve("backup-source.sqlite");
        Path backup = temporaryDirectory.resolve("backup'snapshot.sqlite");
        Clan expected = simpleClan(9, "BackupClan", "B9", memberId(9));

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED,
                    store.registerIfAvailable(expected));
            assertEquals(backup.toAbsolutePath().normalize(), store.backupTo(backup));
            assertTrue(Files.isRegularFile(backup));
        }

        try (SqliteClanStore restored = SqliteClanStore.open(backup)) {
            assertEquals(Optional.of(expected), restored.findById(expected.id()));
        }
    }

    @Test
    void backupToRefusesToOverwriteAnExistingFile() throws Exception {
        Path database = temporaryDirectory.resolve("backup-overwrite-source.sqlite");
        Path destination = temporaryDirectory.resolve("existing-backup.sqlite");
        Files.writeString(destination, "preserve-existing-file");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertThrows(StorageException.class, () -> store.backupTo(destination));
        }
        assertEquals("preserve-existing-file", Files.readString(destination));
    }

    @Test
    void registrationEnforcesUniqueIdsTagsAndMembersWithoutPartialWrites() {
        Path database = temporaryDirectory.resolve("constraints.sqlite");
        Clan original = simpleClan(10, "Alpha", "A1", memberId(10));
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(original));
            assertEquals(
                    ClanCatalog.RegistrationStatus.CLAN_ID_CONFLICT,
                    store.registerIfAvailable(simpleClan(10, "Other", "B2", memberId(11))));
            assertEquals(
                    ClanCatalog.RegistrationStatus.TAG_CONFLICT,
                    store.registerIfAvailable(simpleClan(11, "Other", "a1", memberId(12))));
            assertEquals(
                    ClanCatalog.RegistrationStatus.MEMBER_CONFLICT,
                    store.registerIfAvailable(simpleClan(12, "Other", "C3", memberId(10))));

            assertTrue(store.findById(UUID.fromString("00000000-0000-0000-0000-000000000012"))
                    .isEmpty());
            assertTrue(store.findByTag("C3").isEmpty());
            assertEquals(Optional.of(original), store.findByPlayerId(memberId(10)));
        }
    }

    @Test
    void compareAndUpdateExpandsAndRejectsStaleSnapshots() {
        Path database = temporaryDirectory.resolve("capacity.sqlite");
        Clan initial = simpleClan(20, "Capacity", "C20", memberId(20));
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            Clan expanded = initial.withExpandedCapacity(20);
            assertEquals(
                    ClanCatalog.CapacityUpdateStatus.UPDATED,
                    store.updateCapacityIfUnchanged(initial, memberId(20), expanded));
            assertEquals(Optional.of(expanded), store.findById(initial.id()));
            assertEquals(
                    ClanCatalog.CapacityUpdateStatus.STATE_CONFLICT,
                    store.updateCapacityIfUnchanged(initial, memberId(20), expanded));
            assertEquals(Optional.of(expanded), store.findById(initial.id()));
        }
    }

    @Test
    void compareAndUpdateDetectsLeaderChangeAndInvalidTransition() throws Exception {
        Path database = temporaryDirectory.resolve("leader-change.sqlite");
        Clan initial = completeClan();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            assertEquals(
                    ClanCatalog.CapacityUpdateStatus.INVALID_UPDATE,
                    store.updateCapacityIfUnchanged(
                            initial, memberId(3), new Clan(
                                    initial.id(),
                                    initial.name(),
                                    initial.tag(),
                                    initial.createdAt(),
                                    40,
                                    initial.members(),
                                    initial.totalXp(),
                                    initial.tagline())));
            changeLeader(database, memberId(3), memberId(4));
            assertEquals(
                    ClanCatalog.CapacityUpdateStatus.LEADER_CHANGED,
                    store.updateCapacityIfUnchanged(
                            initial, memberId(3), initial.withExpandedCapacity(30)));
        }
    }

    @Test
    void failedSqlUpdateRollsBackCapacityAndRevision() throws Exception {
        Path database = temporaryDirectory.resolve("rollback-update.sqlite");
        Clan initial = simpleClan(30, "Rollback", "R30", memberId(30));
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            executeSql(database, """
                    CREATE TRIGGER reject_capacity_update
                    BEFORE UPDATE OF capacity ON clans
                    BEGIN SELECT RAISE(ABORT, 'forced failure'); END
                    """);

            assertThrows(
                    StorageException.class,
                    () -> store.updateCapacityIfUnchanged(
                            initial, memberId(30), initial.withExpandedCapacity(20)));
            assertEquals(Optional.of(initial), store.findById(initial.id()));
            executeSql(database, "DROP TRIGGER reject_capacity_update");
            Clan expanded = initial.withExpandedCapacity(20);
            assertEquals(
                    ClanCatalog.CapacityUpdateStatus.UPDATED,
                    store.updateCapacityIfUnchanged(initial, memberId(30), expanded));
            assertEquals(Optional.of(expanded), store.findById(initial.id()));
        }
    }

    @Test
    void membershipUpdateRejectsPlayerAlreadyBelongingToAnotherClan() {
        Path database = temporaryDirectory.resolve("membership-member-conflict.sqlite");
        Clan first = simpleClan(27, "MemberOne", "MC27", memberId(27));
        Clan second = simpleClan(28, "MemberTwo", "MC28", memberId(28));
        Clan conflicting = withAdditionalMember(first, memberId(28));

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(first);
            store.registerIfAvailable(second);
            assertEquals(ClanCatalog.MembershipUpdateStatus.MEMBER_CONFLICT,
                    store.updateMembershipIfUnchanged(first, conflicting));
            assertEquals(Optional.of(first), store.findById(first.id()));
            assertEquals(Optional.of(second), store.findByPlayerId(memberId(28)));
            assertEquals(Optional.of(0L), store.findRevision(first.id()));
        }
    }

    @Test
    void membershipChangesPreserveCapacityPurchaseRevisionAndCommittedProof() {
        Path database = temporaryDirectory.resolve("membership-after-purchase.sqlite");
        Clan initial = simpleClan(25, "MemberAfter", "MAP25", memberId(25));
        CapacityPurchaseIntent intent = purchaseIntent(initial);
        Clan updated = withAdditionalMember(initial.withExpandedCapacity(20), memberId(26));

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            store.prepare(intent);
            assertTransition(store, intent, CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            assertTransition(store, intent, CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "provider-map25");
            assertEquals(CapacityPurchaseStore.CommitStatus.COMMITTED,
                    store.commitCapacityPurchase(intent.operationId()).status());

            Clan purchased = store.findById(initial.id()).orElseThrow();
            assertEquals(ClanCatalog.MembershipUpdateStatus.UPDATED,
                    store.updateMembershipIfUnchanged(purchased, updated));
            assertEquals(Optional.of(1L), store.findRevision(initial.id()));
        }

        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(Optional.of(updated), reopened.findById(initial.id()));
            assertEquals(Optional.of(1L), reopened.findRevision(initial.id()));
            assertEquals(CapacityPurchaseState.COMMITTED,
                    reopened.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
        }
    }

    @Test
    void concurrentUpdatesAcrossConnectionsAllowOnlyOneWinner() throws Exception {
        Path database = temporaryDirectory.resolve("concurrent.sqlite");
        Clan initial = simpleClan(40, "Concurrent", "Q40", memberId(40));
        try (SqliteClanStore first = SqliteClanStore.open(database);
             SqliteClanStore second = SqliteClanStore.open(database)) {
            first.registerIfAvailable(initial);
            Clan expanded = initial.withExpandedCapacity(20);
            CountDownLatch start = new CountDownLatch(1);
            ExecutorService executor = Executors.newFixedThreadPool(2);
            try {
                Future<ClanCatalog.CapacityUpdateStatus> firstResult = executor.submit(() -> {
                    start.await();
                    return first.updateCapacityIfUnchanged(initial, memberId(40), expanded);
                });
                Future<ClanCatalog.CapacityUpdateStatus> secondResult = executor.submit(() -> {
                    start.await();
                    return second.updateCapacityIfUnchanged(initial, memberId(40), expanded);
                });
                start.countDown();
                ClanCatalog.CapacityUpdateStatus one = firstResult.get();
                ClanCatalog.CapacityUpdateStatus two = secondResult.get();
                assertNotEquals(one, two);
                assertTrue(one == ClanCatalog.CapacityUpdateStatus.UPDATED
                        || two == ClanCatalog.CapacityUpdateStatus.UPDATED);
                assertTrue(one == ClanCatalog.CapacityUpdateStatus.STATE_CONFLICT
                        || two == ClanCatalog.CapacityUpdateStatus.STATE_CONFLICT);
                assertEquals(Optional.of(expanded), first.findById(initial.id()));
            } finally {
                executor.shutdownNow();
            }
        }
    }

    @Test
    void purchaseCommitAtomicallyUpdatesClanBusinessMarkerAndState() {
        Path database = temporaryDirectory.resolve("purchase.sqlite");
        Clan initial = simpleClan(50, "Purchase", "P50", memberId(50));
        CapacityPurchaseIntent intent = purchaseIntent(initial);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            assertEquals(
                    CapacityPurchaseJournal.PrepareStatus.CREATED,
                    store.prepare(intent).status());
            store.transition(
                    intent.operationId(),
                    CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.NONE,
                    null);
            store.transition(
                    intent.operationId(),
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                    "provider-ref");

            CapacityPurchaseStore.CommitResult committed =
                    store.commitCapacityPurchase(intent.operationId());
            assertEquals(CapacityPurchaseStore.CommitStatus.COMMITTED, committed.status());
            assertEquals(Optional.of(initial.withExpandedCapacity(20)),
                    store.findById(initial.id()));
            assertEquals(
                    Optional.of(intent.operationId()),
                    store.findAppliedOperationId(intent.businessOperationId()));
            assertEquals(
                    CapacityPurchaseState.COMMITTED,
                    store.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertEquals(
                    CapacityPurchaseStore.CommitStatus.ALREADY_COMMITTED,
                    store.commitCapacityPurchase(intent.operationId()).status());
            assertEquals(
                    java.util.List.of(
                            CapacityPurchaseState.PREPARED,
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseState.COMMITTED),
                    store.listEvents(intent.operationId()).stream()
                            .map(CapacityPurchaseEvent::toState)
                            .toList());
        }
    }

    @Test
    void purchaseCommitFailureRollsBackClanMarkerAndStatusTogether() throws Exception {
        Path database = temporaryDirectory.resolve("purchase-rollback.sqlite");
        Clan initial = simpleClan(60, "PurchaseRollback", "PR60", memberId(60));
        CapacityPurchaseIntent intent = purchaseIntent(initial);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            store.prepare(intent);
            store.transition(
                    intent.operationId(),
                    CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.NONE,
                    null);
            store.transition(
                    intent.operationId(),
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                    "external-operation");
            executeSql(database, """
                    CREATE TRIGGER reject_purchase_commit
                    BEFORE UPDATE OF state ON capacity_purchase_operations
                    WHEN NEW.state = 'COMMITTED'
                    BEGIN SELECT RAISE(ABORT, 'forced failure'); END
                    """);

            assertThrows(
                    StorageException.class,
                    () -> store.commitCapacityPurchase(intent.operationId()));
            assertEquals(Optional.of(initial), store.findById(initial.id()));
            assertTrue(store.findAppliedOperationId(intent.businessOperationId()).isEmpty());
            assertEquals(
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    store.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertEquals(
                    java.util.List.of(
                            CapacityPurchaseState.PREPARED,
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseState.DEBIT_CONFIRMED),
                    store.listEvents(intent.operationId()).stream()
                            .map(CapacityPurchaseEvent::toState)
                            .toList());
        }
    }

    @Test
    void duplicateRequestsAreIdempotentAndUnresolvedPurchasesAreQueryable() {
        Path database = temporaryDirectory.resolve("journal.sqlite");
        Clan initial = simpleClan(70, "Journal", "J70", memberId(70));
        CapacityPurchaseIntent intent = purchaseIntent(initial);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            assertEquals(
                    CapacityPurchaseJournal.PrepareStatus.CREATED,
                    store.prepare(intent).status());
            assertEquals(
                    CapacityPurchaseJournal.PrepareStatus.DUPLICATE_REQUEST,
                    store.prepare(intent).status());
            assertEquals(1, store.findUnresolved().size());

            CapacityPurchaseIntent changedPayload = new CapacityPurchaseIntent(
                    UUID.randomUUID(),
                    intent.idempotencyKey(),
                    "different-business-id",
                    initial,
                    memberId(70),
                    0,
                    20,
                    intent.amount());
            assertEquals(
                    CapacityPurchaseJournal.PrepareStatus.IDEMPOTENCY_KEY_CONFLICT,
                    store.prepare(changedPayload).status());
        }
    }

    @Test
    void idempotencyKeyRequiresEveryIntentFieldToMatch() {
            Path database = temporaryDirectory.resolve("payload-fingerprint.sqlite");
            Clan initial = completeClan();
            CapacityPurchaseIntent original = purchaseIntent(initial);

            try (SqliteClanStore store = SqliteClanStore.open(database)) {
                store.registerIfAvailable(initial);
                assertEquals(CapacityPurchaseJournal.PrepareStatus.CREATED,
                        store.prepare(original).status());
                assertEquals(CapacityPurchaseJournal.PrepareStatus.DUPLICATE_REQUEST,
                        store.prepare(original).status());

                assertIdempotencyConflict(store, withIntent(original,
                        UUID.randomUUID(), original.businessOperationId(),
                        original.expectedClan(), original.actorId(), 0,
                        original.targetCapacity(), original.amount()));
                assertIdempotencyConflict(store, withIntent(original,
                        original.operationId(), "different-business", original.expectedClan(),
                        original.actorId(), 0, original.targetCapacity(), original.amount()));
                Clan changedSnapshot = new Clan(
                        initial.id(), initial.name(), initial.tag(), initial.createdAt(),
                        initial.capacity(), initial.members(), initial.totalXp(), "Changed tagline");
                assertIdempotencyConflict(store, withIntent(original,
                        original.operationId(), original.businessOperationId(), changedSnapshot,
                        original.actorId(), 0, original.targetCapacity(), original.amount()));
                assertIdempotencyConflict(store, withIntent(original,
                        original.operationId(), original.businessOperationId(), initial,
                        original.actorId(), 1, original.targetCapacity(), original.amount()));
                Clan changedLeader = withLeader(initial, memberId(4));
                assertIdempotencyConflict(store, withIntent(original,
                        original.operationId(), original.businessOperationId(), changedLeader,
                        memberId(4), 0, original.targetCapacity(), original.amount()));
                assertIdempotencyConflict(store, withIntent(original,
                        original.operationId(), original.businessOperationId(), initial,
                        original.actorId(), 0, original.targetCapacity(), original.amount() + 1));
                assertIdempotencyConflict(store, withIntent(original,
                        original.operationId(), original.businessOperationId(), initial,
                        original.actorId(), 0, initial.capacity() + 20,
                        original.amount() + 100));
                Clan differentClan = new Clan(
                        UUID.randomUUID(), initial.name(), initial.tag(), initial.createdAt(),
                        initial.capacity(), initial.members(), initial.totalXp(), initial.tagline());
                assertIdempotencyConflict(store, withIntent(original,
                        original.operationId(), original.businessOperationId(), differentClan,
                        original.actorId(), 0, original.targetCapacity(), original.amount()));
            }
        }

    @Test
    void identicalIdempotencyPayloadIsStillDetectedAfterReopen() {
        Path database = temporaryDirectory.resolve("payload-reopen.sqlite");
        Clan clan = simpleClan(71, "PayloadReopen", "PP71", memberId(71));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            assertEquals(CapacityPurchaseJournal.PrepareStatus.CREATED,
                    store.prepare(intent).status());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseJournal.PrepareStatus.DUPLICATE_REQUEST,
                    reopened.prepare(intent).status());
        }
    }

    @Test
    void concurrentPrepareAcrossConnectionsIsIdempotentAndSurvivesReopen() throws Exception {
        Path database = temporaryDirectory.resolve("concurrent-prepare.sqlite");
        Clan clan = simpleClan(73, "Concurrent", "CP73", memberId(73));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore first = SqliteClanStore.open(database);
             SqliteClanStore second = SqliteClanStore.open(database)) {
            first.registerIfAvailable(clan);
            CountDownLatch start = new CountDownLatch(1);
            ExecutorService executor = Executors.newFixedThreadPool(2);
            try {
                Future<CapacityPurchaseJournal.PrepareStatus> firstResult = executor.submit(() -> {
                    start.await();
                    return first.prepare(intent).status();
                });
                Future<CapacityPurchaseJournal.PrepareStatus> secondResult = executor.submit(() -> {
                    start.await();
                    return second.prepare(intent).status();
                });
                start.countDown();
                java.util.List<CapacityPurchaseJournal.PrepareStatus> statuses =
                        java.util.List.of(firstResult.get(), secondResult.get());
                assertEquals(1, statuses.stream()
                        .filter(status -> status == CapacityPurchaseJournal.PrepareStatus.CREATED)
                        .count());
                assertEquals(1, statuses.stream()
                        .filter(status -> status
                                == CapacityPurchaseJournal.PrepareStatus.DUPLICATE_REQUEST)
                        .count());

                CapacityPurchaseIntent changed = withIntent(
                        intent, UUID.randomUUID(), intent.businessOperationId(),
                        clan, intent.actorId(), 0, intent.targetCapacity(), intent.amount() + 1);
                assertIdempotencyConflict(first, changed);
            } finally {
                executor.shutdownNow();
            }
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseJournal.PrepareStatus.DUPLICATE_REQUEST,
                    reopened.prepare(intent).status());
            assertEquals(1, reopened.findUnresolved().size());
        }
    }

    @Test
    void concurrentPrepareWithSameKeyAndDifferentPayloadCreatesOnlyOneOperation()
            throws Exception {
        Path database = temporaryDirectory.resolve("concurrent-prepare-conflict.sqlite");
        Clan clan = simpleClan(76, "Conflict", "CC76", memberId(76));
        CapacityPurchaseIntent firstIntent = purchaseIntent(clan);
        CapacityPurchaseIntent secondIntent = withIntent(
                firstIntent,
                UUID.randomUUID(),
                firstIntent.businessOperationId() + "-different",
                clan,
                firstIntent.actorId(),
                0,
                firstIntent.targetCapacity(),
                firstIntent.amount());
        try (SqliteClanStore first = SqliteClanStore.open(database);
             SqliteClanStore second = SqliteClanStore.open(database)) {
            first.registerIfAvailable(clan);
            CountDownLatch start = new CountDownLatch(1);
            ExecutorService executor = Executors.newFixedThreadPool(2);
            try {
                Future<CapacityPurchaseJournal.PrepareStatus> firstResult = executor.submit(() -> {
                    start.await();
                    return first.prepare(firstIntent).status();
                });
                Future<CapacityPurchaseJournal.PrepareStatus> secondResult = executor.submit(() -> {
                    start.await();
                    return second.prepare(secondIntent).status();
                });
                start.countDown();
                java.util.List<CapacityPurchaseJournal.PrepareStatus> statuses =
                        java.util.List.of(firstResult.get(), secondResult.get());
                assertEquals(1, statuses.stream()
                        .filter(status -> status == CapacityPurchaseJournal.PrepareStatus.CREATED)
                        .count());
                assertEquals(1, statuses.stream()
                        .filter(status -> status
                                == CapacityPurchaseJournal.PrepareStatus.IDEMPOTENCY_KEY_CONFLICT)
                        .count());
            } finally {
                executor.shutdownNow();
            }
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            CapacityPurchaseOperation stored =
                    reopened.findByIdempotencyKey(firstIntent.idempotencyKey()).orElseThrow();
            assertTrue(stored.operationId().equals(firstIntent.operationId())
                    || stored.operationId().equals(secondIntent.operationId()));
            assertEquals(1, reopened.findUnresolved().size());
        }
    }

    @Test
    void compensationStatesPersistAcrossReopenAndCannotBeRetriedImplicitly() {
        Path database = temporaryDirectory.resolve("compensation-recovery.sqlite");
        Clan clan = simpleClan(74, "Recovery", "CR74", memberId(74));
        CapacityPurchaseIntent intent = purchaseIntent(clan);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            assertTransition(store, intent, CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            assertTransition(store, intent, CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "debit-ref");
            assertTransition(store, intent, CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseState.COMPENSATION_PENDING,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_REQUIRED_REPORTED, "debit-ref");
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseState.COMPENSATION_PENDING,
                    reopened.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertTransition(reopened, intent, CapacityPurchaseState.COMPENSATION_PENDING,
                    CapacityPurchaseState.COMPENSATION_CALLING,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED, null);
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseState.COMPENSATION_CALLING,
                    reopened.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertTransition(reopened, intent, CapacityPurchaseState.COMPENSATION_CALLING,
                    CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    "refund-ref");
            assertEquals(CapacityPurchaseJournal.TransitionStatus.INVALID_TRANSITION,
                    reopened.transition(
                            intent.operationId(),
                            CapacityPurchaseState.COMPENSATION_UNKNOWN,
                            CapacityPurchaseState.COMPENSATION_CALLING,
                            CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED,
                            null).status());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    reopened.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertTransition(reopened, intent, CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseState.COMPENSATION_FAILED,
                    CapacityPurchaseTransitionEvidence.RECONCILED_COMPENSATION_NO_EFFECT_REPORTED,
                    "refund-ref");
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseState.COMPENSATION_FAILED,
                    reopened.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertEquals(
                    java.util.List.of(
                            CapacityPurchaseState.PREPARED,
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseState.COMPENSATION_PENDING,
                            CapacityPurchaseState.COMPENSATION_CALLING,
                            CapacityPurchaseState.COMPENSATION_UNKNOWN,
                            CapacityPurchaseState.COMPENSATION_FAILED),
                    reopened.listEvents(intent.operationId()).stream()
                            .map(CapacityPurchaseEvent::toState)
                            .toList());
        }
    }

    @Test
    void rejectsCorruptedHistoriesEvenWhenLastEventMatchesOperation() throws Exception {
        assertCorruptHistoryRejected(
                "history-prepared-compensated.sqlite",
                new CapacityPurchaseState[] {
                    CapacityPurchaseState.PREPARED, CapacityPurchaseState.COMPENSATED
                },
                new String[] {null, null},
                new String[] {"2025-01-01T00:00:00Z", "2025-01-01T00:00:01Z"},
                CapacityPurchaseState.COMPENSATED,
                null);
        assertCorruptHistoryRejected(
                "history-call-compensated.sqlite",
                new CapacityPurchaseState[] {
                    CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.COMPENSATED
                },
                new String[] {null, null, null},
                new String[] {
                    "2025-01-01T00:00:00Z",
                    "2025-01-01T00:00:01Z",
                    "2025-01-01T00:00:02Z"
                },
                CapacityPurchaseState.COMPENSATED,
                null);
        assertCorruptHistoryRejected(
                "history-skips-debit-confirmation.sqlite",
                new CapacityPurchaseState[] {
                    CapacityPurchaseState.PREPARED, CapacityPurchaseState.DEBIT_CONFIRMED
                },
                new String[] {null, "debit-ref"},
                new String[] {"2025-01-01T00:00:00Z", "2025-01-01T00:00:01Z"},
                CapacityPurchaseState.DEBIT_CONFIRMED,
                "debit-ref");
        assertCorruptHistoryRejected(
                "history-after-terminal.sqlite",
                new CapacityPurchaseState[] {
                    CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.FAILED_NO_EFFECT,
                    CapacityPurchaseState.CALLING
                },
                new String[] {null, null, null},
                new String[] {
                    "2025-01-01T00:00:00Z",
                    "2025-01-01T00:00:01Z",
                    "2025-01-01T00:00:02Z"
                },
                CapacityPurchaseState.CALLING,
                null);
        assertCorruptHistoryRejected(
                "history-out-of-order.sqlite",
                new CapacityPurchaseState[] {
                    CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.PREPARED
                },
                new String[] {null, null, null},
                new String[] {
                    "2025-01-01T00:00:00Z",
                    "2025-01-01T00:00:01Z",
                    "2025-01-01T00:00:02Z"
                },
                CapacityPurchaseState.PREPARED,
                null);
    }

    @Test
    void refusesCorruptedHistoryThroughLookupEventsAndUnresolvedPaths() throws Exception {
        Path database = temporaryDirectory.resolve("history-alternative-reads.sqlite");
        Clan clan = simpleClan(77, "ReadPaths", "RP77", memberId(77));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            replacePurchaseHistory(
                    database,
                    intent,
                    new CapacityPurchaseState[] {
                        CapacityPurchaseState.PREPARED, CapacityPurchaseState.COMPENSATED
                    },
                    new String[] {null, null},
                    new String[] {"2025-01-01T00:00:00Z", "2025-01-01T00:00:01Z"},
                    CapacityPurchaseState.COMPENSATED,
                    null);
            assertThrows(StorageException.class,
                    () -> store.findByBusinessOperationId(intent.businessOperationId()));
            assertThrows(StorageException.class, () -> store.findUnresolved());
            assertThrows(StorageException.class, () -> store.listEvents(intent.operationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void completeCompensationHistoryLoadsAfterReopen() {
        Path database = temporaryDirectory.resolve("complete-history-reopen.sqlite");
        Clan clan = simpleClan(78, "ValidHistory", "VH78", memberId(78));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            assertTransition(store, intent, CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            assertTransition(store, intent, CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "debit-ref");
            assertTransition(store, intent, CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseState.COMPENSATION_PENDING,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_REQUIRED_REPORTED, "debit-ref");
            assertTransition(store, intent, CapacityPurchaseState.COMPENSATION_PENDING,
                    CapacityPurchaseState.COMPENSATION_CALLING,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED, null);
            assertTransition(store, intent, CapacityPurchaseState.COMPENSATION_CALLING,
                    CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    "refund-ref");
            assertTransition(store, intent, CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseState.COMPENSATED,
                    CapacityPurchaseTransitionEvidence.RECONCILED_COMPENSATION_SUCCESS_REPORTED,
                    "refund-ref");
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseState.COMPENSATED,
                    reopened.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertEquals(7, reopened.listEvents(intent.operationId()).size());
        }
    }

    @Test
    void versionThreeMigrationPreservesVersionTwoPurchaseRowsAndEvents() throws Exception {
        Path database = temporaryDirectory.resolve("purchase-v3-migration.sqlite");
        assertThrows(RuntimeException.class, () -> SqliteClanStore.open(
                database,
                SqliteTransactionControl.JDBC,
                version -> {
                    if (version == 3) {
                        throw new IllegalStateException("leave database at version two");
                    }
                }));
        assertEquals(2, pragmaInt(database, "PRAGMA user_version"));

        UUID clanId = UUID.fromString("00000000-0000-0000-0000-000000000102");
        UUID actorId = UUID.fromString("00000000-0000-0000-0000-000000000103");
        executeSql(database, """
                INSERT INTO clans (
                    id, name, tag, tag_key, created_at, capacity, total_xp, tagline, revision
                ) VALUES (
                    '%s', 'Migrated Clan', 'MC3', 'mc3',
                    '2025-01-01T00:00:00Z', 20, 0, NULL, 1
                )
                """.formatted(clanId));
        executeSql(database, """
                INSERT INTO clan_members (
                    clan_id, player_id, role, membership_started_at, appointed_by_deputy_id
                ) VALUES (
                    '%s', '%s', 'LEADER', '2025-01-01T00:00:00Z', NULL
                )
                """.formatted(clanId, actorId));

        UUID callingId = UUID.fromString("00000000-0000-0000-0000-000000000101");
        UUID unknownId = UUID.fromString("00000000-0000-0000-0000-000000000104");
        UUID committedId = UUID.fromString("00000000-0000-0000-0000-000000000107");
        seedLegacyPurchase(database, callingId, "legacy-calling", "legacy-business-calling",
                clanId, actorId, CapacityPurchaseState.CALLING, null);
        seedLegacyPurchase(database, unknownId, "legacy-unknown", "legacy-business-unknown",
                clanId, actorId, CapacityPurchaseState.UNKNOWN, "provider-unknown");
        seedLegacyPurchase(database, committedId, "legacy-committed", "legacy-business-committed",
                clanId, actorId, CapacityPurchaseState.COMMITTED, "provider-committed");
        seedLegacyPurchaseEvent(database, callingId, CapacityPurchaseState.PREPARED, null);
        seedLegacyPurchaseEvent(database, callingId, CapacityPurchaseState.CALLING, null);
        seedLegacyPurchaseEvent(database, unknownId, CapacityPurchaseState.PREPARED, null);
        seedLegacyPurchaseEvent(database, unknownId, CapacityPurchaseState.CALLING, null);
        seedLegacyPurchaseEvent(
                database, unknownId, CapacityPurchaseState.UNKNOWN, "provider-unknown");
        seedLegacyPurchaseEvent(database, committedId, CapacityPurchaseState.PREPARED, null);
        seedLegacyPurchaseEvent(database, committedId, CapacityPurchaseState.CALLING, null);
        seedLegacyPurchaseEvent(
                database, committedId, CapacityPurchaseState.DEBIT_CONFIRMED, "provider-committed");
        seedLegacyPurchaseEvent(
                database, committedId, CapacityPurchaseState.COMMITTED, "provider-committed");
        executeSql(database, """
                INSERT INTO applied_business_operations (
                    business_operation_id, operation_id, clan_id,
                    from_capacity, to_capacity, committed_at
                ) VALUES (
                    'legacy-business-committed', '%s', '%s', 10, 20, '2025-01-01T00:00:04Z'
                )
                """.formatted(committedId, clanId));

        try (SqliteClanStore migrated = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertEquals(
                    CapacityPurchaseState.CALLING,
                    migrated.findByIdempotencyKey("legacy-calling").orElseThrow().state());
            assertEquals(
                    CapacityPurchaseState.UNKNOWN,
                    migrated.findByIdempotencyKey("legacy-unknown").orElseThrow().state());
            assertEquals(
                    CapacityPurchaseState.COMMITTED,
                    migrated.findByIdempotencyKey("legacy-committed").orElseThrow().state());
            assertEquals(2, migrated.listEvents(callingId).size());
            assertEquals(3, migrated.listEvents(unknownId).size());
            assertEquals(4, migrated.listEvents(committedId).size());
            assertEquals(
                    1,
                    scalarInt(database, """
                            SELECT COUNT(*) FROM applied_business_operations
                            WHERE operation_id = '%s'
                            """.formatted(committedId)));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(CapacityPurchaseState.COMMITTED,
                    reopened.findByIdempotencyKey("legacy-committed").orElseThrow().state());
            assertEquals(2, reopened.findUnresolved().size());
            assertEquals(
                    CapacityPurchaseState.UNKNOWN,
                    reopened.findByIdempotencyKey("legacy-unknown").orElseThrow().state());
        }
    }

    @Test
    void journalEnforcesEvidenceAndReservesCommittedForAtomicStoreCommit() {
        Path database = temporaryDirectory.resolve("transition-policy.sqlite");
        Clan clan = simpleClan(72, "TransitionPolicy", "TP72", memberId(72));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            assertEquals(CapacityPurchaseJournal.TransitionStatus.UPDATED,
                    store.transition(
                            intent.operationId(),
                            CapacityPurchaseState.PREPARED,
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseTransitionEvidence.NONE,
                            null).status());
            assertEquals(CapacityPurchaseJournal.TransitionStatus.UNEXPECTED_EVIDENCE,
                    store.transition(
                            intent.operationId(),
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED,
                            "wrong-reference").status());
            assertEquals(CapacityPurchaseJournal.TransitionStatus.EVIDENCE_REQUIRED,
                    store.transition(
                            intent.operationId(),
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseTransitionEvidence.NONE,
                            null).status());
            assertEquals(CapacityPurchaseJournal.TransitionStatus.UPDATED,
                    store.transition(
                            intent.operationId(),
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                            "confirmed-reference").status());
            assertEquals(CapacityPurchaseJournal.TransitionStatus.INVALID_TRANSITION,
                    store.transition(
                            intent.operationId(),
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseState.COMMITTED,
                            CapacityPurchaseTransitionEvidence.ATOMIC_CAPACITY_COMMIT,
                            "confirmed-reference").status());
            assertEquals(CapacityPurchaseState.DEBIT_CONFIRMED,
                    store.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
        }
    }

    @Test
    void persistsPurchaseJournalAfterCloseAndReopen() {
        Path database = temporaryDirectory.resolve("journal-reopen.sqlite");
        Clan initial = simpleClan(80, "JournalReopen", "JR80", memberId(80));
        CapacityPurchaseIntent intent = purchaseIntent(initial);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            store.prepare(intent);
            store.transition(
                    intent.operationId(),
                    CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.NONE,
                    null);
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(
                    CapacityPurchaseState.CALLING,
                    reopened.findByBusinessOperationId(intent.businessOperationId())
                            .orElseThrow().state());
            assertEquals(1, reopened.findUnresolved().size());
        }
    }

    @Test
    void refusesCorruptedEmptyAndUnsupportedDatabases() throws Exception {
        Path corrupted = temporaryDirectory.resolve("corrupted.sqlite");
        Files.writeString(corrupted, "not a sqlite database");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(corrupted));

        Path emptyExisting = temporaryDirectory.resolve("empty.sqlite");
        Files.createFile(emptyExisting);
        assertThrows(StorageException.class, () -> SqliteClanStore.open(emptyExisting));

        Path unsupported = temporaryDirectory.resolve("unsupported.sqlite");
        try (SqliteClanStore ignored = SqliteClanStore.open(unsupported)) {
            // Create a valid database before marking it with a future schema version.
        }
        executeSql(unsupported, "PRAGMA user_version = 999");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(unsupported));
    }

    @Test
    void rejectsSupportedVersionWithMissingTablesColumnsOrMigrationHistory() throws Exception {
        Path missingTable = createDatabase("missing-table.sqlite");
        executeSql(missingTable, "PRAGMA user_version = 1");
        executeSql(missingTable, "DELETE FROM schema_migrations WHERE version = 2");
        executeSql(missingTable, "DROP TABLE capacity_purchase_events");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(missingTable));

        Path missingColumn = createDatabase("missing-column.sqlite");
        executeSql(missingColumn,
                "ALTER TABLE capacity_purchase_operations DROP COLUMN payload_fingerprint");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(missingColumn));

        Path missingHistory = createDatabase("missing-history.sqlite");
        executeSql(missingHistory, "DELETE FROM schema_migrations WHERE version = 2");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(missingHistory));

        Path mismatchedHistory = createDatabase("mismatched-history.sqlite");
        executeSql(mismatchedHistory, "UPDATE schema_migrations SET version = 99 WHERE version = 2");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(mismatchedHistory));

        Path missingIndex = createDatabase("missing-index.sqlite");
        executeSql(missingIndex, "DROP INDEX capacity_purchase_state_idx");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(missingIndex));

        Path missingTrigger = createDatabase("missing-trigger.sqlite");
        executeSql(missingTrigger, "DROP TRIGGER capacity_purchase_events_no_update");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(missingTrigger));
    }

    @Test
    void rejectsModifiedAppendOnlyTriggersEvenWhenTheyContainExpectedFragments() throws Exception {
        Path falseUpdateTrigger = createDatabase("false-update-trigger.sqlite");
        executeSql(falseUpdateTrigger, "DROP TRIGGER capacity_purchase_events_no_update");
        executeSql(falseUpdateTrigger, """
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                WHEN 0
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                """);
        assertThrows(StorageException.class, () -> SqliteClanStore.open(falseUpdateTrigger));

        Path falseDeleteTrigger = createDatabase("false-delete-trigger.sqlite");
        executeSql(falseDeleteTrigger, "DROP TRIGGER capacity_purchase_events_no_delete");
        executeSql(falseDeleteTrigger, """
                CREATE TRIGGER capacity_purchase_events_no_delete
                BEFORE DELETE ON capacity_purchase_events
                WHEN 0
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                """);
        assertThrows(StorageException.class, () -> SqliteClanStore.open(falseDeleteTrigger));
    }

    @Test
    void triggerDdlNormalizationOnlyAllowsWhitespaceOutsideQuotedTokens() throws Exception {
        Path formatted = createDatabase("formatted-trigger.sqlite");
        executeSql(formatted, "DROP TRIGGER capacity_purchase_events_no_update");
        executeSql(formatted, """
                CREATE TRIGGER capacity_purchase_events_no_update
                  BEFORE UPDATE
                  ON capacity_purchase_events
                  BEGIN
                    SELECT RAISE(ABORT, 'purchase events are append-only');
                  END
                """);
        try (SqliteClanStore ignored = SqliteClanStore.open(formatted)) {
            // Opening the database confirms whitespace-only formatting is accepted.
        }

        assertModifiedUpdateTriggerRejected("changed-literal-whitespace.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'purchase  events are append-only'); END
                """);
        assertModifiedUpdateTriggerRejected("changed-message.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'purchase events are immutable'); END
                """);
        assertModifiedUpdateTriggerRejected("changed-literal-case.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'Purchase events are append-only'); END
                """);
        assertModifiedUpdateTriggerRejected("changed-keyword-case.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                before update on capacity_purchase_events
                begin select raise(abort, 'purchase events are append-only'); end
                """);
        assertModifiedUpdateTriggerRejected("escaped-literal.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only''!'); END
                """);
        assertModifiedUpdateTriggerRejected("commented-trigger.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                /* comment */
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                """);
        assertModifiedUpdateTriggerRejected("line-commented-trigger.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                -- comment
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                """);
        assertModifiedUpdateTriggerRejected("modified-body.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(FAIL, 'purchase events are append-only'); END
                """);
        assertModifiedUpdateTriggerRejected("when-false-trigger.sqlite", """
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                WHEN 0
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                """);
    }

    @Test
    void migrationFailureRollsBackCurrentStepAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-rollback.sqlite");
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database,
                SqliteTransactionControl.JDBC,
                version -> {
                    if (version == 2) {
                        throw new IllegalStateException("injected migration failure");
                    }
                }));

        assertEquals(1, pragmaInt(database, "PRAGMA user_version"));
        assertFalseColumnExists(database, "capacity_purchase_operations", "payload_fingerprint");
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertTrueColumnExists(database, "capacity_purchase_operations", "payload_fingerprint");
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
        }
    }

    private void downgradeCurrentSchemaToVersionEight(Path database) throws Exception {
        // Keep exactly the v8 object set, then drop every table introduced by later migrations.
        java.util.Set<String> v8Tables = java.util.Set.of(
                "schema_migrations", "clans", "clan_members",
                "capacity_purchase_operations", "capacity_purchase_events",
                "applied_business_operations", "clan_settings", "clan_requests",
                "clan_request_events", "clan_xp_events", "clan_elections",
                "clan_election_candidates", "clan_election_votes",
                "clan_election_events", "clan_player_activity");
        java.util.List<String> toDrop = new java.util.ArrayList<>();
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery(
                     "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'")) {
            while (rows.next()) {
                String table = rows.getString(1);
                if (!v8Tables.contains(table)) toDrop.add(table);
            }
        }
        for (String table : toDrop) {
            executeSql(database, "DROP TABLE \"" + table + "\"");
        }
        // v9 reintroduces these guards; a genuine v8 snapshot does not contain them yet.
        for (String trigger : java.util.List.of(
                "clan_election_candidates_insert_guard",
                "clan_election_candidates_no_update",
                "clan_election_candidates_no_delete",
                "clan_election_votes_insert_guard",
                "clan_election_votes_no_update",
                "clan_election_votes_no_delete")) {
            executeSql(database, "DROP TRIGGER IF EXISTS \"" + trigger + "\"");
        }
        executeSql(database, "DELETE FROM schema_migrations WHERE version > 8");
        executeSql(database, "PRAGMA user_version = 8");
    }

    @Test
    void migrationToVersionFiveRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v5-rollback.sqlite");
        try (SqliteClanStore ignored = SqliteClanStore.open(database)) {
            // Create a valid current database, then return its schema to a valid v4 snapshot.
        }
        downgradeCurrentSchemaToVersionEight(database);
        executeSql(database, "DROP TABLE clan_player_activity");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 8");
        executeSql(database, "PRAGMA user_version = 7");
        executeSql(database, "DROP TRIGGER clan_election_events_no_update");
        executeSql(database, "DROP TRIGGER clan_election_events_no_delete");
        executeSql(database, "DROP TABLE clan_election_events");
        executeSql(database, "DROP TABLE clan_election_votes");
        executeSql(database, "DROP TABLE clan_election_candidates");
        executeSql(database, "DROP TABLE clan_elections");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 7");
        executeSql(database, "PRAGMA user_version = 6");
        executeSql(database, "DROP TRIGGER clan_xp_events_no_update");
        executeSql(database, "DROP TRIGGER clan_xp_events_no_delete");
        executeSql(database, "DROP TABLE clan_xp_events");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 6");
        executeSql(database, "DROP TRIGGER clan_request_events_no_update");
        executeSql(database, "DROP TRIGGER clan_request_events_no_delete");
        executeSql(database, "DROP TABLE clan_request_events");
        executeSql(database, "DROP TABLE clan_requests");
        executeSql(database, "DROP TABLE clan_settings");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 5");
        executeSql(database, "PRAGMA user_version = 4");

        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 5) throw new IllegalStateException("injected v5 failure");
                }));
        assertEquals(4, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_requests"));
        assertFalse(tableExists(database, "clan_settings"));

        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertTrue(tableExists(database, "clan_requests"));
            assertTrue(tableExists(database, "clan_request_events"));
            assertTrue(tableExists(database, "clan_settings"));
            assertTrue(tableExists(database, "clan_xp_events"));
        }
    }

    @Test
    void migrationToVersionSixRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v6-rollback.sqlite");
        try (SqliteClanStore ignored = SqliteClanStore.open(database)) { }
        downgradeCurrentSchemaToVersionEight(database);
        executeSql(database, "DROP TABLE clan_player_activity");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 8");
        executeSql(database, "PRAGMA user_version = 7");
        executeSql(database, "DROP TRIGGER clan_election_events_no_update");
        executeSql(database, "DROP TRIGGER clan_election_events_no_delete");
        executeSql(database, "DROP TABLE clan_election_events");
        executeSql(database, "DROP TABLE clan_election_votes");
        executeSql(database, "DROP TABLE clan_election_candidates");
        executeSql(database, "DROP TABLE clan_elections");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 7");
        executeSql(database, "PRAGMA user_version = 6");
        executeSql(database, "DROP TRIGGER clan_xp_events_no_update");
        executeSql(database, "DROP TRIGGER clan_xp_events_no_delete");
        executeSql(database, "DROP TABLE clan_xp_events");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 6");
        executeSql(database, "PRAGMA user_version = 5");

        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 6) throw new IllegalStateException("injected v6 failure");
                }));
        assertEquals(5, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_xp_events"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertTrue(tableExists(database, "clan_xp_events"));
        }
    }

    @Test
    void migrationToVersionSevenRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v7-rollback.sqlite");
        try (SqliteClanStore ignored = SqliteClanStore.open(database)) { }
        downgradeCurrentSchemaToVersionEight(database);
        executeSql(database, "DROP TABLE clan_player_activity");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 8");
        executeSql(database, "PRAGMA user_version = 7");
        executeSql(database, "DROP TRIGGER clan_election_events_no_update");
        executeSql(database, "DROP TRIGGER clan_election_events_no_delete");
        executeSql(database, "DROP TABLE clan_election_events");
        executeSql(database, "DROP TABLE clan_election_votes");
        executeSql(database, "DROP TABLE clan_election_candidates");
        executeSql(database, "DROP TABLE clan_elections");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 7");
        executeSql(database, "PRAGMA user_version = 6");
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 7) throw new IllegalStateException("injected v7 failure");
                }));
        assertEquals(6, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_elections"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertTrue(tableExists(database, "clan_elections"));
            assertTrue(tableExists(database, "clan_election_candidates"));
            assertTrue(tableExists(database, "clan_election_votes"));
            assertTrue(tableExists(database, "clan_election_events"));
        }
    }

    @Test
    void migrationToVersionEightRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v8-rollback.sqlite");
        try (SqliteClanStore ignored = SqliteClanStore.open(database)) { }
        downgradeCurrentSchemaToVersionEight(database);
        executeSql(database, "DROP TABLE clan_player_activity");
        executeSql(database, "DELETE FROM schema_migrations WHERE version = 8");
        executeSql(database, "PRAGMA user_version = 7");
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 8) throw new IllegalStateException("injected v8 failure");
                }));
        assertEquals(7, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_player_activity"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertTrue(tableExists(database, "clan_player_activity"));
        }
    }

    @Test
    void migrationToVersionNineRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v9-rollback.sqlite");
        try (SqliteClanStore ignored = SqliteClanStore.open(database)) { }
        downgradeCurrentSchemaToVersionEight(database);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 9) throw new IllegalStateException("injected v9 failure");
                }));
        assertEquals(8, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_election_owner_blocks"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertTrue(tableExists(database, "clan_election_owner_blocks"));
        }
    }

    @Test
    void clanCreationPaymentJournalCommitsDebitAndClanAtomicallyAndSurvivesReopen() {
        Path database = temporaryDirectory.resolve("paid-clan-creation.sqlite");
        UUID creator = memberId(880);
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new com.skyworldclans.clan.ClanFactory().create(
                UUID.randomUUID(), "Paid Clan", "PC88", creator, now, now, "A slogan");
        ClanCreationPaymentOperation operation = new ClanCreationPaymentOperation(
                UUID.randomUUID(), "creation-880", creator, clan.id(), clan.name(), clan.tag(),
                clan.tagline(), clan.createdAt(), ClanCreationPaymentOperation.CREATION_PRICE_UNITS,
                ClanCreationPaymentState.PREPARED, null, now, now);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal.CreationPrepareStatus.CREATED,
                    store.prepare(operation).status());
            assertEquals(com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED,
                    store.transition(operation.operationId(), ClanCreationPaymentState.PREPARED,
                            ClanCreationPaymentState.CALLING, null, now.plusSeconds(1)).status());
            assertEquals(com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED,
                    store.transition(operation.operationId(), ClanCreationPaymentState.CALLING,
                            ClanCreationPaymentState.DEBIT_CONFIRMED, null, now.plusSeconds(2)).status());
            assertEquals(com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal.CreationCommitStatus.COMMITTED,
                    store.commitPaidClan(operation.operationId(), clan, now.plusSeconds(3)).status());
            assertEquals(Optional.of(clan), store.findById(clan.id()));
            assertEquals(ClanCreationPaymentState.COMMITTED,
                    store.findCreationById(operation.operationId()).orElseThrow().state());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(Optional.of(clan), reopened.findById(clan.id()));
            assertEquals(ClanCreationPaymentState.COMMITTED,
                    reopened.findCreationById(operation.operationId()).orElseThrow().state());
        }
    }

    @Test
    void unresolvedClanCreationPaymentBlocksSecondChargeForSamePlayer() {
        Path database = temporaryDirectory.resolve("unresolved-clan-creation.sqlite");
        UUID creator = memberId(881);
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan firstClan = new com.skyworldclans.clan.ClanFactory().create(
                UUID.randomUUID(), "First Clan", "FC88", creator, now, now);
        Clan secondClan = new com.skyworldclans.clan.ClanFactory().create(
                UUID.randomUUID(), "Second Clan", "SC88", creator, now.plusSeconds(1), now.plusSeconds(1));
        ClanCreationPaymentOperation first = new ClanCreationPaymentOperation(
                UUID.randomUUID(), "creation-first", creator, firstClan.id(), firstClan.name(), firstClan.tag(),
                null, firstClan.createdAt(), ClanCreationPaymentOperation.CREATION_PRICE_UNITS,
                ClanCreationPaymentState.PREPARED, null, now, now);
        ClanCreationPaymentOperation second = new ClanCreationPaymentOperation(
                UUID.randomUUID(), "creation-second", creator, secondClan.id(), secondClan.name(), secondClan.tag(),
                null, secondClan.createdAt(), ClanCreationPaymentOperation.CREATION_PRICE_UNITS,
                ClanCreationPaymentState.PREPARED, null, now.plusSeconds(1), now.plusSeconds(1));
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal.CreationPrepareStatus.CREATED,
                    store.prepare(first).status());
            store.transition(first.operationId(), ClanCreationPaymentState.PREPARED,
                    ClanCreationPaymentState.CALLING, null, now.plusSeconds(2));
            store.transition(first.operationId(), ClanCreationPaymentState.CALLING,
                    ClanCreationPaymentState.UNKNOWN, "provider result lost", now.plusSeconds(3));
            assertEquals(com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal.CreationPrepareStatus.PLAYER_HAS_UNRESOLVED_CREATION,
                    store.prepare(second).status());
            Clan otherPlayerSameTag = new com.skyworldclans.clan.ClanFactory().create(
                    UUID.randomUUID(), "Another Clan", "FC88", memberId(882), now, now);
            assertEquals(ClanCatalog.RegistrationStatus.TAG_CONFLICT,
                    store.registerIfAvailable(otherPlayerSameTag));
            ClanCreationPaymentOperation third = new ClanCreationPaymentOperation(
                    UUID.randomUUID(), "creation-third", memberId(883), UUID.randomUUID(),
                    "Third Clan", "fc88", null, now, ClanCreationPaymentOperation.CREATION_PRICE_UNITS,
                    ClanCreationPaymentState.PREPARED, null, now, now);
            assertEquals(com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal.CreationPrepareStatus.TAG_TAKEN,
                    store.prepare(third).status());
            assertTrue(store.findById(firstClan.id()).isEmpty());
        }
    }

    @Test
    void migrationToVersionTenRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v10-rollback.sqlite");
        try (SqliteClanStore ignored = SqliteClanStore.open(database)) { }
        downgradeCurrentSchemaToVersionEight(database);
        assertThrows(IllegalStateException.class, () -> SqliteClanStore.open(
                database, SqliteTransactionControl.JDBC, version -> {
                    if (version == 10) throw new IllegalStateException("injected v10 failure");
                }));
        assertEquals(9, pragmaInt(database, "PRAGMA user_version"));
        assertFalse(tableExists(database, "clan_creation_payment_operations"));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            assertTrue(tableExists(database, "clan_creation_payment_operations"));
        }
    }

    @Test
    void reachingLevelTenAutomaticallyAwardsTheLevelTenAchievementOnce() {
        Path database = temporaryDirectory.resolve("level-ten-achievement.sqlite");
        UUID leader = memberId(565);
        Clan clan = simpleClan(565, "LevelTenClan", "LT565", leader).withTotalXp(274_500L);
        Instant now = Instant.parse("2026-02-02T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanXpAwardResult.Status.AWARDED, store.awardClanXp(
                    clan.id(), ClanXpEventType.WAR_WIN, leader, "level-ten-trigger", now).status());
            assertEquals(285_500L, store.findById(clan.id()).orElseThrow().totalXp());
            assertEquals(10, store.findById(clan.id()).orElseThrow().level());
            assertEquals(ClanXpAwardResult.Status.DUPLICATE, store.awardClanXp(
                    clan.id(), ClanXpEventType.WAR_WIN, leader, "level-ten-trigger", now).status());
            assertEquals(285_500L, store.findById(clan.id()).orElseThrow().totalXp());
        }
    }

    @Test
    void recruitmentAndMemberPeakXpAreAwardedAtomicallyAndIdempotently() {
        Path database = temporaryDirectory.resolve("membership-achievements.sqlite");
        UUID leader = memberId(570);
        UUID memberA = memberId(571), memberB = memberId(572), memberC = memberId(573);
        UUID recruit = memberId(574);
        Clan clan = withAdditionalMember(withAdditionalMember(withAdditionalMember(
                simpleClan(570, "AchievementClan", "AC570", leader), memberA), memberB), memberC);
        Instant now = Instant.parse("2026-02-03T00:00:00Z");
        UUID requestId = UUID.randomUUID();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(new ClanRequest(
                    requestId, ClanRequest.Type.INVITATION, clan.id(), recruit, leader, now,
                    now.plus(java.time.Duration.ofMinutes(2)), ClanRequest.Status.PENDING)));
            assertEquals(ClanRequestStore.ResolveStatus.ACCEPTED,
                    store.resolveRequest(requestId, recruit, true, now.plusSeconds(1)));
            assertEquals(1_170L, store.findById(clan.id()).orElseThrow().totalXp());
            store.reconcileMembershipAchievements(clan.id(), now.plusSeconds(2));
            store.reconcileMembershipAchievements(clan.id(), now.plusSeconds(3));
            assertEquals(1_170L, store.findById(clan.id()).orElseThrow().totalXp());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(1_170L, reopened.findById(clan.id()).orElseThrow().totalXp());
        }
    }

    @Test
    void expiredRequestIsReplacedCorrectlyAcrossFractionalSecondBoundary() {
        UUID leader = memberId(577);
        UUID target = memberId(576);
        Clan clan = simpleClan(577, "ExpiryClan", "EX577", leader);
        Instant firstCreated = Instant.parse("2026-02-03T00:00:00Z");
        Instant firstExpiry = firstCreated.plusSeconds(1);
        Instant secondCreated = Instant.parse("2026-02-03T00:00:01.100Z");
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("fractional-request-time.sqlite"))) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(new ClanRequest(
                    UUID.randomUUID(), ClanRequest.Type.INVITATION, clan.id(), target, leader,
                    firstCreated, firstExpiry, ClanRequest.Status.PENDING)));
            UUID secondRequest = UUID.randomUUID();
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(new ClanRequest(
                    secondRequest, ClanRequest.Type.INVITATION, clan.id(), target, leader,
                    secondCreated, secondCreated.plusSeconds(120), ClanRequest.Status.PENDING)));
            assertEquals(List.of(secondRequest), store.listPendingRequestsForPlayer(target, ClanRequest.Type.INVITATION, secondCreated)
                    .stream().map(ClanRequest::id).toList());
        }
    }

    @Test
    void dueElectionOrderingHandlesFractionalInstantTimestamps() {
        UUID leader = memberId(579);
        UUID candidate = memberId(578);
        Clan clan = withAdditionalMember(simpleClan(579, "FractionClan", "FC579", leader), candidate);
        Instant started = Instant.parse("2026-02-03T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("fractional-election-time.sqlite"))) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(SqliteClanStore.ElectionCreateStatus.CREATED, store.createElection(
                    UUID.randomUUID(), clan.id(), "DEPARTURE", leader, started,
                    started.plusSeconds(1), List.of(candidate)));
            assertEquals(List.of(clan.id()), store.dueElectionClanIds(
                    Instant.parse("2026-02-03T00:00:01.100Z")));
        }
    }

    @Test
    void systemStatusCountsReflectClanMembersAndActiveElections() {
        Path database = temporaryDirectory.resolve("system-status-counts.sqlite");
        UUID leader = memberId(580);
        UUID candidate = memberId(581);
        Clan clan = withAdditionalMember(simpleClan(580, "StatusClan", "ST580", leader), candidate);
        Instant started = Instant.parse("2026-02-04T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(1, store.countClans());
            assertEquals(2, store.countMembers());
            assertEquals(0, store.countActiveElections());
            UUID election = UUID.randomUUID();
            assertEquals(SqliteClanStore.ElectionCreateStatus.CREATED, store.createElection(
                    election, clan.id(), "DEPARTURE", leader, started,
                    started.plus(java.time.Duration.ofHours(24)), List.of(candidate)));
            assertEquals(1, store.countActiveElections());
            assertEquals(SqliteClanStore.ElectionTransitionStatus.UPDATED,
                    store.completeElectionWithOutcome(election, candidate,
                            started.plus(java.time.Duration.ofHours(24))));
            assertEquals(0, store.countActiveElections());
            assertEquals(1, store.countClans());
            assertEquals(1, store.countMembers());
        }
    }

    @Test
    void onlineActivityBatchOnlyRecordsCurrentClanMembers() {
        UUID leader = memberId(575);
        UUID nonMember = memberId(574);
        Clan clan = simpleClan(575, "ActivityBatch", "AB575", leader);
        Instant seenAt = Instant.parse("2026-02-03T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("activity-batch.sqlite"))) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            store.recordOnlineMemberActivity(List.of(leader, nonMember), seenAt);
            assertEquals(seenAt, store.lastPlayerActivity(leader).orElseThrow());
            assertTrue(store.lastPlayerActivity(nonMember).isEmpty());
        }
    }

    @Test
    void playerActivityPersistsAndCannotMoveBackwards() {
        Path database = temporaryDirectory.resolve("player-activity.sqlite");
        UUID playerId = memberId(590);
        Instant later = Instant.parse("2026-02-03T12:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.recordPlayerActivity(playerId, later);
            store.recordPlayerActivity(playerId, later.minusSeconds(3600));
            assertEquals(java.util.Optional.of(later), store.lastPlayerActivity(playerId));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(java.util.Optional.of(later), reopened.lastPlayerActivity(playerId));
        }
    }

    @Test
    void departureElectionPersistsVotesAndAppliesLeadershipAtomically() {
        Path database = temporaryDirectory.resolve("clan-election-lifecycle.sqlite");
        UUID leaderId = memberId(601);
        UUID voterId = memberId(602);
        UUID winnerId = memberId(603);
        Clan clan = withAdditionalMember(withAdditionalMember(
                simpleClan(601, "ElectionClan", "EL601", leaderId), voterId), winnerId);
        UUID electionId = UUID.randomUUID();
        Instant started = Instant.parse("2026-02-01T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(SqliteClanStore.ElectionCreateStatus.CREATED, store.createElection(
                    electionId, clan.id(), "DEPARTURE", leaderId, started,
                    started.plus(java.time.Duration.ofHours(24)), List.of(winnerId, voterId)));
            assertEquals(SqliteClanStore.ElectionCreateStatus.ACTIVE_ELECTION_EXISTS, store.createElection(
                    UUID.randomUUID(), clan.id(), "DEPARTURE", leaderId, started,
                    started.plus(java.time.Duration.ofHours(24)), List.of(winnerId, voterId)));
            assertEquals(SqliteClanStore.ElectionVoteStatus.VOTED, store.castElectionVote(
                    electionId, "LOCAL", voterId, winnerId, started.plusSeconds(1)));
            assertEquals(SqliteClanStore.ElectionVoteStatus.ALREADY_VOTED, store.castElectionVote(
                    electionId, "LOCAL", voterId, voterId, started.plusSeconds(2)));
            assertEquals(Map.of(winnerId, 1), store.electionTally(electionId, "LOCAL"));
            assertEquals(SqliteClanStore.ElectionTransitionStatus.UPDATED,
                    store.completeElectionWithOutcome(electionId, winnerId, started.plus(java.time.Duration.ofHours(24))));
            Clan updated = store.findById(clan.id()).orElseThrow();
            assertTrue(updated.member(leaderId).isEmpty());
            assertEquals(ClanRole.LEADER, updated.member(winnerId).orElseThrow().role());
            assertTrue(store.findActiveElection(clan.id()).isEmpty());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            Clan updated = reopened.findById(clan.id()).orElseThrow();
            assertTrue(updated.member(leaderId).isEmpty());
            assertEquals(ClanRole.LEADER, updated.member(winnerId).orElseThrow().role());
        }
        assertThrows(java.sql.SQLException.class, () -> executeSql(database,
                "UPDATE clan_election_votes SET candidate_id = 'tampered' WHERE election_id = '" + electionId + "'"));
        assertThrows(java.sql.SQLException.class, () -> executeSql(database,
                "DELETE FROM clan_election_votes WHERE election_id = '" + electionId + "'"));
        assertThrows(java.sql.SQLException.class, () -> executeSql(database,
                "UPDATE clan_election_candidates SET candidate_id = 'tampered' WHERE election_id = '" + electionId + "'"));
        assertThrows(java.sql.SQLException.class, () -> executeSql(database,
                "DELETE FROM clan_election_candidates WHERE election_id = '" + electionId + "'"));
        assertThrows(java.sql.SQLException.class, () -> executeSql(database,
                "INSERT INTO clan_election_candidates(election_id, phase, candidate_id) VALUES ('" + electionId + "', 'LOCAL', 'late')"));
        assertThrows(java.sql.SQLException.class, () -> executeSql(database,
                "INSERT INTO clan_election_votes(election_id, phase, voter_id, candidate_id, voted_at) VALUES ('" + electionId + "', 'LOCAL', 'late-voter', '" + winnerId + "', '2026-02-03T00:00:00Z')"));
    }

    @Test
    void tiedLocalElectionTransitionsToGlobalVoteAndCompletesWithOnlyTiedCandidates() {
        Path database = temporaryDirectory.resolve("clan-election-global-tie.sqlite");
        UUID leaderId = memberId(621);
        UUID candidateA = memberId(622);
        UUID candidateB = memberId(623);
        UUID globalVoter = memberId(624);
        Clan clan = withAdditionalMember(withAdditionalMember(
                simpleClan(621, "TieClan", "TC621", leaderId), candidateA), candidateB);
        UUID electionId = UUID.randomUUID();
        Instant started = Instant.parse("2026-02-05T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(SqliteClanStore.ElectionCreateStatus.CREATED, store.createElection(
                    electionId, clan.id(), "DEPARTURE", leaderId, started,
                    started.plus(java.time.Duration.ofHours(24)), List.of(candidateA, candidateB)));
            assertEquals(SqliteClanStore.ElectionVoteStatus.VOTED, store.castElectionVote(
                    electionId, "LOCAL", candidateA, candidateA, started.plusSeconds(1)));
            assertEquals(SqliteClanStore.ElectionVoteStatus.VOTED, store.castElectionVote(
                    electionId, "LOCAL", candidateB, candidateB, started.plusSeconds(2)));
            assertEquals(Map.of(candidateA, 1, candidateB, 1), store.electionTally(electionId, "LOCAL"));
            Instant globalStart = started.plus(java.time.Duration.ofHours(24));
            assertEquals(SqliteClanStore.ElectionTransitionStatus.UPDATED,
                    store.advanceElectionToTieBreak(electionId, List.of(candidateA, candidateB),
                            globalStart, globalStart.plus(java.time.Duration.ofHours(6))));
            assertEquals(SqliteClanStore.ElectionVoteStatus.VOTED, store.castElectionVote(
                    electionId, "GLOBAL_TIE_BREAK", globalVoter, candidateA, globalStart.plusSeconds(1)));
            assertEquals(SqliteClanStore.ElectionVoteStatus.ALREADY_VOTED, store.castElectionVote(
                    electionId, "GLOBAL_TIE_BREAK", globalVoter, candidateB, globalStart.plusSeconds(2)));
            assertEquals(SqliteClanStore.ElectionTransitionStatus.UPDATED,
                    store.completeElectionWithOutcome(electionId, candidateA,
                            globalStart.plus(java.time.Duration.ofHours(6))));
            Clan updated = store.findById(clan.id()).orElseThrow();
            assertTrue(updated.member(leaderId).isEmpty());
            assertEquals(ClanRole.LEADER, updated.member(candidateA).orElseThrow().role());
        }
    }

    @Test
    void corruptElectionEventHistoryFailsClosedOnReopen() throws Exception {
        Path database = temporaryDirectory.resolve("clan-election-corrupt-history.sqlite");
        UUID leaderId = memberId(611);
        UUID candidateId = memberId(612);
        Clan clan = withAdditionalMember(simpleClan(611, "ElectionAudit", "EA611", leaderId), candidateId);
        Instant started = Instant.parse("2026-02-02T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(SqliteClanStore.ElectionCreateStatus.CREATED, store.createElection(
                    UUID.randomUUID(), clan.id(), "DEPARTURE", leaderId, started,
                    started.plus(java.time.Duration.ofHours(24)), List.of(candidateId)));
        }
        executeSql(database, "DROP TRIGGER clan_election_events_no_update");
        executeSql(database, "UPDATE clan_election_events SET occurred_at = 'not-an-instant'");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void clanXpAwardsAreIdempotentAndRejectPayloadConflicts() {
        Path database = temporaryDirectory.resolve("clan-xp-idempotency.sqlite");
        UUID leaderId = memberId(551);
        Clan clan = simpleClan(551, "XpClan", "XP551", leaderId);
        Instant now = Instant.parse("2026-01-06T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            ClanXpAwardResult awarded = store.awardClanXp(clan.id(), ClanXpEventType.WAR_WIN,
                    leaderId, "war-551-win", now);
            assertEquals(ClanXpAwardResult.Status.AWARDED, awarded.status());
            assertEquals(1_551L, awarded.totalXp().orElseThrow());
            assertEquals(ClanXpAwardResult.Status.DUPLICATE,
                    store.awardClanXp(clan.id(), ClanXpEventType.WAR_WIN,
                            leaderId, "war-551-win", now).status());
            assertEquals(ClanXpAwardResult.Status.IDEMPOTENCY_KEY_CONFLICT,
                    store.awardClanXp(clan.id(), ClanXpEventType.WAR_DRAW,
                            leaderId, "war-551-win", now).status());
            assertEquals(1_551L, store.findById(clan.id()).orElseThrow().totalXp());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(1_551L, reopened.findById(clan.id()).orElseThrow().totalXp());
        }
    }

    @Test
    void clanXpEventTamperingFailsClosedOnReopen() throws Exception {
        Path database = temporaryDirectory.resolve("corrupt-clan-xp-event.sqlite");
        UUID leaderId = memberId(571);
        Clan clan = simpleClan(571, "XpHistory", "XH571", leaderId);
        Instant now = Instant.parse("2026-01-08T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanXpAwardResult.Status.AWARDED,
                    store.awardClanXp(clan.id(), ClanXpEventType.WAR_WIN,
                            leaderId, "war-571-win", now).status());
        }
        executeSql(database, "DROP TRIGGER clan_xp_events_no_update");
        executeSql(database, "UPDATE clan_xp_events SET amount = 999 WHERE idempotency_key = 'war-571-win'");
        executeSql(database, "CREATE TRIGGER clan_xp_events_no_update BEFORE UPDATE ON clan_xp_events "
                + "BEGIN SELECT RAISE(ABORT, 'clan XP events are append-only'); END");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void zeroXpAndOverflowAwardsAreHandledWithoutCorruptingClanState() {
        Path database = temporaryDirectory.resolve("clan-xp-zero-overflow.sqlite");
        UUID zeroLeader = memberId(561);
        UUID overflowLeader = memberId(562);
        Clan zeroClan = simpleClan(561, "ZeroXp", "ZX561", zeroLeader);
        Clan base = simpleClan(562, "MaxXp", "MX562", overflowLeader);
        Clan maxClan = new Clan(base.id(), base.name(), base.tag(), base.createdAt(),
                base.capacity(), base.members(), Long.MAX_VALUE, base.tagline());
        Instant now = Instant.parse("2026-01-07T00:00:00Z");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(zeroClan));
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(maxClan));
            assertEquals(ClanXpAwardResult.Status.AWARDED,
                    store.awardClanXp(zeroClan.id(), ClanXpEventType.WAR_LOSS,
                            zeroLeader, "war-561-loss", now).status());
            assertEquals(ClanXpAwardResult.Status.XP_OVERFLOW,
                    store.awardClanXp(maxClan.id(), ClanXpEventType.WAR_WIN,
                            overflowLeader, "war-562-win", now).status());
            assertEquals(Long.MAX_VALUE, store.findById(maxClan.id()).orElseThrow().totalXp());
        }
    }

    @Test
    void failedInitialMigrationRemovesOnlyItsNewDatabaseAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("initial-migration-failure.sqlite");
        assertFalse(Files.exists(database));

        RuntimeException failure = assertThrows(RuntimeException.class, () -> SqliteClanStore.open(
                database,
                SqliteTransactionControl.JDBC,
                version -> {
                    if (version == 1) {
                        throw new IllegalStateException("injected first migration failure");
                    }
                }));
        assertTrue(failure.getCause() instanceof IllegalStateException);

        assertFalse(Files.exists(database));
        assertFalse(Files.exists(Path.of(database + "-wal")));
        assertFalse(Files.exists(Path.of(database + "-shm")));
        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
        }
    }

    @Test
    void fingerprintRejectsMalformedUtf16AndEncodesUnicodeWithoutNormalization() {
        assertThrows(
                IllegalArgumentException.class,
                () -> CapacityPurchaseFingerprint.encodeString("\uD800"));
        assertThrows(
                IllegalArgumentException.class,
                () -> CapacityPurchaseFingerprint.encodeString("\uDC00"));

        assertEquals(
                java.util.Arrays.toString("😀".getBytes(java.nio.charset.StandardCharsets.UTF_8)),
                java.util.Arrays.toString(CapacityPurchaseFingerprint.encodeString("😀")));
        assertEquals(
                java.util.Arrays.toString("Привет".getBytes(java.nio.charset.StandardCharsets.UTF_8)),
                java.util.Arrays.toString(CapacityPurchaseFingerprint.encodeString("Привет")));
        assertNotEquals(
                java.util.Arrays.toString(CapacityPurchaseFingerprint.encodeString("é")),
                java.util.Arrays.toString(CapacityPurchaseFingerprint.encodeString("e\u0301")));
    }

    @Test
    void verifiesEffectivePragmaSettingsAndForeignKeyEnforcement() throws Exception {
        Path database = temporaryDirectory.resolve("pragma-settings.sqlite");
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            SqliteClanStore.PragmaSettings settings = store.pragmaSettings();
            assertEquals(1, settings.foreignKeys());
            assertEquals("wal", settings.journalMode().toLowerCase(java.util.Locale.ROOT));
            assertEquals(2, settings.synchronous());
            assertEquals(10_000, settings.busyTimeoutMillis());
        }

        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
            assertThrows(SQLException.class, () -> statement.executeUpdate("""
                    INSERT INTO clan_members (
                        clan_id, player_id, role, membership_started_at, appointed_by_deputy_id
                    ) VALUES ('missing-clan', 'orphan-player', 'MEMBER', '2025-01-01T00:00:00Z', NULL)
                    """));
        }
    }

    @Test
    void failedRollbackOrCommitPoisonsConnectionButSuccessfulRollbackDoesNot() throws Exception {
        Path rollbackDatabase = temporaryDirectory.resolve("rollback-poison.sqlite");
        FaultInjectingTransactionControl rollbackControl =
                new FaultInjectingTransactionControl();
        try (SqliteClanStore store = SqliteClanStore.open(
                rollbackDatabase, rollbackControl, SqliteMigrationHook.NONE)) {
            executeSql(rollbackDatabase, """
                    CREATE TRIGGER reject_registration
                    BEFORE INSERT ON clans
                    BEGIN SELECT RAISE(ABORT, 'forced registration failure'); END
                    """);
            rollbackControl.failRollback = true;
            StorageException failure = assertThrows(StorageException.class,
                    () -> store.registerIfAvailable(simpleClan(90, "Bad", "B90", memberId(90))));
            assertTrue(failure.getSuppressed().length > 0
                    || failure.getCause().getSuppressed().length > 0);
            assertTrue(rollbackControl.connection.get().isClosed());
            assertTrue(assertThrows(StorageException.class,
                    () -> store.findById(new UUID(0, 90)))
                    .getMessage().contains("unusable"));
        }

        Path commitDatabase = temporaryDirectory.resolve("commit-poison.sqlite");
        FaultInjectingTransactionControl commitControl =
                new FaultInjectingTransactionControl();
        try (SqliteClanStore store = SqliteClanStore.open(
                commitDatabase, commitControl, SqliteMigrationHook.NONE)) {
            commitControl.failCommit = true;
            StorageException failure = assertThrows(StorageException.class,
                    () -> store.registerIfAvailable(
                            simpleClan(91, "UnknownCommit", "UC91", memberId(91))));
            assertTrue(failure.getMessage().contains("outcome is unknown"));
            assertTrue(commitControl.connection.get().isClosed());
            assertTrue(assertThrows(StorageException.class,
                    () -> store.findById(new UUID(0, 91)))
                    .getMessage().contains("unusable"));
        }
    }

    @Test
    void journalEventsStoreTransitionSourceDestinationAndEvidence() throws Exception {
        Path database = temporaryDirectory.resolve("stored-evidence.sqlite");
        Clan clan = simpleClan(110, "StoredEvidence", "SE110", memberId(110));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "debit-ref");

            List<CapacityPurchaseEvent> events = store.listEvents(intent.operationId());
            assertEquals(3, events.size());
            assertNull(events.get(0).fromState());
            assertEquals(CapacityPurchaseState.PREPARED, events.get(0).toState());
            assertNull(events.get(0).evidence());
            assertEquals(CapacityPurchaseEvidenceProvenance.RECORDED,
                    events.get(0).evidenceProvenance());
            assertEquals(CapacityPurchaseState.PREPARED, events.get(1).fromState());
            assertEquals(CapacityPurchaseState.CALLING, events.get(1).toState());
            assertEquals(CapacityPurchaseTransitionEvidence.NONE, events.get(1).evidence());
            assertEquals(CapacityPurchaseState.CALLING, events.get(2).fromState());
            assertEquals(CapacityPurchaseState.DEBIT_CONFIRMED, events.get(2).toState());
            assertEquals(CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                    events.get(2).evidence());
            assertEquals("debit-ref", events.get(2).providerOperationId());
        }

        // The values must come from the rows themselves, not from a reconstruction in Java.
        assertEquals("DEBIT_SUCCESS_REPORTED", scalarText(database, """
                SELECT evidence FROM capacity_purchase_events
                WHERE operation_id = '%s' ORDER BY event_id DESC LIMIT 1
                """.formatted(intent.operationId())));
        assertEquals("CALLING", scalarText(database, """
                SELECT from_state FROM capacity_purchase_events
                WHERE operation_id = '%s' ORDER BY event_id DESC LIMIT 1
                """.formatted(intent.operationId())));
        assertEquals("RECORDED", scalarText(database, """
                SELECT evidence_provenance FROM capacity_purchase_events
                WHERE operation_id = '%s' ORDER BY event_id ASC LIMIT 1
                """.formatted(intent.operationId())));

        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            List<CapacityPurchaseEvent> events = reopened.listEvents(intent.operationId());
            assertEquals(3, events.size());
            assertEquals(CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                    events.get(2).evidence());
            assertEquals(CapacityPurchaseState.CALLING, events.get(2).fromState());
        }
    }

    @Test
    void rejectsStoredEvidenceThatDoesNotConfirmItsOwnTransition() throws Exception {
        Path database = temporaryDirectory.resolve("wrong-stored-evidence.sqlite");
        Clan clan = simpleClan(111, "WrongEvidence", "WE111", memberId(111));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            clearPurchaseJournal(database, intent.operationId());
            insertPurchaseEventRow(database, 10, intent.operationId(),
                    null, CapacityPurchaseState.PREPARED, null, "RECORDED", null,
                    "2025-01-01T00:00:00Z");
            // PREPARED -> CALLING requires NONE; a different evidence value must not be accepted
            // just because the pair of states is itself allowed.
            insertPurchaseEventRow(database, 20, intent.operationId(),
                    CapacityPurchaseState.PREPARED, CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED, "RECORDED", null,
                    "2025-01-01T00:00:01Z");
            executeSql(database, """
                    UPDATE capacity_purchase_operations SET state = 'CALLING'
                    WHERE operation_id = '%s'
                    """.formatted(intent.operationId()));
            assertThrows(StorageException.class,
                    () -> store.findByIdempotencyKey(intent.idempotencyKey()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void rejectsRecordedEventThatOmitsItsSourceStateOrEvidence() throws Exception {
        Path database = temporaryDirectory.resolve("missing-stored-evidence.sqlite");
        Clan clan = simpleClan(112, "MissingEvidence", "ME112", memberId(112));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            clearPurchaseJournal(database, intent.operationId());
            insertPurchaseEventRow(database, 10, intent.operationId(),
                    null, CapacityPurchaseState.PREPARED, null, "RECORDED", null,
                    "2025-01-01T00:00:00Z");
            insertPurchaseEventRow(database, 20, intent.operationId(),
                    null, CapacityPurchaseState.CALLING, null, "RECORDED", null,
                    "2025-01-01T00:00:01Z");
            executeSql(database, """
                    UPDATE capacity_purchase_operations SET state = 'CALLING'
                    WHERE operation_id = '%s'
                    """.formatted(intent.operationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void rejectsSourceStateThatDoesNotContinueThePreviousEvent() throws Exception {
        Path database = temporaryDirectory.resolve("source-state-gap.sqlite");
        Clan clan = simpleClan(113, "SourceGap", "SG113", memberId(113));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            clearPurchaseJournal(database, intent.operationId());
            insertPurchaseEventRow(database, 10, intent.operationId(),
                    null, CapacityPurchaseState.PREPARED, null, "RECORDED", null,
                    "2025-01-01T00:00:00Z");
            insertPurchaseEventRow(database, 20, intent.operationId(),
                    CapacityPurchaseState.PREPARED, CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.NONE, "RECORDED", null,
                    "2025-01-01T00:00:01Z");
            // UNKNOWN -> DEBIT_CONFIRMED is a legal edge with legal evidence, so only the broken
            // link to the previous event can reject this row.
            insertPurchaseEventRow(database, 30, intent.operationId(),
                    CapacityPurchaseState.UNKNOWN, CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.RECONCILED_DEBIT_SUCCESS_REPORTED,
                    "RECORDED", "debit-ref", "2025-01-01T00:00:02Z");
            executeSql(database, """
                    UPDATE capacity_purchase_operations
                    SET state = 'DEBIT_CONFIRMED', provider_operation_id = 'debit-ref'
                    WHERE operation_id = '%s'
                    """.formatted(intent.operationId()));
            assertThrows(StorageException.class, () -> store.listEvents(intent.operationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void rejectsDisallowedTransitionEdgeWrittenThroughSql() throws Exception {
        Path database = temporaryDirectory.resolve("forged-edge.sqlite");
        Clan clan = simpleClan(114, "ForgedEdge", "FE114", memberId(114));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            clearPurchaseJournal(database, intent.operationId());
            insertPurchaseEventRow(database, 10, intent.operationId(),
                    null, CapacityPurchaseState.PREPARED, null, "RECORDED", null,
                    "2025-01-01T00:00:00Z");
            insertPurchaseEventRow(database, 20, intent.operationId(),
                    CapacityPurchaseState.PREPARED, CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                    "RECORDED", "debit-ref", "2025-01-01T00:00:01Z");
            executeSql(database, """
                    UPDATE capacity_purchase_operations
                    SET state = 'DEBIT_CONFIRMED', provider_operation_id = 'debit-ref'
                    WHERE operation_id = '%s'
                    """.formatted(intent.operationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void rejectsEventIdsThatContradictTheChronologicalOrder() throws Exception {
        Path database = temporaryDirectory.resolve("event-id-order.sqlite");
        Clan clan = simpleClan(115, "IdOrder", "IO115", memberId(115));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            clearPurchaseJournal(database, intent.operationId());
            // By occurred_at the chain PREPARED -> CALLING -> DEBIT_CONFIRMED would be valid.
            // event_id is the ordering authority, and in that order the chain is broken.
            insertPurchaseEventRow(database, 10, intent.operationId(),
                    null, CapacityPurchaseState.PREPARED, null, "RECORDED", null,
                    "2025-01-01T00:00:00Z");
            insertPurchaseEventRow(database, 20, intent.operationId(),
                    CapacityPurchaseState.CALLING, CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                    "RECORDED", "debit-ref", "2025-01-01T00:00:02Z");
            insertPurchaseEventRow(database, 30, intent.operationId(),
                    CapacityPurchaseState.PREPARED, CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.NONE, "RECORDED", null,
                    "2025-01-01T00:00:01Z");
            executeSql(database, """
                    UPDATE capacity_purchase_operations
                    SET state = 'CALLING', provider_operation_id = NULL
                    WHERE operation_id = '%s'
                    """.formatted(intent.operationId()));
            assertThrows(StorageException.class, () -> store.findUnresolved());
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void rejectsEventWrittenAfterATerminalState() throws Exception {
        Path database = temporaryDirectory.resolve("event-after-terminal-v4.sqlite");
        Clan clan = simpleClan(116, "AfterTerminal", "AT116", memberId(116));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            clearPurchaseJournal(database, intent.operationId());
            insertPurchaseEventRow(database, 10, intent.operationId(),
                    null, CapacityPurchaseState.PREPARED, null, "RECORDED", null,
                    "2025-01-01T00:00:00Z");
            insertPurchaseEventRow(database, 20, intent.operationId(),
                    CapacityPurchaseState.PREPARED, CapacityPurchaseState.FAILED_NO_EFFECT,
                    CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED,
                    "RECORDED", null, "2025-01-01T00:00:01Z");
            // FAILED_NO_EFFECT is terminal and has no allowed continuation at all, so the row that
            // follows it is rejected both by the terminal rule and by the stored evidence check.
            insertPurchaseEventRow(database, 30, intent.operationId(),
                    CapacityPurchaseState.FAILED_NO_EFFECT, CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.NONE, "RECORDED", null,
                    "2025-01-01T00:00:02Z");
            executeSql(database, """
                    UPDATE capacity_purchase_operations SET state = 'CALLING'
                    WHERE operation_id = '%s'
                    """.formatted(intent.operationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void rejectsLegacyEventMixedIntoRecordedHistory() throws Exception {
        Path database = temporaryDirectory.resolve("legacy-after-recorded.sqlite");
        Clan clan = simpleClan(117, "MixedHistory", "MH117", memberId(117));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            executeSql(database, """
                    INSERT INTO capacity_purchase_events (
                        operation_id, from_state, to_state, evidence, evidence_provenance,
                        provider_operation_id, occurred_at
                    ) VALUES ('%s', NULL, 'CALLING', NULL, 'UNVERIFIED_LEGACY', NULL,
                        '2025-01-01T00:00:01Z')
                    """.formatted(intent.operationId()));
            executeSql(database, """
                    UPDATE capacity_purchase_operations SET state = 'CALLING'
                    WHERE operation_id = '%s'
                    """.formatted(intent.operationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void schemaRejectsUnknownEvidenceProvenance() throws Exception {
        Path database = temporaryDirectory.resolve("unknown-provenance.sqlite");
        Clan clan = simpleClan(118, "BadProvenance", "BP118", memberId(118));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            assertThrows(java.sql.SQLException.class, () -> executeSql(database, """
                    INSERT INTO capacity_purchase_events (
                        operation_id, from_state, to_state, evidence, evidence_provenance,
                        provider_operation_id, occurred_at
                    ) VALUES ('%s', 'PREPARED', 'CALLING', 'NONE', 'SELF_REPORTED', NULL,
                        '2025-01-01T00:00:01Z')
                    """.formatted(intent.operationId())));
            // Nothing was written, so the journal still reads back cleanly.
            assertEquals(1, store.listEvents(intent.operationId()).size());
        }
    }


    @Test
    void legacyMigrationKeepsEventsUnverifiedAndBlocksCommit() throws Exception {
        Path database = temporaryDirectory.resolve("legacy-unverified-commit.sqlite");
        assertThrows(RuntimeException.class, () -> SqliteClanStore.open(
                database,
                SqliteTransactionControl.JDBC,
                version -> {
                    if (version == 3) {
                        throw new IllegalStateException("leave database at version two");
                    }
                }));
        assertEquals(2, pragmaInt(database, "PRAGMA user_version"));

        UUID clanId = UUID.fromString("00000000-0000-0000-0000-000000000301");
        UUID leaderId = UUID.fromString("00000000-0000-0000-0000-000000000302");
        UUID operationId = UUID.fromString("00000000-0000-0000-0000-000000000303");
        UUID callingOperationId = UUID.fromString("00000000-0000-0000-0000-000000000304");
        seedClan(database, clanId, leaderId, 10, 0);
        seedLegacyPurchase(database, operationId, "legacy-debit-key", "legacy-debit-business",
                clanId, leaderId, CapacityPurchaseState.DEBIT_CONFIRMED, "provider-debit");
        seedLegacyPurchaseEvent(database, operationId, CapacityPurchaseState.PREPARED, null);
        seedLegacyPurchaseEvent(database, operationId, CapacityPurchaseState.CALLING, null);
        seedLegacyPurchaseEvent(
                database, operationId, CapacityPurchaseState.DEBIT_CONFIRMED, "provider-debit");
        seedLegacyPurchase(database, callingOperationId, "legacy-calling-key",
                "legacy-calling-business", clanId, leaderId, CapacityPurchaseState.CALLING, null);
        seedLegacyPurchaseEvent(database, callingOperationId, CapacityPurchaseState.PREPARED, null);
        seedLegacyPurchaseEvent(database, callingOperationId, CapacityPurchaseState.CALLING, null);


        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
            List<CapacityPurchaseEvent> migrated = store.listEvents(operationId);
            assertEquals(3, migrated.size());
            for (CapacityPurchaseEvent event : migrated) {
                assertNull(event.fromState());
                assertNull(event.evidence());
                assertEquals(CapacityPurchaseEvidenceProvenance.UNVERIFIED_LEGACY,
                        event.evidenceProvenance());
            }
            assertEquals(
                    CapacityPurchaseStore.CommitStatus.HISTORY_EVIDENCE_UNVERIFIABLE,
                    store.commitCapacityPurchase(operationId).status());
            assertEquals(CapacityPurchaseState.DEBIT_CONFIRMED,
                    store.findByIdempotencyKey("legacy-debit-key").orElseThrow().state());
            assertTrue(store.findAppliedOperationId("legacy-debit-business").isEmpty());
            assertEquals(10, scalarInt(database,
                    "SELECT capacity FROM clans WHERE id = '" + clanId + "'"));
        }

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            // New transitions record their own evidence, including the source state they started from.
            assertEquals(
                    CapacityPurchaseJournal.TransitionStatus.UPDATED,
                    store.transition(
                            operationId,
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseState.COMPENSATION_PENDING,
                            CapacityPurchaseTransitionEvidence.COMPENSATION_REQUIRED_REPORTED,
                            "provider-debit").status());
            List<CapacityPurchaseEvent> events = store.listEvents(operationId);
            assertEquals(4, events.size());
            assertEquals(CapacityPurchaseEvidenceProvenance.RECORDED,
                    events.get(3).evidenceProvenance());
            assertEquals(CapacityPurchaseState.DEBIT_CONFIRMED, events.get(3).fromState());
            assertEquals(CapacityPurchaseState.COMPENSATION_PENDING, events.get(3).toState());
            // The state gate still comes first: this operation can no longer commit at all.
            assertEquals(
                    CapacityPurchaseStore.CommitStatus.WRONG_STATE,
                    store.commitCapacityPurchase(operationId).status());
        }

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            // A recorded tail does not launder an unverifiable legacy prefix: the commit stays blocked.
            assertEquals(
                    CapacityPurchaseJournal.TransitionStatus.UPDATED,
                    store.transition(
                            callingOperationId,
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseState.DEBIT_CONFIRMED,
                            CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                            "provider-tail").status());
            List<CapacityPurchaseEvent> mixed = store.listEvents(callingOperationId);
            assertEquals(3, mixed.size());
            assertEquals(CapacityPurchaseEvidenceProvenance.UNVERIFIED_LEGACY,
                    mixed.get(0).evidenceProvenance());
            assertEquals(CapacityPurchaseEvidenceProvenance.RECORDED,
                    mixed.get(2).evidenceProvenance());
            assertEquals(CapacityPurchaseState.CALLING, mixed.get(2).fromState());
            assertEquals(
                    CapacityPurchaseStore.CommitStatus.HISTORY_EVIDENCE_UNVERIFIABLE,
                    store.commitCapacityPurchase(callingOperationId).status());
            assertEquals(CapacityPurchaseState.DEBIT_CONFIRMED,
                    store.findByIdempotencyKey("legacy-calling-key").orElseThrow().state());
            assertTrue(store.findAppliedOperationId("legacy-calling-business").isEmpty());
            assertEquals(10, scalarInt(database,
                    "SELECT capacity FROM clans WHERE id = '" + clanId + "'"));
        }

        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            List<CapacityPurchaseEvent> events = reopened.listEvents(operationId);
            assertEquals(CapacityPurchaseEvidenceProvenance.UNVERIFIED_LEGACY,
                    events.get(0).evidenceProvenance());
            assertEquals(CapacityPurchaseEvidenceProvenance.RECORDED,
                    events.get(3).evidenceProvenance());
            assertEquals(2, reopened.findUnresolved().size());
        }
    }


    @Test
    void committedPurchaseStoresProofThatReconcilesWithTheClanRow() throws Exception {
        Path database = temporaryDirectory.resolve("committed-proof.sqlite");
        Clan clan = simpleClan(120, "CommitProof", "CP120", memberId(120));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "debit-ref");
            assertEquals(
                    CapacityPurchaseStore.CommitStatus.COMMITTED,
                    store.commitCapacityPurchase(intent.operationId()).status());
        }

        assertEquals("RECORDED", scalarText(database, """
                SELECT commit_evidence_provenance FROM applied_business_operations
                WHERE operation_id = '%s'
                """.formatted(intent.operationId())));
        assertEquals("0", scalarText(database, """
                SELECT expected_revision FROM applied_business_operations
                WHERE operation_id = '%s'
                """.formatted(intent.operationId())));
        assertEquals("1", scalarText(database, """
                SELECT applied_revision FROM applied_business_operations
                WHERE operation_id = '%s'
                """.formatted(intent.operationId())));
        assertEquals("ATOMIC_CAPACITY_COMMIT", scalarText(database, """
                SELECT evidence FROM capacity_purchase_events
                WHERE operation_id = '%s' ORDER BY event_id DESC LIMIT 1
                """.formatted(intent.operationId())));

        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(
                    Optional.of(intent.operationId()),
                    reopened.findAppliedOperationId(intent.businessOperationId()));
            assertEquals(CapacityPurchaseState.COMMITTED,
                    reopened.findByIdempotencyKey(intent.idempotencyKey()).orElseThrow().state());
            assertEquals(Optional.of(clan.withExpandedCapacity(20)), reopened.findById(clan.id()));
            assertTrue(reopened.findUnresolved().isEmpty());
        }
    }

    @Test
    void earlierCommittedPurchaseRemainsValidAfterLaterCapacityPurchase() throws Exception {
        Path database = temporaryDirectory.resolve("sequential-purchases.sqlite");
        Clan initial = simpleClan(122, "SeqPurchase", "SP122", memberId(122));
        CapacityPurchaseIntent first = purchaseIntent(initial);
        UUID secondOperationId = UUID.randomUUID();
        String secondIdempotencyKey = "request-" + UUID.randomUUID();
        String secondBusinessOperationId = "capacity-" + initial.id() + "-20-to-30";

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(initial);
            store.prepare(first);
            assertTransition(store, first, CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            assertTransition(store, first, CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "provider-first");
            assertEquals(CapacityPurchaseStore.CommitStatus.COMMITTED,
                    store.commitCapacityPurchase(first.operationId()).status());

            Clan afterFirst = store.findById(initial.id()).orElseThrow();
            CapacityPurchaseIntent second = new CapacityPurchaseIntent(
                    secondOperationId, secondIdempotencyKey, secondBusinessOperationId,
                    afterFirst, memberId(122), 1, 30, 200);
            store.prepare(second);
            assertTransition(store, second, CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            assertTransition(store, second, CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "provider-second");
            assertEquals(CapacityPurchaseStore.CommitStatus.COMMITTED,
                    store.commitCapacityPurchase(second.operationId()).status());
        }

        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(30, reopened.findById(initial.id()).orElseThrow().capacity());
            assertEquals(CapacityPurchaseState.COMMITTED,
                    reopened.findByIdempotencyKey(first.idempotencyKey()).orElseThrow().state());
            assertEquals(CapacityPurchaseState.COMMITTED,
                    reopened.findByIdempotencyKey(secondIdempotencyKey).orElseThrow().state());
            assertEquals(Optional.of(first.operationId()),
                    reopened.findAppliedOperationId(first.businessOperationId()));
            assertEquals(Optional.of(secondOperationId),
                    reopened.findAppliedOperationId(secondBusinessOperationId));
        }
    }

    @Test
    void rejectsCommittedMarkerThatNeverChangedTheClanRow() throws Exception {
        Path database = temporaryDirectory.resolve("committed-without-clan-change.sqlite");
        Clan clan = simpleClan(121, "FakeCommit", "FC121", memberId(121));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "debit-ref");
        }

        // Operation row, full recorded history and a self-consistent marker are written by hand,
        // while the clan keeps its original capacity 10 and revision 0.
        clearPurchaseJournal(database, intent.operationId());
        insertPurchaseEventRow(database, 10, intent.operationId(),
                null, CapacityPurchaseState.PREPARED, null, "RECORDED", null,
                "2025-01-01T00:00:00Z");
        insertPurchaseEventRow(database, 20, intent.operationId(),
                CapacityPurchaseState.PREPARED, CapacityPurchaseState.CALLING,
                CapacityPurchaseTransitionEvidence.NONE, "RECORDED", null,
                "2025-01-01T00:00:01Z");
        insertPurchaseEventRow(database, 30, intent.operationId(),
                CapacityPurchaseState.CALLING, CapacityPurchaseState.DEBIT_CONFIRMED,
                CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                "RECORDED", "debit-ref", "2025-01-01T00:00:02Z");
        insertPurchaseEventRow(database, 40, intent.operationId(),
                CapacityPurchaseState.DEBIT_CONFIRMED, CapacityPurchaseState.COMMITTED,
                CapacityPurchaseTransitionEvidence.ATOMIC_CAPACITY_COMMIT,
                "RECORDED", "debit-ref", "2025-01-01T00:00:03Z");
        executeSql(database, """
                UPDATE capacity_purchase_operations
                SET state = 'COMMITTED', provider_operation_id = 'debit-ref'
                WHERE operation_id = '%s'
                """.formatted(intent.operationId()));
        executeSql(database, """
                INSERT INTO applied_business_operations (
                    business_operation_id, operation_id, clan_id, from_capacity, to_capacity,
                    committed_at, expected_revision, applied_revision, amount,
                    commit_evidence_provenance
                ) VALUES ('%s', '%s', '%s', 10, 20, '2025-01-01T00:00:03Z', 0, 1, 100, 'RECORDED')
                """.formatted(
                intent.businessOperationId(), intent.operationId(), clan.id()));

        assertEquals(10, scalarInt(database,
                "SELECT capacity FROM clans WHERE id = '" + clan.id() + "'"));
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void everyReadPathFailsClosedWhenCommittedCapacityIsRolledBack() throws Exception {
        Path database = temporaryDirectory.resolve("committed-capacity-reverted.sqlite");
        Clan clan = simpleClan(122, "RevertedCommit", "RC122", memberId(122));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "debit-ref");
            store.commitCapacityPurchase(intent.operationId());

            // A direct write outside the store undoes the clan change the commit claims to have
            // made. Journal, marker and operation row still agree, so only the clan check can
            // catch it, and every public read path has to refuse the record.
            executeSql(database, """
                    UPDATE clans SET capacity = 10, revision = 0 WHERE id = '%s'
                    """.formatted(clan.id()));

            assertThrows(StorageException.class,
                    () -> store.findByIdempotencyKey(intent.idempotencyKey()));
            assertThrows(StorageException.class,
                    () -> store.findByBusinessOperationId(intent.businessOperationId()));
            assertThrows(StorageException.class, () -> store.findUnresolved());
            assertThrows(StorageException.class,
                    () -> store.listEvents(intent.operationId()));
            assertThrows(StorageException.class,
                    () -> store.findAppliedOperationId(intent.businessOperationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void rejectsCommitMarkerThatDisagreesWithOperationOrClanRevision() throws Exception {
        assertCommitMarkerRejected("marker-revision.sqlite", """
                UPDATE applied_business_operations SET applied_revision = 7
                """);
        assertCommitMarkerRejected("marker-amount.sqlite", """
                UPDATE applied_business_operations SET amount = 999
                """);
        assertCommitMarkerRejected("marker-expected-revision.sqlite", """
                UPDATE applied_business_operations SET expected_revision = 5
                """);
    }

    @Test
    void migrationToVersionFourRollsBackAndCanBeRetried() throws Exception {
        Path database = temporaryDirectory.resolve("migration-v4-rollback.sqlite");
        assertThrows(RuntimeException.class, () -> SqliteClanStore.open(
                database,
                SqliteTransactionControl.JDBC,
                version -> {
                    if (version == 4) {
                        throw new IllegalStateException("injected fourth migration failure");
                    }
                }));

        assertEquals(3, pragmaInt(database, "PRAGMA user_version"));
        assertFalseColumnExists(database, "capacity_purchase_events", "to_state");
        assertFalseColumnExists(database, "applied_business_operations", "applied_revision");

        try (SqliteClanStore recovered = SqliteClanStore.open(database)) {
            assertTrueColumnExists(database, "capacity_purchase_events", "to_state");
            assertTrueColumnExists(database, "capacity_purchase_events", "evidence_provenance");
            assertTrueColumnExists(
                    database, "applied_business_operations", "commit_evidence_provenance");
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(28, pragmaInt(database, "PRAGMA user_version"));
        }
    }

    @Test
    void invitationAcceptanceAtomicallyAddsMemberAndClosesRequest() {
        Path database = temporaryDirectory.resolve("invitation-acceptance.sqlite");
        UUID leaderId = memberId(501);
        UUID inviteeId = memberId(502);
        Clan clan = simpleClan(501, "InviteClan", "IC501", leaderId);
        Instant created = Instant.parse("2026-01-01T00:00:00Z");
        ClanRequest request = new ClanRequest(UUID.randomUUID(), ClanRequest.Type.INVITATION,
                clan.id(), inviteeId, leaderId, created, created.plusSeconds(120),
                ClanRequest.Status.PENDING);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(request));
            assertEquals(ClanRequestStore.CreateStatus.DUPLICATE_PENDING_REQUEST,
                    store.createRequest(new ClanRequest(UUID.randomUUID(), ClanRequest.Type.INVITATION,
                            clan.id(), inviteeId, leaderId, created.plusSeconds(1),
                            created.plusSeconds(121), ClanRequest.Status.PENDING)));
            assertEquals(ClanRequestStore.ResolveStatus.ACCEPTED,
                    store.resolveRequest(request.id(), inviteeId, true, created.plusSeconds(2)));
            assertTrue(store.findByPlayerId(inviteeId).isPresent());
            assertTrue(store.listPendingRequestsForPlayer(inviteeId,
                    ClanRequest.Type.INVITATION, created.plusSeconds(3)).isEmpty());
        }
    }

    @Test
    void applicationRequiresLeaderOrDeputyAndAcceptsAtomically() {
        Path database = temporaryDirectory.resolve("application-acceptance.sqlite");
        UUID leaderId = memberId(511);
        UUID applicantId = memberId(512);
        Clan clan = simpleClan(511, "ApplyClan", "AC511", leaderId);
        Instant created = Instant.parse("2026-01-02T00:00:00Z");
        ClanRequest request = new ClanRequest(UUID.randomUUID(), ClanRequest.Type.APPLICATION,
                clan.id(), applicantId, applicantId, created, created.plusSeconds(86_400),
                ClanRequest.Status.PENDING);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(request));
            assertEquals(ClanRequestStore.ResolveStatus.NOT_AUTHORIZED,
                    store.resolveRequest(request.id(), applicantId, true, created.plusSeconds(1)));
            assertEquals(ClanRequestStore.ResolveStatus.ACCEPTED,
                    store.resolveRequest(request.id(), leaderId, true, created.plusSeconds(2)));
            assertEquals(Optional.of(clan.id()), store.findByPlayerId(applicantId).map(Clan::id));
        }
    }

    @Test
    void clanRequestHistoryCorruptionFailsClosedOnReopen() throws Exception {
        Path database = temporaryDirectory.resolve("corrupt-clan-request-history.sqlite");
        UUID leaderId = memberId(541);
        UUID inviteeId = memberId(542);
        Clan clan = simpleClan(541, "HistoryClan", "HC541", leaderId);
        Instant now = Instant.parse("2026-01-05T00:00:00Z");
        ClanRequest request = new ClanRequest(UUID.randomUUID(), ClanRequest.Type.INVITATION,
                clan.id(), inviteeId, leaderId, now, now.plusSeconds(120), ClanRequest.Status.PENDING);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(request));
        }
        executeSql(database, "UPDATE clan_requests SET status = 'ACCEPTED' WHERE request_id = '"
                + request.id() + "'");
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    @Test
    void onlyLeaderCanTogglePublicApplicationsAndClosedApplicationsAreRejected() {
        Path database = temporaryDirectory.resolve("public-applications-setting.sqlite");
        UUID leaderId = memberId(531);
        UUID applicantId = memberId(532);
        Clan clan = simpleClan(531, "PublicClan", "PC531", leaderId);
        Instant now = Instant.parse("2026-01-04T00:00:00Z");
        ClanRequest application = new ClanRequest(UUID.randomUUID(), ClanRequest.Type.APPLICATION,
                clan.id(), applicantId, applicantId, now, now.plusSeconds(86_400),
                ClanRequest.Status.PENDING);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertTrue(store.arePublicApplicationsOpen(clan.id()));
            assertEquals(ClanRequestStore.SettingStatus.NOT_LEADER,
                    store.setPublicApplicationsOpen(clan.id(), applicantId, false));
            assertEquals(ClanRequestStore.SettingStatus.UPDATED,
                    store.setPublicApplicationsOpen(clan.id(), leaderId, false));
            assertFalse(store.arePublicApplicationsOpen(clan.id()));
            assertEquals(ClanRequestStore.CreateStatus.APPLICATIONS_CLOSED,
                    store.createRequest(application));
            assertEquals(ClanRequestStore.SettingStatus.UPDATED,
                    store.setPublicApplicationsOpen(clan.id(), leaderId, true));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(application));
        }
    }

    @Test
    void expiredPendingRequestDoesNotBlockNewRequest() {
        Path database = temporaryDirectory.resolve("expired-request-replacement.sqlite");
        UUID leaderId = memberId(521);
        UUID inviteeId = memberId(522);
        Clan clan = simpleClan(521, "ExpiryClan", "EC521", leaderId);
        Instant created = Instant.parse("2026-01-03T00:00:00Z");
        ClanRequest oldRequest = new ClanRequest(UUID.randomUUID(), ClanRequest.Type.INVITATION,
                clan.id(), inviteeId, leaderId, created, created.plusSeconds(120),
                ClanRequest.Status.PENDING);
        ClanRequest newRequest = new ClanRequest(UUID.randomUUID(), ClanRequest.Type.INVITATION,
                clan.id(), inviteeId, leaderId, created.plusSeconds(121),
                created.plusSeconds(241), ClanRequest.Status.PENDING);

        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(oldRequest));
            assertEquals(ClanRequestStore.CreateStatus.CREATED, store.createRequest(newRequest));
            assertEquals(1, store.listPendingRequests(clan.id(), ClanRequest.Type.INVITATION,
                    created.plusSeconds(122)).size());
        }
    }

    private void assertCommitMarkerRejected(String fileName, String corruption) throws Exception {
        Path database = temporaryDirectory.resolve(fileName);
        Clan clan = simpleClan(123, "MarkerDrift", "MD123", memberId(123));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE, null);
            store.transition(
                    intent.operationId(), CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, "debit-ref");
            assertEquals(
                    CapacityPurchaseStore.CommitStatus.COMMITTED,
                    store.commitCapacityPurchase(intent.operationId()).status());
            executeSql(database, corruption);
            assertThrows(StorageException.class,
                    () -> store.findAppliedOperationId(intent.businessOperationId()));
        }
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database), fileName);
    }

    private static void seedClan(
            Path database,
            UUID clanId,
            UUID leaderId,
            int capacity,
            long revision) throws Exception {
        executeSql(database, """
                INSERT INTO clans (
                    id, name, tag, tag_key, created_at, capacity, total_xp, tagline, revision
                ) VALUES (
                    '%s', 'Legacy Clan', 'LG%d', 'lg%d', '2025-01-01T00:00:00Z', %d, 0, NULL, %d
                )
                """.formatted(clanId, capacity, capacity, capacity, revision));
        executeSql(database, """
                INSERT INTO clan_members (
                    clan_id, player_id, role, membership_started_at, appointed_by_deputy_id
                ) VALUES ('%s', '%s', 'LEADER', '2025-01-01T00:00:00Z', NULL)
                """.formatted(clanId, leaderId));
    }

    private static void changeLeader(Path database, UUID oldLeader, UUID newLeader)
            throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
            statement.executeUpdate(
                    "UPDATE clan_members SET role = 'MEMBER' WHERE player_id = '"
                            + oldLeader + "'");
            statement.executeUpdate(
                    "UPDATE clan_members SET role = 'LEADER' WHERE player_id = '"
                            + newLeader + "'");
            statement.executeUpdate("UPDATE clans SET revision = revision + 1");
        }
    }

    private static void executeSql(Path database, String sql) throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement()) {
            statement.execute(sql);
        }
    }

    private static boolean tableExists(Path database, String tableName) throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             var statement = connection.prepareStatement(
                     "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?")) {
            statement.setString(1, tableName);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    private static int scalarInt(Path database, String sql) throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(sql)) {
            if (!result.next()) {
                throw new AssertionError("Query returned no row");
            }
            return result.getInt(1);
        }
    }

    private static String scalarText(Path database, String sql) throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(sql)) {
            if (!result.next()) {
                throw new AssertionError("Query returned no row");
            }
            return result.getString(1);
        }
    }

    /**
     * Removes the append-only protection for one operation so a test can write a history that the
     * public API would never produce. The triggers are restored afterwards, so the rejected read is
     * still performed against a database that looks structurally intact.
     */
    private static void clearPurchaseJournal(Path database, UUID operationId) throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement()) {
            statement.execute("DROP TRIGGER capacity_purchase_events_no_update");
            statement.execute("DROP TRIGGER capacity_purchase_events_no_delete");
            statement.executeUpdate(
                    "DELETE FROM capacity_purchase_events WHERE operation_id = '"
                            + operationId + "'");
            statement.execute("""
                    CREATE TRIGGER capacity_purchase_events_no_update
                    BEFORE UPDATE ON capacity_purchase_events
                    BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                    """);
            statement.execute("""
                    CREATE TRIGGER capacity_purchase_events_no_delete
                    BEFORE DELETE ON capacity_purchase_events
                    BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                    """);
        }
    }

    private static void insertPurchaseEventRow(
            Path database,
            long eventId,
            UUID operationId,
            CapacityPurchaseState fromState,
            CapacityPurchaseState toState,
            CapacityPurchaseTransitionEvidence evidence,
            String provenance,
            String providerReference,
            String occurredAt) throws Exception {
        executeSql(database, """
                INSERT INTO capacity_purchase_events (
                    event_id, operation_id, from_state, to_state, evidence,
                    evidence_provenance, provider_operation_id, occurred_at
                ) VALUES (%d, '%s', %s, '%s', %s, '%s', %s, '%s')
                """.formatted(
                eventId,
                operationId,
                fromState == null ? "NULL" : "'" + fromState.name() + "'",
                toState.name(),
                evidence == null ? "NULL" : "'" + evidence.name() + "'",
                provenance,
                providerReference == null ? "NULL" : "'" + providerReference + "'",
                occurredAt));
    }

    private static void seedLegacyPurchase(
            Path database,
            UUID operationId,
            String idempotencyKey,
            String businessOperationId,
            UUID clanId,
            UUID actorId,
            CapacityPurchaseState state,
            String providerReference) throws Exception {
        String reference = providerReference == null ? "NULL" : "'" + providerReference + "'";
        executeSql(database, """
                INSERT INTO capacity_purchase_operations (
                    operation_id, idempotency_key, business_operation_id, clan_id, actor_id,
                    expected_capacity, target_capacity, expected_revision, amount,
                    state, provider_operation_id, created_at, updated_at, payload_fingerprint
                ) VALUES (
                    '%s', '%s', '%s', '%s', '%s',
                    10, 20, 0, 100, '%s', %s,
                    '2025-01-01T00:00:00Z', '2025-01-01T00:00:04Z', 'legacy-fingerprint-%s'
                )
                """.formatted(
                operationId,
                idempotencyKey,
                businessOperationId,
                clanId,
                actorId,
                state.name(),
                reference,
                operationId));
    }

    private static void seedLegacyPurchaseEvent(
            Path database,
            UUID operationId,
            CapacityPurchaseState state,
            String providerReference) throws Exception {
        String reference = providerReference == null ? "NULL" : "'" + providerReference + "'";
        executeSql(database, """
                INSERT INTO capacity_purchase_events (
                    operation_id, state, provider_operation_id, occurred_at
                ) VALUES ('%s', '%s', %s, '2025-01-01T00:00:01Z')
                """.formatted(operationId, state.name(), reference));
    }

    private Path createDatabase(String name) {
        Path database = temporaryDirectory.resolve(name);
        try (SqliteClanStore ignored = SqliteClanStore.open(database)) {
            return database;
        }
    }

    private void assertModifiedUpdateTriggerRejected(String fileName, String ddl)
            throws Exception {
        Path database = createDatabase(fileName);
        executeSql(database, "DROP TRIGGER capacity_purchase_events_no_update");
        executeSql(database, ddl);
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database));
    }

    private static int pragmaInt(Path database, String pragma) throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(pragma)) {
            if (!result.next()) {
                throw new AssertionError("PRAGMA returned no value: " + pragma);
            }
            return result.getInt(1);
        }
    }

    private static void assertFalseColumnExists(Path database, String table, String column)
            throws Exception {
        assertFalse(columnExists(database, table, column));
    }

    private static void assertTrueColumnExists(Path database, String table, String column)
            throws Exception {
        assertTrue(columnExists(database, table, column));
    }

    private static boolean columnExists(Path database, String table, String column)
            throws Exception {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA table_info('" + table + "')")) {
            while (result.next()) {
                if (column.equals(result.getString("name"))) {
                    return true;
                }
            }
            return false;
        }
    }

    private static void assertIdempotencyConflict(
            SqliteClanStore store,
            CapacityPurchaseIntent changed) {
        assertEquals(
                CapacityPurchaseJournal.PrepareStatus.IDEMPOTENCY_KEY_CONFLICT,
                store.prepare(changed).status());
    }

    private void assertCorruptHistoryRejected(
            String fileName,
            CapacityPurchaseState[] states,
            String[] providerReferences,
            String[] timestamps,
            CapacityPurchaseState finalState,
            String finalProviderReference) throws Exception {
        Path database = temporaryDirectory.resolve(fileName);
        Clan clan = simpleClan(90, "CorruptHistory", "CH90", memberId(90));
        CapacityPurchaseIntent intent = purchaseIntent(clan);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(clan);
            store.prepare(intent);
        }
        replacePurchaseHistory(
                database, intent, states, providerReferences, timestamps,
                finalState, finalProviderReference);
        assertThrows(StorageException.class, () -> SqliteClanStore.open(database), fileName);
    }

    private static void replacePurchaseHistory(
            Path database,
            CapacityPurchaseIntent intent,
            CapacityPurchaseState[] states,
            String[] providerReferences,
            String[] timestamps,
            CapacityPurchaseState finalState,
            String finalProviderReference) throws Exception {
        if (states.length == 0
                || states.length != providerReferences.length
                || states.length != timestamps.length
                || states[states.length - 1] != finalState
                || !java.util.Objects.equals(
                        providerReferences[providerReferences.length - 1],
                        finalProviderReference)) {
            throw new IllegalArgumentException("Invalid corrupted-history fixture");
        }
        try (Connection connection = DriverManager.getConnection("jdbc:sqlite:" + database);
             Statement statement = connection.createStatement()) {
            statement.execute("DROP TRIGGER capacity_purchase_events_no_update");
            statement.execute("DROP TRIGGER capacity_purchase_events_no_delete");
            statement.executeUpdate(
                    "DELETE FROM capacity_purchase_events WHERE operation_id = '"
                            + intent.operationId() + "'");
            for (int index = 0; index < states.length; index++) {
                String reference = providerReferences[index] == null
                        ? "NULL"
                        : "'" + providerReferences[index] + "'";
                // The fixture keeps the pre-v4 shape of the journal: stored evidence is left empty
                // and the row is tagged as unverified, so the corruption under test stays the only
                // reason the history is rejected.
                statement.executeUpdate("""
                        INSERT INTO capacity_purchase_events (
                            operation_id, from_state, to_state, evidence, evidence_provenance,
                            provider_operation_id, occurred_at
                        ) VALUES ('%s', NULL, '%s', NULL, 'UNVERIFIED_LEGACY', %s, '%s')
                        """.formatted(
                        intent.operationId(),
                        states[index].name(),
                        reference,
                        timestamps[index]));
            }
            String finalReference = finalProviderReference == null
                    ? "NULL"
                    : "'" + finalProviderReference + "'";
            statement.executeUpdate("""
                    UPDATE capacity_purchase_operations
                    SET state = '%s', provider_operation_id = %s
                    WHERE operation_id = '%s'
                    """.formatted(finalState.name(), finalReference, intent.operationId()));
        }
    }

    private static void assertTransition(
            SqliteClanStore store,
            CapacityPurchaseIntent intent,
            CapacityPurchaseState current,
            CapacityPurchaseState next,
            CapacityPurchaseTransitionEvidence evidence,
            String providerOperationId) {
        assertEquals(
                CapacityPurchaseJournal.TransitionStatus.UPDATED,
                store.transition(
                        intent.operationId(), current, next, evidence, providerOperationId).status(),
                current + " -> " + next);
    }

    private static CapacityPurchaseIntent withIntent(
            CapacityPurchaseIntent source,
            UUID operationId,
            String businessOperationId,
            Clan expectedClan,
            UUID actorId,
            long expectedRevision,
            int targetCapacity,
            long amount) {
        return new CapacityPurchaseIntent(
                operationId,
                source.idempotencyKey(),
                businessOperationId,
                expectedClan,
                actorId,
                expectedRevision,
                targetCapacity,
                amount);
    }

    private static Clan withLeader(Clan source, UUID newLeaderId) {
        Map<UUID, ClanMember> members = new java.util.HashMap<>();
        source.members().forEach((id, member) -> members.put(
                id,
                member.withRole(
                        id.equals(newLeaderId) ? ClanRole.LEADER
                                : member.role() == ClanRole.LEADER ? ClanRole.MEMBER : member.role(),
                        member.appointedByDeputyId())));
        return new Clan(
                source.id(), source.name(), source.tag(), source.createdAt(),
                source.capacity(), members, source.totalXp(), source.tagline());
    }

    private static CapacityPurchaseIntent purchaseIntent(Clan clan) {
        return new CapacityPurchaseIntent(
                UUID.randomUUID(),
                "request-" + UUID.randomUUID(),
                "capacity-" + clan.id() + "-" + clan.capacity() + "-to-" + (clan.capacity() + 10),
                clan,
                clan.leader().orElseThrow().playerId(),
                0,
                clan.capacity() + 10,
                clan.capacity() * 10L);
    }

    private static Clan completeClan() {
        UUID leader = memberId(3);
        UUID deputy = memberId(1);
        UUID moderator = memberId(2);
        UUID member = memberId(4);
        Instant started = Instant.parse("2025-01-02T03:04:05.123456789Z");
        return new Clan(
                UUID.fromString("00000000-0000-0000-0000-000000000003"),
                "Complete Clan",
                "Ab3",
                Instant.parse("2024-12-31T23:59:58.987654321Z"),
                20,
                Map.of(
                        leader, new ClanMember(leader, ClanRole.LEADER, started, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, started.plusSeconds(1), null),
                        moderator, new ClanMember(
                                moderator, ClanRole.MODERATOR, started.plusSeconds(2), deputy),
                        member, new ClanMember(member, ClanRole.MEMBER, started.plusSeconds(3), null)),
                987654321L,
                "A full tagline");
    }

    private static Clan withAdditionalMember(Clan source, UUID playerId) {
        Map<UUID, ClanMember> members = new java.util.HashMap<>(source.members());
        members.put(playerId, new ClanMember(playerId, ClanRole.MEMBER,
                Instant.parse("2025-02-04T04:05:06.123456789Z"), null));
        return new Clan(source.id(), source.name(), source.tag(), source.createdAt(),
                source.capacity(), members, source.totalXp(), source.tagline());
    }

    private static Clan simpleClan(int number, String name, String tag, UUID memberId) {
        UUID clanId = new UUID(0, number);
        ClanMember leader = new ClanMember(
                memberId,
                ClanRole.LEADER,
                Instant.parse("2025-02-03T04:05:06.123456789Z"),
                null);
        return new Clan(
                clanId,
                name,
                tag,
                Instant.parse("2025-01-01T00:00:00.987654321Z"),
                10,
                Map.of(memberId, leader),
                number,
                null);
    }

    private static UUID memberId(int number) {
        return new UUID(1, number);
    }

    private static final class FaultInjectingTransactionControl
            implements SqliteTransactionControl {
        private final AtomicReference<Connection> connection = new AtomicReference<>();
        private boolean failCommit;
        private boolean failRollback;

        @Override
        public void begin(Connection connection) throws SQLException {
            this.connection.set(connection);
            SqliteTransactionControl.JDBC.begin(connection);
        }

        @Override
        public void commit(Connection connection) throws SQLException {
            if (failCommit) {
                // This simulates an exception before JDBC COMMIT, not a lost response after commit.
                throw new SQLException("Injected uncertain commit outcome");
            }
            SqliteTransactionControl.JDBC.commit(connection);
        }

        @Override
        public void rollback(Connection connection) throws SQLException {
            SqliteTransactionControl.JDBC.rollback(connection);
            if (failRollback) {
                // The actual rollback succeeded; the injected exception tests fail-closed handling.
                throw new SQLException("Injected rollback failure");
            }
        }
    }
}

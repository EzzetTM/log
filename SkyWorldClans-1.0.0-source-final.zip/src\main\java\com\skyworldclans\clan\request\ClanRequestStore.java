package com.skyworldclans.clan.request;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Persistence contract for invitations and join applications. */
public interface ClanRequestStore {
    CreateStatus createRequest(ClanRequest request);
    List<ClanRequest> listPendingRequestsForPlayer(UUID playerId, ClanRequest.Type type, Instant now);
    List<ClanRequest> listPendingRequests(UUID clanId, ClanRequest.Type type, Instant now);
    ResolveStatus resolveRequest(UUID requestId, UUID actorId, boolean accept, Instant now);
    boolean arePublicApplicationsOpen(UUID clanId);
    SettingStatus setPublicApplicationsOpen(UUID clanId, UUID actorId, boolean open);

    enum SettingStatus { UPDATED, CLAN_NOT_FOUND, NOT_LEADER }

    enum CreateStatus {
        CREATED, CLAN_NOT_FOUND, ACTOR_NOT_AUTHORIZED, PLAYER_ALREADY_IN_CLAN,
        CLAN_FULL, DUPLICATE_PENDING_REQUEST, APPLICATIONS_CLOSED, ELECTION_ACTIVE, INVALID_REQUEST
    }

    enum ResolveStatus {
        ACCEPTED, DECLINED, NOT_FOUND, NOT_PENDING, EXPIRED, NOT_AUTHORIZED,
        PLAYER_ALREADY_IN_CLAN, PLAYER_HAS_PENDING_CREATION, CLAN_FULL, ELECTION_ACTIVE, CONCURRENT_MODIFICATION
    }
}

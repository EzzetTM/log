package com.skyworldclans.clan.application.purchase;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CapacityPurchaseDomainPolicyTest {
    private static final Instant CREATED_AT = Instant.parse("2025-01-01T00:00:00Z");
    private static final Instant UPDATED_AT = Instant.parse("2025-01-01T00:01:00Z");

    @Test
    void operationAcceptsEveryNextCapacityAndRejectsInvalidPayloads() {
        assertOperation(10, 20, 100);
        assertOperation(20, 30, 200);
        assertOperation(30, 40, 300);
        assertOperation(40, 50, 400);

        assertThrows(IllegalArgumentException.class, () -> operation(10, 30, 100));
        assertThrows(IllegalArgumentException.class, () -> operation(50, 50, 500));
        assertThrows(IllegalArgumentException.class, () -> operation(10, 20, 0));
        assertThrows(IllegalArgumentException.class, () -> operation(10, 20, -1));
        assertThrows(IllegalArgumentException.class, () -> operation(10, 20, 101));
        assertThrows(IllegalArgumentException.class, () -> operation(10, 20, Long.MAX_VALUE));
        assertThrows(IllegalArgumentException.class, () -> new CapacityPurchaseOperation(
                UUID.randomUUID(), " ", "business", UUID.randomUUID(), UUID.randomUUID(),
                10, 20, 0, 100, CapacityPurchaseState.PREPARED, null,
                CREATED_AT, UPDATED_AT));
        assertThrows(IllegalArgumentException.class, () -> new CapacityPurchaseOperation(
                UUID.randomUUID(), "request", "business", UUID.randomUUID(), UUID.randomUUID(),
                10, 20, -1, 100, CapacityPurchaseState.PREPARED, null,
                CREATED_AT, UPDATED_AT));
        assertThrows(IllegalArgumentException.class, () -> new CapacityPurchaseOperation(
                UUID.randomUUID(), "request", "business", UUID.randomUUID(), UUID.randomUUID(),
                10, 20, 0, 100, CapacityPurchaseState.PREPARED, null,
                UPDATED_AT, CREATED_AT));
    }

    @Test
    void policyAllowsOnlyEvidenceBoundStateTransitions() {
        Set<String> allowedPairs = new HashSet<>();
        for (AllowedTransition transition : allowedTransitions()) {
            allowedPairs.add(key(transition.from(), transition.to()));
            assertEquals(
                    CapacityPurchaseTransitionPolicy.Result.ALLOWED,
                    CapacityPurchaseTransitionPolicy.evaluate(
                            transition.from(), transition.to(), transition.evidence()),
                    transition.toString());
        }

        for (CapacityPurchaseState from : CapacityPurchaseState.values()) {
            for (CapacityPurchaseState to : CapacityPurchaseState.values()) {
                if (!allowedPairs.contains(key(from, to))) {
                    assertEquals(
                            CapacityPurchaseTransitionPolicy.Result.INVALID_TRANSITION,
                            CapacityPurchaseTransitionPolicy.evaluate(
                                    from, to, CapacityPurchaseTransitionEvidence.NONE),
                            from + " -> " + to);
                }
            }
        }
    }

    @Test
    void policyRequiresCorrectConfirmationAndBlocksUnsafeUnknownTransitions() {
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.EVIDENCE_REQUIRED,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.CALLING,
                        CapacityPurchaseState.DEBIT_CONFIRMED,
                        CapacityPurchaseTransitionEvidence.NONE));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.UNEXPECTED_EVIDENCE,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.CALLING,
                        CapacityPurchaseState.DEBIT_CONFIRMED,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.INVALID_TRANSITION,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.UNKNOWN,
                        CapacityPurchaseState.CALLING,
                        CapacityPurchaseTransitionEvidence.NONE));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.INVALID_TRANSITION,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.UNKNOWN,
                        CapacityPurchaseState.COMPENSATED,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.EVIDENCE_REQUIRED,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMPENSATION_PENDING,
                        CapacityPurchaseState.COMPENSATION_CALLING,
                        CapacityPurchaseTransitionEvidence.NONE));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.INVALID_TRANSITION,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMPENSATION_CALLING,
                        CapacityPurchaseState.COMPENSATION_CALLING,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.INVALID_TRANSITION,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMPENSATION_UNKNOWN,
                        CapacityPurchaseState.COMPENSATION_CALLING,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.UNEXPECTED_EVIDENCE,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMPENSATION_UNKNOWN,
                        CapacityPurchaseState.COMPENSATED,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.ALLOWED,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMPENSATION_UNKNOWN,
                        CapacityPurchaseState.COMPENSATED,
                        CapacityPurchaseTransitionEvidence
                                .RECONCILED_COMPENSATION_SUCCESS_REPORTED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.UNEXPECTED_EVIDENCE,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.UNKNOWN,
                        CapacityPurchaseState.DEBIT_CONFIRMED,
                        CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.UNEXPECTED_EVIDENCE,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMPENSATION_PENDING,
                        CapacityPurchaseState.COMPENSATION_CALLING,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.UNEXPECTED_EVIDENCE,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMPENSATION_CALLING,
                        CapacityPurchaseState.COMPENSATION_FAILED,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED));
        assertEquals(
                CapacityPurchaseTransitionPolicy.Result.INVALID_TRANSITION,
                CapacityPurchaseTransitionPolicy.evaluate(
                        CapacityPurchaseState.COMMITTED,
                        CapacityPurchaseState.CALLING,
                        CapacityPurchaseTransitionEvidence.NONE));
    }

    @Test
    void classifiesRecoveryForEveryPersistedStateWithoutRetryingUnknownCalls() {
        assertRecovery(CapacityPurchaseState.PREPARED,
                CapacityPurchaseRecoveryAction.SAFE_TO_CONTINUE_INTERNAL_PROCESSING);
        assertRecovery(CapacityPurchaseState.DEBIT_CONFIRMED,
                CapacityPurchaseRecoveryAction.SAFE_TO_CONTINUE_INTERNAL_PROCESSING);
        assertRecovery(CapacityPurchaseState.CALLING,
                CapacityPurchaseRecoveryAction.REQUIRES_EXTERNAL_RESULT_RECONCILIATION);
        assertRecovery(CapacityPurchaseState.UNKNOWN,
                CapacityPurchaseRecoveryAction.REQUIRES_MANUAL_OR_SEPARATE_RECOVERY);
        assertRecovery(CapacityPurchaseState.COMPENSATION_PENDING,
                CapacityPurchaseRecoveryAction.SAFE_TO_START_COMPENSATION);
        assertRecovery(CapacityPurchaseState.COMPENSATION_CALLING,
                CapacityPurchaseRecoveryAction.REQUIRES_COMPENSATION_RESULT_RECONCILIATION);
        assertRecovery(CapacityPurchaseState.COMPENSATION_UNKNOWN,
                CapacityPurchaseRecoveryAction.REQUIRES_MANUAL_OR_SEPARATE_RECOVERY);
        assertRecovery(CapacityPurchaseState.COMPENSATION_FAILED,
                CapacityPurchaseRecoveryAction.REQUIRES_MANUAL_OR_SEPARATE_RECOVERY);
        assertRecovery(CapacityPurchaseState.COMMITTED, CapacityPurchaseRecoveryAction.COMPLETED);
        assertRecovery(CapacityPurchaseState.FAILED_NO_EFFECT,
                CapacityPurchaseRecoveryAction.COMPLETED);
        assertRecovery(CapacityPurchaseState.COMPENSATED,
                CapacityPurchaseRecoveryAction.COMPLETED);
    }

    private static void assertOperation(int expected, int target, long amount) {
        CapacityPurchaseOperation operation = operation(expected, target, amount);
        assertEquals(CapacityPurchaseState.PREPARED, operation.state());
        assertEquals(CREATED_AT, operation.createdAt());
        assertEquals(UPDATED_AT, operation.updatedAt());
    }

    private static CapacityPurchaseOperation operation(int expected, int target, long amount) {
        return new CapacityPurchaseOperation(
                UUID.randomUUID(),
                "request-" + expected,
                "business-" + expected,
                UUID.randomUUID(),
                UUID.randomUUID(),
                expected,
                target,
                0,
                amount,
                CapacityPurchaseState.PREPARED,
                null,
                CREATED_AT,
                UPDATED_AT);
    }

    private static void assertRecovery(
            CapacityPurchaseState state,
            CapacityPurchaseRecoveryAction expected) {
        assertEquals(expected, CapacityPurchaseRecoveryPolicy.classify(operationForState(state)));
    }

    private static CapacityPurchaseOperation operationForState(CapacityPurchaseState state) {
        return new CapacityPurchaseOperation(
                UUID.randomUUID(), "request", "business", UUID.randomUUID(), UUID.randomUUID(),
                10, 20, 0, 100, state, null, CREATED_AT, UPDATED_AT);
    }

    private static String key(CapacityPurchaseState from, CapacityPurchaseState to) {
        return from.name() + "->" + to.name();
    }

    private static AllowedTransition[] allowedTransitions() {
        return new AllowedTransition[] {
            new AllowedTransition(CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING, CapacityPurchaseTransitionEvidence.NONE),
            new AllowedTransition(CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.FAILED_NO_EFFECT,
                    CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED),
            new AllowedTransition(CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED),
            new AllowedTransition(CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.FAILED_NO_EFFECT,
                    CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED),
            new AllowedTransition(CapacityPurchaseState.CALLING,
                    CapacityPurchaseState.UNKNOWN,
                    CapacityPurchaseTransitionEvidence.DEBIT_RESULT_UNKNOWN_REPORTED),
            new AllowedTransition(CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseState.COMMITTED,
                    CapacityPurchaseTransitionEvidence.ATOMIC_CAPACITY_COMMIT),
            new AllowedTransition(CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseState.COMPENSATION_PENDING,
            CapacityPurchaseTransitionEvidence.COMPENSATION_REQUIRED_REPORTED),
            new AllowedTransition(CapacityPurchaseState.UNKNOWN,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
            CapacityPurchaseTransitionEvidence.RECONCILED_DEBIT_SUCCESS_REPORTED),
            new AllowedTransition(CapacityPurchaseState.UNKNOWN,
                    CapacityPurchaseState.FAILED_NO_EFFECT,
            CapacityPurchaseTransitionEvidence.RECONCILED_DEBIT_NO_EFFECT_REPORTED),
            new AllowedTransition(CapacityPurchaseState.COMPENSATION_PENDING,
            CapacityPurchaseState.COMPENSATION_CALLING,
            CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED),
            new AllowedTransition(CapacityPurchaseState.COMPENSATION_CALLING,
            CapacityPurchaseState.COMPENSATED,
            CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED),
            new AllowedTransition(CapacityPurchaseState.COMPENSATION_CALLING,
            CapacityPurchaseState.COMPENSATION_FAILED,
            CapacityPurchaseTransitionEvidence.COMPENSATION_NO_EFFECT_REPORTED),
            new AllowedTransition(CapacityPurchaseState.COMPENSATION_CALLING,
            CapacityPurchaseState.COMPENSATION_UNKNOWN,
            CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED),
            new AllowedTransition(CapacityPurchaseState.COMPENSATION_UNKNOWN,
            CapacityPurchaseState.COMPENSATED,
            CapacityPurchaseTransitionEvidence
                    .RECONCILED_COMPENSATION_SUCCESS_REPORTED),
            new AllowedTransition(CapacityPurchaseState.COMPENSATION_UNKNOWN,
            CapacityPurchaseState.COMPENSATION_FAILED,
            CapacityPurchaseTransitionEvidence
                    .RECONCILED_COMPENSATION_NO_EFFECT_REPORTED)
        };
    }

    private record AllowedTransition(
            CapacityPurchaseState from,
            CapacityPurchaseState to,
            CapacityPurchaseTransitionEvidence evidence) {
    }
}

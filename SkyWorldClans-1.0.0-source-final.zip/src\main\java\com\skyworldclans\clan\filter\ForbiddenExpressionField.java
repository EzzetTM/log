package com.skyworldclans.clan.filter;

public enum ForbiddenExpressionField {
    NAME,
    TAG,
    SLOGAN
}

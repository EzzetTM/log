package com.skyworldclans.clan.application;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.filter.ForbiddenExpressionField;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.service.ClanRegistrationResult;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class CreateClanResult {
    private final Status status;
    private final Optional<ForbiddenExpressionField> forbiddenField;
    private final Optional<ClanRegistrationResult.Status> registrationStatus;
    private final List<ClanMembershipStateValidator.Violation> validationViolations;
    private final Optional<Clan> clan;

    public CreateClanResult(
            Status status,
            Optional<ForbiddenExpressionField> forbiddenField,
            Optional<ClanRegistrationResult.Status> registrationStatus,
            Optional<Clan> clan) {
        this(status, forbiddenField, registrationStatus, List.of(), clan, false);
    }

    public CreateClanResult(
            Status status,
            Optional<ForbiddenExpressionField> forbiddenField,
            Optional<ClanRegistrationResult.Status> registrationStatus,
            List<ClanMembershipStateValidator.Violation> validationViolations,
            Optional<Clan> clan) {
        this(status, forbiddenField, registrationStatus, validationViolations, clan, true);
    }

    private CreateClanResult(
            Status status,
            Optional<ForbiddenExpressionField> forbiddenField,
            Optional<ClanRegistrationResult.Status> registrationStatus,
            List<ClanMembershipStateValidator.Violation> validationViolations,
            Optional<Clan> clan,
            boolean requireMembershipViolations) {
        this.status = Objects.requireNonNull(status, "status");
        this.forbiddenField = Objects.requireNonNull(forbiddenField, "forbiddenField");
        this.registrationStatus = Objects.requireNonNull(registrationStatus, "registrationStatus");
        this.validationViolations = List.copyOf(validationViolations);
        this.clan = Objects.requireNonNull(clan, "clan");
        if ((status == Status.FORBIDDEN_EXPRESSION) != forbiddenField.isPresent()) {
            throw new IllegalArgumentException(
                    "A forbidden field is only valid for a forbidden-expression result");
        }
        if ((status == Status.REGISTRATION_FAILED) != registrationStatus.isPresent()) {
            throw new IllegalArgumentException(
                    "A registration status is only valid for a registration failure");
        }
        if ((status == Status.CREATED) != clan.isPresent()) {
            throw new IllegalArgumentException("Only a created result may contain a clan");
        }
        boolean invalidMembership = registrationStatus
                .filter(value -> value == ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE)
                .isPresent();
        if (!this.validationViolations.isEmpty() && !invalidMembership) {
            throw new IllegalArgumentException(
                    "Membership violations are only valid for an invalid membership registration");
        }
        if (requireMembershipViolations
                && invalidMembership != !this.validationViolations.isEmpty()) {
            throw new IllegalArgumentException(
                    "Invalid membership registration must include its validation violations");
        }
    }

    public Status status() {
        return status;
    }

    public Optional<ForbiddenExpressionField> forbiddenField() {
        return forbiddenField;
    }

    public Optional<ClanRegistrationResult.Status> registrationStatus() {
        return registrationStatus;
    }

    public List<ClanMembershipStateValidator.Violation> validationViolations() {
        return validationViolations;
    }

    public Optional<Clan> clan() {
        return clan;
    }

    public boolean created() {
        return status == Status.CREATED;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CreateClanResult that)) {
            return false;
        }
        return status == that.status
                && forbiddenField.equals(that.forbiddenField)
                && registrationStatus.equals(that.registrationStatus)
                && validationViolations.equals(that.validationViolations)
                && clan.equals(that.clan);
    }

    @Override
    public int hashCode() {
        return Objects.hash(status, forbiddenField, registrationStatus, validationViolations, clan);
    }

    @Override
    public String toString() {
        return "CreateClanResult[status=" + status
                + ", forbiddenField=" + forbiddenField
                + ", registrationStatus=" + registrationStatus
                + ", validationViolations=" + validationViolations
                + ", clan=" + clan + "]";
    }

    public enum Status {
        CREATED,
        INVALID_INPUT,
        INVALID_NAME_FORMAT,
        INVALID_TAG_FORMAT,
        FILTER_UNAVAILABLE,
        FORBIDDEN_EXPRESSION,
        CREATOR_ALREADY_IN_CLAN,
        TAG_TAKEN,
        REGISTRATION_FAILED
    }
}

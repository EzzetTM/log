package com.skyworldclans.clan.membership;

import org.junit.jupiter.api.Test;

import java.util.EnumSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class ClanPermissionPolicyTest {
    private final ClanPermissionPolicy policy = new ClanPermissionPolicy();

    @Test
    void checksEveryPermissionForLeader() {
        assertPermissions(ClanRole.LEADER, EnumSet.complementOf(
                EnumSet.of(ClanPermission.BANK_REQUEST_WITHDRAWAL)));
    }

    @Test
    void checksEveryPermissionForDeputy() {
        assertPermissions(ClanRole.DEPUTY, EnumSet.of(
                ClanPermission.BANK_DEPOSIT,
                ClanPermission.BANK_REQUEST_WITHDRAWAL,
                ClanPermission.BANK_PERSONAL_PAYOUT,
                ClanPermission.BANK_CLAN_REWARD,
                ClanPermission.HOME_SET_OR_RENAME,
                ClanPermission.HOME_DELETE,
                ClanPermission.HOME_TELEPORT,
                ClanPermission.STORAGE_USE,
                ClanPermission.CHAT_MUTE,
                ClanPermission.CHAT_VIEW_ACTIVE_MUTES,
                ClanPermission.CHAT_UNMUTE,
                ClanPermission.WARNING_DELETE,
                ClanPermission.TASK_CONTRIBUTE,
                ClanPermission.TOURNAMENT_REGISTER,
                ClanPermission.MEMBER_REMOVE));
    }

    @Test
    void checksEveryPermissionForModerator() {
        assertPermissions(ClanRole.MODERATOR, EnumSet.of(
                ClanPermission.BANK_DEPOSIT,
                ClanPermission.HOME_TELEPORT,
                ClanPermission.STORAGE_USE,
                ClanPermission.CHAT_MUTE,
                ClanPermission.CHAT_VIEW_ACTIVE_MUTES,
                ClanPermission.TASK_CONTRIBUTE));
    }

    @Test
    void checksEveryPermissionForMember() {
        assertPermissions(ClanRole.MEMBER, EnumSet.of(
                ClanPermission.BANK_DEPOSIT,
                ClanPermission.HOME_TELEPORT,
                ClanPermission.STORAGE_USE,
                ClanPermission.TASK_CONTRIBUTE));
    }

    @Test
    void deniesEveryPermissionWhenRoleIsNull() {
        for (ClanPermission permission : ClanPermission.values()) {
            assertFalse(policy.hasPermission(null, permission), "permission: " + permission);
        }
    }

    @Test
    void deniesNullPermissionForEveryRole() {
        for (ClanRole role : ClanRole.values()) {
            assertFalse(policy.hasPermission(role, null), "role: " + role);
        }
    }

    private void assertPermissions(ClanRole role, Set<ClanPermission> allowedPermissions) {
        for (ClanPermission permission : ClanPermission.values()) {
            assertEquals(
                    allowedPermissions.contains(permission),
                    policy.hasPermission(role, permission),
                    () -> role + " permission " + permission);
        }
    }
}

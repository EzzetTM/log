package com.skyworldclans.clan.policy;

import java.util.OptionalInt;

public final class ClanCapacityPolicy {
    private static final int INITIAL_CAPACITY = 10;
    private static final int MAX_CAPACITY = 50;

    private ClanCapacityPolicy() {
    }

    public static int initialCapacity() {
        return INITIAL_CAPACITY;
    }

    public static boolean isValidCapacity(int capacity) {
        return switch (capacity) {
            case INITIAL_CAPACITY, 20, 30, 40, MAX_CAPACITY -> true;
            default -> false;
        };
    }

    public static boolean hasAvailableSpace(int capacity, int memberCount) {
        return isValidCapacity(capacity) && memberCount >= 0 && memberCount < capacity;
    }

    public static boolean isFull(int capacity, int memberCount) {
        return isValidCapacity(capacity) && memberCount >= 0 && memberCount >= capacity;
    }

    public static OptionalInt nextCapacity(int currentCapacity) {
        return switch (currentCapacity) {
            case 10 -> OptionalInt.of(20);
            case 20 -> OptionalInt.of(30);
            case 30 -> OptionalInt.of(40);
            case 40 -> OptionalInt.of(50);
            default -> OptionalInt.empty();
        };
    }

    public static boolean canExpandTo(int currentCapacity, int requestedCapacity) {
        OptionalInt next = nextCapacity(currentCapacity);
        return next.isPresent() && next.getAsInt() == requestedCapacity;
    }

    public static OptionalInt nextExpansionCost(int currentCapacity) {
        return switch (currentCapacity) {
            case 10 -> OptionalInt.of(100);
            case 20 -> OptionalInt.of(200);
            case 30 -> OptionalInt.of(300);
            case 40 -> OptionalInt.of(400);
            default -> OptionalInt.empty();
        };
    }
}

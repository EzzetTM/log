package com.skyworldclans.clan.reward;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

/** Pure reward authorization rules from the clan specification. This class never moves money. */
public final class ClanRewardPolicy {
    public static final BigDecimal DEPUTY_ORDINARY_MAXIMUM = new BigDecimal("100000");
    public static final BigDecimal LARGE_REWARD_MAXIMUM = new BigDecimal("1000000");
    public static final int DEPUTY_ORDINARY_DAILY_LIMIT = 3;
    public static final Duration BANK_REWARD_MEMBERSHIP_AGE = Duration.ofDays(7);

    public Decision personalPayout(Clan clan, UUID issuerId, UUID recipientId, BigDecimal amount) {
        if (!validAmount(amount)) return Decision.INVALID_AMOUNT;
        if (recipientId == null) return Decision.INVALID_RECIPIENT;
        if (!canIssue(clan, issuerId)) return Decision.ISSUER_NOT_AUTHORIZED;
        // Personal payouts intentionally have no recipient-tenure, amount or count restriction.
        return Decision.ALLOWED;
    }

    public Decision ordinaryBankReward(Clan clan, UUID issuerId, UUID recipientId, BigDecimal amount,
            int issuerOrdinaryPayoutsToday, Instant now) {
        if (!validAmount(amount)) return Decision.INVALID_AMOUNT;
        if (now == null) return Decision.INVALID_TIME;
        if (!canIssue(clan, issuerId)) return Decision.ISSUER_NOT_AUTHORIZED;
        ClanMember recipient = clan.member(recipientId).orElse(null);
        if (recipient == null) return Decision.RECIPIENT_NOT_MEMBER;
        if (recipient.membershipStartedAt().plus(BANK_REWARD_MEMBERSHIP_AGE).isAfter(now))
            return Decision.RECIPIENT_MEMBERSHIP_TOO_NEW;
        ClanRole issuerRole = clan.member(issuerId).orElseThrow().role();
        if (issuerRole == ClanRole.DEPUTY) {
            if (amount.compareTo(DEPUTY_ORDINARY_MAXIMUM) > 0) return Decision.DEPUTY_AMOUNT_LIMIT;
            if (issuerOrdinaryPayoutsToday < 0) return Decision.INVALID_DAILY_COUNT;
            if (issuerOrdinaryPayoutsToday >= DEPUTY_ORDINARY_DAILY_LIMIT) return Decision.DEPUTY_DAILY_LIMIT;
        }
        // The specification explicitly exempts the leader from deputy limits.
        return Decision.ALLOWED;
    }

    /**
     * A deputy's large-reward request is deliberately blocked until the owner decides when the
     * weekly quota is consumed (submission or approval). The 7-day recipient rule is still checked.
     */
    public Decision largeBankRewardRequest(Clan clan, UUID deputyId, UUID recipientId,
            BigDecimal amount, Instant now) {
        if (!validAmount(amount)) return Decision.INVALID_AMOUNT;
        if (now == null) return Decision.INVALID_TIME;
        if (clan == null || deputyId == null || clan.member(deputyId).map(ClanMember::role).orElse(null) != ClanRole.DEPUTY)
            return Decision.ISSUER_NOT_AUTHORIZED;
        if (amount.compareTo(DEPUTY_ORDINARY_MAXIMUM) <= 0 || amount.compareTo(LARGE_REWARD_MAXIMUM) > 0)
            return Decision.INVALID_LARGE_REWARD_AMOUNT;
        ClanMember recipient = clan.member(recipientId).orElse(null);
        if (recipient == null) return Decision.RECIPIENT_NOT_MEMBER;
        if (recipient.membershipStartedAt().plus(BANK_REWARD_MEMBERSHIP_AGE).isAfter(now))
            return Decision.RECIPIENT_MEMBERSHIP_TOO_NEW;
        return Decision.WEEKLY_QUOTA_POLICY_UNRESOLVED;
    }

    private static boolean canIssue(Clan clan, UUID issuerId) {
        if (clan == null || issuerId == null) return false;
        ClanRole role = clan.member(issuerId).map(ClanMember::role).orElse(null);
        return role == ClanRole.LEADER || role == ClanRole.DEPUTY;
    }

    private static boolean validAmount(BigDecimal amount) {
        if (amount == null || amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 8) return false;
        double value = amount.doubleValue();
        return Double.isFinite(value) && value > 0.0D
                && BigDecimal.valueOf(value).compareTo(amount.stripTrailingZeros()) == 0;
    }

    public enum Decision {
        ALLOWED, INVALID_AMOUNT, INVALID_TIME, INVALID_RECIPIENT, INVALID_DAILY_COUNT,
        ISSUER_NOT_AUTHORIZED, RECIPIENT_NOT_MEMBER, RECIPIENT_MEMBERSHIP_TOO_NEW,
        DEPUTY_AMOUNT_LIMIT, DEPUTY_DAILY_LIMIT, INVALID_LARGE_REWARD_AMOUNT,
        WEEKLY_QUOTA_POLICY_UNRESOLVED
    }
}

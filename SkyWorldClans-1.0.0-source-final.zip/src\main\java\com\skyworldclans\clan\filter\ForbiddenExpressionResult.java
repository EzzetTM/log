package com.skyworldclans.clan.filter;

import java.util.Objects;
import java.util.Optional;

public record ForbiddenExpressionResult(
        ForbiddenExpressionStatus status,
        Optional<ForbiddenExpressionField> field) {

    public ForbiddenExpressionResult {
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(field, "field");
    }

    public boolean allowed() {
        return status == ForbiddenExpressionStatus.ALLOWED;
    }
}

package com.skyworldclans.clan.application.purchase;

/**
 * A typed assertion from the caller, not proof from an economy provider.
 * The integration layer must establish the truth of any reported external result.
 */
public enum CapacityPurchaseTransitionEvidence {
    NONE,
    DEBIT_NO_EFFECT_REPORTED,
    DEBIT_RESULT_UNKNOWN_REPORTED,
    DEBIT_SUCCESS_REPORTED,
    RECONCILED_DEBIT_NO_EFFECT_REPORTED,
    RECONCILED_DEBIT_SUCCESS_REPORTED,
    ATOMIC_CAPACITY_COMMIT,
    COMPENSATION_REQUIRED_REPORTED,
    COMPENSATION_CALL_INTENT_RECORDED,
    COMPENSATION_SUCCESS_REPORTED,
    COMPENSATION_NO_EFFECT_REPORTED,
    COMPENSATION_RESULT_UNKNOWN_REPORTED,
    RECONCILED_COMPENSATION_SUCCESS_REPORTED,
    RECONCILED_COMPENSATION_NO_EFFECT_REPORTED
}

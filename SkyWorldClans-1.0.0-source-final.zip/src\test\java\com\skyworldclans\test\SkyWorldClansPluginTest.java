package com.skyworldclans.test;

import com.skyworldclans.SkyWorldClansPlugin;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class SkyWorldClansPluginTest {

    @Test
    void pluginDescriptorHasRequiredMetadata() {
        YamlConfiguration descriptor = loadPluginDescriptor();

        assertFalse(descriptor.getString("name", "").isBlank());
        assertFalse(descriptor.getString("version", "").isBlank());
        assertFalse(descriptor.getString("api-version", "").isBlank());
    }

    @Test
    void pluginDescriptorMainIdentifiesPluginClass() {
        YamlConfiguration descriptor = loadPluginDescriptor();

        assertEquals(SkyWorldClansPlugin.class.getName(), descriptor.getString("main"));
        assertTrue(JavaPlugin.class.isAssignableFrom(SkyWorldClansPlugin.class));
    }

    private YamlConfiguration loadPluginDescriptor() {
        InputStream input = Objects.requireNonNull(
                getClass().getClassLoader().getResourceAsStream("plugin.yml"),
                "plugin.yml must be available on the test classpath");
        try (Reader reader = new InputStreamReader(input, StandardCharsets.UTF_8)) {
            return YamlConfiguration.loadConfiguration(reader);
        } catch (java.io.IOException exception) {
            throw new AssertionError("Could not read plugin.yml", exception);
        }
    }
}
package com.skyworldclans.clan.application;

import java.util.UUID;

public record CreateClanCommand(
        UUID creatorId,
        String name,
        String tag,
        String slogan) {
}

package com.skyworldclans.clan.membership;

import com.skyworldclans.clan.policy.ClanCapacityPolicy;

public final class ClanMembershipPolicy {
    private static final int MAX_DEPUTIES = 4;
    private static final int MAX_MODERATORS_PER_DEPUTY = 2;
    private static final int MAX_MODERATORS_APPOINTED_BY_DEPUTIES = 8;

    private ClanMembershipPolicy() {
    }

    public static boolean canJoin(boolean alreadyInAnotherClan, int memberCount, int capacity) {
        return !alreadyInAnotherClan
                && ClanCapacityPolicy.hasAvailableSpace(capacity, memberCount);
    }

    public static boolean canInvite(ClanRole actorRole) {
        return actorRole == ClanRole.LEADER || actorRole == ClanRole.DEPUTY;
    }

    public static boolean canReviewApplication(ClanRole actorRole) {
        return actorRole == ClanRole.LEADER || actorRole == ClanRole.DEPUTY;
    }

    public static boolean canAssignDeputy(ClanRole actorRole, int currentDeputyCount) {
        return actorRole == ClanRole.LEADER
                && currentDeputyCount >= 0
                && currentDeputyCount < MAX_DEPUTIES;
    }

    public static boolean isValidDeputyCount(int deputyCount) {
        return deputyCount >= 0 && deputyCount <= MAX_DEPUTIES;
    }

    public static boolean isValidDeputyAssignedModeratorCount(int moderatorCount) {
        return moderatorCount >= 0 && moderatorCount <= MAX_MODERATORS_PER_DEPUTY;
    }

    public static boolean isValidTotalDeputyAssignedModeratorCount(int moderatorCount) {
        return moderatorCount >= 0
                && moderatorCount <= MAX_MODERATORS_APPOINTED_BY_DEPUTIES;
    }

    public static boolean canAssignModerator(
            ClanRole actorRole,
            int moderatorsAppointedByThisDeputy,
            int moderatorsAppointedByAllDeputies) {
        if (moderatorsAppointedByThisDeputy < 0 || moderatorsAppointedByAllDeputies < 0) {
            return false;
        }
        if (actorRole == ClanRole.LEADER) {
            return true;
        }
        if (actorRole != ClanRole.DEPUTY) {
            return false;
        }
        return moderatorsAppointedByThisDeputy < MAX_MODERATORS_PER_DEPUTY
                && moderatorsAppointedByAllDeputies < MAX_MODERATORS_APPOINTED_BY_DEPUTIES;
    }
}

package com.skyworldclans.combat;

import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Instant;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.Set;
import java.util.UUID;

/** Global server-wide 30-second PvP combat tag. */
public final class CombatLogService {
    public static final long TAG_DURATION_SECONDS = 30L;
    private final SqliteClanStore store;
    private final ConcurrentMap<UUID, Instant> volatileFallback = new ConcurrentHashMap<>();
    private final Set<UUID> recentlyDied = ConcurrentHashMap.newKeySet();
    private final Set<UUID> logoutViolations = ConcurrentHashMap.newKeySet();

    public CombatLogService(SqliteClanStore store) {
        this.store = Objects.requireNonNull(store, "store");
    }

    public void recordPvpDamage(UUID attackerId, UUID victimId, Instant occurredAt) {
        if (attackerId == null || victimId == null || attackerId.equals(victimId) || occurredAt == null) return;
        Instant expiresAt = occurredAt.plusSeconds(TAG_DURATION_SECONDS);
        recentlyDied.remove(attackerId);
        recentlyDied.remove(victimId);
        volatileFallback.merge(attackerId, expiresAt, (oldValue, newValue) -> oldValue.isAfter(newValue) ? oldValue : newValue);
        volatileFallback.merge(victimId, expiresAt, (oldValue, newValue) -> oldValue.isAfter(newValue) ? oldValue : newValue);
        store.recordCombatLogDamage(attackerId, victimId, occurredAt);
    }

    /** Marks an active logout as a violation and returns whether the Bukkit player must die. */
    public boolean onQuit(UUID playerId, Instant occurredAt) {
        if (playerId == null || occurredAt == null) return false;
        if (recentlyDied.remove(playerId)) {
            volatileFallback.remove(playerId);
            store.clearCombatLogOnDeath(playerId, occurredAt);
            return false;
        }
        boolean persistedViolation = false;
        try {
            persistedViolation = store.markCombatLogQuit(playerId, occurredAt);
        } catch (RuntimeException storageFailure) {
            // Keep the in-memory fallback authoritative for this process if SQLite is temporarily unavailable.
        }
        Instant fallbackExpiry = volatileFallback.remove(playerId);
        boolean violation = persistedViolation || fallbackExpiry != null && fallbackExpiry.isAfter(occurredAt);
        if (violation) logoutViolations.add(playerId);
        return violation;
    }

    public void onRespawn(UUID playerId) {
        if (playerId != null) {
            recentlyDied.remove(playerId);
            logoutViolations.remove(playerId);
        }
    }

    public boolean onDeath(UUID playerId, Instant occurredAt) {
        if (playerId == null) return false;
        volatileFallback.remove(playerId);
        recentlyDied.add(playerId);
        return store.clearCombatLogOnDeath(playerId, occurredAt);
    }

    public int expireDue(Instant now) {
        try { return store.expireDueCombatLogSessions(now); }
        finally {
            if (now != null) volatileFallback.entrySet().removeIf(entry -> !entry.getValue().isAfter(now));
        }
    }

    /** Converts process-interrupted active tags to review-only; never a logout violation. */
    public int recoverAfterRestart(Instant now) {
        volatileFallback.clear();
        recentlyDied.clear();
        logoutViolations.clear();
        return store.recoverCombatLogAfterRestart(now);
    }

    public boolean isLogoutViolation(UUID playerId) {
        return playerId != null && logoutViolations.contains(playerId);
    }

    public boolean needsRestartReview(UUID playerId) {
        return store.findCombatLogSession(playerId)
                .map(session -> session.status() == SqliteClanStore.CombatLogSessionStatus.INTERRUPTED_REVIEW)
                .orElse(false);
    }
}

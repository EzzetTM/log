package com.skyworldclans.combat;

import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.time.Clock;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Bukkit adapter for the persistent, global combat tag service. */
public final class CombatLogListener implements Listener {
    private final CombatLogService service;
    private final Clock clock;
    private final Logger logger;

    public CombatLogListener(CombatLogService service, Clock clock, Logger logger) {
        this.service = java.util.Objects.requireNonNull(service, "service");
        this.clock = java.util.Objects.requireNonNull(clock, "clock");
        this.logger = java.util.Objects.requireNonNull(logger, "logger");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim) || event.getFinalDamage() <= 0.0D) return;
        Player attacker = null;
        if (event.getDamager() instanceof Player directPlayer) {
            attacker = directPlayer;
        } else if (event.getDamager() instanceof Projectile projectile
                && projectile.getShooter() instanceof Player projectilePlayer) {
            attacker = projectilePlayer;
        }
        if (attacker == null || attacker.getUniqueId().equals(victim.getUniqueId())) return;
        try {
            service.recordPvpDamage(attacker.getUniqueId(), victim.getUniqueId(), clock.instant());
        } catch (RuntimeException exception) {
            logger.log(Level.SEVERE, "Could not persist combat log tag for PvP damage; volatile fallback remains active.", exception);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        try {
            if (service.onQuit(player.getUniqueId(), clock.instant())) {
                logger.warning("CombatLog logout violation: player=" + player.getUniqueId()
                        + "; player is killed for quitting during active PvP combat.");
                player.setHealth(0.0D);
            }
        } catch (RuntimeException exception) {
            logger.log(Level.SEVERE, "Could not apply combat log logout handling for " + player.getUniqueId(), exception);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCombatLogResurrection(EntityResurrectEvent event) {
        if (event.getEntity() instanceof Player player && service.isLogoutViolation(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        try { service.onDeath(event.getEntity().getUniqueId(), clock.instant()); }
        catch (RuntimeException exception) {
            logger.log(Level.SEVERE, "Could not clear combat log after player death.", exception);
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        service.onRespawn(event.getPlayer().getUniqueId());
    }
}

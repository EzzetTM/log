package com.skyworldclans.clan.bank;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.integration.EconomyOperations;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Coordinates durable SQLite intent writes with main-thread Vault calls. The persistence executor
 * must be a single ordered worker; provider methods are invoked only through the supplied
 * main-thread dispatcher. Ambiguous provider results are never retried automatically.
 */
public final class ClanBankTransferCoordinator {
    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final EconomyOperations economy;
    private final Executor persistenceExecutor;
    private final MainThreadDispatcher mainThread;
    private final Clock clock;
    private final Supplier<UUID> ids;

    public ClanBankTransferCoordinator(ClanCatalog clans, SqliteClanStore store,
            EconomyOperations economy, Executor persistenceExecutor, MainThreadDispatcher mainThread,
            Clock clock, Supplier<UUID> ids) {
        this.clans = Objects.requireNonNull(clans, "clans");
        this.store = Objects.requireNonNull(store, "store");
        this.economy = economy;
        this.persistenceExecutor = Objects.requireNonNull(persistenceExecutor, "persistenceExecutor");
        this.mainThread = Objects.requireNonNull(mainThread, "mainThread");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.ids = Objects.requireNonNull(ids, "ids");
    }

    public void deposit(UUID clanId, UUID playerId, BigDecimal amount, Consumer<Result> completion) {
        if (!authorizedMember(clanId, playerId)) {
            complete(completion, new Result(Status.NOT_AUTHORIZED, null));
            return;
        }
        UUID operationId = ids.get();
        start(clanId, playerId, playerId, null, "DEPOSIT", amount,
                operationId, operationId, "clan-bank-deposit:" + operationId, completion);
    }

    public void leaderWithdraw(UUID clanId, UUID leaderId, BigDecimal amount, Consumer<Result> completion) {
        if (!hasRole(clanId, leaderId, ClanRole.LEADER)) {
            complete(completion, new Result(Status.NOT_AUTHORIZED, null));
            return;
        }
        UUID operationId = ids.get();
        start(clanId, leaderId, leaderId, null, "LEADER_WITHDRAWAL", amount,
                operationId, operationId, "clan-bank-leader-withdrawal:" + operationId, completion);
    }

    public void payApprovedDeputyRequest(UUID clanId, UUID leaderId, UUID requestId, Consumer<Result> completion) {
        if (!hasRole(clanId, leaderId, ClanRole.LEADER)) {
            complete(completion, new Result(Status.NOT_AUTHORIZED, null));
            return;
        }
        SqliteClanStore.ClanBankWithdrawalRequest request = store.findClanBankWithdrawalRequests(clanId, false)
                .stream().filter(value -> value.requestId().equals(requestId)).findFirst().orElse(null);
        if (request == null || request.status() != SqliteClanStore.ClanBankWithdrawalRequestStatus.APPROVED) {
            complete(completion, new Result(Status.REQUEST_NOT_APPROVED, null));
            return;
        }
        UUID operationId = ids.get();
        UUID businessId = UUID.nameUUIDFromBytes(("SkyWorldClans:bank-withdrawal:" + requestId)
                .getBytes(StandardCharsets.UTF_8));
        start(clanId, leaderId, request.beneficiaryId(), requestId, "WITHDRAWAL", request.amount(),
                operationId, businessId, "clan-bank-request:" + requestId + ":" + operationId, completion);
    }

    private void start(UUID clanId, UUID actorId, UUID beneficiaryId, UUID requestId, String operationType,
            BigDecimal amount, UUID operationId, UUID businessId, String idempotencyKey,
            Consumer<Result> completion) {
        if (economy == null) {
            complete(completion, new Result(Status.ECONOMY_UNAVAILABLE, null));
            return;
        }
        if (amount == null || amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 8
                || !Double.isFinite(amount.doubleValue()) || amount.doubleValue() <= 0.0
                || BigDecimal.valueOf(amount.doubleValue()).compareTo(amount.stripTrailingZeros()) != 0) {
            complete(completion, new Result(Status.INVALID_AMOUNT, null));
            return;
        }
        try {
            persistenceExecutor.execute(() -> prepareAndMarkCalling(clanId, actorId, beneficiaryId, requestId,
                    operationType, amount, operationId, businessId, idempotencyKey, completion));
        } catch (RuntimeException exception) {
            complete(completion, new Result(Status.STORAGE_ERROR, null));
        }
    }

    private void prepareAndMarkCalling(UUID clanId, UUID actorId, UUID beneficiaryId, UUID requestId,
            String operationType, BigDecimal amount, UUID operationId, UUID businessId, String idempotencyKey,
            Consumer<Result> completion) {
        try {
            var prepared = store.prepareClanBankOperation(operationId, idempotencyKey, businessId,
                    clanId, actorId, beneficiaryId, requestId, operationType, amount, clock.instant());
            if (prepared.status() == SqliteClanStore.ClanBankOperationStatus.DUPLICATE) {
                if (prepared.operation().state() == SqliteClanStore.ClanBankOperationState.EXTERNAL_CONFIRMED) {
                    var committed = store.commitConfirmedClanBankOperation(prepared.operation().operationId(), clock.instant());
                    complete(completion, new Result(committed.status() == SqliteClanStore.ClanBankOperationStatus.COMMITTED
                            ? Status.SUCCESS : Status.LOCAL_COMMIT_PENDING, committed.operation()));
                    return;
                }
                Status duplicateStatus = switch (prepared.operation().state()) {
                    case COMMITTED -> Status.ALREADY_COMPLETED;
                    case UNKNOWN -> Status.MANUAL_RECONCILIATION_REQUIRED;
                    case PREPARED, CALLING, FAILED_NO_EFFECT, EXTERNAL_CONFIRMED -> Status.OPERATION_ALREADY_EXISTS;
                };
                complete(completion, new Result(duplicateStatus, prepared.operation()));
                return;
            }
            if (prepared.status() != SqliteClanStore.ClanBankOperationStatus.PREPARED) {
                if (prepared.status() == SqliteClanStore.ClanBankOperationStatus.ACTOR_OPERATION_IN_PROGRESS
                        && prepared.operation() != null
                        && prepared.operation().state() == SqliteClanStore.ClanBankOperationState.EXTERNAL_CONFIRMED) {
                    var committed = store.commitConfirmedClanBankOperation(prepared.operation().operationId(), clock.instant());
                    complete(completion, new Result(committed.status() == SqliteClanStore.ClanBankOperationStatus.COMMITTED
                            ? Status.SUCCESS : Status.LOCAL_COMMIT_PENDING, committed.operation()));
                    return;
                }
                Status status = prepared.status() == SqliteClanStore.ClanBankOperationStatus.ACTOR_OPERATION_IN_PROGRESS
                        && prepared.operation() != null
                        && prepared.operation().state() == SqliteClanStore.ClanBankOperationState.UNKNOWN
                        ? Status.MANUAL_RECONCILIATION_REQUIRED : mapPrepareStatus(prepared.status());
                complete(completion, new Result(status, prepared.operation()));
                return;
            }
            var calling = store.transitionClanBankOperation(operationId,
                    SqliteClanStore.ClanBankOperationState.PREPARED,
                    SqliteClanStore.ClanBankOperationState.CALLING,
                    "CALL_INTENT_DURABLY_RECORDED", clock.instant());
            if (calling.status() != SqliteClanStore.ClanBankOperationStatus.UPDATED) {
                complete(completion, new Result(Status.STORAGE_ERROR, calling.operation()));
                return;
            }
            try {
                mainThread.execute(() -> invokeProvider(calling.operation(), completion));
            } catch (RuntimeException dispatchFailure) {
                store.transitionClanBankOperation(operationId, SqliteClanStore.ClanBankOperationState.CALLING,
                        SqliteClanStore.ClanBankOperationState.FAILED_NO_EFFECT,
                        "MAIN_THREAD_DISPATCH_FAILED_BEFORE_PROVIDER_CALL", clock.instant());
                complete(completion, new Result(Status.PROVIDER_NOT_CALLED, calling.operation()));
            }
        } catch (RuntimeException exception) {
            complete(completion, new Result(Status.STORAGE_ERROR, null));
        }
    }

    private void invokeProvider(SqliteClanStore.ClanBankOperation operation, Consumer<Result> completion) {
        EconomyOperations.OperationResult external;
        try {
            external = operation.operationType().equals("DEPOSIT")
                    ? economy.withdraw(operation.actorId(), operation.amount().doubleValue())
                    : economy.deposit(operation.beneficiaryId(), operation.amount().doubleValue());
            if (external == null) external = new EconomyOperations.OperationResult(
                    EconomyOperations.Status.UNKNOWN, "Provider returned no result");
        } catch (RuntimeException exception) {
            external = new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN,
                    exception.getClass().getSimpleName());
        }
        EconomyOperations.OperationResult finalExternal = external;
        try {
            persistenceExecutor.execute(() -> finishProviderCall(operation, finalExternal, completion));
        } catch (RuntimeException exception) {
            // CALLING remains durable. Startup recovery will convert it to UNKNOWN and prohibit retry.
            complete(completion, new Result(Status.MANUAL_RECONCILIATION_REQUIRED, operation));
        }
    }

    private void finishProviderCall(SqliteClanStore.ClanBankOperation operation,
            EconomyOperations.OperationResult external, Consumer<Result> completion) {
        try {
            if (external.status() == EconomyOperations.Status.SUCCESS) {
                var confirmed = store.transitionClanBankOperation(operation.operationId(),
                        SqliteClanStore.ClanBankOperationState.CALLING,
                        SqliteClanStore.ClanBankOperationState.EXTERNAL_CONFIRMED,
                        "PROVIDER_SUCCESS_RESPONSE", clock.instant());
                if (confirmed.status() != SqliteClanStore.ClanBankOperationStatus.UPDATED) {
                    complete(completion, new Result(Status.MANUAL_RECONCILIATION_REQUIRED, confirmed.operation()));
                    return;
                }
                var committed = store.commitConfirmedClanBankOperation(operation.operationId(), clock.instant());
                complete(completion, new Result(committed.status() == SqliteClanStore.ClanBankOperationStatus.COMMITTED
                        ? Status.SUCCESS : Status.LOCAL_COMMIT_PENDING, committed.operation()));
                return;
            }
            if (operation.operationType().equals("DEPOSIT")
                    && external.status() == EconomyOperations.Status.INSUFFICIENT_FUNDS) {
                var failed = store.transitionClanBankOperation(operation.operationId(),
                        SqliteClanStore.ClanBankOperationState.CALLING,
                        SqliteClanStore.ClanBankOperationState.FAILED_NO_EFFECT,
                        "PROVIDER_REPORTED_INSUFFICIENT_PERSONAL_FUNDS", clock.instant());
                complete(completion, new Result(failed.status() == SqliteClanStore.ClanBankOperationStatus.UPDATED
                        ? Status.INSUFFICIENT_PERSONAL_FUNDS : Status.MANUAL_RECONCILIATION_REQUIRED, failed.operation()));
                return;
            }
            var unknown = store.transitionClanBankOperation(operation.operationId(),
                    SqliteClanStore.ClanBankOperationState.CALLING,
                    SqliteClanStore.ClanBankOperationState.UNKNOWN,
                    "PROVIDER_RESULT_UNCERTAIN: " + external.status(), clock.instant());
            complete(completion, new Result(Status.MANUAL_RECONCILIATION_REQUIRED, unknown.operation()));
        } catch (RuntimeException exception) {
            // The last durable state remains CALLING or EXTERNAL_CONFIRMED. Startup recovery handles it.
            complete(completion, new Result(Status.MANUAL_RECONCILIATION_REQUIRED, operation));
        }
    }

    private boolean authorizedMember(UUID clanId, UUID playerId) {
        if (clanId == null || playerId == null) return false;
        Clan clan = clans.findById(clanId).orElse(null);
        return clan != null && clan.member(playerId).isPresent();
    }

    private boolean hasRole(UUID clanId, UUID playerId, ClanRole role) {
        if (clanId == null || playerId == null) return false;
        Clan clan = clans.findById(clanId).orElse(null);
        ClanMember member = clan == null ? null : clan.member(playerId).orElse(null);
        return member != null && member.role() == role;
    }

    private void complete(Consumer<Result> completion, Result result) {
        if (completion == null) return;
        try {
            mainThread.execute(() -> completion.accept(result));
        } catch (RuntimeException dispatchFailure) {
            // A shutting-down server may reject the callback; the durable operation state remains authoritative.
            System.getLogger(ClanBankTransferCoordinator.class.getName()).log(
                    System.Logger.Level.ERROR, "Could not dispatch clan-bank completion callback", dispatchFailure);
        }
    }

    private static Status mapPrepareStatus(SqliteClanStore.ClanBankOperationStatus status) {
        return switch (status) {
            case CLAN_NOT_FOUND -> Status.CLAN_NOT_FOUND;
            case INSUFFICIENT_BANK_FUNDS -> Status.INSUFFICIENT_BANK_FUNDS;
            case REQUEST_NOT_APPROVED -> Status.REQUEST_NOT_APPROVED;
            case REQUEST_ALREADY_LINKED, ACTOR_OPERATION_IN_PROGRESS -> Status.OPERATION_ALREADY_EXISTS;
            case NOT_AUTHORIZED -> Status.NOT_AUTHORIZED;
            case IDEMPOTENCY_CONFLICT, BUSINESS_OPERATION_CONFLICT -> Status.IDEMPOTENCY_CONFLICT;
            default -> Status.STORAGE_ERROR;
        };
    }

    public enum Status {
        SUCCESS, ECONOMY_UNAVAILABLE, INVALID_AMOUNT, NOT_AUTHORIZED, CLAN_NOT_FOUND,
        INSUFFICIENT_BANK_FUNDS, INSUFFICIENT_PERSONAL_FUNDS, REQUEST_NOT_APPROVED,
        OPERATION_ALREADY_EXISTS, ALREADY_COMPLETED, IDEMPOTENCY_CONFLICT,
        MANUAL_RECONCILIATION_REQUIRED, LOCAL_COMMIT_PENDING, PROVIDER_NOT_CALLED, STORAGE_ERROR
    }

    public record Result(Status status, SqliteClanStore.ClanBankOperation operation) { }

    @FunctionalInterface
    public interface MainThreadDispatcher { void execute(Runnable task); }
}

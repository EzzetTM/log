package com.skyworldclans.clan.application.purchase;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.application.purchase.PaymentPort.CompensationResult;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;
import com.skyworldclans.clan.storage.StorageException;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.*;

class CompensationRecoveryTest {

    @TempDir
    Path temporaryDirectory;

    static final class TestPaymentPort implements PaymentPort {
        private final Map<String, CompensationResult> providerState;
        private final List<String> compensateCalls = new CopyOnWriteArrayList<>();
        private final List<String> reconcileCalls = new CopyOnWriteArrayList<>();
        private final boolean throwOnReconcile;

        TestPaymentPort() {
            this(new ConcurrentHashMap<>(), false);
        }

        TestPaymentPort(Map<String, CompensationResult> providerState, boolean throwOnReconcile) {
            this.providerState = providerState;
            this.throwOnReconcile = throwOnReconcile;
        }

        @Override
        public PaymentResult debit(UUID actorId, long amount, String context) {
            return new PaymentResult(true, false, "provider-op-" + UUID.randomUUID());
        }

        @Override
        public CompensationResult compensate(
                UUID actorId,
                long amount,
                String originalProviderOperationId,
                String compensationId,
                String context) {
            compensateCalls.add(compensationId);
            CompensationResult result = providerState.computeIfAbsent(
                    compensationId,
                    id -> CompensationResult.success(id, originalProviderOperationId));
            return result;
        }

        @Override
        public CompensationResult reconcile(String originalProviderOperationId, String compensationId) throws PaymentException {
            reconcileCalls.add(compensationId);
            if (throwOnReconcile) {
                throw new PaymentException("simulated reconcile failure");
            }
            return providerState.getOrDefault(
                    compensationId,
                    CompensationResult.unknown(compensationId, originalProviderOperationId));
        }

        int compensateCallCount() {
            return compensateCalls.size();
        }

        int reconcileCallCount() {
            return reconcileCalls.size();
        }
    }

    private SqliteClanStore openStoreAt(Path dbPath) {
        return SqliteClanStore.open(dbPath);
    }

    private void createCompensationCallingOperation(
            SqliteClanStore store,
            UUID operationId,
            String originalProviderOperationId) {
        UUID clanId = UUID.randomUUID();
        UUID actorId = UUID.randomUUID();
            // Use a unique tag based on clanId to avoid TAG_CONFLICT when multiple clans are created
            String tag = "TC" + clanId.toString().substring(0, 2).toUpperCase();
        Clan clan = new Clan(
                clanId,
                "Clan" + clanId.toString().substring(0, 8),
                    tag,
                Instant.EPOCH,
                10,
                Map.of(actorId, new ClanMember(actorId, ClanRole.LEADER, Instant.EPOCH, null)),
                0,
                "");
            var regResult = store.registerIfAvailable(clan);
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, regResult,
                    "Clan registration should succeed with unique tag: " + tag);

        long amount = ClanCapacityPolicy.nextExpansionCost(10).orElseThrow();
        CapacityPurchaseIntent intent = new CapacityPurchaseIntent(
                operationId,
                "idem-" + operationId,
                "expand-" + clanId + "-" + operationId,
                clan,
                actorId,
                0L,
                20,
                amount);
        var prepared = store.prepare(intent);
        assertEquals(CapacityPurchaseJournal.PrepareStatus.CREATED, prepared.status(),
                "operation should be prepared: " + operationId);

        assertEquals(CapacityPurchaseStore.TransitionStatus.UPDATED,
                store.transition(operationId, CapacityPurchaseState.PREPARED, CapacityPurchaseState.CALLING,
                        CapacityPurchaseTransitionEvidence.NONE, null).status(),
                "PREPARED -> CALLING should succeed: " + operationId);
        assertEquals(CapacityPurchaseStore.TransitionStatus.UPDATED,
                store.transition(operationId, CapacityPurchaseState.CALLING, CapacityPurchaseState.DEBIT_CONFIRMED,
                        CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED, originalProviderOperationId).status(),
                "CALLING -> DEBIT_CONFIRMED should succeed: " + operationId);

        assertEquals(CapacityPurchaseStore.TransitionStatus.UPDATED,
                store.transition(operationId, CapacityPurchaseState.DEBIT_CONFIRMED, CapacityPurchaseState.COMPENSATION_PENDING,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_REQUIRED_REPORTED, originalProviderOperationId).status(),
                "DEBIT_CONFIRMED -> COMPENSATION_PENDING should succeed: " + operationId);
        assertEquals(CapacityPurchaseStore.TransitionStatus.UPDATED,
                store.transition(operationId, CapacityPurchaseState.COMPENSATION_PENDING, CapacityPurchaseState.COMPENSATION_CALLING,
                        CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED, originalProviderOperationId).status(),
                "COMPENSATION_PENDING -> COMPENSATION_CALLING should succeed: " + operationId);
    }

    private Optional<CapacityPurchaseOperation> findOperationById(CapacityPurchaseStore store, UUID operationId) {
        for (CapacityPurchaseState state : new CapacityPurchaseState[] {
                CapacityPurchaseState.COMPENSATION_CALLING,
                CapacityPurchaseState.COMPENSATED,
                CapacityPurchaseState.COMPENSATION_UNKNOWN,
                CapacityPurchaseState.COMPENSATION_FAILED
        }) {
            Optional<CapacityPurchaseOperation> found = store.findByState(state).stream()
                    .filter(op -> op.operationId().equals(operationId))
                    .findFirst();
            if (found.isPresent()) {
                return found;
            }
        }
        return Optional.empty();
    }

    private static String compensationId(UUID operationId) {
        return "compensation-" + operationId;
    }

    @Test
    void compensationIdIsStableForSameUuid() {
        UUID operationId = UUID.fromString("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee");
        assertEquals("compensation-" + operationId, compensationId(operationId));
        assertEquals(compensationId(operationId), compensationId(operationId));
    }

    @Test
    void differentUuidsProduceDifferentCompensationIds() {
        UUID a = UUID.randomUUID();
        UUID b = UUID.randomUUID();
        assertNotEquals(compensationId(a), compensationId(b));
    }

    @Test
    void missingOriginalProviderOperationIdRemainsUnknownWithoutCallingProvider() {
        Path db = temporaryDirectory.resolve("recover-missing-provider-id.sqlite");
        UUID operationId = UUID.randomUUID();

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, null);
            TestPaymentPort paymentPort = new TestPaymentPort();
            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATION_UNKNOWN, results.get(0).status());
            assertEquals(0, paymentPort.reconcileCallCount());
            assertEquals(0, paymentPort.compensateCallCount());

            CapacityPurchaseOperation recovered = findOperationById(store, operationId).orElseThrow();
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN, recovered.state());
            assertEquals("compensation-" + operationId, recovered.providerOperationId());
        }
    }

    @Test
    void successfulReconcileTransitionsToCompensated() {
        Path db = temporaryDirectory.resolve("recover-success.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-success";
        String compId = compensationId(operationId);

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
            providerState.put(compId, CompensationResult.success(compId, providerOp));
            TestPaymentPort paymentPort = new TestPaymentPort(providerState, false);
            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATED, results.get(0).status());
            assertEquals(1, paymentPort.reconcileCallCount());
            assertEquals(0, paymentPort.compensateCallCount());
            assertEquals(CapacityPurchaseState.COMPENSATED, findOperationById(store, operationId).orElseThrow().state());
        }
    }

    @Test
    void unknownReconcileTransitionsToCompensationUnknown() {
        Path db = temporaryDirectory.resolve("recover-unknown.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-unknown";
        String compId = compensationId(operationId);

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
            providerState.put(compId, CompensationResult.unknown(compId, providerOp));
            TestPaymentPort paymentPort = new TestPaymentPort(providerState, false);
            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATION_UNKNOWN, results.get(0).status());
            assertEquals(1, paymentPort.reconcileCallCount());
            assertEquals(0, paymentPort.compensateCallCount());
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN, findOperationById(store, operationId).orElseThrow().state());
        }
    }

    @Test
    void reconcileErrorDoesNotCallCompensateAndLeavesUnknown() {
        Path db = temporaryDirectory.resolve("recover-error.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-error";

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
            TestPaymentPort paymentPort = new TestPaymentPort(providerState, true);
            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATION_UNKNOWN, results.get(0).status());
            assertEquals(1, paymentPort.reconcileCallCount());
            assertEquals(0, paymentPort.compensateCallCount());
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN, findOperationById(store, operationId).orElseThrow().state());
        }
    }

    @Test
    void uncheckedProviderFailureFailsClosedWithoutIssuingAnotherRefund() {
        Path db = temporaryDirectory.resolve("recover-runtime-provider-error.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-runtime-error";
        String compId = compensationId(operationId);

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            PaymentPort paymentPort = new PaymentPort() {
                @Override
                public PaymentResult debit(UUID actorId, long amount, String context) {
                    return PaymentResult.success("unused");
                }

                @Override
                public CompensationResult compensate(UUID actorId, long amount,
                        String originalProviderOperationId, String compensationId, String context) {
                    fail("Recovery must never issue a new compensation");
                    return null;
                }

                @Override
                public CompensationResult reconcile(String originalProviderOperationId,
                        String compensationId) {
                    throw new IllegalStateException("simulated unchecked provider failure");
                }
            };

            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);
            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATION_UNKNOWN, results.get(0).status());
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    findOperationById(store, operationId).orElseThrow().state());
            assertEquals("compensation-" + operationId,
                    findOperationById(store, operationId).orElseThrow().providerOperationId());
        }
    }

    @Test
    void mismatchedCompensationIdFailsClosed() {
        Path db = temporaryDirectory.resolve("recover-mismatch-compid.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-mismatch-compid";
        String compId = compensationId(operationId);

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
            providerState.put(compId, CompensationResult.success("wrong-" + compId, providerOp));
            TestPaymentPort paymentPort = new TestPaymentPort(providerState, false);
            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATION_UNKNOWN, results.get(0).status());
            assertEquals(0, paymentPort.compensateCallCount());
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN, findOperationById(store, operationId).orElseThrow().state());
        }
    }

    @Test
    void mismatchedOriginalProviderOperationIdFailsClosed() {
        Path db = temporaryDirectory.resolve("recover-mismatch-provider.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-mismatch-provider";
        String compId = compensationId(operationId);

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
            providerState.put(compId, CompensationResult.success(compId, "different-provider-op"));
            TestPaymentPort paymentPort = new TestPaymentPort(providerState, false);
            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATION_UNKNOWN, results.get(0).status());
            assertEquals(0, paymentPort.compensateCallCount());
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN, findOperationById(store, operationId).orElseThrow().state());
        }
    }

    @Test
    void newRecoveryInstanceRecoversPersistedOperationAfterReopen() {
        Path db = temporaryDirectory.resolve("recover-restart.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-restart";
        String compId = compensationId(operationId);
        Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
        // Simulate provider already completed refund before crash; result persists in provider backing store.
        providerState.put(compId, CompensationResult.success(compId, providerOp));

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
        }

        try (SqliteClanStore reopenedStore = openStoreAt(db)) {
            TestPaymentPort newPortInstance = new TestPaymentPort(providerState, false);
            CompensationRecovery newRecoveryInstance = new CompensationRecovery(reopenedStore, newPortInstance);

            List<CapacityExpansionResult> results = newRecoveryInstance.recover();

            assertEquals(1, results.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATED, results.get(0).status());
            assertEquals(1, newPortInstance.reconcileCallCount());
            assertEquals(0, newPortInstance.compensateCallCount());
            assertEquals(CapacityPurchaseState.COMPENSATED, findOperationById(reopenedStore, operationId).orElseThrow().state());
        }
    }

    @Test
    void repeatedRecoveryDoesNotIssueRefund() {
        Path db = temporaryDirectory.resolve("recover-repeat.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-repeat";
        String compId = compensationId(operationId);
        Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
        providerState.put(compId, CompensationResult.success(compId, providerOp));

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            TestPaymentPort paymentPort = new TestPaymentPort(providerState, false);
            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            List<CapacityExpansionResult> first = recovery.recover();
            List<CapacityExpansionResult> second = recovery.recover();

            assertEquals(1, first.size());
            assertEquals(CapacityExpansionResult.Status.COMPENSATED, first.get(0).status());
            assertEquals(0, second.size(), "already compensated operation must not be recovered again");
            assertEquals(1, paymentPort.reconcileCallCount(), "only first recovery should reconcile");
            assertEquals(0, paymentPort.compensateCallCount(), "compensate must never be called during recovery");
        }
    }

    @Test
    void errorOnOneOperationDoesNotPreventRecoveryOfOthers() {
        Path db = temporaryDirectory.resolve("recover-multi.sqlite");
        UUID op1 = UUID.randomUUID();
        UUID op2 = UUID.randomUUID();
        String providerOp1 = "provider-op1";
        String providerOp2 = "provider-op2";
        String compId1 = compensationId(op1);
        String compId2 = compensationId(op2);

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, op1, providerOp1);
            createCompensationCallingOperation(store, op2, providerOp2);

            Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
            // op1 will cause reconcile exception via throwing port? we need per-call behavior; easier: pre-put success for op2 and use port that throws only for op1
            providerState.put(compId2, CompensationResult.success(compId2, providerOp2));
            PaymentPort selectivePort = new PaymentPort() {
                final List<String> compensateCalls = new CopyOnWriteArrayList<>();
                final List<String> reconcileCalls = new CopyOnWriteArrayList<>();

                @Override
                public PaymentResult debit(UUID actorId, long amount, String context) {
                    return new PaymentResult(true, false, "d");
                }

                @Override
                public CompensationResult compensate(UUID actorId, long amount, String originalProviderOperationId, String compensationId, String context) {
                    compensateCalls.add(compensationId);
                    return CompensationResult.success(compensationId, originalProviderOperationId);
                }

                @Override
                public CompensationResult reconcile(String originalProviderOperationId, String compensationId) throws PaymentException {
                    reconcileCalls.add(compensationId);
                    if (compensationId.equals(compId1)) {
                        throw new PaymentException("boom for op1");
                    }
                    return providerState.getOrDefault(compensationId, CompensationResult.unknown(compensationId, originalProviderOperationId));
                }
            };
            CompensationRecovery recovery = new CompensationRecovery(store, selectivePort);

            List<CapacityExpansionResult> results = recovery.recover();

            assertEquals(2, results.size());
            // op1 should become COMPENSATION_UNKNOWN due to reconcile exception handling
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN, findOperationById(store, op1).orElseThrow().state());
            assertEquals(CapacityPurchaseState.COMPENSATED, findOperationById(store, op2).orElseThrow().state());
        }
    }

    @Test
    void doesNotReportSuccessWhenJournalTransitionConflicts() {
        Path db = temporaryDirectory.resolve("recover-transition-conflict.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-transition-conflict";
        String compId = compensationId(operationId);

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
            PaymentPort paymentPort = new PaymentPort() {
                @Override
                public PaymentResult debit(UUID actorId, long amount, String context) {
                    return PaymentResult.success("unused");
                }

                @Override
                public CompensationResult compensate(
                        UUID actorId,
                        long amount,
                        String originalProviderOperationId,
                        String compensationId,
                        String context) {
                    fail("Recovery must never issue a new compensation");
                    return null;
                }

                @Override
                public CompensationResult reconcile(
                        String originalProviderOperationId,
                        String compensationId) {
                    var concurrentTransition = store.transition(
                            operationId,
                            CapacityPurchaseState.COMPENSATION_CALLING,
                            CapacityPurchaseState.COMPENSATION_UNKNOWN,
                            CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                            compensationId);
                    assertEquals(CapacityPurchaseJournal.TransitionStatus.UPDATED,
                            concurrentTransition.status());
                    return CompensationResult.success(compensationId, providerOp);
                }
            };

            CompensationRecovery recovery = new CompensationRecovery(store, paymentPort);

            assertThrows(StorageException.class, recovery::recover);
            assertEquals(CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    findOperationById(store, operationId).orElseThrow().state());
        }
    }

    @Test
    void corruptedHistoryIsNotBypassedByRecovery() throws Exception {
        Path db = temporaryDirectory.resolve("recover-corrupted.sqlite");
        UUID operationId = UUID.randomUUID();
        String providerOp = "provider-corrupted";
        String compId = compensationId(operationId);
        Map<String, CompensationResult> providerState = new ConcurrentHashMap<>();
        providerState.put(compId, CompensationResult.success(compId, providerOp));

        try (SqliteClanStore store = openStoreAt(db)) {
            createCompensationCallingOperation(store, operationId, providerOp);
        }

        // Corrupt history: remove an event to break the append-only chain after store is closed.
        // SQLite v4 enforces append-only events with triggers; temporarily drop them to simulate
        // on-disk corruption, then restore them before reopening.
        try (var conn = java.sql.DriverManager.getConnection("jdbc:sqlite:" + db.toAbsolutePath());
             var stmt = conn.createStatement()) {
            stmt.execute("DROP TRIGGER IF EXISTS capacity_purchase_events_no_update");
            stmt.execute("DROP TRIGGER IF EXISTS capacity_purchase_events_no_delete");
            int deleted = stmt.executeUpdate(
                    "DELETE FROM capacity_purchase_events WHERE operation_id = '" + operationId + "' AND event_id = 2");
            assertEquals(1, deleted, "expected to delete one event to corrupt history");
            stmt.execute("CREATE TRIGGER capacity_purchase_events_no_update "
                    + "BEFORE UPDATE ON capacity_purchase_events "
                    + "BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END");
            stmt.execute("CREATE TRIGGER capacity_purchase_events_no_delete "
                    + "BEFORE DELETE ON capacity_purchase_events "
                    + "BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END");
        }

        // Reopening must fail closed on corrupted purchase history; recovery cannot bypass
        // or "repair" append-only journal corruption, and no compensation/reconciliation is possible.
        assertThrows(StorageException.class, () -> openStoreAt(db),
                "corrupted purchase history must be detected on reopen");
    }
}

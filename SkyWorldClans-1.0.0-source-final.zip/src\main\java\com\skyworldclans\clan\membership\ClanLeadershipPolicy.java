package com.skyworldclans.clan.membership;

import java.time.Duration;
import java.util.Optional;

public final class ClanLeadershipPolicy {
    private static final int MAX_DEPUTIES = 4;
    private static final Duration REQUIRED_INACTIVITY = Duration.ofDays(30);
    private static final Duration REQUIRED_WAIT_AFTER_INCUMBENT_COUP_WIN = Duration.ofDays(30);

    public Optional<LeaderDepartureOutcome> determineLeaderDeparture(
            int remainingMemberCount,
            int deputyCount) {
        if (remainingMemberCount < 0
                || deputyCount < 0
                || deputyCount > MAX_DEPUTIES
                || deputyCount > remainingMemberCount) {
            return Optional.empty();
        }
        if (remainingMemberCount == 0) {
            return Optional.of(LeaderDepartureOutcome.EMPTY_CLAN);
        }
        if (deputyCount == 1) {
            return Optional.of(LeaderDepartureOutcome.TRANSFER_TO_DEPUTY);
        }
        if (deputyCount >= 2) {
            return Optional.of(LeaderDepartureOutcome.ELECTION_AMONG_DEPUTIES);
        }
        return Optional.of(LeaderDepartureOutcome.ELECTION_AMONG_MEMBERS);
    }

    public boolean canTransferLeadershipTo(ClanRole targetRole, boolean electionActive) {
        return targetRole == ClanRole.DEPUTY && !electionActive;
    }

    public boolean canInitiateCoup(
            ClanRole actorRole,
            Duration leaderInactiveFor,
            boolean incumbentWonPreviousCoup,
            Duration timeSincePreviousCoup) {
        if (actorRole != ClanRole.DEPUTY
                || leaderInactiveFor == null
                || timeSincePreviousCoup == null
                || leaderInactiveFor.isNegative()
                || timeSincePreviousCoup.isNegative()
                || leaderInactiveFor.compareTo(REQUIRED_INACTIVITY) < 0) {
            return false;
        }

        return !incumbentWonPreviousCoup
                || timeSincePreviousCoup.compareTo(REQUIRED_WAIT_AFTER_INCUMBENT_COUP_WIN) >= 0;
    }

    public boolean requiresGlobalTieBreak(boolean runoffIsTied) {
        return runoffIsTied;
    }
}

package com.skyworldclans.clan.moderation;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * Clan chat mutes and warnings.
 *
 * <p>The technical specification fixes the maximum mute duration per issuing role and the
 * visibility of warning history, but leaves two points open (owner questions #7 and #8): whether
 * seniors may be muted and who may issue warnings. Until the owner decides, this service applies
 * the conservative ordering {@code LEADER > DEPUTY > MODERATOR > MEMBER}: an actor may only act on
 * a strictly lower role and never on themselves. That grants no power the specification does not
 * already imply and refuses every ambiguous case instead of guessing.</p>
 */
public final class ClanModerationService {
    public static final Duration MODERATOR_MUTE_LIMIT = Duration.ofHours(24);
    public static final Duration DEPUTY_MUTE_LIMIT = Duration.ofDays(3);
    public static final Duration WARNING_WINDOW = Duration.ofHours(12);
    public static final Duration CASE_DECISION_WINDOW = Duration.ofHours(24);

    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final Clock clock;
    private final java.util.function.Supplier<UUID> ids;

    public ClanModerationService(ClanCatalog clans, SqliteClanStore store, Clock clock,
            java.util.function.Supplier<UUID> ids) {
        this.clans = Objects.requireNonNull(clans); this.store = Objects.requireNonNull(store);
        this.clock = Objects.requireNonNull(clock); this.ids = Objects.requireNonNull(ids);
    }

    public Result mute(UUID actorId, UUID targetId, Duration requestedDuration, String reason) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return Result.NOT_IN_CLAN;
        ClanMember actor = clan.member(actorId).orElse(null);
        ClanMember target = clan.member(targetId).orElse(null);
        if (actor == null) return Result.NOT_IN_CLAN;
        if (target == null) return Result.TARGET_NOT_IN_CLAN;
        if (!canModerate(actor.role(), target.role())) return Result.INSUFFICIENT_PERMISSION;
        Instant now = clock.instant();
        Instant expiresAt;
        if (actor.role() == ClanRole.LEADER) {
            // The leader may mute indefinitely; a requested finite duration is still honoured.
            expiresAt = requestedDuration == null || requestedDuration.isZero() || requestedDuration.isNegative()
                    ? null : now.plus(requestedDuration);
        } else {
            Duration limit = actor.role() == ClanRole.DEPUTY ? DEPUTY_MUTE_LIMIT : MODERATOR_MUTE_LIMIT;
            if (requestedDuration == null || requestedDuration.isZero() || requestedDuration.isNegative()
                    || requestedDuration.compareTo(limit) > 0) return Result.DURATION_EXCEEDS_ROLE_LIMIT;
            expiresAt = now.plus(requestedDuration);
        }
        var status = store.setClanChatMute(clan.id(), targetId, actorId, expiresAt, reason, now);
        return switch (status) {
            case APPLIED -> Result.APPLIED;
            case CLAN_NOT_FOUND, NOT_A_MEMBER -> Result.TARGET_NOT_IN_CLAN;
            case INVALID_INPUT -> Result.INVALID_INPUT;
            default -> Result.STORAGE_ERROR;
        };
    }

    public Result unmute(UUID actorId, UUID targetId) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return Result.NOT_IN_CLAN;
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) return Result.NOT_IN_CLAN;
        if (actor.role() != ClanRole.LEADER && actor.role() != ClanRole.DEPUTY)
            return Result.INSUFFICIENT_PERMISSION;
        var status = store.clearClanChatMute(clan.id(), targetId, actorId, "UNMUTED",
                "unmuted by " + actor.role(), clock.instant());
        return switch (status) {
            case CLEARED -> Result.APPLIED;
            case NOT_FOUND -> Result.NOT_MUTED;
            default -> Result.STORAGE_ERROR;
        };
    }

    public List<SqliteClanStore.ClanChatMute> mutes(UUID actorId) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return List.of();
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null || actor.role() == ClanRole.MEMBER) return List.of();
        Instant now = clock.instant();
        return store.listClanChatMutes(clan.id()).stream()
                .filter(mute -> !mute.isExpired(now))
                .toList();
    }

    /** True when the player currently may not write to clan chat. Expired mutes are ignored. */
    public boolean isChatMuted(UUID clanId, UUID playerId) {
        if (clanId == null || playerId == null) return false;
        return store.findClanChatMute(clanId, playerId)
                .filter(mute -> !mute.isExpired(clock.instant()))
                .isPresent();
    }

    public Result warn(UUID actorId, UUID targetId, String reason) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return Result.NOT_IN_CLAN;
        ClanMember actor = clan.member(actorId).orElse(null);
        ClanMember target = clan.member(targetId).orElse(null);
        if (actor == null) return Result.NOT_IN_CLAN;
        if (target == null) return Result.TARGET_NOT_IN_CLAN;
        if (!canModerate(actor.role(), target.role())) return Result.INSUFFICIENT_PERMISSION;
        Instant now = clock.instant();
        var issued = store.issueClanWarning(ids.get(), clan.id(), targetId, actorId, reason, now);
        if (issued != SqliteClanStore.ModerationStatus.APPLIED) return Result.STORAGE_ERROR;
        store.openWarningCaseIfEligible(clan.id(), targetId, now);
        return Result.APPLIED;
    }

    public Result removeWarning(UUID actorId, UUID targetId) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return Result.NOT_IN_CLAN;
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null) return Result.NOT_IN_CLAN;
        if (actor.role() != ClanRole.LEADER && actor.role() != ClanRole.DEPUTY)
            return Result.INSUFFICIENT_PERMISSION;
        var status = store.removeLatestClanWarning(clan.id(), targetId, actorId, clock.instant());
        return switch (status) {
            case CLEARED -> Result.APPLIED;
            case NO_ACTIVE_WARNING -> Result.NO_ACTIVE_WARNING;
            default -> Result.STORAGE_ERROR;
        };
    }

    /** Warning history filtered by the viewer's approved visibility. */
    public List<SqliteClanStore.ClanWarning> warnings(UUID viewerId, UUID targetId) {
        Clan clan = clans.findByPlayerId(viewerId).orElse(null);
        if (clan == null) return List.of();
        ClanMember viewer = clan.member(viewerId).orElse(null);
        if (viewer == null) return List.of();
        List<SqliteClanStore.ClanWarning> all = store.listClanWarnings(clan.id(), targetId, false);
        return switch (viewer.role()) {
            case LEADER, DEPUTY -> all;
            // A moderator only sees warnings they issued themselves; a plain member has no
            // approved listing right in the specification and therefore sees nothing.
            case MODERATOR -> all.stream()
                    .filter(warning -> warning.issuedBy().equals(viewerId)).toList();
            case MEMBER -> List.of();
        };
    }

    public List<SqliteClanStore.ClanWarningCase> cases(UUID actorId) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return List.of();
        ClanMember actor = clan.member(actorId).orElse(null);
        if (actor == null || actor.role() == ClanRole.MEMBER || actor.role() == ClanRole.MODERATOR)
            return List.of();
        return store.listWarningCases(clan.id());
    }

    /** Scheduler entry point: overdue cases move to the leader; no sanction is applied. */
    public List<UUID> escalateDueCases() {
        return store.escalateDueWarningCases(clock.instant());
    }

    /** Ends moderation state for a departing member; a later re-join starts clean. */
    public void clearOnDeparture(UUID clanId, UUID playerId) {
        if (clanId == null || playerId == null) return;
        store.clearModerationOnDeparture(clanId, playerId, null, clock.instant());
    }

    public Optional<Clan> clanOf(UUID playerId) { return clans.findByPlayerId(playerId); }

    /**
     * Conservative ordering: an actor may only act on a strictly lower role, never on itself.
     * Leaders therefore cannot be muted or warned by deputies/moderators; nobody self-moderates.
     */
    static boolean canModerate(ClanRole actor, ClanRole target) {
        return roleWeight(actor) > roleWeight(target);
    }

    private static int roleWeight(ClanRole role) {
        return switch (role) {
            case LEADER -> 4;
            case DEPUTY -> 3;
            case MODERATOR -> 2;
            case MEMBER -> 1;
        };
    }

    public enum Result {
        APPLIED, NOT_IN_CLAN, TARGET_NOT_IN_CLAN, INSUFFICIENT_PERMISSION,
        DURATION_EXCEEDS_ROLE_LIMIT, NOT_MUTED, NO_ACTIVE_WARNING, INVALID_INPUT, STORAGE_ERROR
    }
}
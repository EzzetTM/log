package com.skyworldclans.clan.application.purchase;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.application.purchase.CapacityExpansionResult;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseIntent;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseOperation;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseState;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseTransitionEvidence;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;
import com.skyworldclans.clan.storage.StorageException;
import java.util.List;
import java.util.Optional;
import java.util.Objects;
import java.util.OptionalInt;
import java.util.UUID;

/**
 * Attempts to expand a clan's capacity through a paid purchase.
 * <p>
 * The full sequence is:
 * 1. Validate actor is the current clan leader
 * 2. Verify requested capacity is the next valid level
 * 3. Determine the exact cost via ClanCapacityPolicy
 * 4. Prepare (or look up) the purchase operation with idempotency key
 * 5. Call the external payment provider via PaymentPort
 * 6. Transition the operation state based on the debit result
 * 7. Commit atomically (requires business marker + clan capacity proof)
 * <p>
 * If any step fails, the method returns a descriptive result status and leaves the
 * operation in a safe state (typically UNKNOWN, FAILED_NO_EFFECT, or an error status).
 * The operation's history is always validated on read; corrupted histories are rejected.
 * <p>
 * On startup, the coordinator may be invoked with CompensationRecovery.recover()
 * to handle any operations left in COMPENSATION_CALLING state from a previous run.
 */

public final class ClanCapacityExpansionCoordinator {

    private final ClanCatalog clanCatalog;
    private final CapacityPurchaseStore purchaseStore;
    private final PaymentPort paymentPort;
    private final CompensationRecovery compensationRecovery;

    /**
     * Creates a new coordinator with the given dependencies.
     *
     * @param clanCatalog      source of clan data and CAS-based capacity updates
     * @param purchaseStore    journal-backed capacity-purchase store (SqliteClanStore implements this)
     * @param paymentPort      neutral port for external debit; may be a test double in unit tests
     * @param compensationRecovery optional recovery component for handling COMPENSATION_CALLING
     *                               operations from previous runs; may be null if not needed
     */
    public ClanCapacityExpansionCoordinator(
            ClanCatalog clanCatalog,
            CapacityPurchaseStore purchaseStore,
            PaymentPort paymentPort,
            CompensationRecovery compensationRecovery) {
        this.clanCatalog = Objects.requireNonNull(clanCatalog, "clanCatalog");
        this.purchaseStore = Objects.requireNonNull(purchaseStore, "purchaseStore");
        this.paymentPort = Objects.requireNonNull(paymentPort, "paymentPort");
        this.compensationRecovery = compensationRecovery;
    }

    /**
     * Attempts to expand a clan's capacity through a paid purchase.
     * <p>
     * The full sequence is:
     * 1. Validate actor is the current clan leader
     * 2. Verify requested capacity is the next valid level
     * 3. Determine the exact cost via ClanCapacityPolicy
     * 4. Prepare (or look up) the purchase operation with idempotency key
     * 5. Call the external payment provider via PaymentPort
     * 6. Transition the operation state based on the debit result
     * 7. Commit atomically (requires business marker + clan capacity proof)
     * <p>
     * If any step fails, the method returns a descriptive result status and leaves the
     * operation in a safe state (typically UNKNOWN, FAILED_NO_EFFECT, or an error status).
     * The operation's history is always validated on read; corrupted histories are rejected.
     *
     * @param clanId       the clan to expand
     * @param actorId      the player attempting the purchase (must be the current leader)
     * @param requestedCapacity the desired new capacity level
     * @return a result describing the outcome, including status and optionally the expanded clan
     */
    public CapacityExpansionResult attemptExpandCapacity(
            UUID clanId,
            UUID actorId,
            int requestedCapacity) {
        if (clanId == null || actorId == null) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.INVALID_INPUT, Optional.empty());
        }

        String businessOperationId = "clan-expand-" + clanId + "-" + requestedCapacity;
        String idempotencyKey = "expand-" + clanId + "-" + requestedCapacity + "-" + actorId;
        try {
            Optional<CapacityPurchaseOperation> existing =
                    purchaseStore.findByIdempotencyKey(idempotencyKey);
            if (existing.isPresent()) {
                return handleExistingOperation(idempotencyKey, businessOperationId);
            }
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }

        // 1. Look up the clan and validate leadership.
        Optional<Clan> currentOptional = clanCatalog.findById(clanId);
        if (currentOptional.isEmpty()) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.CLAN_NOT_FOUND,
                    Optional.empty());
        }
        Clan current = currentOptional.get();

        // Check leadership: actor must be the current leader
        if (!current.leader()
                .map(leader -> leader.playerId().equals(actorId))
                .orElse(false)) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.NOT_LEADER,
                    Optional.empty());
        }

        // 2. Verify requested capacity is the next valid level
        if (!ClanCapacityPolicy.canExpandTo(current.capacity(), requestedCapacity)) {
            try {
                if (purchaseStore.findByIdempotencyKey(idempotencyKey).isPresent()) {
                    return handleExistingOperation(idempotencyKey, businessOperationId);
                }
            } catch (StorageException exception) {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
            }
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                    Optional.empty());
        }

        // 3. Determine the exact cost
        OptionalInt costOptional = ClanCapacityPolicy.nextExpansionCost(current.capacity());
        if (!costOptional.isPresent()) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                    Optional.empty());
        }
                int amount = costOptional.getAsInt();

        // 4. Prepare (or look up) the purchase operation with idempotency key.

        Optional<Long> revisionOptional = clanCatalog.findRevision(clanId);
                if (revisionOptional.isEmpty()) {
                    return new CapacityExpansionResult(
                            CapacityExpansionResult.Status.CLAN_NOT_FOUND,
                            Optional.empty());
                }
                long revision = revisionOptional.get();

                CapacityPurchaseIntent intent = new CapacityPurchaseIntent(
                        UUID.randomUUID(),
                        idempotencyKey,
                        businessOperationId,
                        current,
                        actorId,
                        revision,
                        requestedCapacity,
                        amount);

        // Try to prepare; handles idempotency key conflicts
        CapacityPurchaseStore.PrepareResult prepareResult;
        try {
            prepareResult = purchaseStore.prepare(intent);
        } catch (IllegalArgumentException e) {
            // Invalid intent (e.g., amount mismatch, wrong capacity)
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                    Optional.empty());
        }

        // A concurrent delivery can create the same request between the initial lookup and
        // prepare(). Reuse its persisted operationId and let the stored fingerprint decide whether
        // the complete payload is identical; never weaken the fingerprint comparison.
        if (prepareResult.status() == CapacityPurchaseStore.PrepareStatus.IDEMPOTENCY_KEY_CONFLICT) {
            try {
                Optional<CapacityPurchaseOperation> existing =
                        purchaseStore.findByIdempotencyKey(idempotencyKey);
                if (existing.isPresent()) {
                    CapacityPurchaseIntent retryIntent = new CapacityPurchaseIntent(
                            existing.get().operationId(), idempotencyKey, businessOperationId,
                            current, actorId, revision, requestedCapacity, amount);
                    prepareResult = purchaseStore.prepare(retryIntent);
                }
            } catch (StorageException | IllegalArgumentException exception) {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
            }
        }

        // Handle prepare statuses
                switch (prepareResult.status()) {
                    case CREATED -> {
                        // New operation created; continue flow
                    }
                    case DUPLICATE_REQUEST -> {
                        return handleExistingOperation(idempotencyKey, businessOperationId);
                    }
                    case IDEMPOTENCY_KEY_CONFLICT -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.IDEMPOTENCY_KEY_CONFLICT,
                                Optional.empty());
                    }
                    case OPERATION_ID_CONFLICT -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.OPERATION_ID_CONFLICT,
                                Optional.empty());
                    }
                    case BUSINESS_OPERATION_CONFLICT -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.BUSINESS_OPERATION_CONFLICT,
                                Optional.empty());
                    }
                    case CLAN_NOT_FOUND -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.CLAN_NOT_FOUND,
                                Optional.empty());
                    }
                    case LEADER_CHANGED -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.LEADER_CHANGED,
                                Optional.empty());
                    }
                    case STATE_CONFLICT -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.STATE_CONFLICT,
                                Optional.empty());
                    }
                    default -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                                Optional.empty());
                    }
                }

        // At this point we have a freshly created operation in PREPARED state
        // Transition PREPARED -> CALLING before invoking the external provider
        try {
            CapacityPurchaseStore.TransitionResult callingTransition =
                    purchaseStore.transition(
                            intent.operationId(),
                            CapacityPurchaseState.PREPARED,
                            CapacityPurchaseState.CALLING,
                            CapacityPurchaseTransitionEvidence.NONE,
                            null);
            if (callingTransition.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.TRANSITION_FAILED,
                        Optional.empty());
            }
        } catch (StorageException e) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED,
                    Optional.empty());
        }

        // 5. Call external payment provider via PaymentPort
        PaymentPort.PaymentResult paymentResult;
        try {
            paymentResult = paymentPort.debit(actorId, amount, "clan-expand-" + clanId);
        } catch (PaymentPort.PaymentException e) {
            // Technical failure in payment provider - treat as unknown result
            // Do NOT automatically retry; leave operation in a state requiring manual review
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.PAYMENT_PROVIDER_ERROR,
                    Optional.empty());
        }

        // 6. Validate and interpret the provider response. A malformed or contradictory
        // response is uncertainty, never permission to retry a debit or claim failure.
        if (paymentResult == null || (paymentResult.success() && paymentResult.unknown())) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.UNKNOWN_RESULT, Optional.empty());
        }
        boolean debitSuccess = paymentResult.success();
        boolean debitUnknown = paymentResult.unknown();

        if (debitUnknown) {
            // Result unknown - do NOT automatically retry
            // Transition to UNKNOWN state with appropriate evidence
            try {
                CapacityPurchaseStore.TransitionResult transitionResult =
                        purchaseStore.transition(
                                intent.operationId(),
                                CapacityPurchaseState.CALLING,
                                CapacityPurchaseState.UNKNOWN,
                                CapacityPurchaseTransitionEvidence.DEBIT_RESULT_UNKNOWN_REPORTED,
                                paymentResult.providerOperationId());

                if (transitionResult.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
                    // Transition failed - operation may be in a safe terminal state
                    return new CapacityExpansionResult(
                            CapacityExpansionResult.Status.UNKNOWN_RESULT,
                            Optional.empty());
                }
            } catch (StorageException e) {
                // Journal validation failed - corrupted history
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.HISTORY_CORRUPTED,
                        Optional.empty());
            }
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.UNKNOWN_RESULT,
                    Optional.empty());
        }

        if (debitSuccess) {
            // Debit succeeded - transition to DEBIT_CONFIRMED
            try {
                CapacityPurchaseStore.TransitionResult transitionResult =
                        purchaseStore.transition(
                                intent.operationId(),
                                CapacityPurchaseState.CALLING,
                                CapacityPurchaseState.DEBIT_CONFIRMED,
                                CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                                paymentResult.providerOperationId());

                if (transitionResult.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
                    return new CapacityExpansionResult(
                            CapacityExpansionResult.Status.TRANSITION_FAILED,
                            Optional.empty());
                }
            } catch (StorageException e) {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.HISTORY_CORRUPTED,
                        Optional.empty());
            }

            // 7. Attempt atomic commit
            try {
                CapacityPurchaseStore.CommitResult commitResult =
                        purchaseStore.commitCapacityPurchase(intent.operationId());

                switch (commitResult.status()) {
                    case COMMITTED -> {
                        // Read the updated clan state
                        Clan updated = clanCatalog.findById(clanId).orElse(current);
            return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.EXPANDED,
                                Optional.of(updated));
                    }
                    case ALREADY_COMMITTED -> {
                        // Already committed - read current state
                        Clan updated = clanCatalog.findById(clanId).orElse(current);
            return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.EXPANDED,
                                Optional.of(updated));
                    }
                    case WRONG_STATE, CLAN_NOT_FOUND, LEADER_CHANGED,
                            STATE_CONFLICT, BUSINESS_OPERATION_CONFLICT -> {
                        // The debit is confirmed, but the local business operation did not commit.
                        // Persist and execute the compensation through the complete state machine.
                        CapacityPurchaseOperation confirmed = purchaseStore
                                .findByIdempotencyKey(idempotencyKey)
                                .orElse(null);
                        if (confirmed == null || confirmed.state() != CapacityPurchaseState.DEBIT_CONFIRMED) {
                            return new CapacityExpansionResult(
                                    CapacityExpansionResult.Status.STATE_CONFLICT, Optional.empty());
                        }
                        return initiateCompensation(confirmed, "CAPACITY_COMMIT_" + commitResult.status());
                    }
                    case HISTORY_EVIDENCE_UNVERIFIABLE -> {
                        // Do not issue a refund when the durable history cannot be trusted.
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.HISTORY_EVIDENCE_UNVERIFIABLE,
                                Optional.empty());
                    }
                    case OPERATION_NOT_FOUND -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.COMMIT_FAILED, Optional.empty());
                    }
                    default -> {
                        return new CapacityExpansionResult(
                                CapacityExpansionResult.Status.COMMIT_FAILED, Optional.empty());
                    }
                }
            } catch (StorageException e) {
                // Journal validation failed during commit - corrupted history
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.HISTORY_CORRUPTED,
                        Optional.empty());
            }
        } else {
            // Debit failed (insufficient funds, etc.)
            try {
                CapacityPurchaseStore.TransitionResult transitionResult =
                        purchaseStore.transition(
                                intent.operationId(),
                                CapacityPurchaseState.CALLING,
                                CapacityPurchaseState.FAILED_NO_EFFECT,
                                CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED,
                                paymentResult.providerOperationId());

                if (transitionResult.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
                    return new CapacityExpansionResult(
                            CapacityExpansionResult.Status.TRANSITION_FAILED,
                            Optional.empty());
                }
            } catch (StorageException e) {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.HISTORY_CORRUPTED,
                        Optional.empty());
            }
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.EXPANSION_FAILED,
                    Optional.empty());
        }
    }

    /**
     * Handles lookup of an existing operation when a duplicate or conflicting idempotency key
         * is detected during prepare. Implements safe compensation for concurrent purchases.
     */
    private CapacityExpansionResult handleExistingOperation(
            String idempotencyKey,
            String businessOperationId) {

        // Look up by idempotency key
        Optional<CapacityPurchaseOperation> existing =
                purchaseStore.findByIdempotencyKey(idempotencyKey);

        if (existing.isEmpty()) {
            // Operation disappeared - this should not happen; treat as a new creation
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                    Optional.empty());
        }

        CapacityPurchaseOperation op = existing.get();

        // Check the operation state and return appropriate result
        switch (op.state()) {
            case PREPARED -> {
                // PREPARED proves the external call was not started; it is safe to resume once.
                return resumePreparedOperation(op);
            }
            case CALLING -> {
                // External call in progress - cannot safely re-attempt
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.EXPANSION_IN_PROGRESS,
                        Optional.empty());
            }
            case DEBIT_CONFIRMED -> {
                // Debit confirmed but not yet committed - check if already committed
                try {
                    CapacityPurchaseStore.CommitResult commitResult =
                            purchaseStore.commitCapacityPurchase(op.operationId());

                    switch (commitResult.status()) {
                        case COMMITTED -> {
                            Clan updated = clanCatalog.findById(op.clanId()).orElse(null);
                            return new CapacityExpansionResult(
                                    CapacityExpansionResult.Status.EXPANDED,
                                    Optional.ofNullable(updated));
                        }
                        case ALREADY_COMMITTED -> {
                            Clan updated = clanCatalog.findById(op.clanId()).orElse(null);
                            return new CapacityExpansionResult(
                                    CapacityExpansionResult.Status.EXPANDED,
                                    Optional.ofNullable(updated));
                        }
                        case WRONG_STATE, CLAN_NOT_FOUND, LEADER_CHANGED,
                                STATE_CONFLICT, BUSINESS_OPERATION_CONFLICT -> {
                            return initiateCompensation(
                                    op, "RECOVERED_DEBIT_NOT_COMMITTED_" + commitResult.status());
                        }
                        case HISTORY_EVIDENCE_UNVERIFIABLE -> {
                            return new CapacityExpansionResult(
                                    CapacityExpansionResult.Status.HISTORY_EVIDENCE_UNVERIFIABLE,
                                    Optional.empty());
                        }
                        default -> {
                            return new CapacityExpansionResult(
                                    CapacityExpansionResult.Status.COMMIT_FAILED,
                                    Optional.empty());
                        }
                    }
                } catch (StorageException e) {
                    return new CapacityExpansionResult(
                            CapacityExpansionResult.Status.HISTORY_CORRUPTED,
                            Optional.empty());
                }
            }
            case COMMITTED -> {
                Clan updated = clanCatalog.findById(op.clanId()).orElse(null);
                if (updated != null) {
                    return new CapacityExpansionResult(
                            CapacityExpansionResult.Status.EXPANDED,
                            Optional.of(updated));
                }
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.CLAN_NOT_FOUND,
                        Optional.empty());
            }
            case UNKNOWN -> {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.UNKNOWN_RESULT,
                        Optional.empty());
            }
            case COMPENSATION_PENDING -> {
                return resumePendingCompensation(op, "RESUME_PENDING_COMPENSATION");
            }
            case COMPENSATION_CALLING -> {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.COMPENSATION_REQUIRED, Optional.empty());
            }
            case COMPENSATION_UNKNOWN -> {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.COMPENSATION_UNKNOWN, Optional.empty());
            }
            case COMPENSATED -> {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.COMPENSATED, Optional.empty());
            }
            case COMPENSATION_FAILED -> {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.COMPENSATION_FAILED, Optional.empty());
            }
            case FAILED_NO_EFFECT -> {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.EXPANSION_FAILED,
                        Optional.empty());
            }
            default -> {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION,
                        Optional.empty());
            }
        }
        }

    /** Resumes a PREPARED operation; the durable state proves no debit call has started yet. */
    private CapacityExpansionResult resumePreparedOperation(CapacityPurchaseOperation operation) {
        CapacityPurchaseStore.TransitionResult calling;
        try {
            calling = purchaseStore.transition(
                    operation.operationId(),
                    CapacityPurchaseState.PREPARED,
                    CapacityPurchaseState.CALLING,
                    CapacityPurchaseTransitionEvidence.NONE,
                    null);
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }
        if (calling.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.TRANSITION_FAILED, Optional.empty());
        }

        final PaymentPort.PaymentResult debit;
        try {
            debit = paymentPort.debit(
                    operation.actorId(), operation.amount(), "clan-expand-" + operation.clanId());
        } catch (PaymentPort.PaymentException exception) {
            // CALLING is intentionally retained: the provider outcome may be unknown.
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.PAYMENT_PROVIDER_ERROR, Optional.empty());
        }

        if (debit == null || debit.unknown() || (debit.success() && debit.unknown())) {
            return transitionDebitOutcome(
                    operation,
                    CapacityPurchaseState.UNKNOWN,
                    CapacityPurchaseTransitionEvidence.DEBIT_RESULT_UNKNOWN_REPORTED,
                    debit == null ? null : debit.providerOperationId(),
                    CapacityExpansionResult.Status.UNKNOWN_RESULT);
        }
        if (!debit.success()) {
            return transitionDebitOutcome(
                    operation,
                    CapacityPurchaseState.FAILED_NO_EFFECT,
                    CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED,
                    debit.providerOperationId(),
                    CapacityExpansionResult.Status.EXPANSION_FAILED);
        }
        CapacityExpansionResult confirmed = transitionDebitOutcome(
                operation,
                CapacityPurchaseState.DEBIT_CONFIRMED,
                CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED,
                debit.providerOperationId(),
                CapacityExpansionResult.Status.DEBIT_CONFIRMED);
        if (confirmed.status() != CapacityExpansionResult.Status.DEBIT_CONFIRMED) {
            return confirmed;
        }

        CapacityPurchaseOperation persisted;
        try {
            persisted = purchaseStore.findByIdempotencyKey(operation.idempotencyKey())
                    .orElseThrow(() -> new StorageException(
                            "Recovered debit operation disappeared: " + operation.operationId()));
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }
        return commitConfirmedOperation(persisted);
    }

    private CapacityExpansionResult transitionDebitOutcome(
            CapacityPurchaseOperation operation,
            CapacityPurchaseState targetState,
            CapacityPurchaseTransitionEvidence evidence,
            String providerOperationId,
            CapacityExpansionResult.Status successStatus) {
        try {
            CapacityPurchaseStore.TransitionResult transition = purchaseStore.transition(
                    operation.operationId(), CapacityPurchaseState.CALLING,
                    targetState, evidence, providerOperationId);
            if (transition.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.TRANSITION_FAILED, Optional.empty());
            }
            return new CapacityExpansionResult(successStatus, Optional.empty());
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }
    }

    private CapacityExpansionResult commitConfirmedOperation(CapacityPurchaseOperation operation) {
        try {
            CapacityPurchaseStore.CommitResult commit =
                    purchaseStore.commitCapacityPurchase(operation.operationId());
            return switch (commit.status()) {
                case COMMITTED, ALREADY_COMMITTED -> {
                    Clan updated = clanCatalog.findById(operation.clanId()).orElse(null);
                    yield updated == null
                            ? new CapacityExpansionResult(
                                    CapacityExpansionResult.Status.CLAN_NOT_FOUND, Optional.empty())
                            : new CapacityExpansionResult(
                                    CapacityExpansionResult.Status.EXPANDED, Optional.of(updated));
                }
                case WRONG_STATE, CLAN_NOT_FOUND, LEADER_CHANGED,
                        STATE_CONFLICT, BUSINESS_OPERATION_CONFLICT ->
                        initiateCompensation(operation, "RESUMED_DEBIT_NOT_COMMITTED_" + commit.status());
                case HISTORY_EVIDENCE_UNVERIFIABLE -> new CapacityExpansionResult(
                        CapacityExpansionResult.Status.HISTORY_EVIDENCE_UNVERIFIABLE, Optional.empty());
                case OPERATION_NOT_FOUND -> new CapacityExpansionResult(
                        CapacityExpansionResult.Status.COMMIT_FAILED, Optional.empty());
                default -> new CapacityExpansionResult(
                        CapacityExpansionResult.Status.COMMIT_FAILED, Optional.empty());
            };
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }
    }

    /**
     * Starts compensation only after a confirmed debit could not be committed locally.
     * The intent and call are persisted as two separate transitions before contacting
     * the provider, so a restart can reconcile without issuing a second refund.
     */
    private CapacityExpansionResult initiateCompensation(
            CapacityPurchaseOperation op,
            String reason) {
        if (op.state() != CapacityPurchaseState.DEBIT_CONFIRMED) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.STATE_CONFLICT, Optional.empty());
        }

        CapacityPurchaseStore.TransitionResult pending;
        try {
            pending = purchaseStore.transition(
                    op.operationId(),
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseState.COMPENSATION_PENDING,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_REQUIRED_REPORTED,
                    op.providerOperationId());
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }
        if (pending.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.TRANSITION_FAILED, Optional.empty());
        }

        return startCompensationCall(op, reason);
    }

    private CapacityExpansionResult resumePendingCompensation(
            CapacityPurchaseOperation op, String reason) {
        if (op.state() != CapacityPurchaseState.COMPENSATION_PENDING) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.STATE_CONFLICT, Optional.empty());
        }
        return startCompensationCall(op, reason);
    }

    private CapacityExpansionResult startCompensationCall(
            CapacityPurchaseOperation op, String reason) {
        CapacityPurchaseStore.TransitionResult calling;
        try {
            calling = purchaseStore.transition(
                    op.operationId(),
                    CapacityPurchaseState.COMPENSATION_PENDING,
                    CapacityPurchaseState.COMPENSATION_CALLING,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED,
                    op.providerOperationId());
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }
        if (calling.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.TRANSITION_FAILED, Optional.empty());
        }

        String compensationId = "compensation-" + op.operationId();
        String originalProviderOperationId = op.providerOperationId();
        if (originalProviderOperationId == null || originalProviderOperationId.isBlank()) {
            return persistCompensationOutcome(
                    op, CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId, CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }

        final PaymentPort.CompensationResult result;
        try {
            result = paymentPort.compensate(
                    op.actorId(), op.amount(), originalProviderOperationId,
                    compensationId, "clan-expand-" + op.clanId() + ":" + reason);
        } catch (PaymentPort.PaymentException exception) {
            return persistCompensationOutcome(
                    op, CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId, CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }

        // Provider responses are assertions, not independently verified proof. Any malformed,
        // mismatched, or contradictory response must remain unresolved rather than imply no refund.
        if (result == null
                || !compensationId.equals(result.compensationId())
                || !originalProviderOperationId.equals(result.originalProviderOperationId())
                || (result.success() && result.unknown())) {
            return persistCompensationOutcome(
                    op, CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId, CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }

        if (result.unknown()) {
            return persistCompensationOutcome(
                    op, CapacityPurchaseState.COMPENSATION_UNKNOWN,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED,
                    compensationId, CapacityExpansionResult.Status.COMPENSATION_UNKNOWN);
        }
        if (result.success()) {
            return persistCompensationOutcome(
                    op, CapacityPurchaseState.COMPENSATED,
                    CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED,
                    compensationId, CapacityExpansionResult.Status.COMPENSATED);
        }
        return persistCompensationOutcome(
                op, CapacityPurchaseState.COMPENSATION_FAILED,
                CapacityPurchaseTransitionEvidence.COMPENSATION_NO_EFFECT_REPORTED,
                compensationId, CapacityExpansionResult.Status.COMPENSATION_FAILED);
    }

    private CapacityExpansionResult persistCompensationOutcome(
            CapacityPurchaseOperation operation,
            CapacityPurchaseState targetState,
            CapacityPurchaseTransitionEvidence evidence,
            String providerReference,
            CapacityExpansionResult.Status resultStatus) {
        try {
            CapacityPurchaseStore.TransitionResult transition = purchaseStore.transition(
                    operation.operationId(),
                    CapacityPurchaseState.COMPENSATION_CALLING,
                    targetState,
                    evidence,
                    providerReference);
            if (transition.status() != CapacityPurchaseStore.TransitionStatus.UPDATED) {
                return new CapacityExpansionResult(
                        CapacityExpansionResult.Status.TRANSITION_FAILED, Optional.empty());
            }
        } catch (StorageException exception) {
            return new CapacityExpansionResult(
                    CapacityExpansionResult.Status.HISTORY_CORRUPTED, Optional.empty());
        }
        return new CapacityExpansionResult(resultStatus, Optional.empty());
    }

                /**
                 * Recovers compensation operations left in COMPENSATION_CALLING state after a previous crash.
                 * Called during application startup (not on every user request).
                 * <p>
                 * For each such operation, this method:
                 * 1. Reconstructs the compensationId from the operation's UUID
                 * 2. Calls PaymentPort.reconcile() to check the actual refund result without re-issuing
                 * 3. Saves the reconciled state via the existing transition policy
                 * <p>
                 * This method NEVER calls compensate() for already-COMPENSATION_CALLING operations,
                 * preventing double refunds.
                 * <p>
                 * If reconciliation fails or returns UNKNOWN, the operation is left in a safe state
                 * (COMPENSATION_UNKNOWN or COMPENSATION_FAILED) for manual resolution.
                 * <p>
                 * If no CompensationRecovery is configured, this method is a no-op.
                 *
                 * @return list of recovery results for each operation processed
                 */
                public List<CapacityExpansionResult> recoverOnStartup() {
                    if (compensationRecovery == null) {
                        return List.of();
                    }
                    return compensationRecovery.recover();
                }
            }

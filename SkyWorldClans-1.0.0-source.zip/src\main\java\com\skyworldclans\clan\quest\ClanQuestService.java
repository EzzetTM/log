package com.skyworldclans.clan.quest;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.clan.xp.ClanXpService;

import java.time.Clock;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

/**
 * Clan quests: three daily, three weekly and one special quest per clan.
 *
 * <p>Money rewards are deliberately not implemented: the technical specification forbids inventing
 * their amounts, so only Clan XP is awarded (daily 100/200/350, weekly 500/1 000/1 750, special
 * 2 000/3 500/5 000). Targets come from the examples approved in the specification
 * (5 000 ore, 200 mobs, 10 000 resources, 5 wars). The contributor minimum is the approved
 * 1/3/5, reduced to the clan's actual size so a small clan is not permanently blocked; the
 * specification's proportional scaling formula is still an owner decision.</p>
 */
public final class ClanQuestService {
    private static final ZoneOffset ZONE = ZoneOffset.UTC;

    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final ClanXpService xpService;
    private final Clock clock;

    public ClanQuestService(ClanCatalog clans, SqliteClanStore store, ClanXpService xpService, Clock clock) {
        this.clans = Objects.requireNonNull(clans); this.store = Objects.requireNonNull(store);
        this.xpService = Objects.requireNonNull(xpService); this.clock = Objects.requireNonNull(clock);
    }

    /** Creates missing quests for the current period and expires finished ones. */
    public void ensureRotation(UUID clanId, Instant now) {
        Clan clan = clans.findById(clanId).orElse(null);
        if (clan == null) return;
        int clanSize = Math.max(1, clan.memberCount());
        createMissing(clanId, SqliteClanStore.ClanQuestCategory.DAILY, dailyPeriod(now), 3,
                periodEnd(now, true), clanSize, now);
        createMissing(clanId, SqliteClanStore.ClanQuestCategory.WEEKLY, weeklyPeriod(now), 3,
                weeklyEnd(now), clanSize, now);
        createMissing(clanId, SqliteClanStore.ClanQuestCategory.SPECIAL, monthlyPeriod(now), 1,
                monthlyEnd(now), clanSize, now);
    }

    private void createMissing(UUID clanId, SqliteClanStore.ClanQuestCategory category, String periodKey,
            int count, Instant expiresAt, int clanSize, Instant now) {
        List<SqliteClanStore.ClanQuest> active = store.findClanQuests(clanId, true).stream()
                .filter(quest -> quest.category() == category && quest.periodKey().equals(periodKey))
                .toList();
        if (active.size() >= count) return;
        int required = switch (category) {
            case DAILY -> 1;
            case WEEKLY -> 3;
            case SPECIAL -> 5;
        };
        int effectiveRequired = Math.min(required, clanSize);
        List<SqliteClanStore.ClanQuestMetric> metrics = new ArrayList<>(List.of(
                SqliteClanStore.ClanQuestMetric.values()));
        // Deterministic shuffle so the same clan and period always gets the same set.
        Collections.shuffle(metrics, new Random(Objects.hash(clanId, periodKey, category.name())));
        for (int slot = 1; slot <= count; slot++) {
            final int slotNumber = slot;
            boolean exists = active.stream().anyMatch(quest -> quest.slot() == slotNumber);
            if (exists) continue;
            var metric = metrics.get((slot - 1) % metrics.size());
            var difficulty = SqliteClanStore.ClanQuestDifficulty.values()[(slot - 1) % 3];
            int target = targetFor(metric);
            // War wins are a clan-level metric: they are recorded once per victory by the clan
            // leader, so requiring several distinct contributors would make the quest impossible.
            int requiredForQuest = metric == SqliteClanStore.ClanQuestMetric.WIN_WAR
                    ? 1 : effectiveRequired;
            store.insertClanQuest(UUID.randomUUID(), clanId, category.name(), difficulty.name(),
                    metric.name(), target, requiredForQuest, periodKey, slot, now, expiresAt);
        }
    }

    /** Applies event progress for one player; awards XP once when a quest completes. */
    public void recordProgress(UUID playerId, SqliteClanStore.ClanQuestMetric metric, int amount) {
        if (playerId == null || metric == null || amount <= 0) return;
        Clan clan = clans.findByPlayerId(playerId).orElse(null);
        if (clan == null) return;
        Instant now = clock.instant();
        ensureRotation(clan.id(), now);
        for (SqliteClanStore.ClanQuest quest : store.findClanQuests(clan.id(), true)) {
            if (quest.metric() != metric) continue;
            var result = store.applyClanQuestProgress(quest.questId(), playerId, amount, now);
            if (result.completed()) awardXp(result.quest());
        }
    }

    public void recordWarWin(UUID clanId) {
        if (clanId == null) return;
        Instant now = clock.instant();
        ensureRotation(clanId, now);
        for (SqliteClanStore.ClanQuest quest : store.findClanQuests(clanId, true)) {
            if (quest.metric() != SqliteClanStore.ClanQuestMetric.WIN_WAR) continue;
            // War wins are a clan-level metric: attribute progress to the leader when present.
            UUID actor = clans.findById(clanId).flatMap(Clan::leader)
                    .map(member -> member.playerId()).orElse(new UUID(0L, 0L));
            var result = store.applyClanQuestProgress(quest.questId(), actor, 1, now);
            if (result.completed()) awardXp(result.quest());
        }
    }

    public List<SqliteClanStore.ClanQuest> quests(UUID clanId) {
        if (clanId == null) return List.of();
        Instant now = clock.instant();
        ensureRotation(clanId, now);
        return store.findClanQuests(clanId, true);
    }

    public List<UUID> expireDue() {
        return store.expireDueClanQuests(clock.instant());
    }

    /** Refreshes the rotation for every clan; called by the scheduler. */
    public void rotateAll() {
        Instant now = clock.instant();
        for (UUID clanId : store.allClanIds()) {
            try {
                ensureRotation(clanId, now);
            } catch (RuntimeException ignored) {
                // A single clan must not stop the rotation for the rest.
            }
        }
    }

    private void awardXp(SqliteClanStore.ClanQuest quest) {
        if (!store.markClanQuestXpAwarded(quest.questId(), xpFor(quest.category(), quest.difficulty()),
                clock.instant())) return;
        xpService.award(quest.clanId(), xpEventFor(quest.category(), quest.difficulty()),
                null, "quest:" + quest.questId());
    }

    /** Quest XP uses the approved category × difficulty table; money rewards stay unimplemented. */
    static com.skyworldclans.clan.xp.ClanXpEventType xpEventFor(
            SqliteClanStore.ClanQuestCategory category, SqliteClanStore.ClanQuestDifficulty difficulty) {
        return switch (category) {
            case DAILY -> switch (difficulty) {
                case EASY -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_DAILY_EASY;
                case MEDIUM -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_DAILY_MEDIUM;
                case HARD -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_DAILY_HARD; };
            case WEEKLY -> switch (difficulty) {
                case EASY -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_WEEKLY_EASY;
                case MEDIUM -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_WEEKLY_MEDIUM;
                case HARD -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_WEEKLY_HARD; };
            case SPECIAL -> switch (difficulty) {
                case EASY -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_SPECIAL_EASY;
                case MEDIUM -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_SPECIAL_MEDIUM;
                case HARD -> com.skyworldclans.clan.xp.ClanXpEventType.QUEST_SPECIAL_HARD; };
        };
    }

    public static long xpFor(SqliteClanStore.ClanQuestCategory category,
            SqliteClanStore.ClanQuestDifficulty difficulty) {
        return switch (category) {
            case DAILY -> switch (difficulty) {
                case EASY -> 100; case MEDIUM -> 200; case HARD -> 350; };
            case WEEKLY -> switch (difficulty) {
                case EASY -> 500; case MEDIUM -> 1_000; case HARD -> 1_750; };
            case SPECIAL -> switch (difficulty) {
                case EASY -> 2_000; case MEDIUM -> 3_500; case HARD -> 5_000; };
        };
    }

    /** Targets are the examples approved in the technical specification. */
    static int targetFor(SqliteClanStore.ClanQuestMetric metric) {
        return switch (metric) {
            case MINE_BLOCK -> 5_000;
            case KILL_MOB -> 200;
            case COLLECT_ITEM -> 10_000;
            case WIN_WAR -> 5;
        };
    }

    static String dailyPeriod(Instant now) {
        return now.atZone(ZONE).toLocalDate().toString();
    }

    static String weeklyPeriod(Instant now) {
        var date = now.atZone(ZONE).toLocalDate();
        WeekFields fields = WeekFields.ISO;
        return date.get(fields.weekBasedYear()) + "-W"
                + String.format(Locale.ROOT, "%02d", date.get(fields.weekOfWeekBasedYear()));
    }

    static String monthlyPeriod(Instant now) {
        var date = now.atZone(ZONE).toLocalDate();
        return date.getYear() + "-" + String.format(Locale.ROOT, "%02d", date.getMonthValue());
    }

    static Instant periodEnd(Instant now, boolean daily) {
        return now.atZone(ZONE).toLocalDate().plusDays(1).atStartOfDay(ZONE).toInstant();
    }

    static Instant weeklyEnd(Instant now) {
        var date = now.atZone(ZONE).toLocalDate();
        var sunday = date.with(java.time.temporal.TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
        return sunday.plusDays(1).atStartOfDay(ZONE).toInstant();
    }

    static Instant monthlyEnd(Instant now) {
        var date = now.atZone(ZONE).toLocalDate();
        return date.withDayOfMonth(date.lengthOfMonth()).plusDays(1).atStartOfDay(ZONE).toInstant();
    }
}
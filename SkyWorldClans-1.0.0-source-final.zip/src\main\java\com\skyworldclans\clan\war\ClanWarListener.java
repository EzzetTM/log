package com.skyworldclans.clan.war;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.logging.Level;

/** Scores PvP deaths inside an active clan war and notifies both sides. */
public final class ClanWarListener implements Listener {
    private final SkyWorldClansPlugin plugin;
    private final ClanWarService wars;

    public ClanWarListener(SkyWorldClansPlugin plugin, ClanWarService wars) {
        this.plugin = plugin; this.wars = wars;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null) return;
        try {
            wars.onPvpKill(killer.getUniqueId(), victim.getUniqueId()).ifPresent(result -> {
                if (result.war() == null) return;
                if (result.war().state() == SqliteClanStore.ClanWarStatus.FINISHED) {
                    announceFinished(result.war());
                }
            });
        } catch (RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Could not record clan war kill for "
                    + killer.getUniqueId() + " -> " + victim.getUniqueId(), exception);
        }
    }

    public void announceFinished(SqliteClanStore.ClanWar war) {
        String message;
        if ("WIN".equals(war.outcome())) {
            String tag = plugin.getClanStore().findById(war.winnerClanId())
                    .map(clan -> clan.tag()).orElse("?");
            message = ChatColor.GOLD + "Война завершена. Победил клан [" + tag
                    + "]; военный фонд передан победителю.";
        } else {
            message = ChatColor.YELLOW + "Война завершена вничью; каждый клан получил свой взнос обратно.";
        }
        for (Player online : Bukkit.getOnlinePlayers()) {
            plugin.getClanStore().findByPlayerId(online.getUniqueId()).ifPresent(clan -> {
                if (war.involves(clan.id())) online.sendMessage(message);
            });
        }
        plugin.getLogger().info("Clan war " + war.warId() + " finished: outcome=" + war.outcome()
                + ", winner=" + war.winnerClanId());
    }
}

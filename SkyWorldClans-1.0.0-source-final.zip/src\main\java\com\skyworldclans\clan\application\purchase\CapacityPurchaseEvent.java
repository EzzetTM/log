package com.skyworldclans.clan.application.purchase;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/**
 * One append-only journal row.
 *
 * <p>{@code fromState} and {@code evidence} are the values the store actually wrote when the
 * transition happened. Both are {@code null} for the initial {@code PREPARED} registration event
 * (there is no preceding state) and for every {@link CapacityPurchaseEvidenceProvenance#
 * UNVERIFIED_LEGACY} row imported from schema versions 1-3, which never stored them.
 */
public record CapacityPurchaseEvent(
        long sequence,
        UUID operationId,
        CapacityPurchaseState fromState,
        CapacityPurchaseState toState,
        CapacityPurchaseTransitionEvidence evidence,
        CapacityPurchaseEvidenceProvenance evidenceProvenance,
        Instant occurredAt,
        String providerOperationId) {

    public CapacityPurchaseEvent {
        Objects.requireNonNull(operationId, "operationId");
        Objects.requireNonNull(toState, "toState");
        Objects.requireNonNull(evidenceProvenance, "evidenceProvenance");
        Objects.requireNonNull(occurredAt, "occurredAt");
        if (evidenceProvenance == CapacityPurchaseEvidenceProvenance.UNVERIFIED_LEGACY
                && (fromState != null || evidence != null)) {
            throw new IllegalArgumentException(
                    "An unverified legacy event must not claim a source state or evidence");
        }
        boolean initialRegistration
                = toState == CapacityPurchaseState.PREPARED && fromState == null && evidence == null;
        if (evidenceProvenance == CapacityPurchaseEvidenceProvenance.RECORDED
                && !initialRegistration
                && (fromState == null || evidence == null)) {
            throw new IllegalArgumentException(
                    "A recorded transition event requires both fromState and evidence");
        }
    }
}

package com.skyworldclans.clan.quest;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

import java.util.EnumSet;
import java.util.Set;

/** Feeds Bukkit gameplay events into the clan quest progress ledger. */
public final class ClanQuestListener implements Listener {
    private static final Set<Material> ORES = EnumSet.of(
            Material.COAL_ORE, Material.DEEPSLATE_COAL_ORE, Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE,
            Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE, Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE,
            Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE, Material.LAPIS_ORE,
            Material.DEEPSLATE_LAPIS_ORE, Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE,
            Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE, Material.NETHER_QUARTZ_ORE,
            Material.NETHER_GOLD_ORE, Material.ANCIENT_DEBRIS);

    private final SkyWorldClansPlugin plugin;
    private final ClanQuestService quests;

    public ClanQuestListener(SkyWorldClansPlugin plugin, ClanQuestService quests) {
        this.plugin = plugin; this.quests = quests;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.getPlayer() == null) return;
        if (!ORES.contains(event.getBlock().getType())) return;
        safe(() -> quests.recordProgress(event.getPlayer().getUniqueId(),
                SqliteClanStore.ClanQuestMetric.MINE_BLOCK, 1), "block break");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null || event.getEntity() instanceof Player) return;
        safe(() -> quests.recordProgress(killer.getUniqueId(),
                SqliteClanStore.ClanQuestMetric.KILL_MOB, 1), "mob kill");
    }

    @SuppressWarnings("deprecation")
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(PlayerPickupItemEvent event) {
        int amount = Math.max(1, event.getItem().getItemStack().getAmount());
        safe(() -> quests.recordProgress(event.getPlayer().getUniqueId(),
                SqliteClanStore.ClanQuestMetric.COLLECT_ITEM, amount), "item pickup");
    }

    private void safe(Runnable action, String what) {
        try {
            action.run();
        } catch (RuntimeException exception) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE,
                    "Clan quest progress failed for " + what, exception);
        }
    }
}
package com.skyworldclans.clan.application.purchase;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;

import java.util.Objects;
import java.util.UUID;

public record CapacityPurchaseIntent(
        UUID operationId,
        String idempotencyKey,
        String businessOperationId,
        Clan expectedClan,
        UUID actorId,
        long expectedRevision,
        int targetCapacity,
        long amount) {

    public CapacityPurchaseIntent {
        Objects.requireNonNull(operationId, "operationId");
        Objects.requireNonNull(idempotencyKey, "idempotencyKey");
        Objects.requireNonNull(businessOperationId, "businessOperationId");
        Objects.requireNonNull(expectedClan, "expectedClan");
        Objects.requireNonNull(actorId, "actorId");
        if (expectedRevision < 0) {
            throw new IllegalArgumentException("expectedRevision must not be negative");
        }
        if (idempotencyKey.isBlank()) {
            throw new IllegalArgumentException("idempotencyKey must not be blank");
        }
        if (businessOperationId.isBlank()) {
            throw new IllegalArgumentException("businessOperationId must not be blank");
        }
        if (expectedClan.leader()
                .map(leader -> !leader.playerId().equals(actorId))
                .orElse(true)) {
            throw new IllegalArgumentException("actorId must be the current leader");
        }
        if (!ClanCapacityPolicy.isValidCapacity(targetCapacity) || amount < 0) {
            throw new IllegalArgumentException("Invalid capacity purchase intent");
        }
    }
}

package com.skyworldclans.clan.application.creation;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.ClanFactory;
import com.skyworldclans.clan.application.ClanCreationPreflightResult;
import com.skyworldclans.clan.application.CreateClanCommand;
import com.skyworldclans.clan.application.CreateClanUseCase;
import com.skyworldclans.integration.EconomyOperations;

import java.time.Clock;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Coordinates clan creation with a durable debit intent. An ambiguous Vault result is never
 * retried automatically because Vault's generic Economy API has no idempotency/reconciliation key.
 */
public final class ClanCreationCoordinator {
    private static final double PRICE = 1_000_000.0d;

    private final CreateClanUseCase preflight;
    private final ClanCreationPaymentJournal journal;
    private final Optional<EconomyOperations> economy;
    private final Clock clock;
    private final Supplier<UUID> ids;

    public ClanCreationCoordinator(CreateClanUseCase preflight, ClanCreationPaymentJournal journal,
            Optional<EconomyOperations> economy, Clock clock, Supplier<UUID> ids) {
        this.preflight = Objects.requireNonNull(preflight, "preflight");
        this.journal = Objects.requireNonNull(journal, "journal");
        this.economy = Objects.requireNonNull(economy, "economy");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.ids = Objects.requireNonNull(ids, "ids");
    }

    public Result create(CreateClanCommand command) {
        if (economy.isEmpty()) return result(Status.ECONOMY_UNAVAILABLE);
        ClanCreationPreflightResult checked;
        try {
            checked = preflight.prepare(command);
        } catch (RuntimeException exception) {
            return result(Status.STORAGE_ERROR);
        }
        if (checked.status() != ClanCreationPreflightResult.Status.READY)
            return new Result(Status.PREFLIGHT_REJECTED, Optional.empty(), Optional.of(checked.status()), Optional.empty(), Optional.empty());
        Clan clan = checked.clan().orElseThrow();
        UUID operationId = Objects.requireNonNull(ids.get(), "operation id supplier returned null");
        UUID key = Objects.requireNonNull(ids.get(), "idempotency key supplier returned null");
        var now = clock.instant();
        ClanCreationPaymentOperation operation = new ClanCreationPaymentOperation(
                operationId, key.toString(), command.creatorId(), clan.id(), clan.name(), clan.tag(),
                clan.tagline(), clan.createdAt(), ClanCreationPaymentOperation.CREATION_PRICE_UNITS,
                ClanCreationPaymentState.PREPARED, null, now, now);
        ClanCreationPaymentJournal.CreationPrepareResult prepared;
        try {
            prepared = journal.prepare(operation);
        } catch (RuntimeException exception) {
            return result(Status.STORAGE_ERROR, operationId);
        }
        if (prepared.status() != ClanCreationPaymentJournal.CreationPrepareStatus.CREATED) {
            if (prepared.status() == ClanCreationPaymentJournal.CreationPrepareStatus.PLAYER_ALREADY_IN_CLAN)
                return preflightRejected(ClanCreationPreflightResult.Status.CREATOR_ALREADY_IN_CLAN);
            if (prepared.status() == ClanCreationPaymentJournal.CreationPrepareStatus.TAG_TAKEN)
                return preflightRejected(ClanCreationPreflightResult.Status.TAG_TAKEN);
            return result(mapPrepareStatus(prepared.status()), prepared.operation().map(ClanCreationPaymentOperation::operationId).orElse(null));
        }

        ClanCreationPaymentJournal.CreationTransitionResult calling;
        try {
            calling = journal.transition(operationId, ClanCreationPaymentState.PREPARED,
                    ClanCreationPaymentState.CALLING, null, clock.instant());
        } catch (RuntimeException exception) {
            return result(Status.STORAGE_ERROR, operationId);
        }
        if (calling.status() != ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED)
            return result(Status.STORAGE_ERROR, operationId);

        EconomyOperations.OperationResult debit;
        try {
            debit = economy.orElseThrow().withdraw(command.creatorId(), PRICE);
        } catch (RuntimeException exception) {
            debit = new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN,
                    safeDiagnostic(exception));
        }
        if (debit == null) debit = new EconomyOperations.OperationResult(
                EconomyOperations.Status.UNKNOWN, "Economy provider returned no result");

        if (debit.status() == EconomyOperations.Status.INSUFFICIENT_FUNDS
                || debit.status() == EconomyOperations.Status.PROVIDER_FAILURE
                || debit.status() == EconomyOperations.Status.INVALID_INPUT) {
            try {
                var failed = journal.transition(operationId, ClanCreationPaymentState.CALLING,
                        ClanCreationPaymentState.FAILED_NO_EFFECT, debit.diagnostic(), clock.instant());
                return result(failed.status() == ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED
                        ? (debit.status() == EconomyOperations.Status.INSUFFICIENT_FUNDS
                            ? Status.INSUFFICIENT_FUNDS : Status.PAYMENT_REJECTED)
                        : Status.PAYMENT_RESULT_UNCERTAIN, operationId);
            } catch (RuntimeException exception) {
                return result(Status.PAYMENT_RESULT_UNCERTAIN, operationId);
            }
        }
        if (debit.status() != EconomyOperations.Status.SUCCESS) {
            try {
                journal.transition(operationId, ClanCreationPaymentState.CALLING,
                        ClanCreationPaymentState.UNKNOWN, debit.diagnostic(), clock.instant());
            } catch (RuntimeException ignored) {
                // CALLING is treated as UNKNOWN on startup; never issue another debit.
            }
            return result(Status.PAYMENT_RESULT_UNCERTAIN, operationId);
        }

        ClanCreationPaymentJournal.CreationTransitionResult confirmed;
        try {
            confirmed = journal.transition(operationId, ClanCreationPaymentState.CALLING,
                    ClanCreationPaymentState.DEBIT_CONFIRMED, null, clock.instant());
        } catch (RuntimeException exception) {
            return result(Status.PAYMENT_RESULT_UNCERTAIN, operationId);
        }
        if (confirmed.status() != ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED)
            return result(Status.PAYMENT_RESULT_UNCERTAIN, operationId);
        return finishConfirmed(operationId);
    }

    /** Startup recovery never repeats an external debit. */
    public List<Result> recoverAfterRestart() {
        java.util.ArrayList<Result> results = new java.util.ArrayList<>();
        for (ClanCreationPaymentOperation operation : journal.findUnresolvedCreations()) {
            switch (operation.state()) {
                case PREPARED -> {
                    var transition = journal.transition(operation.operationId(), ClanCreationPaymentState.PREPARED,
                            ClanCreationPaymentState.FAILED_NO_EFFECT,
                            "Server restarted before the provider call began; no debit was issued", clock.instant());
                    results.add(result(transition.status() == ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED
                            ? Status.INTERRUPTED_BEFORE_PAYMENT : Status.STORAGE_ERROR, operation.operationId()));
                }
                case CALLING -> {
                    var transition = journal.transition(operation.operationId(), ClanCreationPaymentState.CALLING,
                            ClanCreationPaymentState.UNKNOWN,
                            "Server restarted while the provider call result was not durably recorded", clock.instant());
                    results.add(result(transition.status() == ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED
                            ? Status.MANUAL_RECONCILIATION_REQUIRED : Status.STORAGE_ERROR, operation.operationId()));
                }
                case DEBIT_CONFIRMED -> results.add(finishConfirmed(operation.operationId()));
                case UNKNOWN -> results.add(result(Status.MANUAL_RECONCILIATION_REQUIRED, operation.operationId()));
                case COMMITTED, FAILED_NO_EFFECT -> { }
            }
        }
        return List.copyOf(results);
    }

    private Result finishConfirmed(UUID operationId) {
        ClanCreationPaymentOperation operation;
        try {
            operation = journal.findCreationById(operationId).orElse(null);
        } catch (RuntimeException exception) {
            return result(Status.PAYMENT_CONFIRMED_REGISTRATION_PENDING, operationId);
        }
        if (operation == null || operation.state() != ClanCreationPaymentState.DEBIT_CONFIRMED)
            return result(Status.STORAGE_ERROR, operationId);
        Clan clan = new ClanFactory().create(operation.clanId(), operation.name(), operation.tag(),
                operation.creatorId(), operation.clanCreatedAt(), operation.clanCreatedAt(), operation.slogan());
        ClanCreationPaymentJournal.CreationCommitResult committed;
        try {
            committed = journal.commitPaidClan(operationId, clan, clock.instant());
        } catch (RuntimeException exception) {
            return result(Status.PAYMENT_CONFIRMED_REGISTRATION_PENDING, operationId);
        }
        return switch (committed.status()) {
            case COMMITTED -> new Result(Status.CREATED, committed.clan(), Optional.empty(), Optional.empty(), Optional.of(operationId));
            case NOT_DEBIT_CONFIRMED -> result(Status.PAYMENT_NOT_CONFIRMED, operationId);
            case NOT_FOUND -> result(Status.STORAGE_ERROR, operationId);
            case CLAN_MISMATCH, TAG_CONFLICT, MEMBER_CONFLICT, CLAN_ID_CONFLICT -> result(Status.PAYMENT_CONFIRMED_REGISTRATION_PENDING, operationId);
        };
    }

    /**
     * Resolves an UNKNOWN Vault operation after a trusted console operator has checked the
     * provider's own transaction records. The supplied evidence is retained in the append-only log.
     */
    public Result reconcileUnknown(UUID operationId, boolean debitConfirmed, String evidence) {
        if (operationId == null || evidence == null || evidence.isBlank())
            return result(Status.RECONCILIATION_FAILED, operationId);
        if (evidence.length() > 900) return result(Status.RECONCILIATION_FAILED, operationId);
        ClanCreationPaymentOperation operation;
        try {
            operation = journal.findCreationById(operationId).orElse(null);
        } catch (RuntimeException exception) {
            return result(Status.STORAGE_ERROR, operationId);
        }
        if (operation == null) return result(Status.OPERATION_NOT_FOUND, operationId);
        if (operation.state() != ClanCreationPaymentState.UNKNOWN)
            return result(Status.OPERATION_NOT_UNKNOWN, operationId);
        ClanCreationPaymentState next = debitConfirmed
                ? ClanCreationPaymentState.DEBIT_CONFIRMED : ClanCreationPaymentState.FAILED_NO_EFFECT;
        String diagnostic = (debitConfirmed ? "CONSOLE_RECONCILIATION_PAID: "
                : "CONSOLE_RECONCILIATION_NO_DEBIT: ") + evidence;
        ClanCreationPaymentJournal.CreationTransitionResult transition;
        try {
            transition = journal.transition(operationId, ClanCreationPaymentState.UNKNOWN,
                    next, diagnostic, clock.instant());
        } catch (RuntimeException exception) {
            return result(Status.RECONCILIATION_FAILED, operationId);
        }
        if (transition.status() != ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED)
            return result(Status.RECONCILIATION_FAILED, operationId);
        return debitConfirmed ? finishConfirmed(operationId)
                : result(Status.RECONCILED_NO_DEBIT, operationId);
    }

    private static Status mapPrepareStatus(ClanCreationPaymentJournal.CreationPrepareStatus status) {
        return switch (status) {
            case CREATED -> Status.STORAGE_ERROR;
            case DUPLICATE, IDEMPOTENCY_CONFLICT, OPERATION_CONFLICT -> Status.DUPLICATE_OR_CONFLICT;
            case PLAYER_ALREADY_IN_CLAN, TAG_TAKEN -> Status.PREFLIGHT_REJECTED;
            case PLAYER_HAS_UNRESOLVED_CREATION -> Status.MANUAL_RECONCILIATION_REQUIRED;
        };
    }

    private static String safeDiagnostic(RuntimeException exception) {
        String message = exception.getMessage();
        String value = message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
        return value.length() > 1000 ? value.substring(0, 1000) : value;
    }

    private static Result preflightRejected(ClanCreationPreflightResult.Status status) {
        return new Result(Status.PREFLIGHT_REJECTED, Optional.empty(), Optional.of(status), Optional.empty(), Optional.empty());
    }

    private static Result result(Status status) {
        return result(status, null);
    }

    private static Result result(Status status, UUID operationId) {
        return new Result(status, Optional.empty(), Optional.empty(), Optional.empty(), Optional.ofNullable(operationId));
    }

    public enum Status { CREATED, ECONOMY_UNAVAILABLE, PREFLIGHT_REJECTED, INSUFFICIENT_FUNDS,
        PAYMENT_REJECTED, PAYMENT_RESULT_UNCERTAIN, PAYMENT_CONFIRMED_REGISTRATION_PENDING,
        PAYMENT_NOT_CONFIRMED, MANUAL_RECONCILIATION_REQUIRED, INTERRUPTED_BEFORE_PAYMENT,
        RECONCILED_NO_DEBIT, RECONCILIATION_FAILED, OPERATION_NOT_FOUND, OPERATION_NOT_UNKNOWN,
        DUPLICATE_OR_CONFLICT, STORAGE_ERROR }

    public record Result(Status status, Optional<Clan> clan,
            Optional<ClanCreationPreflightResult.Status> preflightStatus,
            Optional<String> diagnostic, Optional<UUID> operationId) {
        public Result {
            Objects.requireNonNull(status); Objects.requireNonNull(clan);
            Objects.requireNonNull(preflightStatus); Objects.requireNonNull(diagnostic); Objects.requireNonNull(operationId);
            if ((status == Status.CREATED) != clan.isPresent())
                throw new IllegalArgumentException("Only a created result contains a clan");
        }
    }
}

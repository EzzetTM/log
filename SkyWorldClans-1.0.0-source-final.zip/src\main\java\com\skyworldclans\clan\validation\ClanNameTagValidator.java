package com.skyworldclans.clan.validation;

public final class ClanNameTagValidator {
    private static final int MIN_NAME_LENGTH = 3;
    private static final int MAX_NAME_LENGTH = 16;
    private static final int MIN_TAG_LENGTH = 2;
    private static final int MAX_TAG_LENGTH = 5;

    private ClanNameTagValidator() {
    }

    public static boolean isValidName(String name) {
        if (name == null) {
            return false;
        }

        int length = name.codePointCount(0, name.length());
        return length >= MIN_NAME_LENGTH && length <= MAX_NAME_LENGTH;
    }

    public static boolean isValidTag(String tag) {
        if (tag == null || tag.length() < MIN_TAG_LENGTH || tag.length() > MAX_TAG_LENGTH) {
            return false;
        }

        for (int i = 0; i < tag.length(); i++) {
            char character = tag.charAt(i);
            if (!((character >= 'A' && character <= 'Z')
                    || (character >= 'a' && character <= 'z')
                    || (character >= '0' && character <= '9'))) {
                return false;
            }
        }
        return true;
    }
}

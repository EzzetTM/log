package com.skyworldclans.clan.application.creation;

import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ClanCreationRecoveryPolicyTest {
    private ClanCreationPaymentOperation operation(ClanCreationPaymentState state) {
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        return new ClanCreationPaymentOperation(UUID.randomUUID(), UUID.randomUUID().toString(),
                UUID.randomUUID(), UUID.randomUUID(), "Test Clan", "TEST", null,
                now, ClanCreationPaymentOperation.CREATION_PRICE_UNITS, state, null, now, now);
    }

    @Test void preparedOperationMayBeAbortedWithoutPaymentAfterRestart() {
        assertEquals(ClanCreationRecoveryAction.SAFE_TO_ABORT_WITHOUT_PAYMENT,
                ClanCreationRecoveryPolicy.classify(operation(ClanCreationPaymentState.PREPARED)));
    }

    @Test void confirmedDebitMayFinishRegistrationWithoutAnotherDebit() {
        assertEquals(ClanCreationRecoveryAction.SAFE_TO_FINISH_REGISTRATION,
                ClanCreationRecoveryPolicy.classify(operation(ClanCreationPaymentState.DEBIT_CONFIRMED)));
    }

    @Test void interruptedProviderCallRequiresReconciliationAndMustNotBeRetried() {
        assertEquals(ClanCreationRecoveryAction.REQUIRES_EXTERNAL_RECONCILIATION,
                ClanCreationRecoveryPolicy.classify(operation(ClanCreationPaymentState.CALLING)));
        assertEquals(ClanCreationRecoveryAction.REQUIRES_EXTERNAL_RECONCILIATION,
                ClanCreationRecoveryPolicy.classify(operation(ClanCreationPaymentState.UNKNOWN)));
    }

    @Test void terminalStatesAreComplete() {
        assertEquals(ClanCreationRecoveryAction.COMPLETED,
                ClanCreationRecoveryPolicy.classify(operation(ClanCreationPaymentState.COMMITTED)));
        assertEquals(ClanCreationRecoveryAction.COMPLETED,
                ClanCreationRecoveryPolicy.classify(operation(ClanCreationPaymentState.FAILED_NO_EFFECT)));
    }
}

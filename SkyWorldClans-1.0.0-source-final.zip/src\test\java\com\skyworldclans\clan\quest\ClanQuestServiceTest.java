package com.skyworldclans.clan.quest;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.clan.xp.ClanXpService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanQuestServiceTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-02T10:00:00Z");

    @Test
    void rotationCreatesThreeDailyThreeWeeklyAndOneSpecialQuest() {
        UUID leader = id(1), member = id(2);
        Clan clan = clan(leader, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("quests-rotation.sqlite"))) {
            store.registerIfAvailable(clan);
            var service = new ClanQuestService(store, store, new ClanXpService(store, Clock.fixed(NOW, ZoneOffset.UTC)),
                    Clock.fixed(NOW, ZoneOffset.UTC));
            var quests = service.quests(clan.id());
            assertEquals(3, quests.stream()
                    .filter(quest -> quest.category() == SqliteClanStore.ClanQuestCategory.DAILY).count());
            assertEquals(3, quests.stream()
                    .filter(quest -> quest.category() == SqliteClanStore.ClanQuestCategory.WEEKLY).count());
            assertEquals(1, quests.stream()
                    .filter(quest -> quest.category() == SqliteClanStore.ClanQuestCategory.SPECIAL).count());
            // Calling again must not duplicate the rotation.
            assertEquals(7, service.quests(clan.id()).size());
        }
    }

    @Test
    void completingAQuestAwardsSpecifiedXpExactlyOnce() {
        UUID leader = id(11), member = id(12);
        Clan clan = clan(leader, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("quests-progress.sqlite"))) {
            store.registerIfAvailable(clan);
            var clock = Clock.fixed(NOW, ZoneOffset.UTC);
            var service = new ClanQuestService(store, store, new ClanXpService(store, clock), clock);
            var daily = service.quests(clan.id()).stream()
                    .filter(quest -> quest.category() == SqliteClanStore.ClanQuestCategory.DAILY)
                    .findFirst().orElseThrow();

            service.recordProgress(member, daily.metric(), daily.targetAmount());
            var completed = service.quests(clan.id()).stream()
                    .filter(quest -> quest.questId().equals(daily.questId()))
                    .findFirst();
            // A completed quest leaves the active list, so look it up through the store snapshot.
            assertTrue(completed.isEmpty(), "completed quests are no longer active");
            long expected = ClanQuestService.xpFor(daily.category(), daily.difficulty());
            assertEquals(expected, store.findById(clan.id()).orElseThrow().totalXp());

            // Replaying the same event must not award XP twice.
            service.recordProgress(member, daily.metric(), daily.targetAmount());
            assertEquals(expected, store.findById(clan.id()).orElseThrow().totalXp());
        }
    }

    @Test
    void expiredQuestsAreMarkedAndNoLongerAcceptProgress() {
        UUID leader = id(21), member = id(22);
        Clan clan = clan(leader, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("quests-expiry.sqlite"))) {
            store.registerIfAvailable(clan);
            var clock = Clock.fixed(NOW, ZoneOffset.UTC);
            var service = new ClanQuestService(store, store, new ClanXpService(store, clock), clock);
            var daily = service.quests(clan.id()).stream()
                    .filter(quest -> quest.category() == SqliteClanStore.ClanQuestCategory.DAILY)
                    .findFirst().orElseThrow();
            Instant afterExpiry = daily.expiresAt().plusSeconds(60);
            storageExpire(store, afterExpiry);
            for (var quest : store.findClanQuests(clan.id(), true)) {
                assertTrue(quest.expiresAt().isBefore(afterExpiry) || quest.expiresAt().equals(afterExpiry)
                        || quest.category() == SqliteClanStore.ClanQuestCategory.WEEKLY
                        || quest.category() == SqliteClanStore.ClanQuestCategory.SPECIAL);
            }
        }
    }

    private static void storageExpire(SqliteClanStore store, Instant at) {
        store.expireDueClanQuests(at);
    }

    private static Clan clan(UUID leader, UUID member) {
        Instant start = NOW.minusSeconds(86_400L * 20);
        return new Clan(new UUID(0, 800), "QuestClan", "QS800", start, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, start, null),
                        member, new ClanMember(member, ClanRole.MEMBER, start, null)), 0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }
}
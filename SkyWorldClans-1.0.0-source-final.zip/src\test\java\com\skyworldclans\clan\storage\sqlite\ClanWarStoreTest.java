package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanWarStoreTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-01T12:00:00Z");

    @Test
    void warFundIsDebitedAtomicallyAndPaidToTheWinnerOnce() {
        Path database = temporaryDirectory.resolve("war-win.sqlite");
        Clan attacker = clan(1, "Attacker", "AT1");
        Clan defender = clan(2, "Defender", "DF2");
        UUID attackerLeader = attacker.leader().orElseThrow().playerId();
        UUID defenderLeader = defender.leader().orElseThrow().playerId();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(attacker));
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(defender));
            fund(store, attacker, attackerLeader, "100000");
            fund(store, defender, defenderLeader, "50000");

            UUID warId = UUID.randomUUID();
            assertEquals(SqliteClanStore.ClanWarResultStatus.CREATED,
                    store.declareClanWar(warId, attacker.id(), defender.id(), attackerLeader,
                            3, 3_600, NOW).status());
            assertEquals(SqliteClanStore.ClanWarStatus.PENDING, store.findClanWar(warId).orElseThrow().state());
            assertEquals(SqliteClanStore.ClanWarResultStatus.UPDATED,
                    store.acceptClanWar(warId, defenderLeader, NOW.plusSeconds(1)).status());

            assertEquals(SqliteClanStore.ClanWarResultStatus.UPDATED,
                    store.contributeToWarFund(warId, UUID.randomUUID(), attackerLeader,
                            new BigDecimal("40000"), NOW.plusSeconds(2)).status());
            assertEquals(SqliteClanStore.ClanWarResultStatus.UPDATED,
                    store.contributeToWarFund(warId, UUID.randomUUID(), defenderLeader,
                            new BigDecimal("25000"), NOW.plusSeconds(3)).status());
            assertEquals(new BigDecimal("60000"), store.clanBankBalance(attacker.id()));
            assertEquals(new BigDecimal("25000"), store.clanBankBalance(defender.id()));

            assertEquals(SqliteClanStore.ClanWarResultStatus.UPDATED,
                    store.recordClanWarKill(warId, attacker.id(), UUID.randomUUID(), NOW.plusSeconds(5)).status());
            assertEquals(1, store.findClanWar(warId).orElseThrow().attackerKills());
            var second = store.recordClanWarKill(warId, attacker.id(), UUID.randomUUID(), NOW.plusSeconds(6));
            assertEquals(SqliteClanStore.ClanWarStatus.ACTIVE, second.war().state());
            var third = store.recordClanWarKill(warId, attacker.id(), UUID.randomUUID(), NOW.plusSeconds(7));
            assertEquals(SqliteClanStore.ClanWarStatus.FINISHED, third.war().state());
            assertEquals("WIN", third.war().outcome());
            assertEquals(attacker.id(), third.war().winnerClanId());
            assertEquals(new BigDecimal("125000"), store.clanBankBalance(attacker.id()));
            assertEquals(new BigDecimal("25000"), store.clanBankBalance(defender.id()));
            assertEquals(1, store.countClanWarWins(attacker.id()));
            assertEquals(SqliteClanStore.ClanWarResultStatus.ALREADY_FINISHED,
                    store.surrenderClanWar(warId, defenderLeader, NOW.plusSeconds(8)).status());
            assertEquals(new BigDecimal("125000"), store.clanBankBalance(attacker.id()));
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(SqliteClanStore.ClanWarStatus.FINISHED, reopened.findClanWar(
                    reopened.findClanWars(attacker.id(), 10).get(0).warId()).orElseThrow().state());
            assertEquals(new BigDecimal("125000"), reopened.clanBankBalance(attacker.id()));
        }
    }

    @Test
    void expiredWarWithEqualScoreRefundsEachClanItsOwnFund() {
        Path database = temporaryDirectory.resolve("war-draw.sqlite");
        Clan attacker = clan(3, "DrawOne", "DR3");
        Clan defender = clan(4, "DrawTwo", "DR4");
        UUID attackerLeader = attacker.leader().orElseThrow().playerId();
        UUID defenderLeader = defender.leader().orElseThrow().playerId();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(attacker);
            store.registerIfAvailable(defender);
            fund(store, attacker, attackerLeader, "30000");
            fund(store, defender, defenderLeader, "70000");
            UUID warId = UUID.randomUUID();
            store.declareClanWar(warId, attacker.id(), defender.id(), attackerLeader,
                    100, 60, NOW);
            store.acceptClanWar(warId, defenderLeader, NOW.plusSeconds(1));
            store.contributeToWarFund(warId, UUID.randomUUID(), attackerLeader,
                    new BigDecimal("10000"), NOW.plusSeconds(2));
            store.contributeToWarFund(warId, UUID.randomUUID(), defenderLeader,
                    new BigDecimal("20000"), NOW.plusSeconds(3));

            var resolved = store.resolveDueClanWars(NOW.plusSeconds(62));
            assertEquals(1, resolved.size());
            assertEquals(SqliteClanStore.ClanWarStatus.FINISHED, resolved.get(0).state());
            assertEquals("DRAW", resolved.get(0).outcome());
            assertNull(resolved.get(0).winnerClanId());
            assertEquals(new BigDecimal("30000"), store.clanBankBalance(attacker.id()));
            assertEquals(new BigDecimal("70000"), store.clanBankBalance(defender.id()));
            assertEquals(0, store.countClanWarWins(attacker.id()));
        }
    }

    @Test
    void surrenderTransfersFundAndOpenWarBlocksSecondDeclaration() {
        Path database = temporaryDirectory.resolve("war-surrender.sqlite");
        Clan attacker = clan(5, "SurrenderOne", "SR5");
        Clan defender = clan(6, "SurrenderTwo", "SR6");
        UUID attackerLeader = attacker.leader().orElseThrow().playerId();
        UUID defenderLeader = defender.leader().orElseThrow().playerId();
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            store.registerIfAvailable(attacker);
            store.registerIfAvailable(defender);
            fund(store, attacker, attackerLeader, "10000");
            fund(store, defender, defenderLeader, "10000");
            UUID warId = UUID.randomUUID();
            store.declareClanWar(warId, attacker.id(), defender.id(), attackerLeader,
                    10, 3_600, NOW);
            assertEquals(SqliteClanStore.ClanWarResultStatus.OPEN_WAR_EXISTS,
                    store.declareClanWar(UUID.randomUUID(), defender.id(), attacker.id(),
                            defenderLeader, 10, 3_600, NOW.plusSeconds(1)).status());
            assertEquals(SqliteClanStore.ClanWarResultStatus.STATE_CONFLICT,
                    store.surrenderClanWar(warId, attackerLeader, NOW.plusSeconds(2)).status());
            store.acceptClanWar(warId, defenderLeader, NOW.plusSeconds(3));
            // Both sides escrow into the fund; the winner takes the whole pot.
            store.contributeToWarFund(warId, UUID.randomUUID(), attackerLeader,
                    new BigDecimal("3000"), NOW.plusSeconds(4));
            store.contributeToWarFund(warId, UUID.randomUUID(), defenderLeader,
                    new BigDecimal("5000"), NOW.plusSeconds(5));
            // clanWarFundAmount reports the escrow held for one clan, not the whole pot.
            assertEquals(0, store.clanWarFundAmount(defender.id()).compareTo(new BigDecimal("5000")));
            assertEquals(0, store.clanWarFundAmount(attacker.id()).compareTo(new BigDecimal("3000")));
            var surrender = store.surrenderClanWar(warId, attackerLeader, NOW.plusSeconds(6));
            assertEquals(SqliteClanStore.ClanWarStatus.FINISHED, surrender.war().state());
            assertEquals("WIN", surrender.war().outcome());
            assertEquals(defender.id(), surrender.war().winnerClanId());
            // Defender: 10 000 seeded − 5 000 escrowed + whole pot (3 000 + 5 000) = 13 000.
            assertEquals(new BigDecimal("13000"), store.clanBankBalance(defender.id()));
            assertEquals(SqliteClanStore.ClanWarResultStatus.STATE_CONFLICT,
                    store.cancelClanWar(warId, attackerLeader, NOW.plusSeconds(7)).status());
        }
    }

    private static void fund(SqliteClanStore store, Clan clan, UUID leader, String amount) {
        assertEquals(SqliteClanStore.ClanBankMovementStatus.APPLIED,
                store.recordClanBankMovement(UUID.randomUUID(), "war-seed:" + clan.id(),
                        clan.id(), leader, "DEPOSIT", new BigDecimal(amount), "seed", null, NOW).status());
    }

    private static Clan clan(int number, String name, String tag) {
        UUID clanId = new UUID(0, number);
        UUID leaderId = new UUID(1, number);
        return new Clan(clanId, name, tag, Instant.parse("2025-01-01T00:00:00Z"), 10,
                Map.of(leaderId, new ClanMember(leaderId, ClanRole.LEADER,
                        Instant.parse("2025-01-01T00:00:00Z"), null)), 0, null);
    }
}

package com.skyworldclans.clan;

import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanTest {
    private static final UUID CLAN_ID = UUID.fromString("10000000-0000-0000-0000-000000000001");
    private static final UUID LEADER_ID = UUID.fromString("20000000-0000-0000-0000-000000000001");
    private static final UUID DEPUTY_ID = UUID.fromString("20000000-0000-0000-0000-000000000002");
    private static final UUID MODERATOR_ID = UUID.fromString("20000000-0000-0000-0000-000000000003");
    private static final UUID MEMBER_ID = UUID.fromString("20000000-0000-0000-0000-000000000004");
    private static final Instant CREATED_AT = Instant.parse("2026-01-01T00:00:00Z");
    private static final Instant MEMBER_STARTED_AT = Instant.parse("2026-01-02T00:00:00Z");

    @Test
    void createsClanWithValidProfileMembersCapacityAndXp() {
        Clan clan = validClan();

        assertEquals(CLAN_ID, clan.id());
        assertEquals("Sky World", clan.name());
        assertEquals("SW1", clan.tag());
        assertEquals(CREATED_AT, clan.createdAt());
        assertEquals(10, clan.capacity());
        assertEquals(4, clan.memberCount());
        assertEquals(12_345L, clan.totalXp());
        assertNull(clan.tagline());
        assertEquals(ClanRole.LEADER, clan.leader().orElseThrow().role());
    }

    @Test
    void acceptsNullableAndUnrestrictedTagline() {
        Clan noTagline = validClan();
        Clan longTagline = createClan(
                validMembers(),
                10,
                0,
                "A tagline beyond any length threshold that the model must not impose");

        assertNull(noTagline.tagline());
        assertTrue(longTagline.tagline().length() > 50);
    }

    @Test
    void rejectsNullRequiredFields() {
        assertThrows(NullPointerException.class, () -> createClan(null, 10, 0, null));
        assertThrows(NullPointerException.class,
                () -> new Clan(null, "Sky", "SW", CREATED_AT, 10, validMembers(), 0, null));
        assertThrows(NullPointerException.class,
                () -> new Clan(CLAN_ID, null, "SW", CREATED_AT, 10, validMembers(), 0, null));
        assertThrows(NullPointerException.class,
                () -> new Clan(CLAN_ID, "Sky", null, CREATED_AT, 10, validMembers(), 0, null));
        assertThrows(NullPointerException.class,
                () -> new Clan(CLAN_ID, "Sky", "SW", null, 10, validMembers(), 0, null));
    }

    @Test
    void rejectsInvalidNamesAndTagsUsingTheExistingValidator() {
        assertThrows(IllegalArgumentException.class,
                () -> new Clan(CLAN_ID, "ab", "SW", CREATED_AT, 10, validMembers(), 0, null));
        assertThrows(IllegalArgumentException.class,
                () -> new Clan(CLAN_ID, "Sky", "S!", CREATED_AT, 10, validMembers(), 0, null));
    }

    @Test
    void rejectsInvalidCapacityUsingTheExistingPolicy() {
        assertThrows(IllegalArgumentException.class,
                () -> createClan(validMembers(), 11, 0, null));
    }

    @Test
    void acceptsEveryCapacityDefinedByTheCapacityPolicy() {
        for (int capacity : new int[]{10, 20, 30, 40, 50}) {
            Clan clan = createClan(validMembers(), capacity, 0, null);
            assertTrue(ClanCapacityPolicy.isValidCapacity(clan.capacity()));
        }
    }

    @Test
    void expandsCapacityByEveryAllowedSequentialStep() {
        for (int[] transition : new int[][]{
                {10, 20},
                {20, 30},
                {30, 40},
                {40, 50}
        }) {
            Clan clan = createClan(validMembers(), transition[0], 12_345, "Together");

            assertEquals(transition[1], clan.withExpandedCapacity(transition[1]).capacity());
        }
    }

    @Test
    void expandedCapacityCopyPreservesAllOtherFieldsAndDoesNotMutateSource() {
        Clan original = validClan();

        Clan expanded = original.withExpandedCapacity(20);

        assertNotSame(original, expanded);
        assertEquals(20, expanded.capacity());
        assertEquals(original.id(), expanded.id());
        assertEquals(original.name(), expanded.name());
        assertEquals(original.tag(), expanded.tag());
        assertEquals(original.createdAt(), expanded.createdAt());
        assertEquals(original.members(), expanded.members());
        assertEquals(original.totalXp(), expanded.totalXp());
        assertEquals(original.tagline(), expanded.tagline());
        assertEquals(10, original.capacity());
        assertEquals(4, original.memberCount());
    }

    @Test
    void rejectsCapacityDecreaseSkippedStepMaximumAndInvalidValues() {
        Clan atTen = createClan(validMembers(), 10, 0, null);
        Clan atTwenty = createClan(validMembers(), 20, 0, null);
        Clan atMaximum = createClan(validMembers(), 50, 0, null);

        assertThrows(IllegalArgumentException.class, () -> atTen.withExpandedCapacity(10));
        assertThrows(IllegalArgumentException.class, () -> atTwenty.withExpandedCapacity(10));
        assertThrows(IllegalArgumentException.class, () -> atTen.withExpandedCapacity(30));
        assertThrows(IllegalArgumentException.class, () -> atMaximum.withExpandedCapacity(50));
        assertThrows(IllegalArgumentException.class, () -> atTen.withExpandedCapacity(0));
        assertThrows(IllegalArgumentException.class, () -> atTen.withExpandedCapacity(11));
        assertThrows(IllegalArgumentException.class, () -> atTen.withExpandedCapacity(60));
    }

    @Test
    void expandedClanKeepsMemberMapImmutable() {
        Clan expanded = validClan().withExpandedCapacity(20);

        assertThrows(UnsupportedOperationException.class, expanded.members()::clear);
        assertEquals(4, expanded.memberCount());
        assertTrue(expanded.member(LEADER_ID).isPresent());
    }

    @Test
    void rejectsEmptyMemberMap() {
        assertThrows(IllegalArgumentException.class,
                () -> createClan(Map.of(), 10, 0, null));
    }

    @Test
    void rejectsMemberCountAboveCapacity() {
        assertThrows(IllegalArgumentException.class,
                () -> createClan(membersAboveCapacity(), 10, 0, null));
    }

    @Test
    void rejectsMismatchBetweenMemberMapKeyAndPlayerId() {
        Map<UUID, ClanMember> members = Map.of(
                LEADER_ID, member(LEADER_ID, ClanRole.LEADER),
                DEPUTY_ID, member(MODERATOR_ID, ClanRole.MEMBER));

        assertThrows(IllegalArgumentException.class,
                () -> createClan(members, 10, 0, null));
    }

    @Test
    void rejectsMoreThanOneLeader() {
        Map<UUID, ClanMember> members = Map.of(
                LEADER_ID, member(LEADER_ID, ClanRole.LEADER),
                DEPUTY_ID, member(DEPUTY_ID, ClanRole.LEADER));

        assertThrows(IllegalArgumentException.class,
                () -> createClan(members, 10, 0, null));
    }

    @Test
    void allowsMemberStateWithoutLeaderForElectionTransition() {
        Clan clan = createClan(
                Map.of(DEPUTY_ID, member(DEPUTY_ID, ClanRole.DEPUTY)),
                10,
                0,
                null);

        assertTrue(clan.leader().isEmpty());
        assertEquals(1, clan.memberCount());
    }

    @Test
    void acceptsModeratorAppointedByDeputyInTheSameClan() {
        Clan clan = createClan(
                Map.of(
                        DEPUTY_ID, member(DEPUTY_ID, ClanRole.DEPUTY),
                        MODERATOR_ID, moderator(MODERATOR_ID, DEPUTY_ID)),
                10,
                0,
                null);

        assertEquals(DEPUTY_ID, clan.member(MODERATOR_ID).orElseThrow().appointedByDeputyId());
    }

    @Test
    void rejectsModeratorAppointedByMissingMember() {
        assertThrows(IllegalArgumentException.class,
                () -> createClan(
                        Map.of(MODERATOR_ID, moderator(MODERATOR_ID, DEPUTY_ID)),
                        10,
                        0,
                        null));
    }

    @Test
    void rejectsModeratorAppointedByNonDeputy() {
        assertThrows(IllegalArgumentException.class,
                () -> createClan(
                        Map.of(
                                LEADER_ID, member(LEADER_ID, ClanRole.LEADER),
                                MODERATOR_ID, moderator(MODERATOR_ID, LEADER_ID)),
                        10,
                        0,
                        null));
    }

    @Test
    void rejectsNegativeTotalXp() {
        assertThrows(IllegalArgumentException.class,
                () -> createClan(validMembers(), 10, -1, null));
    }

    @Test
    void copiesInputMapAndDoesNotReflectLaterChanges() {
        Map<UUID, ClanMember> members = new HashMap<>();
        members.put(LEADER_ID, member(LEADER_ID, ClanRole.LEADER));
        Clan clan = createClan(members, 10, 0, null);

        members.put(DEPUTY_ID, member(DEPUTY_ID, ClanRole.DEPUTY));
        members.clear();

        assertEquals(1, clan.memberCount());
        assertTrue(clan.member(LEADER_ID).isPresent());
        assertFalse(clan.member(DEPUTY_ID).isPresent());
    }

    @Test
    void doesNotAllowMutationThroughMembersAccessor() {
        Clan clan = validClan();

        assertThrows(UnsupportedOperationException.class,
                () -> clan.members().put(
                        UUID.fromString("20000000-0000-0000-0000-000000000005"),
                        member(UUID.fromString("20000000-0000-0000-0000-000000000005"),
                                ClanRole.MEMBER)));
        assertThrows(UnsupportedOperationException.class,
                () -> clan.members().clear());
    }

    @Test
    void findsMemberByPlayerIdAndReturnsEmptyForUnknownOrNullId() {
        Clan clan = validClan();

        assertEquals(Optional.of(clan.members().get(MEMBER_ID)), clan.member(MEMBER_ID));
        assertTrue(clan.member(UUID.randomUUID()).isEmpty());
        assertTrue(clan.member(null).isEmpty());
    }

    @Test
    void findsLeaderOrReturnsEmptyWhenThereIsNoLeader() {
        Clan clan = validClan();
        Clan transitionClan = createClan(
                Map.of(DEPUTY_ID, member(DEPUTY_ID, ClanRole.DEPUTY)),
                10,
                0,
                null);

        assertEquals(LEADER_ID, clan.leader().orElseThrow().playerId());
        assertTrue(transitionClan.leader().isEmpty());
    }

    @Test
    void countsMembers() {
        assertEquals(4, validClan().memberCount());
    }

    private static Clan validClan() {
        return createClan(validMembers(), 10, 12_345, null);
    }

    private static Clan createClan(
            Map<UUID, ClanMember> members,
            int capacity,
            long totalXp,
            String tagline) {
        return new Clan(
                CLAN_ID,
                "Sky World",
                "SW1",
                CREATED_AT,
                capacity,
                members,
                totalXp,
                tagline);
    }

    private static Map<UUID, ClanMember> validMembers() {
        return Map.of(
                LEADER_ID, member(LEADER_ID, ClanRole.LEADER),
                DEPUTY_ID, member(DEPUTY_ID, ClanRole.DEPUTY),
                MODERATOR_ID, moderator(MODERATOR_ID, DEPUTY_ID),
                MEMBER_ID, member(MEMBER_ID, ClanRole.MEMBER));
    }

    private static Map<UUID, ClanMember> membersAboveCapacity() {
        Map<UUID, ClanMember> members = new HashMap<>(validMembers());
        for (long playerNumber = 5; playerNumber <= 11; playerNumber++) {
            UUID playerId = new UUID(3, playerNumber);
            members.put(playerId, member(playerId, ClanRole.MEMBER));
        }
        return members;
    }

    private static ClanMember member(UUID playerId, ClanRole role) {
        return new ClanMember(playerId, role, MEMBER_STARTED_AT, null);
    }

    private static ClanMember moderator(UUID playerId, UUID appointedByDeputyId) {
        return new ClanMember(
                playerId, ClanRole.MODERATOR, MEMBER_STARTED_AT, appointedByDeputyId);
    }
}

package com.skyworldclans.clan.validation;

import java.util.Objects;

public final class ClanTagUniquenessChecker {
    private final ClanTagSource tagSource;

    public ClanTagUniquenessChecker(ClanTagSource tagSource) {
        this.tagSource = Objects.requireNonNull(tagSource, "tagSource");
    }

    public boolean isUnique(String tag) {
        if (!ClanNameTagValidator.isValidTag(tag)) {
            return false;
        }

        Iterable<String> existingTags = Objects.requireNonNull(
                tagSource.getExistingTags(),
                "tagSource must return existing tags");
        for (String existingTag : existingTags) {
            if (tag.equalsIgnoreCase(existingTag)) {
                return false;
            }
        }
        return true;
    }
}

package com.skyworldclans.clan.filter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class Utf8FileForbiddenExpressionSource implements ForbiddenExpressionSource {
    private final Path path;

    public Utf8FileForbiddenExpressionSource(Path path) {
        this.path = Objects.requireNonNull(path, "path");
    }

    @Override
    public List<String> readEntries() throws IOException {
        Map<String, String> uniqueEntries = new LinkedHashMap<>();
        var decoder = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT);

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(Files.newInputStream(path), decoder))) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine && !line.isEmpty() && line.charAt(0) == '\uFEFF') {
                    line = line.substring(1);
                }
                firstLine = false;

                if (isBlank(line) || isComment(line)) {
                    continue;
                }

                String normalized = ForbiddenExpressionNormalizer.normalize(line);
                uniqueEntries.putIfAbsent(normalized, line);
            }
        }
        return List.copyOf(uniqueEntries.values());
    }

    private static boolean isBlank(String value) {
        return value.codePoints().allMatch(codePoint ->
                Character.isWhitespace(codePoint) || Character.isSpaceChar(codePoint));
    }

    private static boolean isComment(String value) {
        return value.codePoints()
                .dropWhile(codePoint ->
                        Character.isWhitespace(codePoint) || Character.isSpaceChar(codePoint))
                .findFirst()
                .orElse(-1) == '#';
    }
}

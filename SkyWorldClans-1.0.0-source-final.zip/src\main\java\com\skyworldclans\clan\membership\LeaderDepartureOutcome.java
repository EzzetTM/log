package com.skyworldclans.clan.membership;

public enum LeaderDepartureOutcome {
    EMPTY_CLAN,
    TRANSFER_TO_DEPUTY,
    ELECTION_AMONG_DEPUTIES,
    ELECTION_AMONG_MEMBERS
}

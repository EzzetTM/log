package com.skyworldclans.clan.membership;

import com.skyworldclans.clan.Clan;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/** Candidate and tally rules for leadership departure elections and inactivity coups. */
public final class ClanElectionPolicy {
    public static final Duration DEPARTURE_ELECTION_DURATION = Duration.ofHours(24);
    public static final Duration COUP_ELECTION_DURATION = Duration.ofHours(24);
    public static final Duration GLOBAL_TIE_BREAK_DURATION = Duration.ofHours(6);
    public static final Duration LEADER_INACTIVITY_REQUIRED = Duration.ofDays(30);
    public static final Duration REPEAT_COUP_WAIT = Duration.ofDays(30);

    public List<UUID> departureCandidates(Clan clan, UUID departingLeaderId) {
        Objects.requireNonNull(clan, "clan");
        Objects.requireNonNull(departingLeaderId, "departingLeaderId");
        if (!clan.leader().map(leader -> leader.playerId().equals(departingLeaderId)).orElse(false)) {
            return List.of();
        }
        List<UUID> deputies = clan.members().values().stream()
                .filter(member -> member.role() == ClanRole.DEPUTY)
                .map(ClanMember::playerId)
                .sorted()
                .toList();
        if (deputies.size() >= 2) return deputies;
        if (deputies.size() == 1) return List.of();
        return clan.members().values().stream()
                .filter(member -> !member.playerId().equals(departingLeaderId))
                .map(ClanMember::playerId)
                .sorted()
                .toList();
    }

    public Optional<UUID> automaticSuccessor(Clan clan, UUID departingLeaderId) {
        if (clan == null || departingLeaderId == null
                || !clan.leader().map(leader -> leader.playerId().equals(departingLeaderId)).orElse(false)) {
            return Optional.empty();
        }
        List<UUID> deputies = clan.members().values().stream()
                .filter(member -> member.role() == ClanRole.DEPUTY)
                .map(ClanMember::playerId)
                .toList();
        return deputies.size() == 1 ? Optional.of(deputies.get(0)) : Optional.empty();
    }

    public List<UUID> coupCandidates(Clan clan) {
        Objects.requireNonNull(clan, "clan");
        LinkedHashSet<UUID> candidates = new LinkedHashSet<>();
        clan.leader().map(ClanMember::playerId).ifPresent(candidates::add);
        clan.members().values().stream()
                .filter(member -> member.role() == ClanRole.DEPUTY)
                .map(ClanMember::playerId)
                .sorted()
                .forEach(candidates::add);
        return List.copyOf(candidates);
    }

    /** Returns all candidates tied for the highest vote count; an empty tally preserves all candidates. */
    public List<UUID> tiedForFirst(List<UUID> candidates, Map<UUID, Integer> votes) {
        Objects.requireNonNull(candidates, "candidates");
        Objects.requireNonNull(votes, "votes");
        if (candidates.isEmpty()) return List.of();
        int highest = candidates.stream().mapToInt(candidate -> votes.getOrDefault(candidate, 0))
                .max().orElse(0);
        return candidates.stream()
                .filter(candidate -> votes.getOrDefault(candidate, 0) == highest)
                .distinct()
                .sorted()
                .toList();
    }

    public Optional<UUID> uniqueWinner(List<UUID> candidates, Map<UUID, Integer> votes) {
        List<UUID> tied = tiedForFirst(candidates, votes);
        return tied.size() == 1 ? Optional.of(tied.get(0)) : Optional.empty();
    }

    public boolean canVote(Clan clan, UUID voterId, List<UUID> candidates, UUID candidateId) {
        if (clan == null || voterId == null || candidateId == null || candidates == null
                || !candidates.contains(candidateId)) return false;
        return clan.member(voterId).isPresent();
    }

    public boolean canUseGlobalTieBreakPermission(boolean permissionGranted, UUID voterId,
            List<UUID> candidates, UUID candidateId) {
        return permissionGranted && voterId != null && candidates != null
                && candidates.contains(candidateId);
    }
}

package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Progress-based achievements from the specification: bank contribution, quest counts. */
class ClanProgressAchievementTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-12T10:00:00Z");

    @Test
    void tenMillionCumulativeDepositsAwardsTwoThousandXpOnce() {
        UUID leader = id(1);
        Clan clan = clan(leader);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("bank-achievement.sqlite"))) {
            store.registerIfAvailable(clan);
            // 9 999 999 is below the threshold and must not award anything yet.
            deposit(store, clan, leader, "9999999", NOW);
            store.reconcileProgressAchievements(clan.id(), NOW);
            assertEquals(0L, store.findById(clan.id()).orElseThrow().totalXp());

            deposit(store, clan, leader, "1", NOW.plusSeconds(1));
            store.reconcileProgressAchievements(clan.id(), NOW.plusSeconds(2));
            assertEquals(2_000L, store.findById(clan.id()).orElseThrow().totalXp());

            // Re-running reconciliation must not award twice.
            store.reconcileProgressAchievements(clan.id(), NOW.plusSeconds(3));
            assertEquals(2_000L, store.findById(clan.id()).orElseThrow().totalXp());
            assertEquals(1, xpEventCount(store, clan, "BANK_CONTRIBUTION_10M"));
        }
    }

    @Test
    void hundredCompletedQuestsAndTenContributorsAwardTheirAchievements() {
        UUID leader = id(11);
        Clan clan = clan(leader);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("quest-achievement.sqlite"))) {
            store.registerIfAvailable(clan);
            // 99 quests are not enough.
            for (int index = 0; index < 99; index++) {
                completedQuest(store, clan, leader, "DAILY", "2026-01-" + (index % 28 + 1) + "-" + index);
            }
            store.reconcileProgressAchievements(clan.id(), NOW);
            assertEquals(0L, store.findById(clan.id()).orElseThrow().totalXp());

            completedQuest(store, clan, leader, "DAILY", "final");
            store.reconcileProgressAchievements(clan.id(), NOW.plusSeconds(1));
            // Only HUNDRED_TASKS_COMPLETED (3 000); one contributor is below the ten-contributor rule.
            assertEquals(3_000L, store.findById(clan.id()).orElseThrow().totalXp());
        }
    }

    private static int xpEventCount(SqliteClanStore store, Clan clan, String eventType) {
        try {
            java.lang.reflect.Field field = SqliteClanStore.class.getDeclaredField("connection");
            field.setAccessible(true);
            try (java.sql.Connection connection = (java.sql.Connection) field.get(store);
                 java.sql.PreparedStatement query = connection.prepareStatement(
                         "SELECT COUNT(*) FROM clan_xp_events WHERE clan_id = ? AND event_type = ?")) {
                query.setString(1, clan.id().toString());
                query.setString(2, eventType);
                try (java.sql.ResultSet row = query.executeQuery()) {
                    return row.next() ? row.getInt(1) : 0;
                }
            }
        } catch (ReflectiveOperationException | java.sql.SQLException exception) {
            throw new IllegalStateException("Could not count XP events", exception);
        }
    }

    private static void deposit(SqliteClanStore store, Clan clan, UUID actor, String amount, Instant at) {
        assertEquals(SqliteClanStore.ClanBankMovementStatus.APPLIED,
                store.recordClanBankMovement(UUID.randomUUID(), "dep:" + UUID.randomUUID(),
                        clan.id(), actor, "DEPOSIT", new BigDecimal(amount), "seed", null, at).status());
    }

    private static void completedQuest(SqliteClanStore store, Clan clan, UUID actor,
            String category, String periodKey) {
        UUID questId = UUID.randomUUID();
        store.insertClanQuest(questId, clan.id(), category, "EASY", "MINE_BLOCK", 1, 1,
                periodKey, 1, NOW, NOW.plusSeconds(86_400));
        store.applyClanQuestProgress(questId, actor, 1, NOW.plusSeconds(1));
    }

    private static Clan clan(UUID leader) {
        return new Clan(new UUID(0, 900), "ProgressClan", "PG900", NOW, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, NOW, null)), 0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }
}
package com.skyworldclans.clan.policy;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ClanLevelPolicyTest {
    @Test
    void usesExactCumulativeThresholds() {
        long[] thresholds = {0, 5_000, 12_000, 22_000, 37_000,
                58_000, 88_000, 130_000, 190_000, 275_000};
        for (int index = 0; index < thresholds.length; index++) {
            assertEquals(index + 1, ClanLevelPolicy.levelForXp(thresholds[index]));
            if (index > 0) {
                assertEquals(index, ClanLevelPolicy.levelForXp(thresholds[index] - 1));
            }
        }
    }

    @Test
    void levelCapsAtTenWhileExperienceCanContinueAccumulating() {
        assertEquals(10, ClanLevelPolicy.levelForXp(275_000));
        assertEquals(10, ClanLevelPolicy.levelForXp(Long.MAX_VALUE));
        assertEquals(275_000, ClanLevelPolicy.thresholdForLevel(10));
    }

    @Test
    void rejectsNegativeExperienceAndInvalidLevel() {
        assertThrows(IllegalArgumentException.class, () -> ClanLevelPolicy.levelForXp(-1));
        assertThrows(IllegalArgumentException.class, () -> ClanLevelPolicy.thresholdForLevel(0));
        assertThrows(IllegalArgumentException.class, () -> ClanLevelPolicy.thresholdForLevel(11));
    }
}

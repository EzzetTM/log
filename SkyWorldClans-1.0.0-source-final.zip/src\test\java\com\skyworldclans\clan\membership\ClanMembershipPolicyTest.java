package com.skyworldclans.clan.membership;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanMembershipPolicyTest {

    @Test
    void allowsJoiningWhenPlayerIsNotInAnotherClanAndSpaceExists() {
        assertTrue(ClanMembershipPolicy.canJoin(false, 0, 10));
        assertTrue(ClanMembershipPolicy.canJoin(false, 9, 10));
    }

    @Test
    void deniesJoiningWhenPlayerAlreadyBelongsToAnotherClan() {
        assertFalse(ClanMembershipPolicy.canJoin(true, 0, 10));
        assertFalse(ClanMembershipPolicy.canJoin(true, 9, 10));
    }

    @Test
    void delegatesCapacityAndMemberCountValidationToCapacityPolicy() {
        assertFalse(ClanMembershipPolicy.canJoin(false, 10, 10));
        assertFalse(ClanMembershipPolicy.canJoin(false, -1, 10));
        assertFalse(ClanMembershipPolicy.canJoin(false, 0, 11));
        assertFalse(ClanMembershipPolicy.canJoin(false, 11, 10));
    }

    @Test
    void onlyLeaderAndDeputyCanInvite() {
        assertTrue(ClanMembershipPolicy.canInvite(ClanRole.LEADER));
        assertTrue(ClanMembershipPolicy.canInvite(ClanRole.DEPUTY));
        assertFalse(ClanMembershipPolicy.canInvite(ClanRole.MODERATOR));
        assertFalse(ClanMembershipPolicy.canInvite(ClanRole.MEMBER));
        assertFalse(ClanMembershipPolicy.canInvite(null));
    }

    @Test
    void onlyLeaderAndDeputyCanReviewApplications() {
        assertTrue(ClanMembershipPolicy.canReviewApplication(ClanRole.LEADER));
        assertTrue(ClanMembershipPolicy.canReviewApplication(ClanRole.DEPUTY));
        assertFalse(ClanMembershipPolicy.canReviewApplication(ClanRole.MODERATOR));
        assertFalse(ClanMembershipPolicy.canReviewApplication(ClanRole.MEMBER));
        assertFalse(ClanMembershipPolicy.canReviewApplication(null));
    }

    @Test
    void leaderCanAssignDeputiesBelowTheLimitOfFour() {
        assertTrue(ClanMembershipPolicy.canAssignDeputy(ClanRole.LEADER, 0));
        assertTrue(ClanMembershipPolicy.canAssignDeputy(ClanRole.LEADER, 3));
    }

    @Test
    void cannotAssignDeputyAtTheLimitOrWithInvalidCountOrRole() {
        assertFalse(ClanMembershipPolicy.canAssignDeputy(ClanRole.LEADER, 4));
        assertFalse(ClanMembershipPolicy.canAssignDeputy(ClanRole.LEADER, -1));
        assertFalse(ClanMembershipPolicy.canAssignDeputy(ClanRole.DEPUTY, 0));
        assertFalse(ClanMembershipPolicy.canAssignDeputy(ClanRole.MODERATOR, 0));
        assertFalse(ClanMembershipPolicy.canAssignDeputy(ClanRole.MEMBER, 0));
        assertFalse(ClanMembershipPolicy.canAssignDeputy(null, 0));
    }

    @Test
    void validatesFinalDeputyCountAtTheLimit() {
        assertTrue(ClanMembershipPolicy.isValidDeputyCount(0));
        assertTrue(ClanMembershipPolicy.isValidDeputyCount(4));
        assertFalse(ClanMembershipPolicy.isValidDeputyCount(5));
        assertFalse(ClanMembershipPolicy.isValidDeputyCount(-1));
    }

    @Test
    void validatesFinalDeputyAppointedModeratorCountPerDeputyAtTheLimit() {
        assertTrue(ClanMembershipPolicy.isValidDeputyAssignedModeratorCount(0));
        assertTrue(ClanMembershipPolicy.isValidDeputyAssignedModeratorCount(2));
        assertFalse(ClanMembershipPolicy.isValidDeputyAssignedModeratorCount(3));
        assertFalse(ClanMembershipPolicy.isValidDeputyAssignedModeratorCount(-1));
    }

    @Test
    void validatesFinalTotalDeputyAppointedModeratorCountAtTheLimit() {
        assertTrue(ClanMembershipPolicy.isValidTotalDeputyAssignedModeratorCount(0));
        assertTrue(ClanMembershipPolicy.isValidTotalDeputyAssignedModeratorCount(8));
        assertFalse(ClanMembershipPolicy.isValidTotalDeputyAssignedModeratorCount(9));
        assertFalse(ClanMembershipPolicy.isValidTotalDeputyAssignedModeratorCount(-1));
    }

    @Test
    void leaderCanAssignModeratorsWithoutDeputyLimits() {
        assertTrue(ClanMembershipPolicy.canAssignModerator(ClanRole.LEADER, 2, 8));
        assertTrue(ClanMembershipPolicy.canAssignModerator(ClanRole.LEADER, 100, 100));
    }

    @Test
    void deputyCanAssignUpToTwoModeratorsWhenTotalDeputyAppointmentsAreBelowEight() {
        assertTrue(ClanMembershipPolicy.canAssignModerator(ClanRole.DEPUTY, 0, 0));
        assertTrue(ClanMembershipPolicy.canAssignModerator(ClanRole.DEPUTY, 1, 7));
    }

    @Test
    void deputyCannotExceedEitherModeratorLimit() {
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.DEPUTY, 2, 0));
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.DEPUTY, 0, 8));
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.DEPUTY, 2, 8));
    }

    @Test
    void onlyLeaderAndDeputyCanAssignModerators() {
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.MODERATOR, 0, 0));
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.MEMBER, 0, 0));
        assertFalse(ClanMembershipPolicy.canAssignModerator(null, 0, 0));
    }

    @Test
    void deputyModeratorAssignmentRejectsNegativeCounts() {
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.DEPUTY, -1, 0));
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.DEPUTY, 0, -1));
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.LEADER, -1, 0));
        assertFalse(ClanMembershipPolicy.canAssignModerator(ClanRole.LEADER, 0, -1));
    }
}

package com.skyworldclans.clan.chat;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.integration.flectone.FlectonePulseBridge;
import org.bukkit.entity.Player;

import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/** Clan chat delivery through the optional FlectonePulse message pipeline. */
public final class ClanChatService {
    private final ClanCatalog catalog;
    private final FlectonePulseBridge bridge;
    private final Predicate<UUID> muteCheck;

    public ClanChatService(ClanCatalog catalog, FlectonePulseBridge bridge) {
        this(catalog, bridge, playerId -> false);
    }

    public ClanChatService(ClanCatalog catalog, FlectonePulseBridge bridge, Predicate<UUID> muteCheck) {
        this.catalog = Objects.requireNonNull(catalog, "catalog");
        this.bridge = bridge;
        this.muteCheck = muteCheck == null ? playerId -> false : muteCheck;
    }

    public Result send(Player sender, String message) {
        if (sender == null || message == null || message.isBlank()) return Result.INVALID_MESSAGE;
        try {
            Clan clan = catalog.findByPlayerId(sender.getUniqueId()).orElse(null);
            if (clan == null) return Result.NOT_IN_CLAN;
            if (muteCheck.test(sender.getUniqueId())) return Result.MUTED;
            if (bridge == null) return Result.FLECTONEPULSE_UNAVAILABLE;
            Set<UUID> members = clan.members().keySet().stream().collect(Collectors.toUnmodifiableSet());
            return bridge.sendClanMessage(sender, members, message) ? Result.SENT : Result.DELIVERY_FAILED;
        } catch (RuntimeException exception) {
            return Result.STORAGE_ERROR;
        }
    }

    public enum Result {
        SENT, INVALID_MESSAGE, NOT_IN_CLAN, MUTED, FLECTONEPULSE_UNAVAILABLE, DELIVERY_FAILED, STORAGE_ERROR
    }
}
package com.skyworldclans.clan.catalog;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;

import java.util.Optional;
import java.util.UUID;

public interface ClanCatalog {
    /**
     * Finds a clan by id. A null id returns {@link Optional#empty()}.
     */
    Optional<Clan> findById(UUID clanId);

    /**
     * Finds a clan by a case-insensitive tag match. A null tag returns
     * {@link Optional#empty()}.
     */
    Optional<Clan> findByTag(String tag);

    /**
     * Finds a clan containing the player. A null player id returns
     * {@link Optional#empty()}.
     */
    Optional<Clan> findByPlayerId(UUID playerId);

    /**
     * Returns the revision number of the clan with the given id.
     * The revision is incremented on each successful capacity purchase commit.
     * Returns empty if the clan does not exist.
     */
    Optional<Long> findRevision(UUID clanId);

    /**
     * Atomically registers the clan only if its id, tag, and every member id are unused.
     * A conflict must leave the catalog unchanged. A null clan returns
     * {@link RegistrationStatus#CLAN_REQUIRED}.
     */
    RegistrationStatus registerIfAvailable(Clan clan);

    /**
     * Atomically replaces the expected clan with an expanded-capacity copy.
     * Implementations must not change state when the current snapshot differs
     * from {@code expectedClan}, the leader differs from {@code leaderId}, or
     * the replacement is not exactly the next-capacity copy.
     * The expected and replacement capacities must be a valid next step
     * according to {@link ClanCapacityPolicy}.
     */
    CapacityUpdateStatus updateCapacityIfUnchanged(
            Clan expectedClan,
            UUID leaderId,
            Clan updatedClan);

    /** Atomically replaces a membership-only snapshot without changing the capacity-purchase revision. */
    MembershipUpdateStatus updateMembershipIfUnchanged(Clan expectedClan, Clan updatedClan);

    enum RegistrationStatus {
        REGISTERED,
        CLAN_REQUIRED,
        CLAN_ID_CONFLICT,
        TAG_CONFLICT,
        MEMBER_CONFLICT
    }

    enum CapacityUpdateStatus {
        UPDATED,
        CLAN_NOT_FOUND,
        LEADER_CHANGED,
        STATE_CONFLICT,
        INVALID_UPDATE
    }

    enum MembershipUpdateStatus {
        UPDATED,
        CLAN_NOT_FOUND,
        STATE_CONFLICT,
        MEMBER_CONFLICT,
        INVALID_UPDATE
    }
}

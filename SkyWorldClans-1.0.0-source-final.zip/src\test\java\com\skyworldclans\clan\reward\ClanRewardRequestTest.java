package com.skyworldclans.clan.reward;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.integration.EconomyOperations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/** Large reward requests: approval consumes the weekly quota, rejection does not. */
class ClanRewardRequestTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-20T10:00:00Z");

    @Test
    void creatingARequestDoesNotConsumeQuotaUntilTheLeaderApproves() {
        UUID leader = id(1), deputy = id(2), member = id(3);
        Clan clan = clan(leader, deputy, member);
        FakeEconomy economy = new FakeEconomy();
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reward-requests.sqlite"))) {
            store.registerIfAvailable(clan);
            fund(store, clan, leader, "5000000");
            var coordinator = new ClanRewardCoordinator(store, store, economy,
                    Clock.fixed(NOW, ZoneOffset.UTC), UUID::randomUUID);

            var request = coordinator.requestLarge(deputy, member, new BigDecimal("200000"), "season bonus");
            assertEquals(ClanRewardCoordinator.Status.REQUEST_CREATED, request.status());
            assertEquals("PENDING", request.request().status());
            assertEquals(0, coordinator.approvedLargeRewardsThisWeek(clan.id()),
                    "a pending request must not consume the weekly quota");

            var approved = coordinator.resolveLarge(leader, request.request().requestId(), true);
            assertEquals(ClanRewardCoordinator.Status.SUCCESS, approved.status());
            assertEquals(1, coordinator.approvedLargeRewardsThisWeek(clan.id()));
            assertEquals(0, store.clanBankBalance(clan.id()).compareTo(new BigDecimal("4800000")));

            // A second decision on the same request is rejected, so the quota cannot be reused.
            assertEquals(ClanRewardCoordinator.Status.REQUEST_ALREADY_RESOLVED,
                    coordinator.resolveLarge(leader, request.request().requestId(), true).status());
            assertEquals(1, coordinator.approvedLargeRewardsThisWeek(clan.id()));
        }
    }

    @Test
    void approvedLargeRewardsAreLimitedToThreePerRollingWeek() {
        UUID leader = id(11), deputy = id(12), member = id(13);
        Clan clan = clan(leader, deputy, member);
        FakeEconomy economy = new FakeEconomy();
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reward-quota.sqlite"))) {
            store.registerIfAvailable(clan);
            fund(store, clan, leader, "5000000");
            var coordinator = new ClanRewardCoordinator(store, store, economy,
                    Clock.fixed(NOW, ZoneOffset.UTC), UUID::randomUUID);

            for (int index = 0; index < 3; index++) {
                var request = coordinator.requestLarge(deputy, member, new BigDecimal("150000"),
                        "bonus " + index);
                assertEquals(ClanRewardCoordinator.Status.REQUEST_CREATED, request.status());
                assertEquals(ClanRewardCoordinator.Status.SUCCESS,
                        coordinator.resolveLarge(leader, request.request().requestId(), true).status());
            }
            // Rejected requests must not consume quota.
            var declined = coordinator.requestLarge(deputy, member, new BigDecimal("120000"), "declined");
            assertEquals(ClanRewardCoordinator.Status.REQUEST_DECLINED,
                    coordinator.resolveLarge(leader, declined.request().requestId(), false).status());
            assertEquals(3, coordinator.approvedLargeRewardsThisWeek(clan.id()));

            var fourth = coordinator.requestLarge(deputy, member, new BigDecimal("130000"), "fourth");
            assertEquals(ClanRewardCoordinator.Status.REQUEST_CREATED, fourth.status());
            assertEquals(ClanRewardCoordinator.Status.WEEKLY_QUOTA_EXHAUSTED,
                    coordinator.resolveLarge(leader, fourth.request().requestId(), true).status());
            // The exhausted request stays pending and can still be declined.
            assertEquals(ClanRewardCoordinator.Status.REQUEST_DECLINED,
                    coordinator.resolveLarge(leader, fourth.request().requestId(), false).status());
        }
    }

    @Test
    void ordinaryAmountsAndNonDeputiesCannotUseTheLargeRequestPath() {
        UUID leader = id(21), deputy = id(22), member = id(23);
        Clan clan = clan(leader, deputy, member);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reward-limits.sqlite"))) {
            store.registerIfAvailable(clan);
            var coordinator = new ClanRewardCoordinator(store, store, new FakeEconomy(),
                    Clock.fixed(NOW, ZoneOffset.UTC), UUID::randomUUID);
            assertEquals(ClanRewardCoordinator.Status.INVALID_AMOUNT,
                    coordinator.requestLarge(deputy, member, new BigDecimal("100000"), "too small").status());
            assertEquals(ClanRewardCoordinator.Status.INVALID_AMOUNT,
                    coordinator.requestLarge(deputy, member, new BigDecimal("1000001"), "too large").status());
            assertEquals(ClanRewardCoordinator.Status.NOT_AUTHORIZED,
                    coordinator.requestLarge(member, deputy, new BigDecimal("200000"), "not deputy").status());
            assertEquals(0, coordinator.requests(leader, false).size());
        }
    }

    private static void fund(SqliteClanStore store, Clan clan, UUID leader, String amount) {
        assertEquals(SqliteClanStore.ClanBankMovementStatus.APPLIED,
                store.recordClanBankMovement(UUID.randomUUID(), "seed:" + UUID.randomUUID(),
                        clan.id(), leader, "DEPOSIT", new BigDecimal(amount), "seed", null, NOW).status());
    }

    private static Clan clan(UUID leader, UUID deputy, UUID member) {
        Instant start = NOW.minusSeconds(86_400L * 30);
        return new Clan(new UUID(0, 700), "RewardRequest", "RQ700", start, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, start, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, start, null),
                        member, new ClanMember(member, ClanRole.MEMBER, start, null)),
                0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }

    private static final class FakeEconomy implements EconomyOperations {
        @Override public BalanceResult balance(UUID playerId) { return new BalanceResult(Status.SUCCESS, 1_000_000, null); }
        @Override public OperationResult withdraw(UUID playerId, double amount) {
            return new OperationResult(Status.SUCCESS, "fake");
        }
        @Override public OperationResult deposit(UUID playerId, double amount) {
            return new OperationResult(Status.SUCCESS, "fake");
        }
    }
}
package com.skyworldclans.clan.home;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanHomeServiceTest {
    @TempDir Path temporaryDirectory;

    @Test
    void primaryHomeSupportsRoleRulesRenameDeleteAndRecreateWithDurableHistory() {
        Path database = temporaryDirectory.resolve("clan-home.sqlite");
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        UUID moderator = UUID.randomUUID();
        UUID member = UUID.randomUUID();
        UUID world = UUID.randomUUID();
        Clan clan = new Clan(UUID.randomUUID(), "HomeClan", "HM01", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null),
                        moderator, new ClanMember(moderator, ClanRole.MODERATOR, now, null),
                        member, new ClanMember(member, ClanRole.MEMBER, now, null)), 0, null);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            ClanHomeService service = new ClanHomeService(store, store);
            assertEquals(SqliteClanStore.ClanHomeStatus.NOT_AUTHORIZED,
                    store.setClanHomePoint(clan.id(), moderator, "Основная", world, 1, 2, 3, 0, 0, now).status());
            assertEquals(SqliteClanStore.ClanHomeStatus.LEADER_ONLY,
                    store.deleteClanHomePoint(clan.id(), deputy, now).status());
            var saved = service.setHome(leader, world, 10.5, 70.0, -3.25, 90.0f, 0.0f, now.plusSeconds(1));
            assertEquals(ClanHomeService.Status.SAVED, saved.status());
            assertEquals(ClanHomeService.DEFAULT_HOME_NAME, saved.point().name());
            assertEquals(ClanHomeService.Status.READY, service.homeFor(member).status());
            assertEquals(ClanHomeService.Status.NOT_AUTHORIZED,
                    service.setHome(moderator, world, 1, 2, 3, 0, 0, now.plusSeconds(2)).status());

            var renamed = service.renameHome(deputy, "Общий дом", now.plusSeconds(3));
            assertEquals(ClanHomeService.Status.RENAMED, renamed.status());
            assertEquals("Общий дом", renamed.point().name());
            assertEquals(ClanHomeService.Status.LEADER_ONLY, service.deleteHome(deputy, now.plusSeconds(4)).status());
            assertEquals(ClanHomeService.Status.DELETED, service.deleteHome(leader, now.plusSeconds(5)).status());
            assertEquals(ClanHomeService.Status.HOME_NOT_SET, service.homeFor(member).status());
            var recreated = service.setHome(deputy, world, 20, 80, 30, 180, 10, now.plusSeconds(6));
            assertEquals(ClanHomeService.Status.SAVED, recreated.status());
            assertNotNull(recreated.point());
            assertEquals("Основная", recreated.point().name());
            assertEquals(now.plusSeconds(6), recreated.point().createdAt());
            assertEquals(ClanHomeService.Status.NOT_IN_CLAN, service.homeFor(UUID.randomUUID()).status());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            var point = reopened.findClanHomePoint(clan.id()).orElseThrow();
            assertEquals("Основная", point.name());
            assertEquals(20.0, point.x());
        }
    }

    @Test
    void secondHomePointIsPurchasedFromTheBankAndRequiresTheOwnedSlot() {
        Path database = temporaryDirectory.resolve("clan-home-second.sqlite");
        Instant now = Instant.parse("2026-12-01T12:00:00Z");
        UUID leader = UUID.randomUUID();
        UUID deputy = UUID.randomUUID();
        UUID world = UUID.randomUUID();
        Clan clan = new Clan(UUID.randomUUID(), "TwoHomes", "TH02", now, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, now, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, now, null)), 0, null);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(clan));
            store.recordClanBankMovement(UUID.randomUUID(), "home-seed", clan.id(), leader, "DEPOSIT",
                    new java.math.BigDecimal("250000"), "seed", null, now);
            ClanHomeService service = new ClanHomeService(store, store);

            // The second slot is not available before purchase.
            assertEquals(ClanHomeService.Status.SLOT_NOT_PURCHASED,
                    service.setHome(leader, 2, world, 5, 6, 7, 0, 0, now.plusSeconds(1)).status());
            // Only the leader pays from the clan bank.
            assertEquals(ClanHomeService.Status.LEADER_ONLY,
                    service.purchaseSecondHome(deputy, now.plusSeconds(2)).status());

            assertEquals(ClanHomeService.Status.PURCHASED,
                    service.purchaseSecondHome(leader, now.plusSeconds(3)).status());
            assertEquals(0, store.clanBankBalance(clan.id()).compareTo(new java.math.BigDecimal("50000")));
            assertEquals(ClanHomeService.Status.ALREADY_PURCHASED,
                    service.purchaseSecondHome(leader, now.plusSeconds(4)).status());

            assertEquals(ClanHomeService.Status.SAVED,
                    service.setHome(deputy, 2, world, 5, 6, 7, 0, 0, now.plusSeconds(5)).status());
            assertEquals(ClanHomeService.Status.SAVED,
                    service.setHome(leader, 1, world, 1, 2, 3, 0, 0, now.plusSeconds(5)).status());
            assertEquals(ClanHomeService.SECOND_HOME_NAME,
                    service.homeFor(deputy, 2).point().name());
            assertEquals(2, service.pointsFor(leader).size());

            // Deleting the second point keeps the purchased slot for future use.
            assertEquals(ClanHomeService.Status.DELETED,
                    service.deleteHome(leader, 2, now.plusSeconds(6)).status());
            assertEquals(ClanHomeService.Status.HOME_NOT_SET, service.homeFor(deputy, 2).status());
            assertEquals(ClanHomeService.Status.SAVED,
                    service.setHome(leader, 2, world, 9, 9, 9, 0, 0, now.plusSeconds(7)).status());

            // A clan without funds cannot buy the slot.
            UUID poorLeader = UUID.randomUUID();
            Clan poor = new Clan(UUID.randomUUID(), "PoorClan", "PC03", now, 10,
                    Map.of(poorLeader, new ClanMember(poorLeader, ClanRole.LEADER, now, null)),
                    0, null);
            assertEquals(ClanCatalog.RegistrationStatus.REGISTERED, store.registerIfAvailable(poor));
            assertEquals(ClanHomeService.Status.INSUFFICIENT_BANK_FUNDS,
                    service.purchaseSecondHome(poorLeader, now.plusSeconds(8)).status());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertEquals(2, reopened.findClanHomePoints(clan.id()).size());
            assertEquals(0, reopened.clanBankBalance(clan.id()).compareTo(new java.math.BigDecimal("50000")));
            assertTrue(reopened.homeSlotOwned(clan.id(), 2));
        }
    }
}

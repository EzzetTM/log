package com.skyworldclans.admin;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanAdministrationServiceTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-01T09:00:00Z");
    private static final String CATEGORY = "RULES";

    @Test
    void reportsAreDeduplicatedAndAnonymousAuthorsAreHiddenExceptFromTheOwner() {
        String tag = "RP100";
        UUID leader = id(1), author = id(2);
        Clan clan = clan(leader, id(32), tag);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("reports.sqlite"))) {
            store.registerIfAvailable(clan);
            MutableClock clock = new MutableClock(NOW);
            var service = new ClanAdministrationService(store, store, clock, UUID::randomUUID);

            var created = service.submitReport(author, "Reporter", tag, CATEGORY, "rule violation",
                    List.of("https://example.com/evidence.png"));
            assertEquals(ClanAdministrationService.Status.CREATED, created.status());
            assertEquals(ClanAdministrationService.Status.DUPLICATE,
                    service.submitReport(author, "Reporter", tag, CATEGORY, "again", List.of()).status());
            assertEquals(ClanAdministrationService.Status.INVALID_CATEGORY,
                    service.submitReport(author, "Reporter", tag, "nonsense", "reason", List.of()).status());

            var anonymous = service.submitAnonymousReport(id(3), "Hidden", tag, "ABUSE",
                    "harassment", List.of());
            assertEquals(ClanAdministrationService.Status.CREATED, anonymous.status());

            UUID anonymousId = store.findClanReports(null, 50).stream()
                    .filter(report -> report.anonymous()).findFirst().orElseThrow().reportId();
            var moderatorView = service.viewReport(ClanAdministrationService.Level.MODERATOR, id(9),
                    anonymousId).orElseThrow();
            assertEquals("anonymous", moderatorView.authorName());
            assertEquals(new UUID(0L, 0L), moderatorView.authorId());

            var ownerView = service.viewReport(ClanAdministrationService.Level.OWNER, id(10),
                    anonymousId).orElseThrow();
            assertEquals("Hidden", ownerView.authorName());
            assertEquals(id(3), ownerView.authorId());

            var status = service.changeReportStatus(ClanAdministrationService.Level.MODERATOR, id(9),
                    anonymousId, "REJECTED", "closed");
            assertEquals(ClanAdministrationService.Status.UPDATED, status.status());
            // A closed report no longer blocks a new one for the same author and category.
            assertEquals(ClanAdministrationService.Status.CREATED,
                    service.submitAnonymousReport(id(3), "Hidden", tag, "ABUSE", "second", List.of()).status());
        }
    }

    @Test
    void sanctionsFollowEscalationAndOwnerOnlyRules() {
        String tag = "SN200";
        UUID leader = id(21), target = id(22), moderator = id(23);
        Clan clan = clan(leader, id(32), tag);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("sanctions.sqlite"))) {
            store.registerIfAvailable(clan);
            var service = new ClanAdministrationService(store, store,
                    Clock.fixed(NOW, ZoneOffset.UTC), UUID::randomUUID);

            assertEquals(ClanAdministrationService.Status.CREATED,
                    service.issueSanction(ClanAdministrationService.Level.MODERATOR, moderator, target,
                            "WARNING", "CLAN_CHAT", "spam", null, false).status());
            assertEquals(ClanAdministrationService.Status.UNAUTHORIZED,
                    service.issueSanction(ClanAdministrationService.Level.MODERATOR, moderator, target,
                            "TEMPORARY_FUNCTION_BLOCK", "CLAN_CHAT", "spam", Duration.ofHours(1), false).status());
            assertEquals(ClanAdministrationService.Status.CREATED,
                    service.issueSanction(ClanAdministrationService.Level.ADMIN, id(24), target,
                            "TEMPORARY_FUNCTION_BLOCK", "CLAN_CHAT", "abuse", Duration.ofHours(2), false).status());
            assertTrue(service.isFunctionBlocked(target, "CLAN_CHAT", NOW));
            assertFalse(service.isFunctionBlocked(target, "CLAN_BANK", NOW));

            var block = service.sanctions(ClanAdministrationService.Level.ADMIN, target, 10).stream()
                    .filter(sanction -> sanction.kind()
                            == SqliteClanStore.ClanSanctionKind.TEMPORARY_FUNCTION_BLOCK)
                    .findFirst().orElseThrow();
            assertEquals(ClanAdministrationService.Status.UPDATED,
                    service.revokeSanction(ClanAdministrationService.Level.ADMIN, id(24), block.sanctionId()).status());
            assertFalse(service.isFunctionBlocked(target, "CLAN_CHAT", NOW));
        }
    }

    @Test
    void appealsAreLimitedToSevenDaysAndOwnerSanctionsStayWithTheOwner() {
        String tag = "AP300";
        UUID leader = id(31), target = id(32);
        Clan clan = clan(leader, id(32), tag);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("appeals.sqlite"))) {
            store.registerIfAvailable(clan);
            MutableClock clock = new MutableClock(NOW);
            var service = new ClanAdministrationService(store, store, clock, UUID::randomUUID);

            service.issueSanction(ClanAdministrationService.Level.OWNER, id(33), target,
                    "FINAL_WARNING", "ALL", "serious", null, true);
            UUID sanctionId = store.findClanSanctions(target, 1).get(0).sanctionId();

            assertEquals(ClanAdministrationService.Status.UNAUTHORIZED,
                    service.submitAppeal(id(99), sanctionId, "not involved", null, false).status());
            var appeal = service.submitAppeal(leader, sanctionId, "unfair", "proof", false);
            assertEquals(ClanAdministrationService.Status.CREATED, appeal.status());
            assertEquals(ClanAdministrationService.Status.DUPLICATE,
                    service.submitAppeal(leader, sanctionId, "again", null, false).status());

            UUID appealId = store.findClanAppeals(null, 1).get(0).appealId();
            // An admin cannot decide a sanction issued by the owner.
            assertEquals(ClanAdministrationService.Status.OWNER_ONLY,
                    service.decideAppeal(ClanAdministrationService.Level.ADMIN, id(34), appealId,
                            true, "fine").status());
            assertEquals(ClanAdministrationService.Status.UPDATED,
                    service.decideAppeal(ClanAdministrationService.Level.OWNER, id(33), appealId,
                            true, "accepted").status());
            assertEquals(ClanAdministrationService.Status.ALREADY_DECIDED,
                    service.decideAppeal(ClanAdministrationService.Level.OWNER, id(33), appealId,
                            false, "again").status());

            // A second sanction gets its own appeal; the 7-day window still applies.
            service.issueSanction(ClanAdministrationService.Level.ADMIN, id(35), target,
                    "WARNING", "ALL", "minor", null, false);
            UUID secondSanction = store.findClanSanctions(target, 10).stream()
                    .filter(sanction -> sanction.kind() == SqliteClanStore.ClanSanctionKind.WARNING)
                    .findFirst().orElseThrow().sanctionId();
            clock.set(NOW.plus(Duration.ofDays(8)));
            assertEquals(ClanAdministrationService.Status.APPEAL_WINDOW_EXPIRED,
                    service.submitAppeal(leader, secondSanction, "late", null, false).status());
            assertEquals(ClanAdministrationService.Status.CREATED,
                    service.submitAppeal(leader, secondSanction, "late but allowed", null, true).status());
        }
    }

    private static Clan clan(UUID leader, UUID member, String tag) {
        Instant start = NOW.minusSeconds(86_400L * 30);
        return new Clan(new UUID(0, tag.hashCode() & 0xffff), "AdminClan", tag, start, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, start, null),
                        member, new ClanMember(member, ClanRole.MEMBER, start, null)), 0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }

    private static final class MutableClock extends Clock {
        private Instant current;
        private MutableClock(Instant start) { this.current = start; }
        void set(Instant value) { current = value; }
        @Override public ZoneId getZone() { return ZoneOffset.UTC; }
        @Override public Clock withZone(ZoneId zone) { return this; }
        @Override public Instant instant() { return current; }
    }
}
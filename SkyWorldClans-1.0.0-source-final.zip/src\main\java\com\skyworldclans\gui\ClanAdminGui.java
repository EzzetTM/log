package com.skyworldclans.gui;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.admin.ClanAdministrationService;
import com.skyworldclans.clan.Clan;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Administrative panel: system counters, clan list, complaints, sanctions and appeals.
 *
 * <p>Levels are read from the documented permission nodes ({@code skyworldclans.admin.owner},
 * {@code skyworldclans.admin}, {@code skyworldclans.admin.moderator}); the console is the owner.
 * Every click re-validates the level on the server, and moderator/admin actions never expose
 * anonymous complaint authors.</p>
 */
public final class ClanAdminGui implements Listener {
    private static final int SIZE = 54;

    private final SkyWorldClansPlugin plugin;
    private final ClanAdministrationService service;

    public ClanAdminGui(SkyWorldClansPlugin plugin, ClanAdministrationService service) {
        this.plugin = plugin; this.service = service;
    }

    public void open(Player player) {
        ClanAdministrationService.Level level = plugin.resolveAdminLevel(player);
        if (level == ClanAdministrationService.Level.NONE) {
            player.sendMessage(Component.text("[Кланы] Недостаточно прав для административной панели.",
                    NamedTextColor.RED));
            return;
        }
        Holder holder = new Holder(level, Screen.MAIN, null);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Администрация кланов", NamedTextColor.DARK_RED));
        holder.inventory = inventory;
        var store = plugin.getClanStore();
        inventory.setItem(4, item(Material.NETHER_STAR, "Состояние системы",
                List.of("Схема: " + store.schemaVersion(),
                        "Кланы: " + store.countClans() + " | участники: " + store.countMembers(),
                        "Хранилище: " + store.countStoragePages() + " стр.",
                        "Войны: " + store.countActiveClanWars() + " активных",
                        "Банк UNKNOWN: " + store.countUnknownBankOperations(),
                        "Хранилище на проверке: " + store.countStorageTransfersForReview(),
                        "CombatLog на проверке: " + store.countInterruptedCombatLogSessions()),
                NamedTextColor.AQUA));
        inventory.setItem(19, item(Material.PAPER, "Жалобы",
                List.of("Всего в базе", "Открыть список"), NamedTextColor.YELLOW));
        inventory.setItem(20, item(Material.WRITABLE_BOOK, "Санкции",
                List.of("История санкций", "Открыть список"), NamedTextColor.RED));
        inventory.setItem(21, item(Material.BOOK, "Апелляции",
                List.of("Ожидают решения", "Открыть список"), NamedTextColor.GOLD));
        inventory.setItem(22, item(Material.PLAYER_HEAD, "Кланы",
                List.of("Список кланов и участников"), NamedTextColor.GREEN));
        inventory.setItem(23, item(Material.CHEST, "Резервные копии",
                List.of("Создать копию (консоль): /clan admin backup",
                        "Последняя: " + plugin.latestBackup().map(b -> b.createdAt().toString()).orElse("нет")),
                NamedTextColor.GRAY));
        inventory.setItem(31, item(Material.BARRIER, "Закрыть", List.of(), NamedTextColor.RED));
        fill(inventory);
        player.openInventory(inventory);
    }

    private void openReports(Player player, ClanAdministrationService.Level level) {
        var reports = service.reports(level, null, 45);
        Holder holder = new Holder(level, Screen.REPORTS, null);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Жалобы (" + reports.size() + ")", NamedTextColor.YELLOW));
        holder.inventory = inventory;
        for (int index = 0; index < reports.size() && index < 45; index++) {
            var report = reports.get(index);
            String tag = plugin.getClanStore().findById(report.clanId())
                    .map(Clan::tag).orElse("?");
            inventory.setItem(index, item(Material.PAPER,
                    (index + 1) + ". [" + tag + "] " + report.category(),
                    List.of("Статус: " + report.status(),
                            "Автор: " + (report.anonymous() && level != ClanAdministrationService.Level.OWNER
                                    ? "анонимно" : report.authorName()),
                            "ID: " + report.reportId(),
                            "Нажми, чтобы открыть"),
                    report.anonymous() ? NamedTextColor.LIGHT_PURPLE : NamedTextColor.YELLOW));
        }
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    private void openReportDetail(Player player, ClanAdministrationService.Level level, UUID reportId) {
        var report = service.viewReport(level, player.getUniqueId(), reportId).orElse(null);
        if (report == null) {
            player.sendMessage(Component.text("[Кланы] Жалоба не найдена.", NamedTextColor.RED));
            return;
        }
        Holder holder = new Holder(level, Screen.REPORT_DETAIL, reportId);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Жалоба " + report.reportId().toString().substring(0, 8),
                        NamedTextColor.YELLOW));
        holder.inventory = inventory;
        String tag = plugin.getClanStore().findById(report.clanId()).map(Clan::tag).orElse("?");
        var evidence = service.evidence(level, reportId);
        List<String> lore = new ArrayList<>();
        lore.add("Клан: [" + tag + "]");
        lore.add("Категория: " + report.category());
        lore.add("Статус: " + report.status());
        lore.add("Автор: " + report.authorName());
        lore.add("Причина: " + report.reason());
        lore.add("Доказательств: " + evidence.size());
        inventory.setItem(4, item(Material.PAPER, "Жалоба", lore, NamedTextColor.YELLOW));
        int evidenceSlot = 9;
        for (var entry : evidence) {
            if (evidenceSlot >= 18) break;
            inventory.setItem(evidenceSlot++, item(Material.MAP, "Доказательство",
                    List.of(entry.url(), entry.description() == null ? "" : entry.description()),
                    NamedTextColor.AQUA));
        }
        int action = 28;
        for (var status : List.of("UNDER_REVIEW", "NEEDS_EVIDENCE", "ACCEPTED", "REJECTED")) {
            inventory.setItem(action++, item(Material.LIME_DYE, "Статус: " + status,
                    List.of("Применить"), NamedTextColor.GREEN));
        }
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    private void openSanctions(Player player, ClanAdministrationService.Level level) {
        var sanctions = service.sanctions(level, null, 45);
        Holder holder = new Holder(level, Screen.SANCTIONS, null);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Санкции (" + sanctions.size() + ")", NamedTextColor.RED));
        holder.inventory = inventory;
        for (int index = 0; index < sanctions.size() && index < 45; index++) {
            var sanction = sanctions.get(index);
            inventory.setItem(index, item(Material.PAPER, sanction.kind() + " / " + sanction.scope(),
                    List.of("Цель: " + sanction.targetId(),
                            "Причина: " + sanction.reason(),
                            "Выдана: " + sanction.issuedAt(),
                            "До: " + (sanction.expiresAt() == null ? "бессрочно" : sanction.expiresAt()),
                            "Статус: " + (sanction.revokedAt() == null ? "активна" : "отозвана"),
                            "ID: " + sanction.sanctionId()),
                    sanction.revokedAt() == null ? NamedTextColor.RED : NamedTextColor.GRAY));
        }
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    private void openAppeals(Player player, ClanAdministrationService.Level level) {
        var appeals = service.appeals(level, null, 45);
        Holder holder = new Holder(level, Screen.APPEALS, null);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Апелляции (" + appeals.size() + ")", NamedTextColor.GOLD));
        holder.inventory = inventory;
        for (int index = 0; index < appeals.size() && index < 45; index++) {
            var appeal = appeals.get(index);
            inventory.setItem(index, item(Material.BOOK, "Апелляция " + appeal.status(),
                    List.of("Санкция: " + appeal.sanctionId(),
                            "Причина: " + appeal.reason(),
                            "Подана: " + appeal.submittedAt(),
                            "ID: " + appeal.appealId(),
                            level == ClanAdministrationService.Level.OWNER
                                    || level == ClanAdministrationService.Level.ADMIN
                                    ? "Решение: /clan admin appeal-decide <ID> accept|reject"
                                    : "Решение принимает администратор"),
                    NamedTextColor.GOLD));
        }
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    private void openClans(Player player) {
        var store = plugin.getClanStore();
        Holder holder = new Holder(plugin.resolveAdminLevel(player), Screen.CLANS, null);
        Inventory inventory = Bukkit.createInventory(holder, SIZE,
                Component.text("Кланы (" + store.countClans() + ")", NamedTextColor.GREEN));
        holder.inventory = inventory;
        var ids = store.allClanIds();
        for (int index = 0; index < ids.size() && index < 45; index++) {
            Clan clan = store.findById(ids.get(index)).orElse(null);
            if (clan == null) continue;
            inventory.setItem(index, item(Material.PLAYER_HEAD, clan.name() + " [" + clan.tag() + "]",
                    List.of("Участники: " + clan.memberCount() + "/" + clan.capacity(),
                            "Уровень: " + clan.level() + " | XP: " + clan.totalXp(),
                            "Банк: " + store.clanBankBalance(clan.id()).toPlainString(),
                            "Домов: " + store.findClanHomePoints(clan.id()).size(),
                            "ID: " + clan.id()),
                    NamedTextColor.GREEN));
        }
        inventory.setItem(49, item(Material.ARROW, "Назад", List.of(), NamedTextColor.YELLOW));
        fill(inventory);
        player.openInventory(inventory);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof Holder holder)) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(top)) return;
        ClanAdministrationService.Level level = plugin.resolveAdminLevel(player);
        if (level == ClanAdministrationService.Level.NONE) {
            player.closeInventory();
            return;
        }
        int slot = event.getSlot();
        switch (holder.screen) {
            case MAIN -> {
                switch (slot) {
                    case 19 -> openReports(player, level);
                    case 20 -> openSanctions(player, level);
                    case 21 -> openAppeals(player, level);
                    case 22 -> openClans(player);
                    case 31 -> player.closeInventory();
                    default -> { }
                }
            }
            case REPORTS -> {
                if (slot == 49) { open(player); return; }
                if (slot >= 0 && slot < 45) {
                    var reports = service.reports(level, null, 45);
                    if (slot < reports.size()) openReportDetail(player, level, reports.get(slot).reportId());
                }
            }
            case REPORT_DETAIL -> {
                if (slot == 49) { openReports(player, level); return; }
                if (slot >= 28 && slot < 32 && holder.reportId != null) {
                    List<String> statuses = List.of("UNDER_REVIEW", "NEEDS_EVIDENCE", "ACCEPTED", "REJECTED");
                    String status = statuses.get(slot - 28);
                    var result = service.changeReportStatus(level, player.getUniqueId(),
                            holder.reportId, status, "panel:" + player.getName());
                    if (result.status() == ClanAdministrationService.Status.UPDATED) {
                        player.sendMessage(Component.text("[Кланы] Статус жалобы: " + status,
                                NamedTextColor.GREEN));
                        openReportDetail(player, level, holder.reportId);
                    } else {
                        player.sendMessage(Component.text("[Кланы] Не удалось изменить статус: "
                                + result.status(), NamedTextColor.RED));
                    }
                }
            }
            case SANCTIONS -> { if (slot == 49) open(player); }
            case APPEALS -> { if (slot == 49) open(player); }
            case CLANS -> { if (slot == 49) open(player); }
        }
    }

    private static ItemStack item(Material material, String name, List<String> lore, NamedTextColor color) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        if (!lore.isEmpty()) {
            List<Component> lines = new ArrayList<>();
            for (String value : lore) {
                if (value != null && !value.isBlank()) {
                    lines.add(Component.text(value, NamedTextColor.GRAY)
                            .decoration(TextDecoration.ITALIC, false));
                }
            }
            meta.lore(lines);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private static void fill(Inventory inventory) {
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.displayName(Component.text(" ").decoration(TextDecoration.ITALIC, false));
        filler.setItemMeta(meta);
        for (int index = 0; index < inventory.getSize(); index++) {
            if (inventory.getItem(index) == null) inventory.setItem(index, filler.clone());
        }
    }

    private enum Screen { MAIN, REPORTS, REPORT_DETAIL, SANCTIONS, APPEALS, CLANS }

    private static final class Holder implements InventoryHolder {
        private final ClanAdministrationService.Level level;
        private final Screen screen;
        private final UUID reportId;
        private Inventory inventory;
        private Holder(ClanAdministrationService.Level level, Screen screen, UUID reportId) {
            this.level = level; this.screen = screen; this.reportId = reportId;
        }
        @Override public Inventory getInventory() { return inventory; }
    }
}
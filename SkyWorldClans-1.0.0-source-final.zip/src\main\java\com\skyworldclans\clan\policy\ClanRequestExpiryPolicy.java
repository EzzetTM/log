package com.skyworldclans.clan.policy;

import java.time.Duration;
import java.time.Instant;

public final class ClanRequestExpiryPolicy {
    private static final Duration INVITATION_LIFETIME = Duration.ofMinutes(2);
    private static final Duration APPLICATION_LIFETIME = Duration.ofHours(24);

    private ClanRequestExpiryPolicy() {
    }

    public static boolean isInvitationActive(Instant createdAt, Instant now) {
        return isActive(createdAt, now, INVITATION_LIFETIME);
    }

    public static boolean isApplicationActive(Instant createdAt, Instant now) {
        return isActive(createdAt, now, APPLICATION_LIFETIME);
    }

    private static boolean isActive(Instant createdAt, Instant now, Duration lifetime) {
        return createdAt != null
                && now != null
                && now.isBefore(createdAt.plus(lifetime));
    }
}

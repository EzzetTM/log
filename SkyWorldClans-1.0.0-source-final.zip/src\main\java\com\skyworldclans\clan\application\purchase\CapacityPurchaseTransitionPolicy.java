package com.skyworldclans.clan.application.purchase;

import java.util.Objects;
import java.util.Optional;

public final class CapacityPurchaseTransitionPolicy {
    private CapacityPurchaseTransitionPolicy() {
    }

    public static Result evaluate(
            CapacityPurchaseState current,
            CapacityPurchaseState next,
            CapacityPurchaseTransitionEvidence evidence) {
        Objects.requireNonNull(current, "current");
        Objects.requireNonNull(next, "next");
        Objects.requireNonNull(evidence, "evidence");

        Optional<CapacityPurchaseTransitionEvidence> requiredEvidence =
                evidenceForTransition(current, next);
        if (requiredEvidence.isEmpty()) {
            return Result.INVALID_TRANSITION;
        }
        if (evidence != requiredEvidence.get()) {
            return evidence == CapacityPurchaseTransitionEvidence.NONE
                    ? Result.EVIDENCE_REQUIRED
                    : Result.UNEXPECTED_EVIDENCE;
        }
        return Result.ALLOWED;
    }

    public static Optional<CapacityPurchaseTransitionEvidence> evidenceForTransition(
            CapacityPurchaseState current,
            CapacityPurchaseState next) {
        Objects.requireNonNull(current, "current");
        Objects.requireNonNull(next, "next");
        return Optional.ofNullable(switch (current) {
            case PREPARED -> switch (next) {
                case CALLING -> CapacityPurchaseTransitionEvidence.NONE;
                case FAILED_NO_EFFECT ->
                        CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED;
                default -> null;
            };
            case CALLING -> switch (next) {
                case DEBIT_CONFIRMED -> CapacityPurchaseTransitionEvidence.DEBIT_SUCCESS_REPORTED;
                case FAILED_NO_EFFECT ->
                        CapacityPurchaseTransitionEvidence.DEBIT_NO_EFFECT_REPORTED;
                case UNKNOWN -> CapacityPurchaseTransitionEvidence.DEBIT_RESULT_UNKNOWN_REPORTED;
                default -> null;
            };
            case DEBIT_CONFIRMED -> switch (next) {
                case COMMITTED -> CapacityPurchaseTransitionEvidence.ATOMIC_CAPACITY_COMMIT;
                case COMPENSATION_PENDING ->
                        CapacityPurchaseTransitionEvidence.COMPENSATION_REQUIRED_REPORTED;
                default -> null;
            };
            case UNKNOWN -> switch (next) {
                case DEBIT_CONFIRMED ->
                        CapacityPurchaseTransitionEvidence.RECONCILED_DEBIT_SUCCESS_REPORTED;
                case FAILED_NO_EFFECT ->
                        CapacityPurchaseTransitionEvidence.RECONCILED_DEBIT_NO_EFFECT_REPORTED;
                default -> null;
            };
            case COMPENSATION_PENDING -> switch (next) {
                case COMPENSATION_CALLING ->
                        CapacityPurchaseTransitionEvidence.COMPENSATION_CALL_INTENT_RECORDED;
                default -> null;
            };
            case COMPENSATION_CALLING -> switch (next) {
                case COMPENSATED ->
                        CapacityPurchaseTransitionEvidence.COMPENSATION_SUCCESS_REPORTED;
                case COMPENSATION_FAILED ->
                        CapacityPurchaseTransitionEvidence.COMPENSATION_NO_EFFECT_REPORTED;
                case COMPENSATION_UNKNOWN ->
                        CapacityPurchaseTransitionEvidence.COMPENSATION_RESULT_UNKNOWN_REPORTED;
                default -> null;
            };
            case COMPENSATION_UNKNOWN -> switch (next) {
                case COMPENSATED ->
                        CapacityPurchaseTransitionEvidence
                                .RECONCILED_COMPENSATION_SUCCESS_REPORTED;
                case COMPENSATION_FAILED ->
                        CapacityPurchaseTransitionEvidence
                                .RECONCILED_COMPENSATION_NO_EFFECT_REPORTED;
                default -> null;
            };
            case COMMITTED, FAILED_NO_EFFECT, COMPENSATED, COMPENSATION_FAILED -> null;
        });
    }

    public enum Result {
        ALLOWED,
        INVALID_TRANSITION,
        EVIDENCE_REQUIRED,
        UNEXPECTED_EVIDENCE
    }
}

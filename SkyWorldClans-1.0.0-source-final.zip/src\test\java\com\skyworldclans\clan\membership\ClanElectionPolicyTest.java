package com.skyworldclans.clan.membership;

import com.skyworldclans.clan.Clan;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanElectionPolicyTest {
    private final ClanElectionPolicy policy = new ClanElectionPolicy();

    @Test
    void oneDeputyBecomesAutomaticSuccessorAndDoesNotStartElection() {
        UUID leader = id(1), deputy = id(2), member = id(3);
        Clan clan = clan(1, Map.of(
                leader, member(leader, ClanRole.LEADER),
                deputy, member(deputy, ClanRole.DEPUTY),
                member, member(member, ClanRole.MEMBER)));
        assertEquals(java.util.Optional.of(deputy), policy.automaticSuccessor(clan, leader));
        assertTrue(policy.departureCandidates(clan, leader).isEmpty());
    }

    @Test
    void multipleDeputiesAreCandidatesOtherwiseRemainingMembersAreCandidates() {
        UUID leader = id(11), deputyA = id(12), deputyB = id(13), member = id(14);
        Clan withDeputies = clan(11, Map.of(
                leader, member(leader, ClanRole.LEADER),
                deputyA, member(deputyA, ClanRole.DEPUTY),
                deputyB, member(deputyB, ClanRole.DEPUTY),
                member, member(member, ClanRole.MEMBER)));
        assertEquals(java.util.List.of(deputyA, deputyB), policy.departureCandidates(withDeputies, leader));
        Clan withoutDeputies = clan(12, Map.of(
                leader, member(leader, ClanRole.LEADER), member, member(member, ClanRole.MEMBER)));
        assertEquals(java.util.List.of(member), policy.departureCandidates(withoutDeputies, leader));
    }

    @Test
    void coupCandidatesIncludeIncumbentAndAllDeputies() {
        UUID leader = id(21), deputyA = id(22), deputyB = id(23), member = id(24);
        Clan clan = clan(21, Map.of(
                leader, member(leader, ClanRole.LEADER),
                deputyA, member(deputyA, ClanRole.DEPUTY),
                deputyB, member(deputyB, ClanRole.DEPUTY),
                member, member(member, ClanRole.MEMBER)));
        assertEquals(java.util.List.of(leader, deputyA, deputyB), policy.coupCandidates(clan));
    }

    @Test
    void tieBreakContainsOnlyCandidatesWithTheHighestVoteCount() {
        UUID a = id(31), b = id(32), c = id(33);
        assertEquals(java.util.List.of(a, b), policy.tiedForFirst(
                java.util.List.of(a, b, c), Map.of(a, 4, b, 4, c, 2)));
        assertTrue(policy.uniqueWinner(java.util.List.of(a, b), Map.of(a, 5, b, 3)).isPresent());
        assertFalse(policy.uniqueWinner(java.util.List.of(a, b), Map.of(a, 5, b, 5)).isPresent());
    }

    @Test
    void localVotesRequireClanMembershipAndGlobalVotesRequirePermission() {
        UUID leader = id(41), member = id(42), outsider = id(43);
        Clan clan = clan(41, Map.of(leader, member(leader, ClanRole.LEADER),
                member, member(member, ClanRole.MEMBER)));
        java.util.List<UUID> candidates = java.util.List.of(member);
        assertTrue(policy.canVote(clan, leader, candidates, member));
        assertFalse(policy.canVote(clan, outsider, candidates, member));
        assertTrue(policy.canUseGlobalTieBreakPermission(true, outsider, candidates, member));
        assertFalse(policy.canUseGlobalTieBreakPermission(false, outsider, candidates, member));
        assertFalse(policy.canUseGlobalTieBreakPermission(true, outsider, candidates, outsider));
    }

    @Test
    void electionDurationsMatchTheSpecification() {
        assertEquals(24 * 60 * 60, ClanElectionPolicy.DEPARTURE_ELECTION_DURATION.toSeconds());
        assertEquals(6 * 60 * 60, ClanElectionPolicy.GLOBAL_TIE_BREAK_DURATION.toSeconds());
        assertEquals(30L, ClanElectionPolicy.LEADER_INACTIVITY_REQUIRED.toDays());
        assertEquals(30L, ClanElectionPolicy.REPEAT_COUP_WAIT.toDays());
    }

    private static Clan clan(int n, Map<UUID, ClanMember> members) {
        return new Clan(id(n), "Election" + n, "EL" + n,
                Instant.parse("2025-01-01T00:00:00Z"), 10, members, 0, null);
    }

    private static ClanMember member(UUID id, ClanRole role) {
        return new ClanMember(id, role, Instant.parse("2025-01-01T00:00:00Z"), null);
    }

    private static UUID id(long value) { return new UUID(0, value); }
}

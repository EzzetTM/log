package com.skyworldclans.integration.vault;

import com.skyworldclans.integration.EconomyOperations;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.OfflinePlayer;
import org.bukkit.Server;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/** Optional bridge to the active Vault Economy provider. No provider is treated as unavailable. */
public final class VaultEconomyBridge implements EconomyOperations {
    private final Server server;
    private final Economy economy;

    private VaultEconomyBridge(Server server, Economy economy) {
        this.server = Objects.requireNonNull(server, "server");
        this.economy = Objects.requireNonNull(economy, "economy");
    }

    public static Optional<VaultEconomyBridge> discover(Server server, PluginManager plugins) {
        Objects.requireNonNull(server, "server");
        Objects.requireNonNull(plugins, "plugins");
        if (plugins.getPlugin("Vault") == null) return Optional.empty();
        RegisteredServiceProvider<Economy> registration =
                server.getServicesManager().getRegistration(Economy.class);
        if (registration == null || registration.getProvider() == null) return Optional.empty();
        return Optional.of(new VaultEconomyBridge(server, registration.getProvider()));
    }

    @Override public BalanceResult balance(UUID playerId) {
        if (playerId == null) return new EconomyOperations.BalanceResult(EconomyOperations.Status.INVALID_INPUT, 0.0, "Missing player UUID");
        try {
            OfflinePlayer player = server.getOfflinePlayer(playerId);
            double balance = economy.getBalance(player);
            if (!Double.isFinite(balance) || balance < 0.0) {
                return new EconomyOperations.BalanceResult(EconomyOperations.Status.UNKNOWN, 0.0, "Provider returned an invalid balance");
            }
            return new EconomyOperations.BalanceResult(EconomyOperations.Status.SUCCESS, balance, "");
        } catch (RuntimeException exception) {
            return new EconomyOperations.BalanceResult(EconomyOperations.Status.UNKNOWN, 0.0, safeMessage(exception));
        }
    }

    @Override public OperationResult withdraw(UUID playerId, double amount) {
        return transact(playerId, amount, true);
    }

    @Override public OperationResult deposit(UUID playerId, double amount) {
        return transact(playerId, amount, false);
    }

    private EconomyOperations.OperationResult transact(UUID playerId, double amount, boolean withdraw) {
        if (playerId == null || !Double.isFinite(amount) || amount <= 0.0) {
            return new EconomyOperations.OperationResult(EconomyOperations.Status.INVALID_INPUT, "Invalid player or amount");
        }
        try {
            OfflinePlayer player = server.getOfflinePlayer(playerId);
            if (withdraw && !economy.has(player, amount)) {
                return new EconomyOperations.OperationResult(EconomyOperations.Status.INSUFFICIENT_FUNDS, "Insufficient funds");
            }
            EconomyResponse response = withdraw
                    ? economy.withdrawPlayer(player, amount)
                    : economy.depositPlayer(player, amount);
            if (response == null) return new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN, "Provider returned no response");
            if (response.transactionSuccess()) return new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "");
            return new EconomyOperations.OperationResult(EconomyOperations.Status.PROVIDER_FAILURE,
                    response.errorMessage == null ? "Provider rejected the transaction" : response.errorMessage);
        } catch (RuntimeException exception) {
            return new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN, safeMessage(exception));
        }
    }

    private static String safeMessage(RuntimeException exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
    }

}

package com.skyworldclans.clan.application.creation;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.ClanFactory;
import com.skyworldclans.clan.application.CreateClanCommand;
import com.skyworldclans.clan.application.CreateClanUseCase;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.filter.ForbiddenExpressionFilter;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.service.ClanService;
import com.skyworldclans.integration.EconomyOperations;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanCreationCoordinatorTest {
    @Test void successfulPaymentIsCommittedOnceAndUsesExactPrice() {
        InMemoryCatalog catalog = new InMemoryCatalog();
        InMemoryJournal journal = new InMemoryJournal();
        AtomicInteger debits = new AtomicInteger();
        EconomyOperations economy = economy((player, amount) -> {
            assertEquals(1_000_000.0d, amount);
            debits.incrementAndGet();
            return new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "");
        });
        ClanCreationCoordinator coordinator = coordinator(catalog, journal, economy);

        ClanCreationCoordinator.Result result = coordinator.create(
                new CreateClanCommand(UUID.randomUUID(), "Valid Clan", "VC", "A slogan"));

        assertEquals(ClanCreationCoordinator.Status.CREATED, result.status());
        assertEquals(1, debits.get());
        assertEquals(ClanCreationPaymentState.COMMITTED, journal.operation.state());
        assertEquals(1, journal.commits);
        assertTrue(result.clan().isPresent());
    }

    @Test void unknownProviderResultIsNotRetriedAndBlocksAnotherCreation() {
        InMemoryCatalog catalog = new InMemoryCatalog();
        InMemoryJournal journal = new InMemoryJournal();
        AtomicInteger debits = new AtomicInteger();
        EconomyOperations economy = economy((player, amount) -> {
            debits.incrementAndGet();
            return new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN, "timeout");
        });
        ClanCreationCoordinator coordinator = coordinator(catalog, journal, economy);
        UUID creator = UUID.randomUUID();

        assertEquals(ClanCreationCoordinator.Status.PAYMENT_RESULT_UNCERTAIN,
                coordinator.create(new CreateClanCommand(creator, "Valid Clan", "VC", null)).status());
        assertEquals(ClanCreationPaymentState.UNKNOWN, journal.operation.state());
        assertEquals(ClanCreationCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED,
                coordinator.create(new CreateClanCommand(creator, "Other Clan", "OC", null)).status());
        assertEquals(1, debits.get());
        assertEquals(0, journal.commits);
    }

    @Test void restartFinishesConfirmedDebitWithoutCallingEconomyAgain() {
        InMemoryCatalog catalog = new InMemoryCatalog();
        InMemoryJournal journal = new InMemoryJournal();
        AtomicInteger debits = new AtomicInteger();
        EconomyOperations economy = economy((player, amount) -> {
            debits.incrementAndGet();
            return new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "");
        });
        ClanCreationCoordinator coordinator = coordinator(catalog, journal, economy);
        UUID creator = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new ClanFactory().create(UUID.randomUUID(), "Valid Clan", "VC", creator, now, now);
        journal.operation = new ClanCreationPaymentOperation(UUID.randomUUID(), "confirmed", creator,
                clan.id(), clan.name(), clan.tag(), null, now,
                ClanCreationPaymentOperation.CREATION_PRICE_UNITS, ClanCreationPaymentState.DEBIT_CONFIRMED,
                null, now, now);

        List<ClanCreationCoordinator.Result> results = coordinator.recoverAfterRestart();

        assertEquals(ClanCreationCoordinator.Status.CREATED, results.getFirst().status());
        assertEquals(ClanCreationPaymentState.COMMITTED, journal.operation.state());
        assertEquals(1, journal.commits);
        assertEquals(0, debits.get());
    }

    @Test void restartCancelsPreparedIntentWithoutIssuingDebit() {
        InMemoryCatalog catalog = new InMemoryCatalog();
        InMemoryJournal journal = new InMemoryJournal();
        AtomicInteger debits = new AtomicInteger();
        EconomyOperations economy = economy((player, amount) -> {
            debits.incrementAndGet();
            return new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "");
        });
        ClanCreationCoordinator coordinator = coordinator(catalog, journal, economy);
        UUID creator = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new ClanFactory().create(UUID.randomUUID(), "Valid Clan", "VC", creator, now, now);
        journal.operation = new ClanCreationPaymentOperation(UUID.randomUUID(), "prepared", creator,
                clan.id(), clan.name(), clan.tag(), null, now,
                ClanCreationPaymentOperation.CREATION_PRICE_UNITS, ClanCreationPaymentState.PREPARED,
                null, now, now);

        List<ClanCreationCoordinator.Result> results = coordinator.recoverAfterRestart();

        assertEquals(ClanCreationCoordinator.Status.INTERRUPTED_BEFORE_PAYMENT, results.getFirst().status());
        assertEquals(ClanCreationPaymentState.FAILED_NO_EFFECT, journal.operation.state());
        assertEquals(0, debits.get());
    }

    @Test void consoleReconciliationOfPaidUnknownOperationFinishesClanWithoutAnotherDebit() {
        InMemoryCatalog catalog = new InMemoryCatalog();
        InMemoryJournal journal = new InMemoryJournal();
        AtomicInteger debits = new AtomicInteger();
        ClanCreationCoordinator coordinator = coordinator(catalog, journal, economy((player, amount) -> {
            debits.incrementAndGet();
            return new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "");
        }));
        UUID creator = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new ClanFactory().create(UUID.randomUUID(), "Valid Clan", "VC", creator, now, now);
        journal.operation = new ClanCreationPaymentOperation(UUID.randomUUID(), "console-paid", creator,
                clan.id(), clan.name(), clan.tag(), null, now,
                ClanCreationPaymentOperation.CREATION_PRICE_UNITS, ClanCreationPaymentState.UNKNOWN,
                "timeout", now, now);

        ClanCreationCoordinator.Result result = coordinator.reconcileUnknown(
                journal.operation.operationId(), true, "provider transaction log confirms withdrawal");

        assertEquals(ClanCreationCoordinator.Status.CREATED, result.status());
        assertEquals(ClanCreationPaymentState.COMMITTED, journal.operation.state());
        assertEquals(1, journal.commits);
        assertEquals(0, debits.get());
    }

    @Test void consoleReconciliationOfNoDebitReleasesPlayerAndTagReservation() {
        InMemoryCatalog catalog = new InMemoryCatalog();
        InMemoryJournal journal = new InMemoryJournal();
        ClanCreationCoordinator coordinator = coordinator(catalog, journal, economy((player, amount) ->
                new EconomyOperations.OperationResult(EconomyOperations.Status.UNKNOWN, "timeout")));
        UUID creator = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new ClanFactory().create(UUID.randomUUID(), "Valid Clan", "VC", creator, now, now);
        journal.operation = new ClanCreationPaymentOperation(UUID.randomUUID(), "console-no-debit", creator,
                clan.id(), clan.name(), clan.tag(), null, now,
                ClanCreationPaymentOperation.CREATION_PRICE_UNITS, ClanCreationPaymentState.UNKNOWN,
                "timeout", now, now);

        ClanCreationCoordinator.Result result = coordinator.reconcileUnknown(
                journal.operation.operationId(), false, "provider transaction log contains no withdrawal");

        assertEquals(ClanCreationCoordinator.Status.RECONCILED_NO_DEBIT, result.status());
        assertEquals(ClanCreationPaymentState.FAILED_NO_EFFECT, journal.operation.state());
        assertEquals(0, journal.commits);
    }

    @Test void restartTurnsInterruptedProviderCallIntoUnknownWithoutRepeatingDebit() {
        InMemoryCatalog catalog = new InMemoryCatalog();
        InMemoryJournal journal = new InMemoryJournal();
        AtomicInteger debits = new AtomicInteger();
        EconomyOperations economy = economy((player, amount) -> {
            debits.incrementAndGet();
            return new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "");
        });
        ClanCreationCoordinator coordinator = coordinator(catalog, journal, economy);
        UUID creator = UUID.randomUUID();
        Instant now = Instant.parse("2026-11-15T12:00:00Z");
        Clan clan = new ClanFactory().create(UUID.randomUUID(), "Valid Clan", "VC", creator, now, now);
        journal.operation = new ClanCreationPaymentOperation(UUID.randomUUID(), "resume", creator,
                clan.id(), clan.name(), clan.tag(), null, now,
                ClanCreationPaymentOperation.CREATION_PRICE_UNITS, ClanCreationPaymentState.CALLING,
                null, now, now);

        List<ClanCreationCoordinator.Result> results = coordinator.recoverAfterRestart();

        assertEquals(ClanCreationCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED, results.getFirst().status());
        assertEquals(ClanCreationPaymentState.UNKNOWN, journal.operation.state());
        assertEquals(0, debits.get());
    }

    private static ClanCreationCoordinator coordinator(InMemoryCatalog catalog, InMemoryJournal journal,
            EconomyOperations economy) {
        var service = new ClanService(catalog, new ClanMembershipStateValidator());
        var preflight = new CreateClanUseCase(new ClanFactory(), service,
                ForbiddenExpressionFilter.load(List::of), UUID::randomUUID,
                Clock.fixed(Instant.parse("2026-11-15T12:00:00Z"), ZoneOffset.UTC));
        return new ClanCreationCoordinator(preflight, journal, Optional.of(economy),
                Clock.fixed(Instant.parse("2026-11-15T12:00:00Z"), ZoneOffset.UTC), UUID::randomUUID);
    }

    private static EconomyOperations economy(Withdraw withdraw) {
        return new EconomyOperations() {
            public BalanceResult balance(UUID playerId) { return new BalanceResult(Status.SUCCESS, 2_000_000, ""); }
            public OperationResult withdraw(UUID playerId, double amount) { return withdraw.apply(playerId, amount); }
            public OperationResult deposit(UUID playerId, double amount) { return new OperationResult(Status.SUCCESS, ""); }
        };
    }

    @FunctionalInterface private interface Withdraw { EconomyOperations.OperationResult apply(UUID player, double amount); }

    private static final class InMemoryJournal implements ClanCreationPaymentJournal {
        ClanCreationPaymentOperation operation;
        int commits;
        public CreationPrepareResult prepare(ClanCreationPaymentOperation value) {
            if (operation != null) return new CreationPrepareResult(CreationPrepareStatus.PLAYER_HAS_UNRESOLVED_CREATION, Optional.of(operation));
            operation = value;
            return new CreationPrepareResult(CreationPrepareStatus.CREATED, Optional.of(value));
        }
        public Optional<ClanCreationPaymentOperation> findCreationByIdempotencyKey(String key) {
            return operation != null && operation.idempotencyKey().equals(key) ? Optional.of(operation) : Optional.empty();
        }
        public Optional<ClanCreationPaymentOperation> findCreationById(UUID id) {
            return operation != null && operation.operationId().equals(id) ? Optional.of(operation) : Optional.empty();
        }
        public List<ClanCreationPaymentOperation> findUnresolvedCreations() {
            return operation != null && ClanCreationRecoveryPolicy.classify(operation) != ClanCreationRecoveryAction.COMPLETED
                    ? List.of(operation) : List.of();
        }
        public CreationTransitionResult transition(UUID id, ClanCreationPaymentState expected,
                ClanCreationPaymentState next, String diagnostic, Instant at) {
            if (operation == null || !operation.operationId().equals(id))
                return new CreationTransitionResult(CreationTransitionStatus.NOT_FOUND, Optional.empty());
            if (operation.state() != expected)
                return new CreationTransitionResult(CreationTransitionStatus.STATE_CONFLICT, Optional.of(operation));
            operation = operation.withState(next, diagnostic, at);
            return new CreationTransitionResult(CreationTransitionStatus.UPDATED, Optional.of(operation));
        }
        public CreationCommitResult commitPaidClan(UUID id, Clan clan, Instant at) {
            if (operation == null || operation.state() != ClanCreationPaymentState.DEBIT_CONFIRMED)
                return new CreationCommitResult(CreationCommitStatus.NOT_DEBIT_CONFIRMED, Optional.empty());
            operation = operation.withState(ClanCreationPaymentState.COMMITTED, null, at);
            commits++;
            return new CreationCommitResult(CreationCommitStatus.COMMITTED, Optional.of(clan));
        }
    }

    private static final class InMemoryCatalog implements ClanCatalog {
        final Map<UUID, Clan> clans = new HashMap<>();
        public Optional<Clan> findById(UUID id) { return Optional.ofNullable(clans.get(id)); }
        public Optional<Clan> findByTag(String tag) { return clans.values().stream().filter(c -> c.tag().equalsIgnoreCase(tag)).findFirst(); }
        public Optional<Clan> findByPlayerId(UUID id) { return clans.values().stream().filter(c -> c.member(id).isPresent()).findFirst(); }
        public Optional<Long> findRevision(UUID id) { return clans.containsKey(id) ? Optional.of(0L) : Optional.empty(); }
        public RegistrationStatus registerIfAvailable(Clan clan) { clans.put(clan.id(), clan); return RegistrationStatus.REGISTERED; }
        public CapacityUpdateStatus updateCapacityIfUnchanged(Clan old, UUID leader, Clan updated) { return CapacityUpdateStatus.INVALID_UPDATE; }
        public MembershipUpdateStatus updateMembershipIfUnchanged(Clan old, Clan updated) { return MembershipUpdateStatus.INVALID_UPDATE; }
    }
}

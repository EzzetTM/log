package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Clock;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

/**
 * Clan rename (owner decision #1): the name and the tag change together.
 *
 * <p>The approved price is 200 SWCoin. The public SkyWorldCoins API is not confirmed, so no charge
 * can be performed: the service refuses the operation with a clear diagnostic and never emulates
 * payment through commands or reflection. Once a real adapter exists, the charge happens between
 * the validation step and {@link SqliteClanStore#renameClan} — the storage call itself is
 * idempotent per revision and performs no money movement.</p>
 */
public final class ClanRenameService {
    private static final boolean SWCOIN_AVAILABLE = false;

    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final Clock clock;

    public ClanRenameService(ClanCatalog clans, SqliteClanStore store, Clock clock) {
        this.clans = Objects.requireNonNull(clans);
        this.store = Objects.requireNonNull(store);
        this.clock = Objects.requireNonNull(clock);
    }

    public Result rename(UUID actorId, String newName, String newTag) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return new Result(Status.NOT_IN_CLAN, null, null);
        if (clan.member(actorId).map(member -> member.role() != ClanRole.LEADER).orElse(true))
            return new Result(Status.LEADER_ONLY, clan, null);
        if (newName == null || newName.isBlank() || newTag == null || newTag.isBlank())
            return new Result(Status.INVALID_INPUT, clan, null);
        if (!SWCOIN_AVAILABLE) {
            // Honest refusal instead of a free rename or an invented payment path.
            return new Result(Status.SWCOIN_UNAVAILABLE, clan, null);
        }
        Instant now = clock.instant();
        var result = store.renameClan(clan.id(), actorId, newName, newTag, now);
        return switch (result.status()) {
            case RENAMED -> new Result(Status.RENAMED, result.clan(), null);
            case UNCHANGED -> new Result(Status.UNCHANGED, result.clan(), null);
            case LEADER_ONLY -> new Result(Status.LEADER_ONLY, clan, null);
            case TAG_CONFLICT -> new Result(Status.TAG_TAKEN, clan, null);
            case CLAN_NOT_FOUND -> new Result(Status.NOT_IN_CLAN, null, null);
            default -> new Result(Status.INVALID_INPUT, clan, null);
        };
    }

    /** Performs the rename without charging; used by tests and by the future paid path. */
    Result renameWithoutCharge(UUID actorId, String newName, String newTag) {
        Clan clan = clans.findByPlayerId(actorId).orElse(null);
        if (clan == null) return new Result(Status.NOT_IN_CLAN, null, null);
        var result = store.renameClan(clan.id(), actorId, newName, newTag, clock.instant());
        return switch (result.status()) {
            case RENAMED -> new Result(Status.RENAMED, result.clan(), null);
            case UNCHANGED -> new Result(Status.UNCHANGED, result.clan(), null);
            case LEADER_ONLY -> new Result(Status.LEADER_ONLY, clan, null);
            case TAG_CONFLICT -> new Result(Status.TAG_TAKEN, clan, null);
            default -> new Result(Status.INVALID_INPUT, clan, null);
        };
    }

    public enum Status {
        RENAMED, UNCHANGED, INVALID_INPUT, NOT_IN_CLAN, LEADER_ONLY, TAG_TAKEN,
        SWCOIN_UNAVAILABLE, STORAGE_ERROR
    }

    public record Result(Status status, Clan clan, String diagnostic) { }
}
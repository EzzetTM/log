package com.skyworldclans.clan.xp;

/** XP sources and achievement milestones explicitly listed in the technical specification. */
public enum ClanXpEventType {
    WAR_WIN(1_000), WAR_DRAW(250), WAR_LOSS(0),
    TOURNAMENT_PARTICIPATION(500), TOURNAMENT_WIN_BONUS(3_000),
    FIRST_WAR_WIN(500), TEN_WAR_WINS(2_000), HUNDRED_TASKS_COMPLETED(3_000),
    TEN_MEMBERS_COMPLETED_TASKS(1_000), BANK_CONTRIBUTION_10M(2_000),
    FIRST_TOURNAMENT_WIN(2_500), LEVEL_TEN_ACHIEVEMENT(10_000),
    FIRST_RECRUIT_JOINED(100), MEMBER_PEAK_5(500), MEMBER_PEAK_10(1_000),
    MEMBER_PEAK_25(2_500), MEMBER_PEAK_40(4_000), MEMBER_PEAK_50(7_500),
    // Quest XP table from the technical specification: category × difficulty.
    QUEST_DAILY_EASY(100), QUEST_DAILY_MEDIUM(200), QUEST_DAILY_HARD(350),
    QUEST_WEEKLY_EASY(500), QUEST_WEEKLY_MEDIUM(1_000), QUEST_WEEKLY_HARD(1_750),
    QUEST_SPECIAL_EASY(2_000), QUEST_SPECIAL_MEDIUM(3_500), QUEST_SPECIAL_HARD(5_000);

    private final long amount;
    ClanXpEventType(long amount) { this.amount = amount; }
    public long amount() { return amount; }
}

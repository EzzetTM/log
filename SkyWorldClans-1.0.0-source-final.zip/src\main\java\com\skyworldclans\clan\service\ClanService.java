package com.skyworldclans.clan.service;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public final class ClanService {
    private final ClanCatalog clanCatalog;
    private final ClanMembershipStateValidator membershipStateValidator;

    public ClanService(
            ClanCatalog clanCatalog,
            ClanMembershipStateValidator membershipStateValidator) {
        this.clanCatalog = Objects.requireNonNull(clanCatalog, "clanCatalog");
        this.membershipStateValidator = Objects.requireNonNull(
                membershipStateValidator, "membershipStateValidator");
    }

    public ClanRegistrationResult registerClan(Clan clan) {
        if (clan == null) {
            return result(ClanRegistrationResult.Status.CLAN_REQUIRED);
        }

        List<ClanMembershipStateValidator.Violation> violations =
                membershipStateValidator.validate(clan, false);
        if (!violations.isEmpty()) {
            return new ClanRegistrationResult(
                    ClanRegistrationResult.Status.INVALID_MEMBERSHIP_STATE,
                    violations);
        }

        ClanCatalog.RegistrationStatus registrationStatus = Objects.requireNonNull(
                clanCatalog.registerIfAvailable(clan),
                "clanCatalog must return a registration status");
        return switch (registrationStatus) {
            case REGISTERED -> result(ClanRegistrationResult.Status.REGISTERED);
            case CLAN_REQUIRED -> result(ClanRegistrationResult.Status.CLAN_REQUIRED);
            case CLAN_ID_CONFLICT -> result(ClanRegistrationResult.Status.CLAN_ID_CONFLICT);
            case TAG_CONFLICT -> result(ClanRegistrationResult.Status.TAG_CONFLICT);
            case MEMBER_CONFLICT -> result(ClanRegistrationResult.Status.MEMBER_CONFLICT);
        };
    }

    public boolean isPlayerInClan(UUID playerId) {
        return clanCatalog.findByPlayerId(Objects.requireNonNull(playerId, "playerId")).isPresent();
    }

    public boolean isTagAvailable(String tag) {
        return clanCatalog.findByTag(Objects.requireNonNull(tag, "tag")).isEmpty();
    }

    public ClanCapacityExpansionResult expandCapacity(
            UUID clanId,
            UUID actorId,
            int requestedCapacity) {
        if (clanId == null || actorId == null) {
            return expansionResult(ClanCapacityExpansionResult.Status.INVALID_INPUT);
        }

        Clan current = clanCatalog.findById(clanId).orElse(null);
        if (current == null) {
            return expansionResult(ClanCapacityExpansionResult.Status.CLAN_NOT_FOUND);
        }
        if (!current.leader().map(leader -> leader.playerId().equals(actorId)).orElse(false)) {
            return expansionResult(ClanCapacityExpansionResult.Status.NOT_LEADER);
        }

        Clan expanded;
        try {
            expanded = current.withExpandedCapacity(requestedCapacity);
        } catch (IllegalArgumentException exception) {
            return expansionResult(
                    ClanCapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION);
        }

        ClanCatalog.CapacityUpdateStatus updateStatus =
                Objects.requireNonNull(
                        clanCatalog.updateCapacityIfUnchanged(current, actorId, expanded),
                        "clanCatalog must return a capacity update status");
        return switch (updateStatus) {
            case UPDATED -> new ClanCapacityExpansionResult(
                    ClanCapacityExpansionResult.Status.EXPANDED,
                    Optional.of(expanded));
            case CLAN_NOT_FOUND -> expansionResult(
                    ClanCapacityExpansionResult.Status.CLAN_NOT_FOUND);
            case LEADER_CHANGED, STATE_CONFLICT -> expansionResult(
                    ClanCapacityExpansionResult.Status.CONCURRENT_MODIFICATION);
            case INVALID_UPDATE -> expansionResult(
                    ClanCapacityExpansionResult.Status.INVALID_CAPACITY_TRANSITION);
        };
    }

    private static ClanRegistrationResult result(ClanRegistrationResult.Status status) {
        return new ClanRegistrationResult(status, List.of());
    }

    private static ClanCapacityExpansionResult expansionResult(
            ClanCapacityExpansionResult.Status status) {
        return new ClanCapacityExpansionResult(status, Optional.empty());
    }
}

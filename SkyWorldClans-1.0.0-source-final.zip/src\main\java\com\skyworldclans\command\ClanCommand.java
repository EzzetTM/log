package com.skyworldclans.command;

import com.skyworldclans.SkyWorldClansPlugin;
import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.home.ClanHomeService;
import com.skyworldclans.clan.application.CreateClanCommand;
import com.skyworldclans.clan.application.creation.ClanCreationCoordinator;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.service.ClanMembershipChangeResult;
import com.skyworldclans.clan.request.ClanRequest;
import com.skyworldclans.clan.request.ClanRequestStore;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.math.BigDecimal;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

/** Bukkit adapter for the membership operations currently supported by the domain layer. */
public final class ClanCommand implements CommandExecutor, TabCompleter {
    private final SkyWorldClansPlugin plugin;

    public ClanCommand(SkyWorldClansPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player player) {
                plugin.getClanMainGui().open(player);
                return true;
            }
            help(sender);
            return true;
        }
        if (args[0].equalsIgnoreCase("help")) {
            help(sender);
            return true;
        }
        return switch (args[0].toLowerCase(Locale.ROOT)) {
            case "menu", "gui" -> {
                if (sender instanceof Player player) plugin.getClanMainGui().open(player);
                else help(sender);
                yield true;
            }
            case "info" -> info(sender, args);
            case "create" -> create(sender, args);
            case "admin" -> admin(sender, args);
            case "members" -> members(sender);
            case "leave" -> leave(sender);
            case "kick" -> mutate(sender, args, Action.KICK);
            case "deputy" -> args.length > 1 && args[1].equalsIgnoreCase("remove")
                    ? demote(sender, args, ClanRole.DEPUTY) : mutate(sender, args, Action.DEPUTY);
            case "moderator" -> args.length > 1 && args[1].equalsIgnoreCase("remove")
                    ? demote(sender, args, ClanRole.MODERATOR) : mutate(sender, args, Action.MODERATOR);
            case "leader" -> transfer(sender, args);
            case "election" -> election(sender, args);
            case "coup" -> coup(sender, args);
            case "bank" -> bank(sender, args);
            case "home" -> home(sender, args);
            case "storage" -> storage(sender, args);
            case "war" -> war(sender, args);
            case "reward" -> reward(sender, args);
            case "report" -> report(sender, args);
            case "appeal" -> appeal(sender, args);
            case "quests" -> quests(sender, args);
            case "tournament" -> tournament(sender, args);
            case "delete" -> deleteClan(sender, args);
            case "rename" -> renameClan(sender, args);
            case "invite" -> invite(sender, args);
            case "join" -> join(sender, args);
            case "requests" -> requests(sender);
            case "applications" -> applications(sender, args);
            case "accept" -> resolveRequest(sender, args, true);
            case "decline" -> resolveRequest(sender, args, false);
            default -> { help(sender); yield true; }
        };
    }

    private boolean create(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan create <тег> <название...> [--slogan <слоган...>]");
            return true;
        }
        int sloganMarker = -1;
        for (int i = 2; i < args.length; i++) {
            if (args[i].equalsIgnoreCase("--slogan")) {
                if (sloganMarker >= 0) {
                    sender.sendMessage(ChatColor.RED + "Маркер --slogan можно указать только один раз.");
                    return true;
                }
                sloganMarker = i;
            }
        }
        int nameEnd = sloganMarker < 0 ? args.length : sloganMarker;
        if (nameEnd <= 2 || (sloganMarker >= 0 && sloganMarker == args.length - 1)) {
            sender.sendMessage(ChatColor.RED + "Укажи название и, если добавляешь --slogan, сам слоган.");
            return true;
        }
        String name = String.join(" ", java.util.Arrays.copyOfRange(args, 2, nameEnd));
        String slogan = sloganMarker < 0 ? null
                : String.join(" ", java.util.Arrays.copyOfRange(args, sloganMarker + 1, args.length));
        ClanCreationCoordinator.Result result = plugin.getClanCreationCoordinator().create(
                new CreateClanCommand(player.getUniqueId(), name, args[1], slogan));
        switch (result.status()) {
            case CREATED -> {
                Clan clan = result.clan().orElseThrow();
                sender.sendMessage(ChatColor.GREEN + "Клан " + clan.name() + " [" + clan.tag()
                        + "] создан. Списано 1 000 000 обычной валюты.");
            }
            case ECONOMY_UNAVAILABLE -> sender.sendMessage(ChatColor.RED + "Экономика недоступна. Создание клана временно отключено.");
            case INSUFFICIENT_FUNDS -> sender.sendMessage(ChatColor.RED + "Недостаточно средств. Создание клана стоит 1 000 000.");
            case PAYMENT_REJECTED -> sender.sendMessage(ChatColor.RED + "Провайдер экономики отклонил списание. Клан не создан.");
            case PAYMENT_RESULT_UNCERTAIN -> sender.sendMessage(ChatColor.RED + "Результат списания не подтверждён. Не повторяй команду; обратись к администрации.");
            case PAYMENT_CONFIRMED_REGISTRATION_PENDING -> sender.sendMessage(ChatColor.RED + "Оплата подтверждена, но регистрация клана ожидает восстановления. Не повторяй команду; обратись к администрации.");
            case PAYMENT_NOT_CONFIRMED -> sender.sendMessage(ChatColor.RED + "Списание не подтверждено; регистрация отменена.");
            case MANUAL_RECONCILIATION_REQUIRED -> sender.sendMessage(ChatColor.RED + "Есть незавершённая операция создания клана. Требуется проверка администрацией.");
            case INTERRUPTED_BEFORE_PAYMENT -> sender.sendMessage(ChatColor.RED + "Создание прервалось до списания. Можешь повторить команду.");
            case DUPLICATE_OR_CONFLICT -> sender.sendMessage(ChatColor.RED + "Обнаружен конфликт операции создания клана. Обратись к администрации.");
            case STORAGE_ERROR -> sender.sendMessage(ChatColor.RED + "Не удалось безопасно сохранить операцию. Списание не следует повторять.");
            case PREFLIGHT_REJECTED -> sender.sendMessage(ChatColor.RED + preflightMessage(result.preflightStatus().orElse(null)));
        }
        if (result.status() == ClanCreationCoordinator.Status.PAYMENT_CONFIRMED_REGISTRATION_PENDING
                || result.status() == ClanCreationCoordinator.Status.PAYMENT_RESULT_UNCERTAIN
                || result.status() == ClanCreationCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED
                || result.status() == ClanCreationCoordinator.Status.STORAGE_ERROR) {
            plugin.getLogger().severe("Clan creation needs reconciliation for player " + player.getUniqueId()
                    + ", operation " + result.operationId().map(UUID::toString).orElse("unknown")
                    + ": " + result.status());
            result.operationId().ifPresent(id -> sender.sendMessage(ChatColor.RED + "ID операции: " + id));
        }
        return true;
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (args.length >= 2 && args[1].equalsIgnoreCase("panel")) {
            if (sender instanceof Player player) {
                plugin.getClanAdminGui().open(player);
            } else {
                sender.sendMessage(ChatColor.RED + "Панель открывается игроком; в консоли используйте admin-команды.");
            }
            return true;
        }
        if (args.length >= 2 && args[1].equalsIgnoreCase("reports")) return adminReports(sender, args);
        if (args.length >= 3 && args[1].equalsIgnoreCase("report-status")) return adminReportStatus(sender, args);
        if (args.length >= 3 && args[1].equalsIgnoreCase("sanctions")) return adminSanctions(sender, args);
        if (args.length >= 3 && args[1].equalsIgnoreCase("sanction")) return adminIssueSanction(sender, args);
        if (args.length >= 3 && args[1].equalsIgnoreCase("revoke-sanction")) return adminRevokeSanction(sender, args);
        if (args.length >= 2 && args[1].equalsIgnoreCase("appeals")) return adminAppeals(sender, args);
        if (args.length >= 3 && args[1].equalsIgnoreCase("appeal-decide")) return adminDecideAppeal(sender, args);
        if (!(sender instanceof ConsoleCommandSender)) {
            sender.sendMessage(ChatColor.RED + "Эта административная операция доступна только из консоли сервера.");
            return true;
        }
        if (args.length >= 6 && args[1].equalsIgnoreCase("bank-operation")
                && args[2].equalsIgnoreCase("reconcile")) {
            return reconcileBankOperation(sender, args);
        }
        if (args.length >= 3 && args[1].equalsIgnoreCase("bank-history")) {
            return showBankHistory(sender, args);
        }
        if (args.length >= 3 && args[1].equalsIgnoreCase("combatlog") && args[2].equalsIgnoreCase("list")) {
            return showInterruptedCombatLogSessions(sender, args);
        }
        if (args.length == 2 && args[1].equalsIgnoreCase("backup")) {
            sender.sendMessage(ChatColor.YELLOW + "Создание согласованной резервной копии SQLite запущено в фоновом потоке...");
            plugin.createManualBackup(result -> {
                sender.sendMessage(ChatColor.GREEN + "Резервная копия создана: " + result.backup());
                sender.sendMessage(ChatColor.GRAY + "Удалено старых копий: " + result.removedOlderBackups().size());
                result.warnings().forEach(warning -> sender.sendMessage(ChatColor.YELLOW + warning));
                plugin.getLogger().info("Manual SQLite backup created: " + result.backup());
            }, exception -> {
                sender.sendMessage(ChatColor.RED + "Не удалось создать резервную копию: " + exception.getMessage());
                plugin.getLogger().log(java.util.logging.Level.SEVERE, "Manual SQLite backup failed.", exception);
            });
            return true;
        }
        if (args.length == 2 && args[1].equalsIgnoreCase("status")) {
            return showAdminStatus(sender);
        }
        if (args.length < 6 || !args[1].equalsIgnoreCase("creation-payment")
                || !args[2].equalsIgnoreCase("reconcile")) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan admin creation-payment reconcile ... | /clan admin bank-operation reconcile <operation-uuid> <paid|notpaid> <evidence...>");
            return true;
        }
        UUID operationId;
        try {
            operationId = UUID.fromString(args[3]);
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный UUID операции.");
            return true;
        }
        boolean paid;
        if (args[4].equalsIgnoreCase("paid")) paid = true;
        else if (args[4].equalsIgnoreCase("notpaid")) paid = false;
        else {
            sender.sendMessage(ChatColor.RED + "Укажи paid или notpaid после проверки истории транзакций провайдера.");
            return true;
        }
        String evidence = String.join(" ", java.util.Arrays.copyOfRange(args, 5, args.length));
        var result = plugin.getClanCreationCoordinator().reconcileUnknown(operationId, paid, evidence);
        switch (result.status()) {
            case CREATED -> sender.sendMessage(ChatColor.GREEN + "Платёж подтверждён, регистрация клана завершена.");
            case RECONCILED_NO_DEBIT -> sender.sendMessage(ChatColor.GREEN + "Подтверждено отсутствие списания. Игрок сможет повторить создание клана.");
            case OPERATION_NOT_FOUND -> sender.sendMessage(ChatColor.RED + "Операция не найдена.");
            case OPERATION_NOT_UNKNOWN -> sender.sendMessage(ChatColor.RED + "Операция не находится в состоянии UNKNOWN; сверка не применена.");
            case RECONCILIATION_FAILED, STORAGE_ERROR -> sender.sendMessage(ChatColor.RED + "Не удалось безопасно записать результат сверки.");
            case PAYMENT_CONFIRMED_REGISTRATION_PENDING -> sender.sendMessage(ChatColor.RED + "Списание подтверждено, но создание клана ещё требует восстановления.");
            default -> sender.sendMessage(ChatColor.RED + "Сверка не выполнена: " + result.status());
        }
        plugin.getLogger().warning("Console reconciled clan creation payment " + operationId
                + " as " + (paid ? "PAID" : "NO_DEBIT") + ". Evidence: " + evidence);
        return true;
    }

    private boolean adminReports(CommandSender sender, String[] args) {
        var level = plugin.resolveAdminLevel(sender);
        String status = args.length >= 3 ? args[2].toUpperCase(Locale.ROOT) : null;
        int limit = 20;
        if (args.length >= 4) {
            try { limit = Integer.parseInt(args[3]); }
            catch (NumberFormatException exception) {
                sender.sendMessage(ChatColor.RED + "Лимит должен быть числом.");
                return true;
            }
        }
        var reports = plugin.getClanAdministrationService().reports(level, status, Math.min(Math.max(limit, 1), 100));
        sender.sendMessage(ChatColor.GOLD + "Жалобы (" + reports.size() + "):");
        if (reports.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Жалоб нет.");
        for (var report : reports) {
            boolean hidden = report.anonymous() && level != com.skyworldclans.admin.ClanAdministrationService.Level.OWNER;
            sender.sendMessage(ChatColor.YELLOW + report.reportId().toString() + ChatColor.GRAY
                    + " | " + report.category() + " | " + report.status()
                    + " | автор: " + (hidden ? "анонимно" : report.authorName())
                    + " | " + report.createdAt());
        }
        return true;
    }

    private boolean adminReportStatus(CommandSender sender, String[] args) {
        var level = plugin.resolveAdminLevel(sender);
        UUID reportId;
        try { reportId = UUID.fromString(args[2]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный ID жалобы.");
            return true;
        }
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan admin report-status <ID> <NEW|UNDER_REVIEW|NEEDS_EVIDENCE|ACCEPTED|REJECTED> [комментарий...]");
            return true;
        }
        String status = args[3].toUpperCase(Locale.ROOT);
        String note = args.length > 4 ? String.join(" ", java.util.Arrays.copyOfRange(args, 4, args.length)) : null;
        var result = plugin.getClanAdministrationService().changeReportStatus(
                level, sender instanceof Player p ? p.getUniqueId() : null, reportId, status, note);
        sender.sendMessage(result.status() == com.skyworldclans.admin.ClanAdministrationService.Status.UPDATED
                ? ChatColor.GREEN + "Статус жалобы обновлён: " + status
                : ChatColor.RED + "Статус не изменён: " + result.status());
        return true;
    }

    private boolean adminSanctions(CommandSender sender, String[] args) {
        var level = plugin.resolveAdminLevel(sender);
        java.util.UUID target = null;
        if (args.length >= 3 && !args[2].equalsIgnoreCase("all")) {
            try { target = UUID.fromString(args[2]); }
            catch (IllegalArgumentException exception) {
                sender.sendMessage(ChatColor.RED + "Укажи UUID игрока или all.");
                return true;
            }
        }
        var sanctions = plugin.getClanAdministrationService().sanctions(level, target, 30);
        sender.sendMessage(ChatColor.GOLD + "Санкции (" + sanctions.size() + "):");
        if (sanctions.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Санкций нет.");
        for (var sanction : sanctions) {
            sender.sendMessage(ChatColor.YELLOW + sanction.sanctionId().toString() + ChatColor.GRAY
                    + " | " + sanction.kind() + "/" + sanction.scope()
                    + " | цель: " + sanction.targetId()
                    + " | " + (sanction.revokedAt() == null ? "активна" : "отозвана")
                    + " | до: " + (sanction.expiresAt() == null ? "бессрочно" : sanction.expiresAt())
                    + " | " + sanction.reason());
        }
        return true;
    }

    private boolean adminIssueSanction(CommandSender sender, String[] args) {
        var level = plugin.resolveAdminLevel(sender);
        if (args.length < 6) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan admin sanction <UUID игрока> <WARNING|FINAL_WARNING|TEMPORARY_FUNCTION_BLOCK> <CLAN_CHAT|CLAN_BANK|CLAN_REQUESTS|CLAN_WARS|ALL> <часы|0> <причина...>");
            return true;
        }
        UUID target;
        try { target = UUID.fromString(args[2]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный UUID игрока.");
            return true;
        }
        String kind = args[3].toUpperCase(Locale.ROOT);
        String scope = args[4].toUpperCase(Locale.ROOT);
        long hours;
        try { hours = Long.parseLong(args[5]); }
        catch (NumberFormatException exception) {
            sender.sendMessage(ChatColor.RED + "Часы должны быть числом (0 — бессрочно).");
            return true;
        }
        if (args.length < 7) {
            sender.sendMessage(ChatColor.RED + "Укажи причину санкции.");
            return true;
        }
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 6, args.length));
        java.time.Duration duration = hours <= 0 ? null : java.time.Duration.ofHours(hours);
        var result = plugin.getClanAdministrationService().issueSanction(level,
                sender instanceof Player p ? p.getUniqueId() : null, target, kind, scope, reason, duration,
                level == com.skyworldclans.admin.ClanAdministrationService.Level.OWNER);
        sender.sendMessage(result.status() == com.skyworldclans.admin.ClanAdministrationService.Status.CREATED
                ? ChatColor.GREEN + "Санкция выдана: " + kind + "/" + scope
                : ChatColor.RED + "Санкция не выдана: " + result.status());
        return true;
    }

    private boolean adminRevokeSanction(CommandSender sender, String[] args) {
        var level = plugin.resolveAdminLevel(sender);
        UUID sanctionId;
        try { sanctionId = UUID.fromString(args[2]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный ID санкции.");
            return true;
        }
        var result = plugin.getClanAdministrationService().revokeSanction(level,
                sender instanceof Player p ? p.getUniqueId() : null, sanctionId);
        sender.sendMessage(result.status() == com.skyworldclans.admin.ClanAdministrationService.Status.UPDATED
                ? ChatColor.GREEN + "Санкция отозвана."
                : ChatColor.RED + "Санкция не отозвана: " + result.status());
        return true;
    }

    private boolean adminAppeals(CommandSender sender, String[] args) {
        var level = plugin.resolveAdminLevel(sender);
        String status = args.length >= 3 ? args[2].toUpperCase(Locale.ROOT) : null;
        var appeals = plugin.getClanAdministrationService().appeals(level, status, 30);
        sender.sendMessage(ChatColor.GOLD + "Апелляции (" + appeals.size() + "):");
        if (appeals.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Апелляций нет.");
        for (var appeal : appeals) {
            sender.sendMessage(ChatColor.YELLOW + appeal.appealId().toString() + ChatColor.GRAY
                    + " | " + appeal.status() + " | санкция: " + appeal.sanctionId()
                    + " | от: " + appeal.submittedBy()
                    + " | " + appeal.submittedAt() + " | " + appeal.reason());
        }
        return true;
    }

    private boolean adminDecideAppeal(CommandSender sender, String[] args) {
        var level = plugin.resolveAdminLevel(sender);
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan admin appeal-decide <ID> accept|reject [комментарий...]");
            return true;
        }
        UUID appealId;
        try { appealId = UUID.fromString(args[2]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный ID апелляции.");
            return true;
        }
        boolean accept;
        if (args[3].equalsIgnoreCase("accept")) accept = true;
        else if (args[3].equalsIgnoreCase("reject")) accept = false;
        else {
            sender.sendMessage(ChatColor.RED + "Решение: accept или reject.");
            return true;
        }
        String note = args.length > 4 ? String.join(" ", java.util.Arrays.copyOfRange(args, 4, args.length)) : null;
        var result = plugin.getClanAdministrationService().decideAppeal(level,
                sender instanceof Player p ? p.getUniqueId() : null, appealId, accept, note);
        sender.sendMessage(result.status() == com.skyworldclans.admin.ClanAdministrationService.Status.UPDATED
                ? ChatColor.GREEN + "Апелляция рассмотрена: " + (accept ? "удовлетворена" : "отклонена")
                : ChatColor.RED + "Апелляция не рассмотрена: " + result.status());
        return true;
    }

    private boolean showAdminStatus(CommandSender sender) {
        SqliteClanStore store = plugin.getClanStore();
        sender.sendMessage(ChatColor.GOLD + "SkyWorldClans — состояние:");
        sender.sendMessage(ChatColor.GRAY + "Кланы: " + store.countClans()
                + " | участников: " + store.countMembers()
                + " | выборов: " + store.countActiveElections());
        sender.sendMessage(ChatColor.GRAY + "Страниц хранилища: " + store.countStoragePages()
                + " | Vault Economy: " + (plugin.isVaultEconomyAvailable() ? ChatColor.GREEN + "доступен" : ChatColor.RED + "недоступен"));
        sender.sendMessage(ChatColor.GRAY + "Незавершённых банковских операций: " + store.countUnresolvedBankOperations()
                + " (UNKNOWN: " + store.countUnknownBankOperations() + ")"
                + " | незавершённых оплат создания: " + store.countUnresolvedCreationPayments());
        sender.sendMessage(ChatColor.GRAY + "CombatLog на ручной проверке: " + store.countInterruptedCombatLogSessions());
        sender.sendMessage(ChatColor.GRAY + "Войны: " + store.countActiveClanWars() + " активных"
                + " | хранилище на проверке: " + store.countStorageTransfersForReview()
                + " | задания и турниры ведутся в соответствующих разделах.");
        var backup = plugin.latestBackup();
        sender.sendMessage(ChatColor.GRAY + "Последняя резервная копия: " + backup
                .map(value -> value.createdAt() + " — " + value.path())
                .orElse("не найдена"));
        sender.sendMessage(ChatColor.GRAY + "Схема SQLite: " + store.schemaVersion() + "; полная серверная приёмка ещё не выполнена.");
        return true;
    }

    private boolean showInterruptedCombatLogSessions(CommandSender sender, String[] args) {
        int limit = 50;
        if (args.length >= 4) {
            try { limit = Integer.parseInt(args[3]); }
            catch (NumberFormatException exception) {
                sender.sendMessage(ChatColor.RED + "Лимит должен быть числом от 1 до 100.");
                return true;
            }
        }
        if (limit < 1 || limit > 100) {
            sender.sendMessage(ChatColor.RED + "Лимит должен быть от 1 до 100.");
            return true;
        }
        var sessions = plugin.getClanStore().findCombatLogSessions(
                SqliteClanStore.CombatLogSessionStatus.INTERRUPTED_REVIEW, limit);
        sender.sendMessage(ChatColor.GOLD + "CombatLog-сессии, прерванные перезапуском (" + sessions.size() + "):");
        if (sessions.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Сессий для проверки нет.");
        for (var session : sessions) {
            sender.sendMessage(ChatColor.YELLOW + session.playerId().toString() + ChatColor.GRAY
                    + " vs " + session.opponentId() + " | lastHit=" + session.lastHitAt()
                    + " | deadline=" + session.expiresAt() + " | status=" + session.status());
        }
        sender.sendMessage(ChatColor.GRAY + "Перезапуск не назначает автоматическое наказание; список предназначен только для просмотра.");
        return true;
    }

    private boolean showBankHistory(CommandSender sender, String[] args) {
        UUID clanId;
        try { clanId = UUID.fromString(args[2]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan admin bank-history <clan-uuid> [limit]");
            return true;
        }
        int limit = 20;
        if (args.length >= 4) {
            try { limit = Integer.parseInt(args[3]); }
            catch (NumberFormatException exception) {
                sender.sendMessage(ChatColor.RED + "Лимит должен быть числом от 1 до 100.");
                return true;
            }
        }
        if (limit < 1 || limit > 100) {
            sender.sendMessage(ChatColor.RED + "Лимит должен быть от 1 до 100.");
            return true;
        }
        var clan = plugin.getClanStore().findById(clanId).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Клан не найден.");
            return true;
        }
        var history = plugin.getClanStore().findClanBankTransactions(clanId, limit);
        sender.sendMessage(ChatColor.GOLD + "История банка клана [" + clan.tag() + "] (" + history.size() + "):");
        if (history.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Операций пока нет.");
        for (var transaction : history) {
            sender.sendMessage(ChatColor.YELLOW + transaction.occurredAt().toString() + ChatColor.GRAY + " | "
                    + transaction.transactionType() + " | " + transaction.amount().toPlainString()
                    + " | balance=" + transaction.balanceAfter().toPlainString()
                    + " | actor=" + transaction.actorId()
                    + (transaction.approvedBy() == null ? "" : " | approvedBy=" + transaction.approvedBy())
                    + (transaction.reason() == null ? "" : " | reason=" + transaction.reason()));
        }
        return true;
    }

    private boolean reconcileBankOperation(CommandSender sender, String[] args) {
        UUID operationId;
        try { operationId = UUID.fromString(args[3]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный UUID банковской операции.");
            return true;
        }
        boolean paid;
        if (args[4].equalsIgnoreCase("paid")) paid = true;
        else if (args[4].equalsIgnoreCase("notpaid")) paid = false;
        else {
            sender.sendMessage(ChatColor.RED + "Укажи paid или notpaid после проверки истории транзакций Vault-провайдера.");
            return true;
        }
        String evidence = String.join(" ", java.util.Arrays.copyOfRange(args, 5, args.length));
        var operation = plugin.getClanStore().findClanBankOperation(operationId).orElse(null);
        if (operation == null) {
            sender.sendMessage(ChatColor.RED + "Банковская операция не найдена.");
            return true;
        }
        if (operation.state() != SqliteClanStore.ClanBankOperationState.UNKNOWN) {
            sender.sendMessage(ChatColor.RED + "Сверка разрешена только для операции UNKNOWN; текущее состояние: " + operation.state());
            return true;
        }
        SqliteClanStore.ClanBankOperationResult result;
        try {
            result = plugin.getClanStore().reconcileUnknownClanBankOperation(
                    operationId, paid, evidence, java.time.Instant.now());
        } catch (RuntimeException exception) {
            sender.sendMessage(ChatColor.RED + "Не удалось завершить сверку; операция остаётся для восстановления.");
            plugin.getLogger().log(java.util.logging.Level.SEVERE, "Clan bank reconciliation failed for " + operationId, exception);
            return true;
        }
        switch (result.status()) {
            case COMMITTED -> sender.sendMessage(ChatColor.GREEN + "Списание/выплата подтверждены; локальный банк и журнал синхронизированы.");
            case UPDATED -> sender.sendMessage(ChatColor.GREEN + "Подтверждено отсутствие внешнего эффекта; резерв банка освобождён.");
            case NOT_FOUND -> sender.sendMessage(ChatColor.RED + "Операция не найдена.");
            case INVALID_EVIDENCE -> sender.sendMessage(ChatColor.RED + "Нужно указать проверяемое основание сверки (до 900 символов).");
            case STATE_CONFLICT -> sender.sendMessage(ChatColor.RED + "Состояние операции изменилось; сверка не применена.");
            default -> sender.sendMessage(ChatColor.RED + "Сверка не завершена: " + result.status());
        }
        plugin.getLogger().warning("Console reconciled clan bank operation " + operationId
                + " as " + (paid ? "EXTERNAL_EFFECT_CONFIRMED" : "NO_EXTERNAL_EFFECT")
                + ". Evidence: " + evidence);
        return true;
    }

    private static String preflightMessage(com.skyworldclans.clan.application.ClanCreationPreflightResult.Status status) {
        if (status == null) return "Некорректные данные создания клана.";
        return switch (status) {
            case INVALID_INPUT -> "Заполни все обязательные поля.";
            case INVALID_NAME_FORMAT -> "Название должно содержать от 3 до 16 символов.";
            case INVALID_TAG_FORMAT -> "Тег должен содержать от 2 до 5 латинских букв или цифр.";
            case FILTER_UNAVAILABLE -> "Фильтр названий недоступен; создание временно отключено.";
            case FORBIDDEN_EXPRESSION -> "Название, тег или слоган содержит запрещённое выражение.";
            case CREATOR_ALREADY_IN_CLAN -> "Ты уже состоишь в клане.";
            case TAG_TAKEN -> "Этот тег уже занят.";
            case READY -> "";
        };
    }

    private boolean info(CommandSender sender, String[] args) {
        Optional<Clan> clan;
        if (args.length > 1) clan = plugin.getClanStore().findByTag(args[1]);
        else if (sender instanceof Player player) clan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        else {
            sender.sendMessage(ChatColor.RED + "Использование: /clan info <тег>");
            return true;
        }
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Клан не найден.");
            return true;
        }
        Clan value = clan.get();
        sender.sendMessage(ChatColor.GOLD + value.name() + ChatColor.GRAY + " [" + value.tag() + "]");
        sender.sendMessage(ChatColor.GRAY + "Участники: " + value.memberCount() + "/" + value.capacity());
        sender.sendMessage(ChatColor.GRAY + "Уровень: " + value.level());
        sender.sendMessage(ChatColor.GRAY + "Опыт: " + value.totalXp());
        sender.sendMessage(ChatColor.GRAY + "Публичные заявки: "
                + (plugin.getClanRequestService().arePublicApplicationsOpen(value.id()) ? "открыты" : "закрыты"));
        if (value.tagline() != null && !value.tagline().isBlank()) {
            sender.sendMessage(ChatColor.GRAY + "Девиз: " + value.tagline());
        }
        value.leader().ifPresent(leader -> sender.sendMessage(
                ChatColor.GRAY + "Лидер: " + playerName(leader.playerId())));
        return true;
    }

    private boolean members(CommandSender sender) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Optional<Clan> clan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        sender.sendMessage(ChatColor.GOLD + "Состав клана [" + clan.get().tag() + "]:");
        clan.get().members().values().stream()
                .sorted((a, b) -> a.role().compareTo(b.role()))
                .forEach(member -> sender.sendMessage(ChatColor.GRAY + "- "
                        + playerName(member.playerId()) + " — " + roleName(member.role().name())));
        return true;
    }

    private boolean leave(CommandSender sender) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        var clan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        if (clan.isPresent() && clan.get().leader().map(member -> member.playerId().equals(player.getUniqueId())).orElse(false)) {
            var election = plugin.getClanElectionService().startDeparture(clan.get().id(), player.getUniqueId());
            switch (election) {
                case AUTO_TRANSFERRED -> sender.sendMessage(ChatColor.GREEN + "Ты покинул клан; единственный заместитель автоматически стал лидером.");
                case STARTED -> {
                    sender.sendMessage(ChatColor.GREEN + "Выборы нового лидера начались. Участники клана могут проголосовать в течение 24 часов.");
                    for (Player online : plugin.getServer().getOnlinePlayers()) {
                        if (plugin.getClanStore().findByPlayerId(online.getUniqueId())
                                .map(memberClan -> memberClan.id().equals(clan.get().id())).orElse(false)) {
                            online.sendMessage(ChatColor.GOLD + "В клане [" + clan.get().tag()
                                    + "] начались выборы лидера. Используй /clan election info.");
                        }
                    }
                }
                case ACTIVE_ELECTION_EXISTS -> sender.sendMessage(ChatColor.RED + "В этом клане уже идут выборы.");
                case EMPTY_CLAN_REQUIRES_DELETION_SUPPORT -> sender.sendMessage(ChatColor.RED + "Удаление последнего участника пока не поддерживается.");
                default -> sender.sendMessage(ChatColor.RED + "Не удалось начать выборы лидера: " + election);
            }
            return true;
        }
        ClanMembershipChangeResult result = plugin.getClanMembershipService()
                .leaveClan(player.getUniqueId(), plugin.getClanElectionService().hasActiveElection(clan.map(c -> c.id()).orElse(null)));
        if (result.status() == ClanMembershipChangeResult.Status.UPDATED) {
            sender.sendMessage(ChatColor.GREEN + "Ты покинул клан.");
            clearModerationOnDeparture(clan.map(Clan::id).orElse(null), player.getUniqueId());
        } else if (result.status() == ClanMembershipChangeResult.Status.LEADER_DEPARTURE_REQUIRES_ELECTION) {
            sender.sendMessage(ChatColor.RED + "Для выхода лидера требуется активная система выборов.");
        } else if (result.status() == ClanMembershipChangeResult.Status.EMPTY_CLAN_DELETION_REQUIRES_STORAGE_SUPPORT) {
            sender.sendMessage(ChatColor.RED + "Удаление последнего участника пока не поддерживается.");
        } else {
            failure(sender, result.status());
        }
        return true;
    }

    private boolean mutate(CommandSender sender, String[] args, Action action) {
        int targetIndex = action == Action.KICK ? 1 : 2;
        if (args.length != targetIndex + 1
                || (action != Action.KICK && !args[1].equalsIgnoreCase("add"))) {
            sender.sendMessage(ChatColor.RED + "Использование: " + action.usage);
            return true;
        }
        if (!(sender instanceof Player actor)) return playerOnly(sender);
        Player target = plugin.getServer().getPlayerExact(args[targetIndex]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Целевой игрок должен быть онлайн.");
            return true;
        }
        Optional<Clan> clan = plugin.getClanStore().findByPlayerId(actor.getUniqueId());
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        UUID clanId = clan.get().id();
        ClanMembershipChangeResult result = switch (action) {
            case KICK -> plugin.getClanMembershipService().removeMember(
                    clanId, actor.getUniqueId(), target.getUniqueId(), plugin.getClanElectionService().hasActiveElection(clanId));
            case DEPUTY -> plugin.getClanMembershipService().appointDeputy(
                    clanId, actor.getUniqueId(), target.getUniqueId(), plugin.getClanElectionService().hasActiveElection(clanId));
            case MODERATOR -> plugin.getClanMembershipService().appointModerator(
                    clanId, actor.getUniqueId(), target.getUniqueId(), plugin.getClanElectionService().hasActiveElection(clanId));
        };
        if (result.status() == ClanMembershipChangeResult.Status.UPDATED) {
            sender.sendMessage(ChatColor.GREEN + action.success);
            target.sendMessage(ChatColor.YELLOW + action.targetNotice);
            if (action == Action.KICK) clearModerationOnDeparture(clanId, target.getUniqueId());
        } else failure(sender, result.status());
        return true;
    }

    /** A mute and warning history end with membership; the mute is not restored on re-join. */
    private void clearModerationOnDeparture(UUID clanId, UUID playerId) {
        if (clanId == null || playerId == null) return;
        try {
            plugin.getClanModerationService().clearOnDeparture(clanId, playerId);
        } catch (RuntimeException exception) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE,
                    "Could not clear clan moderation for departing player " + playerId, exception);
        }
    }

    private boolean demote(CommandSender sender, String[] args, ClanRole role) {
        if (args.length != 3) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan "
                    + (role == ClanRole.DEPUTY ? "deputy" : "moderator") + " remove <ник>");
            return true;
        }
        if (!(sender instanceof Player actor)) return playerOnly(sender);
        Player target = plugin.getServer().getPlayerExact(args[2]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Целевой игрок должен быть онлайн.");
            return true;
        }
        Optional<Clan> clan = plugin.getClanStore().findByPlayerId(actor.getUniqueId());
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        UUID clanId = clan.get().id();
        boolean electionActive = plugin.getClanElectionService().hasActiveElection(clanId);
        ClanMembershipChangeResult result = role == ClanRole.DEPUTY
                ? plugin.getClanMembershipService().demoteDeputy(clanId, actor.getUniqueId(), target.getUniqueId(), electionActive)
                : plugin.getClanMembershipService().demoteModerator(clanId, actor.getUniqueId(), target.getUniqueId(), electionActive);
        if (result.status() == ClanMembershipChangeResult.Status.UPDATED) {
            sender.sendMessage(ChatColor.GREEN + (role == ClanRole.DEPUTY
                    ? "Заместитель снят с должности." : "Модератор снят с должности."));
            target.sendMessage(ChatColor.YELLOW + "Твоя должность в клане изменена.");
            if (role == ClanRole.DEPUTY) {
                clan.get().members().values().stream()
                        .filter(member -> member.role() == ClanRole.MODERATOR
                                && target.getUniqueId().equals(member.appointedByDeputyId()))
                        .map(member -> plugin.getServer().getPlayer(member.playerId()))
                        .filter(java.util.Objects::nonNull)
                        .forEach(moderator -> moderator.sendMessage(ChatColor.YELLOW
                                + "Твоя должность изменена после снятия назначившего тебя заместителя."));
            }
        } else failure(sender, result.status());
        return true;
    }

    private boolean transfer(CommandSender sender, String[] args) {
        if (args.length != 3 || !args[1].equalsIgnoreCase("transfer")) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan leader transfer <ник>");
            return true;
        }
        if (!(sender instanceof Player actor)) return playerOnly(sender);
        Player target = plugin.getServer().getPlayerExact(args[2]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Заместитель должен быть онлайн.");
            return true;
        }
        Optional<Clan> clan = plugin.getClanStore().findByPlayerId(actor.getUniqueId());
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        ClanMembershipChangeResult result = plugin.getClanMembershipService().transferLeadership(
                clan.get().id(), actor.getUniqueId(), target.getUniqueId(), plugin.getClanElectionService().hasActiveElection(clan.get().id()));
        if (result.status() == ClanMembershipChangeResult.Status.UPDATED) {
            sender.sendMessage(ChatColor.GREEN + "Лидерство передано.");
            target.sendMessage(ChatColor.GOLD + "Теперь ты лидер клана [" + clan.get().tag() + "].");
        } else failure(sender, result.status());
        return true;
    }

    private boolean coup(CommandSender sender, String[] args) {
        if (args.length != 1) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan coup");
            return true;
        }
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Optional<Clan> clan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        UUID currentLeader = clan.get().leader().map(member -> member.playerId()).orElse(null);
        if (currentLeader != null && plugin.getServer().getOnlinePlayers().stream()
                .anyMatch(online -> online.getUniqueId().equals(currentLeader))) {
            sender.sendMessage(ChatColor.RED + "Переворот невозможен, пока лидер находится на сервере.");
            return true;
        }
        var result = plugin.getClanElectionService().startCoup(clan.get().id(), player.getUniqueId());
        switch (result) {
            case STARTED -> {
                sender.sendMessage(ChatColor.GREEN + "Переворот начат. Голосование длится 24 часа.");
                for (Player online : plugin.getServer().getOnlinePlayers()) {
                    if (plugin.getClanStore().findByPlayerId(online.getUniqueId())
                            .map(memberClan -> memberClan.id().equals(clan.get().id())).orElse(false)) {
                        online.sendMessage(ChatColor.GOLD + "В клане [" + clan.get().tag()
                                + "] начался переворот. Используй /clan election info.");
                    }
                }
            }
            case ACTIVE_ELECTION_EXISTS -> sender.sendMessage(ChatColor.RED + "В клане уже идут выборы.");
            case INACTIVITY_REQUIREMENT_NOT_MET -> sender.sendMessage(ChatColor.RED + "Лидер не был зафиксирован отсутствующим 30 полных дней.");
            case COUP_COOLDOWN_ACTIVE -> sender.sendMessage(ChatColor.RED + "После предыдущей победы лидера должно пройти ещё 30 дней.");
            case NOT_AUTHORIZED -> sender.sendMessage(ChatColor.RED + "Начать переворот может только заместитель.");
            default -> sender.sendMessage(ChatColor.RED + "Не удалось начать переворот: " + result);
        }
        return true;
    }

    private boolean election(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Optional<Clan> ownClan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        Optional<Clan> targetClan = ownClan;
        int candidateIndex = 2;
        if (args.length == 3 && args[1].equalsIgnoreCase("info")) {
            targetClan = plugin.getClanStore().findByTag(args[2]);
        } else if (args.length >= 3 && args[1].equalsIgnoreCase("vote") && args.length == 4) {
            targetClan = plugin.getClanStore().findByTag(args[2]);
            candidateIndex = 3;
        }
        if (targetClan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Укажи тег клана: /clan election vote <тег> <UUID кандидата>.");
            return true;
        }
        var active = plugin.getClanElectionService().activeElection(targetClan.get().id());
        if (active.isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "В этом клане сейчас нет активных выборов.");
            return true;
        }
        var election = active.get();
        if (args.length == 1 || (args.length == 2 && args[1].equalsIgnoreCase("info"))
                || (args.length == 3 && args[1].equalsIgnoreCase("info"))) {
            sender.sendMessage(ChatColor.GOLD + "Выборы лидера: " + election.type());
            sender.sendMessage(ChatColor.GRAY + "Этап: " + election.phase() + "; завершение: " + election.closesAt());
            if (plugin.getClanElectionService().isBlockedForOwnerDecision(targetClan.get().id())) {
                sender.sendMessage(ChatColor.RED + "Глобальное голосование завершилось ничьей. Выборы ожидают решения владельца.");
            }
            sender.sendMessage(ChatColor.GRAY + "Кандидаты:");
            var tally = plugin.getClanElectionService().tally(targetClan.get().id());
            election.candidates().forEach(candidate -> sender.sendMessage(ChatColor.YELLOW + candidate.toString()
                    + ChatColor.GRAY + " — " + playerName(candidate) + "; голосов: " + tally.getOrDefault(candidate, 0)));
            sender.sendMessage(ChatColor.GRAY + "Голос: /clan election vote <UUID кандидата> или /clan election vote <тег> <UUID>");
            if (election.phase() == com.skyworldclans.clan.election.ClanElection.Phase.GLOBAL_TIE_BREAK) {
                sender.sendMessage(ChatColor.GRAY + "Для глобального этапа требуется право skyworldclans.election.vote.global.");
            }
            return true;
        }
        if (args.length == 3 && args[1].equalsIgnoreCase("vote")
                || args.length == 4 && args[1].equalsIgnoreCase("vote")) {
            UUID candidate;
            try { candidate = UUID.fromString(args[candidateIndex]); }
            catch (IllegalArgumentException exception) {
                sender.sendMessage(ChatColor.RED + "Укажи корректный UUID кандидата из списка выборов.");
                return true;
            }
            var result = plugin.getClanElectionService().vote(targetClan.get().id(), player.getUniqueId(),
                    candidate, player.hasPermission("skyworldclans.election.vote.global"));
            switch (result) {
                case VOTED -> sender.sendMessage(ChatColor.GREEN + "Твой голос учтён.");
                case ALREADY_VOTED -> sender.sendMessage(ChatColor.RED + "Ты уже голосовал на этом этапе.");
                case NOT_ELIGIBLE -> sender.sendMessage(ChatColor.RED + "Ты не имеешь права голосовать на этом этапе.");
                case INVALID_CANDIDATE -> sender.sendMessage(ChatColor.RED + "Такого кандидата нет на текущем этапе.");
                case PHASE_CLOSED -> sender.sendMessage(ChatColor.RED + "Голосование завершено. Если осталась ничья, требуется решение владельца.");
                default -> sender.sendMessage(ChatColor.RED + "Голос не принят: " + result);
            }
            return true;
        }
        sender.sendMessage(ChatColor.RED + "Использование: /clan election [info|vote <UUID>] или /clan election vote <тег> <UUID>");
        return true;
    }

    private boolean storage(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        var account = plugin.getClanStorageService().accountFor(player.getUniqueId());
        if (account.status() == com.skyworldclans.clan.storage.ClanStorageService.Status.NOT_IN_CLAN) {
            player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        if (account.status() != com.skyworldclans.clan.storage.ClanStorageService.Status.READY) {
            player.sendMessage(ChatColor.RED + "Хранилище сейчас недоступно: " + account.status() + ".");
            return true;
        }
        if (args.length == 1 || args[1].equalsIgnoreCase("open") || args[1].equalsIgnoreCase("gui")) {
            plugin.getClanStorageGui().openMenu(player);
            return true;
        }
        if (args.length == 3 && args[1].equalsIgnoreCase("page")) {
            final int pageNumber;
            try {
                pageNumber = Integer.parseInt(args[2]);
            } catch (NumberFormatException exception) {
                player.sendMessage(ChatColor.RED + "Использование: /clan storage page <1-10>");
                return true;
            }
            plugin.getClanStorageGui().openPage(player, pageNumber);
            return true;
        }
        if (args.length >= 2 && args[1].equalsIgnoreCase("history")) {
            int limit = 20;
            if (args.length >= 3) {
                try { limit = Integer.parseInt(args[2]); }
                catch (NumberFormatException exception) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan storage history [1-100]");
                    return true;
                }
            }
            if (limit < 1 || limit > 100) {
                player.sendMessage(ChatColor.RED + "Лимит должен быть от 1 до 100.");
                return true;
            }
            var movements = plugin.getClanStore().findClanStorageMovements(account.clan().id(), limit);
            player.sendMessage(ChatColor.GOLD + "Журнал хранилища [" + account.clan().tag() + "] (" + movements.size() + "):");
            if (movements.isEmpty()) player.sendMessage(ChatColor.GRAY + "Операций пока нет.");
            for (var movement : movements) {
                player.sendMessage(ChatColor.YELLOW + movement.occurredAt().toString() + ChatColor.GRAY
                        + " | стр." + movement.pageNumber() + " | " + movement.movementType()
                        + " | " + movement.itemType() + " x" + movement.amount()
                        + " | " + playerName(movement.actorId()));
            }
            return true;
        }
        if (args.length == 2 && args[1].equalsIgnoreCase("info")) {
            player.sendMessage(ChatColor.GOLD + "Хранилище клана " + account.clan().tag());
            player.sendMessage(ChatColor.YELLOW + "Открыто страниц: " + account.pageCount() + "/"
                    + com.skyworldclans.clan.storage.ClanStorageService.MAX_PAGES);
            player.sendMessage(ChatColor.GRAY + "Каждая страница рассчитана на 54 слота; предметы сохраняются в SQLite.");
            player.sendMessage(ChatColor.GRAY + "Открыть GUI: /clan storage; страница: /clan storage page <n>");
            player.sendMessage(ChatColor.GRAY + "Покупка следующей страницы: /clan storage buy " + (account.pageCount() + 1));
            return true;
        }
        if (args.length == 3 && args[1].equalsIgnoreCase("buy")) {
            final int pageNumber;
            try {
                pageNumber = Integer.parseInt(args[2]);
            } catch (NumberFormatException exception) {
                player.sendMessage(ChatColor.RED + "Номер страницы должен быть числом от 2 до 10.");
                return true;
            }
            var result = plugin.getClanStorageService().purchasePage(player.getUniqueId(), pageNumber,
                    java.time.Instant.now());
            switch (result.status()) {
                case PURCHASED -> player.sendMessage(ChatColor.GREEN + "Страница " + pageNumber
                        + " куплена за " + result.purchase().chargedPrice().toPlainString()
                        + ". Скидка уровня клана: " + result.purchase().discountPercent() + "%. ");
                case ALREADY_PURCHASED -> player.sendMessage(ChatColor.YELLOW + "Эта страница уже куплена.");
                case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
                case LEADER_ONLY -> player.sendMessage(ChatColor.RED + "Покупать страницы может только лидер клана.");
                case MAX_PAGES -> player.sendMessage(ChatColor.RED + "Достигнут максимум: 10 страниц.");
                case INSUFFICIENT_FUNDS -> player.sendMessage(ChatColor.RED + "В банке клана недостаточно средств.");
                case INVALID_PAGE -> player.sendMessage(ChatColor.RED + "Покупать страницы можно последовательно, от 2 до 10.");
                default -> player.sendMessage(ChatColor.RED + "Покупка не выполнена: " + result.status() + ".");
            }
            return true;
        }
        player.sendMessage(ChatColor.RED + "Использование: /clan storage [open|info|history [limit]] | /clan storage page <n> | /clan storage buy <n>");
        return true;
    }

    private boolean war(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (plugin.isFunctionBlocked(player.getUniqueId(), "CLAN_WARS")) {
            player.sendMessage(ChatColor.RED + "Военные действия ограничены действующей санкцией.");
            return true;
        }
        var ownClan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        if (args.length == 1) {
            if (ownClan.isEmpty()) {
                player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
                return true;
            }
            var open = plugin.getClanWarService().openWar(ownClan.get().id());
            if (open.isPresent()) {
                showWar(player, open.get());
            } else {
                player.sendMessage(ChatColor.GRAY + "Активной войны нет. История войн:");
                var history = plugin.getClanWarService().history(ownClan.get().id(), 10);
                if (history.isEmpty()) player.sendMessage(ChatColor.GRAY + "Войн пока не было.");
                for (var war : history) {
                    player.sendMessage(ChatColor.YELLOW + war.warId().toString() + ChatColor.GRAY
                            + " | " + war.state() + " | " + war.attackerKills() + ":" + war.defenderKills()
                            + " | исход: " + war.outcome());
                }
            }
            return true;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "declare" -> {
                if (args.length < 5) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan war declare <тег> <цель-убийств> <часы> --confirm");
                    player.sendMessage(ChatColor.GRAY + "Войну объявляет лидер клана. Для подтверждения добавь --confirm.");
                    return true;
                }
                boolean confirmed = args[args.length - 1].equalsIgnoreCase("--confirm");
                int kills;
                long hours;
                try {
                    kills = Integer.parseInt(args[3]);
                    hours = Long.parseLong(args[4]);
                } catch (NumberFormatException exception) {
                    player.sendMessage(ChatColor.RED + "Цель и длительность должны быть числами.");
                    return true;
                }
                if (!confirmed) {
                    player.sendMessage(ChatColor.YELLOW + "Объявление войны клану [" + args[2] + "] до "
                            + kills + " убийств, срок " + hours + " ч.");
                    player.sendMessage(ChatColor.GRAY + "Подтверди: /clan war declare " + args[2] + " "
                            + kills + " " + hours + " --confirm");
                    return true;
                }
                var declaration = plugin.getClanWarService().declare(player.getUniqueId(), args[2], kills, hours);
                switch (declaration.status()) {
                    case CREATED -> {
                        player.sendMessage(ChatColor.GREEN + "Война объявлена клану [" + declaration.defenderTag()
                                + "]. Ожидается подтверждение его лидера.");
                        player.sendMessage(ChatColor.GRAY + "ID войны: " + declaration.war().warId());
                        notifyClan(plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElseThrow().id(),
                                ChatColor.GOLD + "Клан объявил войну [" + declaration.defenderTag() + "].");
                    }
                    case LEADER_ONLY -> player.sendMessage(ChatColor.RED + "Объявлять войну может только лидер клана.");
                    case TARGET_NOT_FOUND -> player.sendMessage(ChatColor.RED + "Клан с таким тегом не найден.");
                    case SAME_CLAN -> player.sendMessage(ChatColor.RED + "Нельзя объявить войну своему клану.");
                    case OPEN_WAR_EXISTS -> player.sendMessage(ChatColor.RED + "У одного из кланов уже есть незавершённая война.");
                    case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
                    case INVALID -> player.sendMessage(ChatColor.RED + "Некорректные параметры войны.");
                    case STORAGE_ERROR -> player.sendMessage(ChatColor.RED + "Не удалось сохранить объявление войны.");
                }
                return true;
            }
            case "accept" -> {
                if (args.length != 3) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan war accept <ID войны>");
                    return true;
                }
                UUID warId = parseWarId(player, args[2]);
                if (warId == null) return true;
                var result = plugin.getClanWarService().accept(player.getUniqueId(), warId);
                switch (result.status()) {
                    case UPDATED -> {
                        player.sendMessage(ChatColor.GREEN + "Война принята и началась.");
                        if (result.war() != null) {
                            notifyClan(result.war().attackerClanId(), ChatColor.GOLD + "Противник принял войну. Бой начался.");
                            notifyClan(result.war().defenderClanId(), ChatColor.GOLD + "Война принята. Бой начался.");
                        }
                    }
                    case NOT_LEADER -> player.sendMessage(ChatColor.RED + "Принимать войну может только лидер атакованного клана.");
                    case STATE_CONFLICT -> player.sendMessage(ChatColor.RED + "Война уже принята или завершена.");
                    case NOT_FOUND -> player.sendMessage(ChatColor.RED + "Война не найдена.");
                    default -> player.sendMessage(ChatColor.RED + "Не удалось принять войну: " + result.status());
                }
                return true;
            }
            case "cancel" -> {
                if (args.length != 3) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan war cancel <ID войны>");
                    return true;
                }
                UUID warId = parseWarId(player, args[2]);
                if (warId == null) return true;
                var result = plugin.getClanWarService().cancel(player.getUniqueId(), warId);
                switch (result.status()) {
                    case UPDATED -> player.sendMessage(ChatColor.GREEN + "Объявление войны отменено.");
                    case NOT_LEADER -> player.sendMessage(ChatColor.RED + "Отменить войну может только лидер одного из кланов.");
                    case STATE_CONFLICT -> player.sendMessage(ChatColor.RED + "Отменить можно только ещё не принятую войну.");
                    case NOT_FOUND -> player.sendMessage(ChatColor.RED + "Война не найдена.");
                    default -> player.sendMessage(ChatColor.RED + "Не удалось отменить войну: " + result.status());
                }
                return true;
            }
            case "fund" -> {
                if (args.length != 4) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan war fund <ID войны> <сумма>");
                    return true;
                }
                UUID warId = parseWarId(player, args[2]);
                if (warId == null) return true;
                BigDecimal amount = parseBankAmount(player, args[3]);
                if (amount == null) return true;
                var result = plugin.getClanWarService().contribute(player.getUniqueId(), warId, amount);
                switch (result.status()) {
                    case UPDATED -> player.sendMessage(ChatColor.GREEN + "В военный фонд внесено "
                            + amount.toPlainString() + " из банка клана.");
                    case INSUFFICIENT_BANK_FUNDS -> player.sendMessage(ChatColor.RED + "В банке клана недостаточно доступных средств.");
                    case NOT_LEADER -> player.sendMessage(ChatColor.RED + "Вносить военный взнос может только лидер клана.");
                    case STATE_CONFLICT -> player.sendMessage(ChatColor.RED + "Взносы принимаются только в активную войну.");
                    default -> player.sendMessage(ChatColor.RED + "Взнос не выполнен: " + result.status());
                }
                return true;
            }
            case "surrender" -> {
                if (args.length < 3) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan war surrender <ID войны> --confirm");
                    return true;
                }
                if (!args[args.length - 1].equalsIgnoreCase("--confirm")) {
                    player.sendMessage(ChatColor.YELLOW + "Капитуляция передаст весь военный фонд противнику.");
                    player.sendMessage(ChatColor.GRAY + "Подтверди: /clan war surrender " + args[2] + " --confirm");
                    return true;
                }
                UUID warId = parseWarId(player, args[2]);
                if (warId == null) return true;
                var result = plugin.getClanWarService().surrender(player.getUniqueId(), warId);
                switch (result.status()) {
                    case UPDATED -> {
                        player.sendMessage(ChatColor.GREEN + "Капитуляция принята. Война завершена.");
                        if (result.war() != null) {
                            plugin.getClanWarListener().announceFinished(result.war());
                        }
                    }
                    case NOT_LEADER -> player.sendMessage(ChatColor.RED + "Капитуляцию может подписать только лидер клана.");
                    case STATE_CONFLICT -> player.sendMessage(ChatColor.RED + "Война не активна.");
                    default -> player.sendMessage(ChatColor.RED + "Капитуляция не выполнена: " + result.status());
                }
                return true;
            }
            case "info" -> {
                UUID warId;
                if (args.length >= 3) {
                    warId = parseWarId(player, args[2]);
                    if (warId == null) return true;
                } else if (ownClan.isPresent()) {
                    warId = plugin.getClanWarService().openWar(ownClan.get().id())
                            .map(com.skyworldclans.clan.storage.sqlite.SqliteClanStore.ClanWar::warId)
                            .orElse(null);
                } else {
                    warId = null;
                }
                if (warId == null) {
                    player.sendMessage(ChatColor.RED + "Активная война не найдена; укажи ID.");
                    return true;
                }
                var war = plugin.getClanStore().findClanWar(warId).orElse(null);
                if (war == null) {
                    player.sendMessage(ChatColor.RED + "Война не найдена.");
                    return true;
                }
                showWar(player, war);
                return true;
            }
            default -> {
                player.sendMessage(ChatColor.RED + "Использование: /clan war [declare|accept|cancel|fund|surrender|info]");
                return true;
            }
        }
    }

    private UUID parseWarId(Player player, String raw) {
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException exception) {
            player.sendMessage(ChatColor.RED + "Некорректный ID войны.");
            return null;
        }
    }

    private void showWar(Player player, com.skyworldclans.clan.storage.sqlite.SqliteClanStore.ClanWar war) {
        String attacker = plugin.getClanStore().findById(war.attackerClanId())
                .map(Clan::tag).orElse("?");
        String defender = plugin.getClanStore().findById(war.defenderClanId())
                .map(Clan::tag).orElse("?");
        player.sendMessage(ChatColor.GOLD + "Война " + war.warId());
        player.sendMessage(ChatColor.GRAY + "[" + attacker + "] " + war.attackerKills()
                + " : " + war.defenderKills() + " [" + defender + "]");
        player.sendMessage(ChatColor.GRAY + "Состояние: " + war.state() + "; цель: " + war.targetKills()
                + " убийств; срок: " + war.durationSeconds() / 3600 + " ч.");
        if (war.startedAt() != null) {
            player.sendMessage(ChatColor.GRAY + "Начало: " + war.startedAt() + "; конец: "
                    + war.startedAt().plusSeconds(war.durationSeconds()));
        }
        if (war.endedAt() != null) {
            player.sendMessage(ChatColor.GRAY + "Завершена: " + war.endedAt() + "; исход: " + war.outcome()
                    + (war.winnerClanId() == null ? "" : "; победитель: " + war.winnerClanId()));
        }
    }

    private void notifyClan(UUID clanId, String message) {
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (plugin.getClanStore().findByPlayerId(online.getUniqueId())
                    .map(clan -> clan.id().equals(clanId)).orElse(false)) {
                online.sendMessage(message);
            }
        }
    }

    private boolean reward(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        if (args.length == 1) {
            player.sendMessage(ChatColor.RED + "Использование: /clan reward personal <ник> <сумма> | "
                    + "/clan reward bank <ник> <сумма> | /clan reward history [лимит]");
            player.sendMessage(ChatColor.GRAY + "Личная выплата идёт с твоего личного баланса. "
                    + "Награда из банка требует 7 полных дней членства получателя.");
            return true;
        }
        if (args[1].equalsIgnoreCase("requests")) {
            var requests = plugin.getClanRewardCoordinator().requests(player.getUniqueId(), false);
            player.sendMessage(ChatColor.GOLD + "Заявки на крупные награды (" + requests.size() + "):");
            if (requests.isEmpty()) player.sendMessage(ChatColor.GRAY + "Заявок нет.");
            for (var request : requests) {
                player.sendMessage(ChatColor.YELLOW + request.requestId().toString() + ChatColor.GRAY
                        + " | " + request.amount().toPlainString() + " | " + request.status()
                        + " | от " + playerName(request.deputyId())
                        + " к " + playerName(request.recipientId())
                        + " | до " + request.expiresAt()
                        + (request.status().equals("PENDING")
                            ? " | /clan reward approve " + request.requestId() : ""));
            }
            player.sendMessage(ChatColor.GRAY + "Крупная награда: 100 001–1 000 000; не более 3 одобрений в неделю.");
            return true;
        }
        if (args[1].equalsIgnoreCase("request")) {
            if (args.length < 5) {
                player.sendMessage(ChatColor.RED + "Использование: /clan reward request <ник> <сумма> <причина...>");
                return true;
            }
            Player target = plugin.getServer().getPlayerExact(args[2]);
            if (target == null) {
                player.sendMessage(ChatColor.RED + "Получатель должен быть онлайн.");
                return true;
            }
            BigDecimal amount = parseBankAmount(player, args[3]);
            if (amount == null) return true;
            String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 4, args.length));
            var result = plugin.getClanRewardCoordinator().requestLarge(
                    player.getUniqueId(), target.getUniqueId(), amount, reason);
            switch (result.status()) {
                case REQUEST_CREATED -> {
                    player.sendMessage(ChatColor.GREEN + "Заявка на крупную награду создана на 24 часа. ID: "
                            + result.request().requestId());
                    clan.leader().ifPresent(leader -> {
                        Player onlineLeader = plugin.getServer().getPlayer(leader.playerId());
                        if (onlineLeader != null) onlineLeader.sendMessage(ChatColor.GOLD
                                + "Заявка на крупную награду " + amount.toPlainString() + " от "
                                + player.getName() + ". /clan reward approve " + result.request().requestId());
                    });
                }
                case REQUEST_DUPLICATE -> player.sendMessage(ChatColor.YELLOW + "Такая заявка уже ожидает решения.");
                case NOT_AUTHORIZED -> player.sendMessage(ChatColor.RED + "Заявки на крупные награды создаёт заместитель.");
                case RECIPIENT_NOT_MEMBER -> player.sendMessage(ChatColor.RED + "Получатель не состоит в клане.");
                case RECIPIENT_MEMBERSHIP_TOO_NEW -> player.sendMessage(ChatColor.RED
                        + "Награда доступна после 7 полных дней членства получателя.");
                case INVALID_AMOUNT -> player.sendMessage(ChatColor.RED
                        + "Крупная награда: от 100 001 до 1 000 000.");
                default -> player.sendMessage(ChatColor.RED + "Заявка не создана: " + result.status() + ".");
            }
            return true;
        }
        if (args[1].equalsIgnoreCase("approve") || args[1].equalsIgnoreCase("decline")) {
            if (args.length != 3) {
                player.sendMessage(ChatColor.RED + "Использование: /clan reward "
                        + args[1].toLowerCase() + " <ID заявки>");
                return true;
            }
            UUID requestId;
            try { requestId = UUID.fromString(args[2]); }
            catch (IllegalArgumentException exception) {
                player.sendMessage(ChatColor.RED + "Некорректный ID заявки.");
                return true;
            }
            boolean approve = args[1].equalsIgnoreCase("approve");
            var result = plugin.getClanRewardCoordinator().resolveLarge(player.getUniqueId(), requestId, approve);
            switch (result.status()) {
                case SUCCESS -> {
                    player.sendMessage(ChatColor.GREEN + "Крупная награда одобрена и выплачена.");
                    UUID recipient = result.request().recipientId();
                    Player online = plugin.getServer().getPlayer(recipient);
                    if (online != null) online.sendMessage(ChatColor.GOLD
                            + "Лидер одобрил крупную награду: " + result.request().amount().toPlainString() + ".");
                }
                case REQUEST_DECLINED -> player.sendMessage(ChatColor.GREEN + "Заявка отклонена.");
                case WEEKLY_QUOTA_EXHAUSTED -> player.sendMessage(ChatColor.RED
                        + "Недельная квота исчерпана: не более 3 крупных наград за 7 дней.");
                case REQUEST_EXPIRED -> player.sendMessage(ChatColor.RED + "Срок заявки истёк; деньги не списывались.");
                case REQUEST_ALREADY_RESOLVED -> player.sendMessage(ChatColor.YELLOW + "Заявка уже обработана.");
                case NOT_AUTHORIZED -> player.sendMessage(ChatColor.RED + "Решать заявки может только лидер.");
                case REQUEST_NOT_FOUND -> player.sendMessage(ChatColor.RED + "Заявка не найдена.");
                case INVALID_AMOUNT -> player.sendMessage(ChatColor.RED + "Сумма превышает предел крупной награды.");
                case MANUAL_RECONCILIATION_REQUIRED -> player.sendMessage(ChatColor.RED
                        + "Выплата не подтверждена. Не повторяй; требуется сверка администрацией.");
                case INSUFFICIENT_BANK_FUNDS -> player.sendMessage(ChatColor.RED + "В банке клана недостаточно средств.");
                default -> player.sendMessage(ChatColor.RED + "Решение не применено: " + result.status() + ".");
            }
            return true;
        }
        if (args[1].equalsIgnoreCase("history")) {
            int limit = 20;
            if (args.length >= 3) {
                try { limit = Integer.parseInt(args[2]); }
                catch (NumberFormatException exception) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan reward history [1-100]");
                    return true;
                }
            }
            if (limit < 1 || limit > 100) {
                player.sendMessage(ChatColor.RED + "Лимит должен быть от 1 до 100.");
                return true;
            }
            var history = plugin.getClanRewardCoordinator().history(clan.id(), limit);
            player.sendMessage(ChatColor.GOLD + "Журнал наград клана [" + clan.tag() + "] (" + history.size() + "):");
            if (history.isEmpty()) player.sendMessage(ChatColor.GRAY + "Наград пока не было.");
            for (var reward : history) {
                player.sendMessage(ChatColor.YELLOW + reward.createdAt().toString() + ChatColor.GRAY
                        + " | " + reward.source() + " | " + reward.amount().toPlainString()
                        + " | от " + playerName(reward.issuerId())
                        + " к " + playerName(reward.recipientId())
                        + " | " + reward.state());
            }
            return true;
        }
        boolean personal;
        if (args[1].equalsIgnoreCase("personal")) personal = true;
        else if (args[1].equalsIgnoreCase("bank")) personal = false;
        else {
            player.sendMessage(ChatColor.RED + "Источник награды: personal или bank.");
            return true;
        }
        if (args.length != 4) {
            player.sendMessage(ChatColor.RED + "Использование: /clan reward " + (personal ? "personal" : "bank")
                    + " <ник> <сумма>");
            return true;
        }
        Player target = plugin.getServer().getPlayerExact(args[2]);
        if (target == null) {
            player.sendMessage(ChatColor.RED + "Получатель должен быть онлайн.");
            return true;
        }
        BigDecimal amount = parseBankAmount(player, args[3]);
        if (amount == null) return true;
        var result = personal
                ? plugin.getClanRewardCoordinator().personalPayout(player.getUniqueId(), target.getUniqueId(), amount)
                : plugin.getClanRewardCoordinator().bankReward(player.getUniqueId(), target.getUniqueId(), amount);
        switch (result.status()) {
            case SUCCESS -> {
                player.sendMessage(ChatColor.GREEN + "Награда " + amount.toPlainString() + " выплачена игроку "
                        + target.getName() + ".");
                target.sendMessage(ChatColor.GOLD + "Ты получил награду клана: " + amount.toPlainString() + ".");
                plugin.getLogger().info("Clan reward paid: clan=" + clan.id() + ", issuer=" + player.getUniqueId()
                        + ", recipient=" + target.getUniqueId() + ", amount=" + amount
                        + ", source=" + (personal ? "PERSONAL" : "BANK")
                        + ", operation=" + (result.operation() == null ? "?" : result.operation().operationId()));
            }
            case NOT_AUTHORIZED -> player.sendMessage(ChatColor.RED + "Выдавать награды могут только лидер и заместитель.");
            case RECIPIENT_NOT_MEMBER -> player.sendMessage(ChatColor.RED + "Получатель не состоит в твоём клане.");
            case RECIPIENT_MEMBERSHIP_TOO_NEW -> player.sendMessage(ChatColor.RED
                    + "Награда из банка доступна только после 7 полных дней членства получателя.");
            case DEPUTY_AMOUNT_LIMIT -> player.sendMessage(ChatColor.RED
                    + "Обычная награда заместителя — не более 100 000. Крупная награда требует одобрения лидера.");
            case DEPUTY_DAILY_LIMIT -> player.sendMessage(ChatColor.RED
                    + "Достигнут дневной лимит: не более 3 обычных наград в день.");
            case INSUFFICIENT_PERSONAL_FUNDS -> player.sendMessage(ChatColor.RED + "На твоём личном балансе недостаточно средств.");
            case INSUFFICIENT_BANK_FUNDS -> player.sendMessage(ChatColor.RED + "В банке клана недостаточно доступных средств.");
            case ECONOMY_UNAVAILABLE -> player.sendMessage(ChatColor.RED + "Vault Economy недоступна.");
            case MANUAL_RECONCILIATION_REQUIRED -> {
                player.sendMessage(ChatColor.RED + "Результат выплаты не подтверждён. Не повторяй команду; требуется сверка.");
                if (result.operation() != null) {
                    plugin.getLogger().severe("Clan reward requires reconciliation: operation="
                            + result.operation().operationId() + ", clan=" + clan.id()
                            + ", issuer=" + player.getUniqueId());
                }
            }
            case WEEKLY_QUOTA_POLICY_UNRESOLVED -> player.sendMessage(ChatColor.RED
                    + "Крупные награды заместителя заблокированы до решения владельца о недельной квоте.");
            default -> player.sendMessage(ChatColor.RED + "Награда не выплачена: " + result.status() + ".");
        }
        return true;
    }

    private boolean report(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length >= 2 && args[1].equalsIgnoreCase("status")) {
            var reports = plugin.getClanStore().findClanReportsByAuthor(player.getUniqueId(), 20);
            player.sendMessage(ChatColor.GOLD + "Твои жалобы (" + reports.size() + "):");
            if (reports.isEmpty()) player.sendMessage(ChatColor.GRAY + "Жалоб нет.");
            for (var report : reports) {
                String tag = plugin.getClanStore().findById(report.clanId())
                        .map(Clan::tag).orElse("?");
                player.sendMessage(ChatColor.YELLOW + report.reportId().toString() + ChatColor.GRAY
                        + " | [" + tag + "] | " + report.category() + " | " + report.status()
                        + " | " + report.createdAt());
            }
            return true;
        }
        if (args.length < 4) {
            player.sendMessage(ChatColor.RED + "Использование: /clan report <тег> <категория> <причина...>");
            player.sendMessage(ChatColor.GRAY + "Категории: rules, abuse, bank_fraud, chat_harassment");
            player.sendMessage(ChatColor.GRAY + "Статус своих жалоб: /clan report status");
            player.sendMessage(ChatColor.GRAY + "Анонимно: /clan report anonymous <тег> <категория> <причина...>");
            return true;
        }
        boolean anonymous = args[1].equalsIgnoreCase("anonymous");
        int tagIndex = anonymous ? 2 : 1;
        int categoryIndex = tagIndex + 1;
        int reasonIndex = categoryIndex + 1;
        if (args.length <= reasonIndex) {
            player.sendMessage(ChatColor.RED + "Укажи причину жалобы.");
            return true;
        }
        String tag = args[tagIndex];
        String category = args[categoryIndex];
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, reasonIndex, args.length));
        var result = anonymous
                ? plugin.getClanAdministrationService().submitAnonymousReport(
                        player.getUniqueId(), player.getName(), tag, category, reason, java.util.List.of())
                : plugin.getClanAdministrationService().submitReport(
                        player.getUniqueId(), player.getName(), tag, category, reason, java.util.List.of());
        switch (result.status()) {
            case CREATED -> player.sendMessage(ChatColor.GREEN
                    + (anonymous ? "Анонимная жалоба отправлена." : "Жалоба отправлена."));
            case DUPLICATE -> player.sendMessage(ChatColor.YELLOW + "По этой категории уже есть открытая жалоба.");
            case CLAN_NOT_FOUND -> player.sendMessage(ChatColor.RED + "Клан с таким тегом не найден.");
            case INVALID_CATEGORY -> player.sendMessage(ChatColor.RED
                    + "Категория: rules, abuse, bank_fraud, chat_harassment.");
            default -> player.sendMessage(ChatColor.RED + "Жалоба не принята: " + result.status() + ".");
        }
        return true;
    }

    private boolean appeal(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length < 3) {
            player.sendMessage(ChatColor.RED + "Использование: /clan appeal <ID санкции> <причина...>");
            player.sendMessage(ChatColor.GRAY + "Срок подачи — 7 дней с момента санкции; позже только с разрешения владельца.");
            return true;
        }
        UUID sanctionId;
        try { sanctionId = UUID.fromString(args[1]); }
        catch (IllegalArgumentException exception) {
            player.sendMessage(ChatColor.RED + "Некорректный ID санкции.");
            return true;
        }
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        var result = plugin.getClanAdministrationService().submitAppeal(
                player.getUniqueId(), sanctionId, reason, null, false);
        switch (result.status()) {
            case CREATED -> player.sendMessage(ChatColor.GREEN + "Апелляция подана. Санкция действует до решения.");
            case DUPLICATE -> player.sendMessage(ChatColor.YELLOW + "По этой санкции уже есть апелляция.");
            case APPEAL_WINDOW_EXPIRED -> player.sendMessage(ChatColor.RED
                    + "Срок подачи истёк (7 дней). Поздняя апелляция — только с разрешения владельца.");
            case UNAUTHORIZED -> player.sendMessage(ChatColor.RED
                    + "Подать апелляцию может лидер клана или сам игрок под санкцией.");
            case NOT_FOUND -> player.sendMessage(ChatColor.RED + "Санкция не найдена.");
            default -> player.sendMessage(ChatColor.RED + "Апелляция не принята: " + result.status() + ".");
        }
        return true;
    }

    private boolean quests(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        var quests = plugin.getClanQuestService().quests(clan.id());
        if (quests.isEmpty()) {
            player.sendMessage(ChatColor.GRAY + "Заданий пока нет; они обновятся автоматически.");
            return true;
        }
        player.sendMessage(ChatColor.GOLD + "Задания клана [" + clan.tag() + "]:");
        for (var quest : quests) {
            String name = switch (quest.metric()) {
                case MINE_BLOCK -> "добыть руду";
                case KILL_MOB -> "убить мобов";
                case COLLECT_ITEM -> "собрать ресурсы";
                case WIN_WAR -> "выиграть войны";
            };
            player.sendMessage(ChatColor.YELLOW + quest.category().name() + "/" + quest.difficulty().name()
                    + ChatColor.GRAY + " — " + name + ": " + quest.progress() + "/" + quest.targetAmount()
                    + " | вкладчиков: " + plugin.getClanStore().countClanQuestContributors(quest.questId())
                    + "/" + quest.requiredContributors()
                    + " | XP: " + com.skyworldclans.clan.quest.ClanQuestService.xpFor(
                            quest.category(), quest.difficulty())
                    + " | до " + quest.expiresAt());
        }
        player.sendMessage(ChatColor.GRAY + "Прогресс общий: добыча руды, убийства мобов, подбор ресурсов и победы в войнах.");
        player.sendMessage(ChatColor.GRAY + "Денежные награды за задания не начисляются до утверждения размеров владельцем.");
        return true;
    }

    private boolean tournament(CommandSender sender, String[] args) {
        if (args.length == 1 || args[1].equalsIgnoreCase("list")) {
            var tournaments = plugin.getClanTournamentService().list(20);
            sender.sendMessage(ChatColor.GOLD + "Турниры (" + tournaments.size() + "):");
            if (tournaments.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Турниров нет.");
            for (var tournament : tournaments) {
                sender.sendMessage(ChatColor.YELLOW + tournament.tournamentId().toString() + ChatColor.GRAY
                        + " | " + tournament.discipline() + " | " + tournament.state()
                        + " | команда: " + tournament.teamSize()
                        + " | " + tournament.name());
            }
            return true;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (!sender.hasPermission("skyworldclans.admin.owner")
                        && sender instanceof Player) {
                    sender.sendMessage(ChatColor.RED + "Создавать турниры может только владелец сервера.");
                    return true;
                }
                if (args.length < 5) {
                    sender.sendMessage(ChatColor.RED + "Использование: /clan tournament create "
                            + "<PVP|PARKOUR|BUILDING|RESOURCE_GATHERING|TREASURE_HUNT> <3|5|10> <название...>");
                    return true;
                }
                int teamSize;
                try { teamSize = Integer.parseInt(args[3]); }
                catch (NumberFormatException exception) {
                    sender.sendMessage(ChatColor.RED + "Размер команды: 3, 5 или 10.");
                    return true;
                }
                String name = String.join(" ", java.util.Arrays.copyOfRange(args, 4, args.length));
                var result = plugin.getClanTournamentService().create(
                        sender instanceof Player p ? p.getUniqueId() : null, args[2], name, teamSize,
                        1, 60, 1, false, true);
                if (result.status() == com.skyworldclans.clan.tournament.ClanTournamentService.Status.CREATED) {
                    sender.sendMessage(ChatColor.GREEN + "Турнир создан: " + result.tournament().tournamentId());
                    sender.sendMessage(ChatColor.GRAY + "Регистрация заблокирована до утверждения условий оплаты владельцем.");
                } else {
                    sender.sendMessage(ChatColor.RED + "Турнир не создан: " + result.status() + ".");
                }
                return true;
            }
            case "open" -> {
                if (args.length != 3) {
                    sender.sendMessage(ChatColor.RED + "Использование: /clan tournament open <ID>");
                    return true;
                }
                UUID id = parseTournamentId(sender, args[2]);
                if (id == null) return true;
                var result = plugin.getClanTournamentService().openRegistration(
                        sender instanceof Player p ? p.getUniqueId() : null, id, java.time.Duration.ofDays(1));
                sender.sendMessage(result.status() == com.skyworldclans.clan.tournament.ClanTournamentService.Status.REGISTRATION_BLOCKED
                        ? ChatColor.YELLOW + "Регистрация пока недоступна: условия оплаты не утверждены владельцем."
                        : ChatColor.RED + "Регистрация не открыта: " + result.status() + ".");
                return true;
            }
            case "info" -> {
                if (args.length != 3) {
                    sender.sendMessage(ChatColor.RED + "Использование: /clan tournament info <ID>");
                    return true;
                }
                UUID id = parseTournamentId(sender, args[2]);
                if (id == null) return true;
                var tournament = plugin.getClanTournamentService().find(id).orElse(null);
                if (tournament == null) {
                    sender.sendMessage(ChatColor.RED + "Турнир не найден.");
                    return true;
                }
                sender.sendMessage(ChatColor.GOLD + tournament.name() + " (" + tournament.discipline() + ")");
                sender.sendMessage(ChatColor.GRAY + "Состояние: " + tournament.state()
                        + " | команда: " + tournament.teamSize()
                        + " | голосование: минимум " + tournament.voteMinimum()
                        + ", " + tournament.voteDurationMinutes() + " мин, очки " + tournament.votePoints()
                        + (tournament.allowAbstain() ? ", воздержание разрешено" : "")
                        + (tournament.hideResults() ? ", итоги скрыты" : ""));
                return true;
            }
            case "vote" -> {
                if (!(sender instanceof Player player)) return playerOnly(sender);
                if (args.length != 4) {
                    sender.sendMessage(ChatColor.RED + "Использование: /clan tournament vote <ID турнира> <тег клана>");
                    return true;
                }
                UUID id = parseTournamentId(sender, args[2]);
                if (id == null) return true;
                var clan = plugin.getClanStore().findByTag(args[3]).orElse(null);
                if (clan == null) {
                    sender.sendMessage(ChatColor.RED + "Клан с таким тегом не найден.");
                    return true;
                }
                var result = plugin.getClanTournamentService().vote(player.getUniqueId(), id, clan.id());
                switch (result.status()) {
                    case VOTED -> sender.sendMessage(ChatColor.GREEN + "Голос учтён.");
                    case ALREADY_VOTED -> sender.sendMessage(ChatColor.RED + "Ты уже голосовал; голос неизменяем.");
                    case NOT_ELIGIBLE -> sender.sendMessage(ChatColor.RED
                            + "Нужно право skyworldclans.tournament.vote.");
                    case VOTE_OWN_CLAN -> sender.sendMessage(ChatColor.RED + "Нельзя голосовать за свой клан.");
                    case VOTE_NOT_ALLOWED -> sender.sendMessage(ChatColor.RED
                            + "Голосование доступно только в дисциплине «строительство».");
                    case VOTING_CLOSED -> sender.sendMessage(ChatColor.RED + "Голосование закрыто.");
                    default -> sender.sendMessage(ChatColor.RED + "Голос не принят: " + result.status() + ".");
                }
                return true;
            }
            case "state" -> {
                if (args.length != 4) {
                    sender.sendMessage(ChatColor.RED + "Использование: /clan tournament state <ID> "
                            + "<REGISTRATION_CLOSED|RUNNING|FINISHED|CANCELLED>");
                    return true;
                }
                if (!sender.hasPermission("skyworldclans.admin.owner") && sender instanceof Player) {
                    sender.sendMessage(ChatColor.RED + "Менять состояние турнира может только владелец.");
                    return true;
                }
                UUID id = parseTournamentId(sender, args[2]);
                if (id == null) return true;
                var result = plugin.getClanTournamentService().changeState(
                        sender instanceof Player p ? p.getUniqueId() : null, id, args[3]);
                switch (result.status()) {
                    case STATE_CHANGED -> sender.sendMessage(ChatColor.GREEN + "Состояние турнира: "
                            + (result.tournament() == null ? args[3] : result.tournament().state()));
                    case STATE_CONFLICT -> sender.sendMessage(ChatColor.RED
                            + "Турнир уже завершён или отменён; состояние не изменено.");
                    case NOT_FOUND -> sender.sendMessage(ChatColor.RED + "Турнир не найден.");
                    default -> sender.sendMessage(ChatColor.RED + "Состояние не изменено: " + result.status() + ".");
                }
                return true;
            }
            case "results" -> {
                if (args.length != 3) {
                    sender.sendMessage(ChatColor.RED + "Использование: /clan tournament results <ID>");
                    return true;
                }
                UUID id = parseTournamentId(sender, args[2]);
                if (id == null) return true;
                var tally = plugin.getClanTournamentService().results(id);
                if (tally.isEmpty()) {
                    sender.sendMessage(ChatColor.YELLOW + "Итоги скрыты до закрытия голосования.");
                    return true;
                }
                sender.sendMessage(ChatColor.GOLD + "Итоги голосования:");
                tally.forEach((clanId, points) -> sender.sendMessage(ChatColor.YELLOW
                        + plugin.getClanStore().findById(clanId).map(Clan::tag).orElse(clanId.toString())
                        + ChatColor.GRAY + " — " + points));
                return true;
            }
            default -> {
                sender.sendMessage(ChatColor.RED + "Использование: /clan tournament "
                        + "[list|info|create|open|vote|results]");
                return true;
            }
        }
    }

    private UUID parseTournamentId(CommandSender sender, String raw) {
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный ID турнира.");
            return null;
        }
    }

    private boolean deleteClan(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        if (!clan.member(player.getUniqueId()).map(member -> member.role() == ClanRole.LEADER).orElse(false)) {
            player.sendMessage(ChatColor.RED + "Удалить клан может только лидер.");
            return true;
        }
        boolean confirmed = args.length >= 2 && args[args.length - 1].equalsIgnoreCase("--confirm");
        if (!confirmed) {
            player.sendMessage(ChatColor.RED + "Удаление клана необратимо: деньги, предметы, дома и улучшения не возвращаются.");
            player.sendMessage(ChatColor.GRAY + "Подтверди: /clan delete --confirm");
            return true;
        }
        boolean deleted;
        try {
            deleted = plugin.getClanStore().deleteClan(clan.id(), player.getUniqueId(), java.time.Instant.now());
        } catch (RuntimeException exception) {
            plugin.getLogger().log(java.util.logging.Level.SEVERE,
                    "Clan deletion failed for " + clan.id(), exception);
            player.sendMessage(ChatColor.RED + "Не удалось удалить клан; данные не изменены.");
            return true;
        }
        if (!deleted) {
            player.sendMessage(ChatColor.RED + "Клан не удалён: недостаточно прав или клан уже отсутствует.");
            return true;
        }
        plugin.getLogger().warning("Clan " + clan.tag() + " (" + clan.id() + ") deleted by leader "
                + player.getUniqueId() + "; irreversible, no compensation.");
        player.sendMessage(ChatColor.GREEN + "Клан [" + clan.tag() + "] удалён без возможности восстановления.");
        return true;
    }

    private boolean renameClan(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length < 4) {
            player.sendMessage(ChatColor.RED + "Использование: /clan rename <новый тег> <новое название...>");
            player.sendMessage(ChatColor.GRAY + "Переименование меняет название и тег одновременно.");
            player.sendMessage(ChatColor.GRAY + "Стоимость: 200 SWCoin. Оплата заблокирована до подтверждения API SkyWorldCoins.");
            return true;
        }
        String newTag = args[1];
        String newName = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
        var result = plugin.getClanRenameService().rename(player.getUniqueId(), newName, newTag);
        switch (result.status()) {
            case RENAMED -> {
                player.sendMessage(ChatColor.GREEN + "Клан переименован: " + result.clan().name()
                        + " [" + result.clan().tag() + "].");
                notifyClan(result.clan().id(), ChatColor.GOLD + "Клан переименован в "
                        + result.clan().name() + " [" + result.clan().tag() + "].");
            }
            case UNCHANGED -> player.sendMessage(ChatColor.YELLOW + "Название и тег уже такие.");
            case LEADER_ONLY -> player.sendMessage(ChatColor.RED + "Переименовать клан может только лидер.");
            case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            case TAG_TAKEN -> player.sendMessage(ChatColor.RED + "Этот тег уже занят (учитывается регистр).");
            case SWCOIN_UNAVAILABLE -> {
                player.sendMessage(ChatColor.RED + "Переименование стоит 200 SWCoin, но публичный API SkyWorldCoins не подтверждён.");
                player.sendMessage(ChatColor.GRAY + "Операция не выполнена и валюта не списана. Обратись к администрации.");
            }
            case INVALID_INPUT -> player.sendMessage(ChatColor.RED
                    + "Название — 3–16 символов, тег — 2–5 латинских букв или цифр.");
            default -> player.sendMessage(ChatColor.RED + "Переименование не выполнено: " + result.status() + ".");
        }
        return true;
    }

    private boolean home(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Команда дома доступна только игроку.");
            return true;
        }
        if (args.length == 1 || isHomeSlot(args[1])) {
            return teleportHome(player, args.length == 1 ? 1 : parseHomeSlot(player, args[1]));
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "buy" -> {
                var result = plugin.getClanHomeService().purchaseSecondHome(
                        player.getUniqueId(), java.time.Instant.now());
                switch (result.status()) {
                    case PURCHASED -> player.sendMessage(ChatColor.GREEN + "Вторая точка дома куплена за 200 000 из банка клана.");
                    case ALREADY_PURCHASED -> player.sendMessage(ChatColor.YELLOW + "Вторая точка дома уже куплена.");
                    case LEADER_ONLY -> player.sendMessage(ChatColor.RED + "Покупать вторую точку может только лидер.");
                    case INSUFFICIENT_BANK_FUNDS -> player.sendMessage(ChatColor.RED + "В банке клана недостаточно средств (нужно 200 000).");
                    case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
                    default -> player.sendMessage(ChatColor.RED + "Покупка не выполнена: " + result.status() + ".");
                }
                return true;
            }
            case "set" -> {
                int slot = 1;
                int nameStart = 2;
                if (args.length >= 3 && isHomeSlot(args[2])) {
                    slot = parseHomeSlot(player, args[2]);
                    nameStart = 3;
                }
                if (args.length > nameStart) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan home set [1|2]");
                    return true;
                }
                if (plugin.getWorldGuardRegionAccess() == null) {
                    player.sendMessage(ChatColor.RED + "WorldGuard не загружен. Установка точки дома отключена.");
                    return true;
                }
                if (!plugin.getWorldGuardRegionAccess().canSetHome(player)) {
                    player.sendMessage(ChatColor.RED + "WorldGuard запрещает установку точки здесь либо данные региона недоступны.");
                    return true;
                }
                Location location = player.getLocation();
                var result = plugin.getClanHomeService().setHome(player.getUniqueId(), slot,
                        location.getWorld().getUID(), location.getX(), location.getY(), location.getZ(),
                        location.getYaw(), location.getPitch(), java.time.Instant.now());
                switch (result.status()) {
                    case SAVED -> player.sendMessage(ChatColor.GREEN + "Точка дома №" + slot + " сохранена.");
                    case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
                    case NOT_AUTHORIZED -> player.sendMessage(ChatColor.RED + "Устанавливать точку дома могут только лидер и заместители.");
                    case SLOT_NOT_PURCHASED -> player.sendMessage(ChatColor.RED
                            + "Вторая точка не куплена. Используй /clan home buy (200 000 из банка).");
                    default -> player.sendMessage(ChatColor.RED + "Не удалось сохранить точку дома: " + result.status() + ".");
                }
                return true;
            }
            case "rename" -> {
                int slot = 1;
                int nameStart = 2;
                if (args.length >= 3 && isHomeSlot(args[2])) {
                    slot = parseHomeSlot(player, args[2]);
                    nameStart = 3;
                }
                if (args.length <= nameStart) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan home rename [1|2] <название>");
                    return true;
                }
                String name = String.join(" ", java.util.Arrays.copyOfRange(args, nameStart, args.length));
                var result = plugin.getClanHomeService().renameHome(player.getUniqueId(), slot, name, java.time.Instant.now());
                switch (result.status()) {
                    case RENAMED -> player.sendMessage(ChatColor.GREEN + "Точка дома переименована в «" + result.point().name() + "».");
                    case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
                    case NOT_AUTHORIZED -> player.sendMessage(ChatColor.RED + "Переименовывать точку могут только лидер и заместители.");
                    case HOME_NOT_SET -> player.sendMessage(ChatColor.RED + "Сначала установи точку дома: /clan home set " + slot + ".");
                    case INVALID_INPUT -> player.sendMessage(ChatColor.RED + "Название должно содержать от 1 до 32 символов.");
                    default -> player.sendMessage(ChatColor.RED + "Не удалось переименовать точку: " + result.status() + ".");
                }
                return true;
            }
            case "delete" -> {
                int slot = 1;
                if (args.length >= 3 && isHomeSlot(args[2])) slot = parseHomeSlot(player, args[2]);
                if (args.length > 3 || (args.length == 3 && !isHomeSlot(args[2]))) {
                    player.sendMessage(ChatColor.RED + "Использование: /clan home delete [1|2]");
                    return true;
                }
                var result = plugin.getClanHomeService().deleteHome(player.getUniqueId(), slot, java.time.Instant.now());
                switch (result.status()) {
                    case DELETED -> player.sendMessage(ChatColor.GREEN + "Точка дома №" + slot + " удалена.");
                    case NOT_IN_CLAN -> player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
                    case LEADER_ONLY -> player.sendMessage(ChatColor.RED + "Удалять точку дома может только лидер клана.");
                    case HOME_NOT_SET -> player.sendMessage(ChatColor.RED + "Точка дома ещё не установлена.");
                    default -> player.sendMessage(ChatColor.RED + "Не удалось удалить точку: " + result.status() + ".");
                }
                return true;
            }
            default -> {
                player.sendMessage(ChatColor.YELLOW + "/clan home [1|2]" + ChatColor.GRAY + " — телепорт к точке клана");
                player.sendMessage(ChatColor.YELLOW + "/clan home set [1|2]" + ChatColor.GRAY + " — установить точку (лидер/заместитель)");
                player.sendMessage(ChatColor.YELLOW + "/clan home buy" + ChatColor.GRAY + " — купить вторую точку (200 000, только лидер)");
                player.sendMessage(ChatColor.YELLOW + "/clan home rename [1|2] <название>" + ChatColor.GRAY + " — переименовать (лидер/заместитель)");
                player.sendMessage(ChatColor.YELLOW + "/clan home delete [1|2]" + ChatColor.GRAY + " — удалить точку (только лидер)");
                return true;
            }
        }
    }

    private static boolean isHomeSlot(String value) {
        return "1".equals(value) || "2".equals(value);
    }

    private int parseHomeSlot(Player player, String value) {
        try {
            int slot = Integer.parseInt(value);
            if (slot >= 1 && slot <= ClanHomeService.MAX_HOME_POINTS) return slot;
        } catch (NumberFormatException ignored) {
            // fall through to the diagnostic below
        }
        player.sendMessage(ChatColor.RED + "Номер точки: 1 или 2.");
        return 1;
    }

    private boolean teleportHome(Player player, int slot) {
        ClanHomeService.Result result = plugin.getClanHomeService().homeFor(player.getUniqueId(), slot);
        if (result.status() == ClanHomeService.Status.NOT_IN_CLAN) {
            player.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        if (result.status() == ClanHomeService.Status.HOME_NOT_SET) {
            player.sendMessage(ChatColor.RED + (slot == 2
                    ? "Вторая точка не установлена. Сначала купи слот: /clan home buy."
                    : "Основная точка дома клана ещё не установлена. Используй /clan home set."));
            return true;
        }
        if (result.status() != ClanHomeService.Status.READY || result.point() == null) {
            player.sendMessage(ChatColor.RED + "Не удалось получить точку дома клана.");
            return true;
        }
        if (plugin.getWorldGuardRegionAccess() == null) {
            player.sendMessage(ChatColor.RED + "WorldGuard не загружен. Телепортация к точке дома отключена.");
            return true;
        }
        var point = result.point();
        World world = Bukkit.getWorld(point.worldId());
        if (world == null) {
            player.sendMessage(ChatColor.RED + "Мир, в котором установлена точка дома, сейчас недоступен.");
            return true;
        }
        Location destination = new Location(world, point.x(), point.y(), point.z(), point.yaw(), point.pitch());
        // Owner decision #3: teleporting home must honour WorldGuard ENTRY.
        if (!plugin.getWorldGuardRegionAccess().canEnterHome(player, destination)) {
            player.sendMessage(ChatColor.RED + "WorldGuard запрещает вход в регион точки дома либо данные региона недоступны.");
            return true;
        }
        if (player.teleport(destination)) player.sendMessage(ChatColor.GREEN + "Ты телепортирован к дому клана: " + point.name() + ".");
        else player.sendMessage(ChatColor.RED + "Телепортация к дому клана не удалась.");
        return true;
    }

    private boolean bank(CommandSender sender, String[] args) {
        if (args.length == 1 || args[1].equalsIgnoreCase("balance")) return bankBalance(sender);
        return switch (args[1].toLowerCase(Locale.ROOT)) {
            case "deposit" -> bankDeposit(sender, args);
            case "withdraw" -> bankLeaderWithdraw(sender, args);
            case "request" -> bankRequest(sender, args);
            case "requests" -> bankRequests(sender);
            case "approve" -> bankResolve(sender, args, true);
            case "decline" -> bankResolve(sender, args, false);
            case "pay" -> bankPayApprovedRequest(sender, args);
            default -> { help(sender); yield true; }
        };
    }

    private boolean bankBalance(CommandSender sender) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        sender.sendMessage(ChatColor.GOLD + "Банк клана [" + clan.tag() + "]:");
        sender.sendMessage(ChatColor.GRAY + "Баланс: " + plugin.getClanStore().clanBankBalance(clan.id()).toPlainString());
        sender.sendMessage(ChatColor.GRAY + "Доступно: " + plugin.getClanStore().clanBankAvailableBalance(clan.id()).toPlainString());
        return true;
    }

    private boolean bankDeposit(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (plugin.isBankBlocked(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Банковские операции ограничены действующей санкцией.");
            return true;
        }
        if (args.length != 3) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan bank deposit <сумма>");
            return true;
        }
        BigDecimal amount = parseBankAmount(sender, args[2]);
        if (amount == null) return true;
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Пополнение банка обрабатывается. Не повторяй команду, пока не получишь результат.");
        plugin.getClanBankTransferCoordinator().deposit(clan.id(), player.getUniqueId(), amount, result -> {
            if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.SUCCESS) {
                player.sendMessage(ChatColor.GREEN + "В банк клана внесено " + amount.toPlainString() + ".");
                notifyClanOnline(clan.id(), ChatColor.GOLD + player.getName() + " пополнил банк клана на " + amount.toPlainString() + ".");
                plugin.getLogger().info("Clan bank deposit committed: clan=" + clan.id() + ", player=" + player.getUniqueId()
                        + ", amount=" + amount + ", operation=" + operationId(result));
            } else {
                player.sendMessage(bankOperationMessage(result.status()));
                if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED
                        || result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.LOCAL_COMMIT_PENDING) {
                    plugin.getLogger().severe("Clan bank deposit requires reconciliation: clan=" + clan.id()
                            + ", player=" + player.getUniqueId() + ", operation=" + operationId(result));
                }
            }
        });
        return true;
    }

    private boolean bankLeaderWithdraw(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (plugin.isBankBlocked(player.getUniqueId())) {
            player.sendMessage(ChatColor.RED + "Банковские операции ограничены действующей санкцией.");
            return true;
        }
        if (args.length != 3) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan bank withdraw <сумма>");
            return true;
        }
        BigDecimal amount = parseBankAmount(sender, args[2]);
        if (amount == null) return true;
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Вывод из банка обрабатывается.");
        plugin.getClanBankTransferCoordinator().leaderWithdraw(clan.id(), player.getUniqueId(), amount, result -> {
            if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.SUCCESS) {
                player.sendMessage(ChatColor.GREEN + "Из банка выведено " + amount.toPlainString() + ".");
                notifyClanOnline(clan.id(), ChatColor.GOLD + "Лидер вывел из банка клана " + amount.toPlainString() + ".");
                plugin.getLogger().warning("Clan bank leader withdrawal committed: clan=" + clan.id()
                        + ", leader=" + player.getUniqueId() + ", amount=" + amount + ", operation=" + operationId(result));
            } else {
                player.sendMessage(bankOperationMessage(result.status()));
                if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED
                        || result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.LOCAL_COMMIT_PENDING) {
                    plugin.getLogger().severe("Clan bank leader withdrawal requires reconciliation: clan=" + clan.id()
                            + ", leader=" + player.getUniqueId() + ", operation=" + operationId(result));
                }
            }
        });
        return true;
    }

    private boolean bankRequest(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length < 4) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan bank request <сумма> <причина...>");
            return true;
        }
        BigDecimal amount = parseBankAmount(sender, args[2]);
        if (amount == null) return true;
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length)).trim();
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        var result = plugin.getClanBankService().requestWithdrawal(clan.id(), player.getUniqueId(), amount, reason);
        if (result.status() != com.skyworldclans.clan.bank.ClanBankService.Status.CREATED) {
            sender.sendMessage(bankRequestMessage(result.status()));
            return true;
        }
        var request = result.request();
        sender.sendMessage(ChatColor.GREEN + "Заявка на " + amount.toPlainString() + " создана на 24 часа. ID: " + request.requestId());
        clan.leader().ifPresent(leader -> {
            Player onlineLeader = plugin.getServer().getPlayer(leader.playerId());
            if (onlineLeader != null) onlineLeader.sendMessage(ChatColor.GOLD + "Новая заявка заместителя на вывод "
                    + amount.toPlainString() + ". Причина: " + reason + ". ID: " + request.requestId()
                    + ". /clan bank requests");
        });
        plugin.getLogger().warning("Clan bank withdrawal requested: request=" + request.requestId() + ", clan="
                + clan.id() + ", deputy=" + player.getUniqueId() + ", amount=" + amount + ", reason=" + reason);
        return true;
    }

    private boolean bankRequests(CommandSender sender) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        if (!clan.member(player.getUniqueId()).map(member -> member.role() == ClanRole.LEADER).orElse(false)) {
            sender.sendMessage(ChatColor.RED + "Список заявок на вывод доступен только лидеру.");
            return true;
        }
        var requests = plugin.getClanBankService().requests(clan.id(), player.getUniqueId(), false);
        sender.sendMessage(ChatColor.GOLD + "Заявки на вывод клана [" + clan.tag() + "]:");
        if (requests.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Заявок пока нет.");
        for (var request : requests) {
            String payment = request.paymentOperationId() == null ? "выплата не запускалась"
                    : plugin.getClanStore().findClanBankOperation(request.paymentOperationId())
                        .map(operation -> "операция " + operation.state()).orElse("операция не найдена");
            sender.sendMessage(ChatColor.YELLOW + request.requestId().toString() + ChatColor.GRAY + " — "
                    + playerName(request.requesterId()) + ", " + request.amount().toPlainString()
                    + ", статус " + request.status() + ", " + payment + ", причина: " + request.reason());
        }
        return true;
    }

    private boolean bankResolve(CommandSender sender, String[] args, boolean approve) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length != 3) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan bank " + (approve ? "approve" : "decline") + " <ID>");
            return true;
        }
        UUID requestId;
        try { requestId = UUID.fromString(args[2]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный ID заявки.");
            return true;
        }
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        var resolved = plugin.getClanBankService().resolveWithdrawal(clan.id(), player.getUniqueId(), requestId, approve);
        if (resolved.status() == com.skyworldclans.clan.bank.ClanBankService.Status.EXPIRED && resolved.request() != null) {
            sender.sendMessage(ChatColor.RED + "Срок заявки истёк; деньги не списывались.");
            Player deputy = plugin.getServer().getPlayer(resolved.request().requesterId());
            if (deputy != null) deputy.sendMessage(ChatColor.RED + "Срок твоей заявки на вывод средств истёк. Деньги не списывались.");
            plugin.getLogger().warning("Clan bank withdrawal request expired during leader review: request=" + requestId
                    + ", clan=" + clan.id() + ", deputy=" + resolved.request().requesterId());
            return true;
        }
        if (resolved.status() == com.skyworldclans.clan.bank.ClanBankService.Status.DECLINED) {
            sender.sendMessage(ChatColor.GREEN + "Заявка отклонена.");
            Player deputy = plugin.getServer().getPlayer(resolved.request().requesterId());
            if (deputy != null) deputy.sendMessage(ChatColor.RED + "Лидер отклонил твою заявку на вывод средств.");
            plugin.getLogger().warning("Clan bank withdrawal request declined: request=" + requestId + ", clan=" + clan.id()
                    + ", leader=" + player.getUniqueId());
            return true;
        }
        if (resolved.status() != com.skyworldclans.clan.bank.ClanBankService.Status.APPROVED) {
            sender.sendMessage(bankRequestMessage(resolved.status()));
            return true;
        }
        sender.sendMessage(ChatColor.GREEN + "Заявка одобрена. Выплата запускается.");
        plugin.getLogger().warning("Clan bank withdrawal request approved: request=" + requestId + ", clan=" + clan.id()
                + ", leader=" + player.getUniqueId() + ", deputy=" + resolved.request().requesterId()
                + ", amount=" + resolved.request().amount());
        launchApprovedBankPayout(player, clan, resolved.request().requesterId(), requestId);
        return true;
    }

    private boolean bankPayApprovedRequest(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (args.length != 3) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan bank pay <ID одобренной заявки>");
            return true;
        }
        UUID requestId;
        try { requestId = UUID.fromString(args[2]); }
        catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный ID заявки.");
            return true;
        }
        Clan clan = plugin.getClanStore().findByPlayerId(player.getUniqueId()).orElse(null);
        if (clan == null) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        UUID deputyId = plugin.getClanStore().findClanBankWithdrawalRequests(clan.id(), false).stream()
                .filter(request -> request.requestId().equals(requestId))
                .map(com.skyworldclans.clan.storage.sqlite.SqliteClanStore.ClanBankWithdrawalRequest::requesterId)
                .findFirst().orElse(null);
        launchApprovedBankPayout(player, clan, deputyId, requestId);
        return true;
    }

    private void launchApprovedBankPayout(Player leader, Clan clan, UUID deputyId, UUID requestId) {
        leader.sendMessage(ChatColor.YELLOW + "Выплата обрабатывается. Не запускай её повторно до результата.");
        plugin.getClanBankTransferCoordinator().payApprovedDeputyRequest(clan.id(), leader.getUniqueId(), requestId, result -> {
            if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.SUCCESS) {
                leader.sendMessage(ChatColor.GREEN + "Выплата по заявке выполнена.");
                UUID beneficiary = deputyId != null ? deputyId
                        : result.operation() == null ? null : result.operation().beneficiaryId();
                if (beneficiary != null) {
                    Player deputy = plugin.getServer().getPlayer(beneficiary);
                    if (deputy != null) deputy.sendMessage(ChatColor.GREEN + "Лидер одобрил и выполнил твою заявку на вывод средств.");
                }
                notifyClanOnline(clan.id(), ChatColor.GOLD + "Выполнена выплата по заявке на вывод из банка клана.");
                plugin.getLogger().warning("Clan bank deputy payout committed: request=" + requestId + ", clan=" + clan.id()
                        + ", operation=" + operationId(result));
            } else {
                leader.sendMessage(bankOperationMessage(result.status()));
                if (deputyId != null) {
                    Player deputy = plugin.getServer().getPlayer(deputyId);
                    if (deputy != null) {
                        if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED
                                || result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.LOCAL_COMMIT_PENDING) {
                            deputy.sendMessage(ChatColor.RED + "Выплата имеет неопределённый результат. Не создавай новую заявку; администрация проверит операцию.");
                        } else if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.INSUFFICIENT_BANK_FUNDS) {
                            deputy.sendMessage(ChatColor.YELLOW + "Лидер одобрил заявку, но в банке пока недостаточно доступных средств. Выплата ожидает пополнения.");
                        } else {
                            deputy.sendMessage(ChatColor.YELLOW + "Лидер одобрил заявку, но выплата пока не завершена: " + result.status() + ".");
                        }
                    }
                }
                if (result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.MANUAL_RECONCILIATION_REQUIRED
                        || result.status() == com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status.LOCAL_COMMIT_PENDING) {
                    plugin.getLogger().severe("Clan bank deputy payout requires reconciliation: request=" + requestId
                            + ", clan=" + clan.id() + ", operation=" + operationId(result));
                } else {
                    plugin.getLogger().warning("Clan bank deputy payout not completed: request=" + requestId
                            + ", clan=" + clan.id() + ", status=" + result.status());
                }
            }
        });
    }

    private void notifyClanOnline(UUID clanId, String message) {
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (plugin.getClanStore().findByPlayerId(online.getUniqueId())
                    .map(value -> value.id().equals(clanId)).orElse(false)) online.sendMessage(message);
        }
    }

    private static BigDecimal parseBankAmount(CommandSender sender, String raw) {
        try {
            BigDecimal amount = new BigDecimal(raw);
            if (amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 8
                    || !Double.isFinite(amount.doubleValue()) || amount.doubleValue() <= 0.0
                    || BigDecimal.valueOf(amount.doubleValue()).compareTo(amount.stripTrailingZeros()) != 0) {
                sender.sendMessage(ChatColor.RED + "Укажи положительную сумму с точностью не более 8 знаков после запятой.");
                return null;
            }
            return amount.stripTrailingZeros();
        } catch (NumberFormatException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректная сумма.");
            return null;
        }
    }

    private static String operationId(com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Result result) {
        return result.operation() == null ? "unknown" : result.operation().operationId().toString();
    }

    private static String bankOperationMessage(com.skyworldclans.clan.bank.ClanBankTransferCoordinator.Status status) {
        return switch (status) {
            case ECONOMY_UNAVAILABLE -> ChatColor.RED + "Vault Economy недоступна; операция не запускалась.";
            case INVALID_AMOUNT -> ChatColor.RED + "Некорректная сумма.";
            case NOT_AUTHORIZED -> ChatColor.RED + "Недостаточно полномочий.";
            case CLAN_NOT_FOUND -> ChatColor.RED + "Клан не найден.";
            case INSUFFICIENT_BANK_FUNDS -> ChatColor.RED + "В банке недостаточно доступных средств.";
            case INSUFFICIENT_PERSONAL_FUNDS -> ChatColor.RED + "На личном балансе недостаточно средств.";
            case REQUEST_NOT_APPROVED -> ChatColor.RED + "Заявка не найдена или не одобрена.";
            case OPERATION_ALREADY_EXISTS -> ChatColor.RED + "Для этой операции уже создана запись; проверь её статус.";
            case ALREADY_COMPLETED -> ChatColor.GREEN + "Эта операция уже завершена.";
            case IDEMPOTENCY_CONFLICT -> ChatColor.RED + "Обнаружен конфликт идентификатора операции; обратись к администрации.";
            case MANUAL_RECONCILIATION_REQUIRED -> ChatColor.RED + "Результат операции неизвестен. Не повторяй команду; требуется сверка администрацией.";
            case LOCAL_COMMIT_PENDING -> ChatColor.RED + "Внешняя выплата подтверждена, но локальная запись ожидает восстановления. Не повторяй команду.";
            case PROVIDER_NOT_CALLED -> ChatColor.RED + "Внешняя операция не запускалась из-за ошибки планировщика.";
            case STORAGE_ERROR -> ChatColor.RED + "Ошибка сохранения операции. Не повторяй команду до проверки журнала.";
            case SUCCESS -> ChatColor.GREEN + "Операция выполнена.";
        };
    }

    private static String bankRequestMessage(com.skyworldclans.clan.bank.ClanBankService.Status status) {
        return switch (status) {
            case INVALID_INPUT -> ChatColor.RED + "Проверь сумму и причину заявки.";
            case CLAN_NOT_FOUND -> ChatColor.RED + "Клан не найден.";
            case NOT_MEMBER -> ChatColor.RED + "Ты не состоишь в клане.";
            case DEPUTY_ONLY -> ChatColor.RED + "Создавать заявки на вывод может только заместитель.";
            case LEADER_ONLY -> ChatColor.RED + "Решать заявки может только лидер.";
            case REQUEST_NOT_FOUND -> ChatColor.RED + "Заявка не найдена в этом клане.";
            case EXPIRED -> ChatColor.RED + "Срок заявки истёк; деньги не списывались.";
            case ALREADY_RESOLVED -> ChatColor.RED + "Заявка уже обработана.";
            case STORAGE_CONFLICT, STORAGE_ERROR -> ChatColor.RED + "Не удалось безопасно сохранить заявку.";
            case DUPLICATE -> ChatColor.YELLOW + "Такая заявка уже существует.";
            case CREATED -> ChatColor.GREEN + "Заявка создана.";
            case APPROVED -> ChatColor.GREEN + "Заявка одобрена.";
            case DECLINED -> ChatColor.GREEN + "Заявка отклонена.";
        };
    }

    private boolean invite(CommandSender sender, String[] args) {
        if (args.length != 2) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan invite <ник>");
            return true;
        }
        if (!(sender instanceof Player actor)) return playerOnly(sender);
        if (plugin.isFunctionBlocked(actor.getUniqueId(), "CLAN_REQUESTS")) {
            sender.sendMessage(ChatColor.RED + "Приглашения ограничены действующей санкцией.");
            return true;
        }
        Player target = plugin.getServer().getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Приглашаемый игрок должен быть онлайн.");
            return true;
        }
        Optional<Clan> clan = plugin.getClanStore().findByPlayerId(actor.getUniqueId());
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        if (plugin.getClanElectionService().hasActiveElection(clan.get().id())) {
            sender.sendMessage(ChatColor.RED + "Во время выборов нельзя менять состав клана.");
            return true;
        }
        ClanRequestStore.CreateStatus status = plugin.getClanRequestService().invite(
                clan.get().id(), actor.getUniqueId(), target.getUniqueId());
        if (status == ClanRequestStore.CreateStatus.CREATED) {
            sender.sendMessage(ChatColor.GREEN + "Приглашение отправлено; оно действует 2 минуты.");
            target.sendMessage(ChatColor.GOLD + "Тебя пригласили в клан [" + clan.get().tag()
                    + "]. Используй /clan requests, затем /clan accept <ID> или /clan decline <ID>.");
        } else {
            sender.sendMessage(ChatColor.RED + requestCreateMessage(status));
        }
        return true;
    }

    private boolean join(CommandSender sender, String[] args) {
        if (args.length != 2) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan join <тег>");
            return true;
        }
        if (!(sender instanceof Player player)) return playerOnly(sender);
        if (plugin.isFunctionBlocked(player.getUniqueId(), "CLAN_REQUESTS")) {
            sender.sendMessage(ChatColor.RED + "Заявки ограничены действующей санкцией.");
            return true;
        }
        ClanRequestStore.CreateStatus status = plugin.getClanRequestService()
                .apply(player.getUniqueId(), args[1]);
        if (status == ClanRequestStore.CreateStatus.CREATED) {
            sender.sendMessage(ChatColor.GREEN + "Заявка отправлена. Она действует 24 часа.");
        } else {
            sender.sendMessage(ChatColor.RED + requestCreateMessage(status));
        }
        return true;
    }

    private boolean requests(CommandSender sender) {
        if (!(sender instanceof Player player)) return playerOnly(sender);
        List<ClanRequest> invitations = plugin.getClanRequestService().pendingForPlayer(
                player.getUniqueId(), ClanRequest.Type.INVITATION);
        sender.sendMessage(ChatColor.GOLD + "Твои приглашения:");
        if (invitations.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Нет активных приглашений.");
        for (ClanRequest request : invitations) {
            Optional<Clan> clan = plugin.getClanStore().findById(request.clanId());
            sender.sendMessage(ChatColor.YELLOW + (clan.map(Clan::tag).orElse("?"))
                    + ChatColor.GRAY + " — ID: " + request.id());
        }
        Optional<Clan> ownClan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        if (ownClan.isPresent()) {
            var role = ownClan.get().member(player.getUniqueId()).orElseThrow().role();
            if (role == com.skyworldclans.clan.membership.ClanRole.LEADER
                    || role == com.skyworldclans.clan.membership.ClanRole.DEPUTY) {
                List<ClanRequest> applications = plugin.getClanRequestService().pendingForClan(
                        ownClan.get().id(), ClanRequest.Type.APPLICATION);
                sender.sendMessage(ChatColor.GOLD + "Заявки в твой клан:");
                if (applications.isEmpty()) sender.sendMessage(ChatColor.GRAY + "Нет активных заявок.");
                for (ClanRequest request : applications) {
                    sender.sendMessage(ChatColor.YELLOW + playerName(request.playerId())
                            + ChatColor.GRAY + " — ID: " + request.id());
                }
            }
        }
        return true;
    }

    private boolean applications(CommandSender sender, String[] args) {
        if (args.length != 2 || !(args[1].equalsIgnoreCase("open") || args[1].equalsIgnoreCase("close"))) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan applications <open|close>");
            return true;
        }
        if (!(sender instanceof Player player)) return playerOnly(sender);
        Optional<Clan> clan = plugin.getClanStore().findByPlayerId(player.getUniqueId());
        if (clan.isEmpty()) {
            sender.sendMessage(ChatColor.RED + "Ты не состоишь в клане.");
            return true;
        }
        boolean open = args[1].equalsIgnoreCase("open");
        ClanRequestStore.SettingStatus status = plugin.getClanRequestService()
                .setPublicApplicationsOpen(clan.get().id(), player.getUniqueId(), open);
        if (status == ClanRequestStore.SettingStatus.UPDATED) {
            sender.sendMessage(ChatColor.GREEN + (open
                    ? "Публичные заявки открыты." : "Публичные заявки закрыты."));
        } else if (status == ClanRequestStore.SettingStatus.NOT_LEADER) {
            sender.sendMessage(ChatColor.RED + "Закрывать и открывать заявки может только лидер.");
        } else {
            sender.sendMessage(ChatColor.RED + "Клан не найден.");
        }
        return true;
    }

    private boolean resolveRequest(CommandSender sender, String[] args, boolean accept) {
        if (args.length != 2) {
            sender.sendMessage(ChatColor.RED + "Использование: /clan "
                    + (accept ? "accept" : "decline") + " <ID>");
            return true;
        }
        if (!(sender instanceof Player player)) return playerOnly(sender);
        UUID requestId;
        try {
            requestId = UUID.fromString(args[1]);
        } catch (IllegalArgumentException exception) {
            sender.sendMessage(ChatColor.RED + "Некорректный ID заявки.");
            return true;
        }
        ClanRequestStore.ResolveStatus status = accept
                ? plugin.getClanRequestService().accept(requestId, player.getUniqueId())
                : plugin.getClanRequestService().decline(requestId, player.getUniqueId());
        switch (status) {
            case ACCEPTED -> {
                plugin.recordClanMemberActivity(player.getUniqueId());
                sender.sendMessage(ChatColor.GREEN + "Запрос принят.");
            }
            case DECLINED -> sender.sendMessage(ChatColor.GREEN + "Запрос отклонён.");
            case EXPIRED -> sender.sendMessage(ChatColor.RED + "Срок действия запроса истёк.");
            case NOT_FOUND -> sender.sendMessage(ChatColor.RED + "Запрос не найден.");
            case NOT_PENDING -> sender.sendMessage(ChatColor.RED + "Запрос уже обработан.");
            case NOT_AUTHORIZED -> sender.sendMessage(ChatColor.RED + "У тебя нет права обработать этот запрос.");
            case PLAYER_ALREADY_IN_CLAN -> sender.sendMessage(ChatColor.RED + "Игрок уже состоит в клане.");
            case PLAYER_HAS_PENDING_CREATION -> sender.sendMessage(ChatColor.RED + "У игрока есть незавершённая операция создания клана.");
            case CLAN_FULL -> sender.sendMessage(ChatColor.RED + "В клане больше нет свободных мест.");
            case ELECTION_ACTIVE -> sender.sendMessage(ChatColor.RED + "Во время выборов нельзя менять состав клана.");
            case CONCURRENT_MODIFICATION -> sender.sendMessage(ChatColor.RED + "Состояние изменилось; повтори запрос.");
        }
        return true;
    }

    private static String requestCreateMessage(ClanRequestStore.CreateStatus status) {
        return switch (status) {
            case CLAN_NOT_FOUND -> "Клан не найден.";
            case ACTOR_NOT_AUTHORIZED -> "Недостаточно полномочий для приглашения.";
            case PLAYER_ALREADY_IN_CLAN -> "Игрок уже состоит в клане.";
            case CLAN_FULL -> "Клан заполнен.";
            case DUPLICATE_PENDING_REQUEST -> "Такой активный запрос уже существует.";
            case APPLICATIONS_CLOSED -> "Публичные заявки в этот клан закрыты.";
            case ELECTION_ACTIVE -> "Во время выборов нельзя менять состав клана.";
            case INVALID_REQUEST -> "Некорректный запрос.";
            case CREATED -> "Запрос создан.";
        };
    }

    private void failure(CommandSender sender, ClanMembershipChangeResult.Status status) {
        String message = switch (status) {
            case CLAN_NOT_FOUND -> "Клан не найден.";
            case ACTOR_NOT_MEMBER -> "Ты не состоишь в клане.";
            case TARGET_NOT_MEMBER -> "Игрок не состоит в твоём клане.";
            case INSUFFICIENT_PERMISSION -> "Недостаточно полномочий.";
            case TARGET_NOT_ELIGIBLE -> "Игрок не подходит для этой роли.";
            case DEPUTY_LIMIT_REACHED -> "Достигнут лимит заместителей (4).";
            case MODERATOR_LIMIT_REACHED -> "Достигнут лимит модераторов.";
            case ELECTION_ACTIVE -> "Во время выборов действие запрещено.";
            case CONCURRENT_MODIFICATION -> "Клан изменился одновременно; повтори действие.";
            case INVALID_MEMBERSHIP_STATE -> "Операция нарушает правила состава клана.";
            default -> "Операция отклонена: " + status.name();
        };
        sender.sendMessage(ChatColor.RED + message);
    }

    private String playerName(UUID id) {
        OfflinePlayer player = plugin.getServer().getOfflinePlayer(id);
        return player.getName() == null ? id.toString() : player.getName();
    }

    private static String roleName(String role) {
        return switch (role) {
            case "LEADER" -> "Лидер";
            case "DEPUTY" -> "Заместитель";
            case "MODERATOR" -> "Модератор";
            default -> "Участник";
        };
    }

    private static boolean playerOnly(CommandSender sender) {
        sender.sendMessage(ChatColor.RED + "Команда доступна только игроку.");
        return true;
    }

    private static void help(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "SkyWorldClans — команды:");
        sender.sendMessage(ChatColor.YELLOW + "/clan create <тег> <название...> [--slogan <слоган...>]" + ChatColor.GRAY + " — создать клан за 1 000 000");
        sender.sendMessage(ChatColor.YELLOW + "/clan admin creation-payment reconcile ..." + ChatColor.GRAY + " — сверка спорного платежа (консоль)");
        sender.sendMessage(ChatColor.YELLOW + "/clan admin bank-operation reconcile ..." + ChatColor.GRAY + " — сверка неизвестной банковской операции (консоль)");
        sender.sendMessage(ChatColor.YELLOW + "/clan admin bank-history <clan-uuid> [limit]" + ChatColor.GRAY + " — просмотр журнала банка (консоль)");
        sender.sendMessage(ChatColor.YELLOW + "/clan admin backup" + ChatColor.GRAY + " — создать резервную копию SQLite (консоль)");
        sender.sendMessage(ChatColor.YELLOW + "/clan admin status" + ChatColor.GRAY + " — состояние реализованных подсистем (консоль)");
        sender.sendMessage(ChatColor.YELLOW + "/clan admin combatlog list [limit]" + ChatColor.GRAY + " — просмотр прерванных перезапуском CombatLog-сессий (консоль)");
        sender.sendMessage(ChatColor.YELLOW + "/clan info [тег]" + ChatColor.GRAY + " — информация о клане");
        sender.sendMessage(ChatColor.YELLOW + "/clan members" + ChatColor.GRAY + " — состав клана");
        sender.sendMessage(ChatColor.YELLOW + "/clan leave" + ChatColor.GRAY + " — выйти из клана");
        sender.sendMessage(ChatColor.YELLOW + "/clan kick <ник>" + ChatColor.GRAY + " — исключить участника");
        sender.sendMessage(ChatColor.YELLOW + "/clan deputy add|remove <ник>" + ChatColor.GRAY + " — назначить/снять заместителя");
        sender.sendMessage(ChatColor.YELLOW + "/clan moderator add|remove <ник>" + ChatColor.GRAY + " — назначить/снять модератора");
        sender.sendMessage(ChatColor.YELLOW + "/clan leader transfer <ник>" + ChatColor.GRAY + " — передать лидерство");
        sender.sendMessage(ChatColor.YELLOW + "/clan election info [тег]" + ChatColor.GRAY + " — состояние выборов и голоса");
        sender.sendMessage(ChatColor.YELLOW + "/clan election vote <UUID>" + ChatColor.GRAY + " — голос своего клана");
        sender.sendMessage(ChatColor.YELLOW + "/clan election vote <тег> <UUID>" + ChatColor.GRAY + " — глобальный этап (нужен permission)");
        sender.sendMessage(ChatColor.YELLOW + "/clan coup" + ChatColor.GRAY + " — инициировать переворот после 30 дней отсутствия лидера");
        sender.sendMessage(ChatColor.YELLOW + "/clan storage" + ChatColor.GRAY + " — открыть GUI хранилища (54 слота)");
        sender.sendMessage(ChatColor.YELLOW + "/clan storage page <n> | buy <n> | history [limit]" + ChatColor.GRAY + " — страницы, покупка и журнал");
        sender.sendMessage(ChatColor.YELLOW + "/clan bank balance|deposit <сумма>" + ChatColor.GRAY + " — баланс и пополнение банка");
        sender.sendMessage(ChatColor.YELLOW + "/clan bank withdraw <сумма>" + ChatColor.GRAY + " — прямой вывод лидером");
        sender.sendMessage(ChatColor.YELLOW + "/clan bank request <сумма> <причина>" + ChatColor.GRAY + " — заявка заместителя на вывод");
        sender.sendMessage(ChatColor.YELLOW + "/clan bank requests|approve|decline|pay <ID>" + ChatColor.GRAY + " — управление заявками лидером");
        sender.sendMessage(ChatColor.YELLOW + "/clan war declare <тег> <убийства> <часы> --confirm" + ChatColor.GRAY + " — объявить войну (лидер)");
        sender.sendMessage(ChatColor.YELLOW + "/clan war accept|cancel|fund|surrender|info <ID>" + ChatColor.GRAY + " — управление войной");
        sender.sendMessage(ChatColor.YELLOW + "/clan reward personal|bank <ник> <сумма>" + ChatColor.GRAY + " — выдать награду");
        sender.sendMessage(ChatColor.YELLOW + "/clan reward request <ник> <сумма> <причина>" + ChatColor.GRAY + " — заявка заместителя на крупную награду");
        sender.sendMessage(ChatColor.YELLOW + "/clan reward approve|decline <ID>" + ChatColor.GRAY + " — решение лидера (квота 3/неделю)");
        sender.sendMessage(ChatColor.YELLOW + "/clan reward requests" + ChatColor.GRAY + " — заявки на крупные награды");
        sender.sendMessage(ChatColor.YELLOW + "/clan report <тег> <категория> <причина>" + ChatColor.GRAY + " — жалоба на клан");
        sender.sendMessage(ChatColor.YELLOW + "/clan report status" + ChatColor.GRAY + " — статусы своих жалоб");
        sender.sendMessage(ChatColor.YELLOW + "/clan appeal <ID санкции> <причина>" + ChatColor.GRAY + " — апелляция (7 дней)");
        sender.sendMessage(ChatColor.YELLOW + "/clan admin panel" + ChatColor.GRAY + " — административная панель");
        sender.sendMessage(ChatColor.YELLOW + "/clan quests" + ChatColor.GRAY + " — клановые задания и прогресс");
        sender.sendMessage(ChatColor.YELLOW + "/clan tournament state <ID> <REGISTRATION_CLOSED|RUNNING|FINISHED|CANCELLED>" + ChatColor.GRAY + " — состояние (владелец)");
        sender.sendMessage(ChatColor.YELLOW + "/clan tournament [list|info|create|open|vote|results]" + ChatColor.GRAY + " — турниры");
        sender.sendMessage(ChatColor.YELLOW + "/clan rename <тег> <название...>" + ChatColor.GRAY + " — переименовать (200 SWCoin, ожидает API)");
        sender.sendMessage(ChatColor.YELLOW + "/clan delete --confirm" + ChatColor.GRAY + " — удалить клан (только лидер, необратимо)");
        sender.sendMessage(ChatColor.YELLOW + "/clan invite <ник>" + ChatColor.GRAY + " — пригласить игрока");
        sender.sendMessage(ChatColor.YELLOW + "/clan join <тег>" + ChatColor.GRAY + " — подать заявку");
        sender.sendMessage(ChatColor.YELLOW + "/clan requests" + ChatColor.GRAY + " — посмотреть запросы");
        sender.sendMessage(ChatColor.YELLOW + "/clan applications <open|close>" + ChatColor.GRAY + " — управление публичными заявками");
        sender.sendMessage(ChatColor.YELLOW + "/clan accept|decline <ID>" + ChatColor.GRAY + " — обработать запрос");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return partial(List.of("help", "create", "admin", "info", "members", "leave", "kick", "deputy", "moderator", "leader", "invite", "join", "requests", "applications", "accept", "decline", "election", "coup", "bank", "home", "storage", "war", "reward", "report", "appeal", "quests", "tournament", "delete", "rename"), args[0]);
        if (args.length == 2 && args[0].equalsIgnoreCase("admin")) return partial(
                List.of("creation-payment", "bank-operation", "bank-history", "combatlog", "backup", "status"), args[1]);
        if (args.length == 3 && args[0].equalsIgnoreCase("admin")
                && (args[1].equalsIgnoreCase("creation-payment") || args[1].equalsIgnoreCase("bank-operation")))
            return partial(List.of("reconcile"), args[2]);
        if (args.length == 3 && args[0].equalsIgnoreCase("admin") && args[1].equalsIgnoreCase("combatlog"))
            return partial(List.of("list"), args[2]);
        if (args.length == 2 && args[0].equalsIgnoreCase("leader")) return partial(List.of("transfer"), args[1]);
        if (args.length == 2 && args[0].equalsIgnoreCase("bank")) return partial(List.of("balance", "deposit", "withdraw", "request", "requests", "approve", "decline", "pay"), args[1]);
        if (args.length == 2 && args[0].equalsIgnoreCase("home")) return partial(List.of("set", "rename", "delete"), args[1]);
        if (args.length == 2 && args[0].equalsIgnoreCase("storage")) return partial(List.of("open", "info", "page", "buy", "history"), args[1]);
        if (args.length == 2 && args[0].equalsIgnoreCase("reward")) return partial(List.of("personal", "bank", "history"), args[1]);
        if (args.length == 2 && args[0].equalsIgnoreCase("war")) return partial(List.of("declare", "accept", "cancel", "fund", "surrender", "info"), args[1]);
        if (args.length == 3 && args[0].equalsIgnoreCase("storage") && args[1].equalsIgnoreCase("page")) return partial(List.of("1", "2", "3", "4", "5", "6", "7", "8", "9", "10"), args[2]);
        if (args.length == 3 && args[0].equalsIgnoreCase("storage") && args[1].equalsIgnoreCase("buy")) return partial(List.of("2", "3", "4", "5", "6", "7", "8", "9", "10"), args[2]);
        if (args.length == 2 && args[0].equalsIgnoreCase("election")) return partial(List.of("info", "vote"), args[1]);
        if (args.length == 2 && args[0].equalsIgnoreCase("applications")) return partial(List.of("open", "close"), args[1]);
        if (args.length == 2 && (args[0].equalsIgnoreCase("deputy") || args[0].equalsIgnoreCase("moderator"))) return partial(List.of("add", "remove"), args[1]);
        if ((args.length == 2 && List.of("kick", "invite").contains(args[0].toLowerCase(Locale.ROOT)))
                || (args.length == 3 && List.of("deputy", "moderator", "leader").contains(args[0].toLowerCase(Locale.ROOT)))) {
            String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
            return plugin.getServer().getOnlinePlayers().stream().map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(prefix)).toList();
        }
        return List.of();
    }

    private static List<String> partial(List<String> values, String prefix) {
        String normalized = prefix.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(normalized)).toList();
    }

    private enum Action {
        KICK("/clan kick <ник>", "Игрок исключён из клана.", "Ты исключён из клана."),
        DEPUTY("/clan deputy add <ник>", "Игрок назначен заместителем.", "Ты назначен заместителем клана."),
        MODERATOR("/clan moderator add <ник>", "Игрок назначен модератором.", "Ты назначен модератором клана.");
        private final String usage;
        private final String success;
        private final String targetNotice;
        Action(String usage, String success, String targetNotice) {
            this.usage = usage;
            this.success = success;
            this.targetNotice = targetNotice;
        }
    }
}

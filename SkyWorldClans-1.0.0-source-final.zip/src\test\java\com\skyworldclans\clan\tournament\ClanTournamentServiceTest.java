package com.skyworldclans.clan.tournament;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanTournamentServiceTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-05T12:00:00Z");

    @Test
    void registrationStaysBlockedUntilTheOwnerApprovesTheFeePolicy() {
        UUID ownerId = id(1);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("tournament-block.sqlite"))) {
            var service = new ClanTournamentService(store, store, Clock.fixed(NOW, ZoneOffset.UTC),
                    UUID::randomUUID, playerId -> true);
            var created = service.create(ownerId, "BUILDING", "Winter Build", 5, 2, 120, 3, false, true);
            assertEquals(ClanTournamentService.Status.CREATED, created.status());
            assertEquals("DRAFT", created.tournament().state());

            var opened = service.openRegistration(ownerId, created.tournament().tournamentId(),
                    java.time.Duration.ofDays(1));
            assertEquals(ClanTournamentService.Status.REGISTRATION_BLOCKED, opened.status());
            assertEquals("DRAFT", service.find(created.tournament().tournamentId()).orElseThrow().state());
        }
    }

    @Test
    void buildingVotesAreUniqueImmutableAndNeverForYourOwnClan() {
        UUID ownerId = id(11), leaderA = id(12), leaderB = id(13), voter = id(14);
        Clan clanA = clan(leaderA, "TA100", 100);
        Clan clanB = clan(leaderB, "TB200", 200);
        Clan voterClan = clan(voter, "TV300", 300);
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("tournament-vote.sqlite"))) {
            store.registerIfAvailable(clanA);
            store.registerIfAvailable(clanB);
            store.registerIfAvailable(voterClan);
            var service = new ClanTournamentService(store, store, Clock.fixed(NOW, ZoneOffset.UTC),
                    UUID::randomUUID, id -> id.equals(voter) || id.equals(leaderA));
            var created = service.create(ownerId, "BUILDING", "Spring Build", 3, 1, 60, 2, false, true);
            UUID tournamentId = created.tournament().tournamentId();
            assertEquals(SqliteClanStore.TournamentStatus.UPDATED,
                    store.setTournamentState(tournamentId, "REGISTRATION_CLOSED", ownerId, NOW));

            assertEquals(ClanTournamentService.Status.VOTE_OWN_CLAN,
                    service.vote(voter, tournamentId, voterClan.id()).status());
            assertEquals(ClanTournamentService.Status.NOT_ELIGIBLE,
                    service.vote(id(99), tournamentId, clanA.id()).status());
            assertEquals(ClanTournamentService.Status.VOTED,
                    service.vote(voter, tournamentId, clanA.id()).status());
            assertEquals(ClanTournamentService.Status.VOTED,
                    service.vote(leaderA, tournamentId, clanB.id()).status());
            assertEquals(ClanTournamentService.Status.ALREADY_VOTED,
                    service.vote(voter, tournamentId, clanB.id()).status());

            assertEquals(2, store.tournamentTally(tournamentId).get(clanA.id()));
            assertEquals(2, store.tournamentTally(tournamentId).get(clanB.id()));
            // Results are hidden until voting closes.
            assertTrue(service.results(tournamentId).isEmpty());
            assertEquals(SqliteClanStore.TournamentStatus.UPDATED,
                    service.revokeVote(ownerId, tournamentId, voter, "suspicious").tournament() != null
                            ? SqliteClanStore.TournamentStatus.UPDATED : SqliteClanStore.TournamentStatus.NOT_FOUND);
            assertEquals(2, store.tournamentTally(tournamentId).get(clanB.id()));
        }
    }

    @Test
    void invalidTournamentParametersAreRejected() {
        try (SqliteClanStore store = SqliteClanStore.open(temporaryDirectory.resolve("tournament-invalid.sqlite"))) {
            var service = new ClanTournamentService(store, store, Clock.fixed(NOW, ZoneOffset.UTC),
                    UUID::randomUUID, playerId -> true);
            assertEquals(ClanTournamentService.Status.INVALID,
                    service.create(id(1), "BUILDING", "Bad", 4, 1, 60, 1, false, true).status());
            assertEquals(ClanTournamentService.Status.INVALID,
                    service.create(id(1), "UNKNOWN", "Bad", 5, 1, 60, 1, false, true).status());
            assertEquals(ClanTournamentService.Status.INVALID,
                    service.create(id(1), "PVP", " ", 5, 1, 60, 1, false, true).status());
        }
    }

    private static Clan clan(UUID leader, String tag, int seed) {
        Instant start = NOW.minusSeconds(86_400L * 10);
        return new Clan(new UUID(0, seed), "Tournament" + seed, tag, start, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, start, null)), 0, null);
    }

    private static UUID id(long value) { return new UUID(1, value); }
}
package com.skyworldclans.clan.application.creation;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;
import com.skyworldclans.clan.validation.ClanNameTagValidator;

/** Immutable snapshot persisted before any call to the external economy provider. */
public record ClanCreationPaymentOperation(
        UUID operationId,
        String idempotencyKey,
        UUID creatorId,
        UUID clanId,
        String name,
        String tag,
        String slogan,
        Instant clanCreatedAt,
        long amountUnits,
        ClanCreationPaymentState state,
        String diagnostic,
        Instant createdAt,
        Instant updatedAt) {

    public static final long CREATION_PRICE_UNITS = 1_000_000L;

    public ClanCreationPaymentOperation {
        Objects.requireNonNull(operationId, "operationId");
        if (idempotencyKey == null || idempotencyKey.isBlank())
            throw new IllegalArgumentException("idempotencyKey must not be blank");
        Objects.requireNonNull(creatorId, "creatorId");
        Objects.requireNonNull(clanId, "clanId");
        if (!ClanNameTagValidator.isValidName(name))
            throw new IllegalArgumentException("name does not satisfy the clan name policy");
        if (!ClanNameTagValidator.isValidTag(tag))
            throw new IllegalArgumentException("tag does not satisfy the clan tag policy");
        Objects.requireNonNull(clanCreatedAt, "clanCreatedAt");
        if (amountUnits != CREATION_PRICE_UNITS)
            throw new IllegalArgumentException("Clan creation price must be exactly 1,000,000 ordinary currency units");
        Objects.requireNonNull(state, "state");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(updatedAt, "updatedAt");
        if (updatedAt.isBefore(createdAt)) throw new IllegalArgumentException("updatedAt precedes createdAt");
        if (diagnostic != null && diagnostic.length() > 1000)
            throw new IllegalArgumentException("diagnostic is too long");
    }

    public ClanCreationPaymentOperation withState(ClanCreationPaymentState next, String nextDiagnostic, Instant at) {
        return new ClanCreationPaymentOperation(operationId, idempotencyKey, creatorId, clanId,
                name, tag, slogan, clanCreatedAt, amountUnits, next, nextDiagnostic, createdAt, at);
    }
}

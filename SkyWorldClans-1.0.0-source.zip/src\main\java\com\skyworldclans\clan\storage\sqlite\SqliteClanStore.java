package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseEvidenceProvenance;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseIntent;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseEvent;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseJournal;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseOperation;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseState;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseStore;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseTransitionEvidence;
import com.skyworldclans.clan.application.purchase.CapacityPurchaseTransitionPolicy;
import com.skyworldclans.clan.application.creation.ClanCreationPaymentJournal;
import com.skyworldclans.clan.application.creation.ClanCreationPaymentOperation;
import com.skyworldclans.clan.application.creation.ClanCreationPaymentState;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.policy.ClanCapacityPolicy;
import com.skyworldclans.clan.policy.ClanLevelPolicy;
import com.skyworldclans.clan.request.ClanRequest;
import com.skyworldclans.clan.request.ClanRequestStore;
import com.skyworldclans.clan.xp.ClanXpAwardResult;
import com.skyworldclans.clan.xp.ClanXpEventType;
import com.skyworldclans.clan.xp.ClanXpStore;
import com.skyworldclans.clan.storage.StorageException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Single JDBC connection owner for clans, purchase/request/XP/election journals, and player activity.
 */
public final class SqliteClanStore
        implements ClanCatalog, CapacityPurchaseStore, ClanRequestStore, ClanXpStore, ClanCreationPaymentJournal, AutoCloseable {
    private static final int SCHEMA_VERSION = 28;
    private static final int BUSY_TIMEOUT_MILLIS = 10_000;
    /** Reserved actor UUID recorded for server-initiated bank movements (war prizes/refunds). */
    static final UUID SYSTEM_ACTOR_ID = new UUID(0L, 0L);
    private static final String PURCHASE_STATES = """
            'PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'COMMITTED',
            'FAILED_NO_EFFECT', 'UNKNOWN', 'COMPENSATION_PENDING',
            'COMPENSATION_CALLING', 'COMPENSATION_UNKNOWN',
            'COMPENSATED', 'COMPENSATION_FAILED'
            """;
    private static final String EVIDENCE_VALUES = """
            'NONE', 'DEBIT_NO_EFFECT_REPORTED', 'DEBIT_RESULT_UNKNOWN_REPORTED',
            'DEBIT_SUCCESS_REPORTED', 'RECONCILED_DEBIT_NO_EFFECT_REPORTED',
            'RECONCILED_DEBIT_SUCCESS_REPORTED', 'ATOMIC_CAPACITY_COMMIT',
            'COMPENSATION_REQUIRED_REPORTED', 'COMPENSATION_CALL_INTENT_RECORDED',
            'COMPENSATION_SUCCESS_REPORTED', 'COMPENSATION_NO_EFFECT_REPORTED',
            'COMPENSATION_RESULT_UNKNOWN_REPORTED',
            'RECONCILED_COMPENSATION_SUCCESS_REPORTED',
            'RECONCILED_COMPENSATION_NO_EFFECT_REPORTED'
            """;
    private static final String NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER capacity_purchase_events_no_update
            BEFORE UPDATE ON capacity_purchase_events
            BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
            """;
    private static final String NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER capacity_purchase_events_no_delete
            BEFORE DELETE ON capacity_purchase_events
            BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
            """;
    private static final String CLAN_REQUEST_NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER clan_request_events_no_update
            BEFORE UPDATE ON clan_request_events
            BEGIN SELECT RAISE(ABORT, 'clan request events are append-only'); END
            """;
    private static final String CLAN_REQUEST_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_request_events_no_delete
            BEFORE DELETE ON clan_request_events
            BEGIN SELECT RAISE(ABORT, 'clan request events are append-only'); END
            """;
    private static final String CLAN_XP_NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER clan_xp_events_no_update
            BEFORE UPDATE ON clan_xp_events
            BEGIN SELECT RAISE(ABORT, 'clan XP events are append-only'); END
            """;
    private static final String CLAN_XP_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_xp_events_no_delete
            BEFORE DELETE ON clan_xp_events
            BEGIN SELECT RAISE(ABORT, 'clan XP events are append-only'); END
            """;
    private static final String CLAN_CREATION_OPERATIONS_IMMUTABLE_TRIGGER_DDL = """
            CREATE TRIGGER clan_creation_payment_operations_immutable
            BEFORE UPDATE ON clan_creation_payment_operations
            WHEN OLD.operation_id <> NEW.operation_id
              OR OLD.idempotency_key <> NEW.idempotency_key
              OR OLD.creator_id <> NEW.creator_id
              OR OLD.clan_id <> NEW.clan_id
              OR OLD.clan_name <> NEW.clan_name
              OR OLD.clan_tag <> NEW.clan_tag
              OR OLD.clan_slogan IS NOT NEW.clan_slogan
              OR OLD.clan_created_at <> NEW.clan_created_at
              OR OLD.amount_units <> NEW.amount_units
              OR OLD.created_at <> NEW.created_at
            BEGIN SELECT RAISE(ABORT, 'clan creation payment intent is immutable'); END
            """;
    private static final String CLAN_CREATION_OPERATIONS_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_creation_payment_operations_no_delete
            BEFORE DELETE ON clan_creation_payment_operations
            BEGIN SELECT RAISE(ABORT, 'clan creation payment operations are retained'); END
            """;
    private static final String CLAN_CREATION_STATE_TRANSITION_TRIGGER_DDL = """
            CREATE TRIGGER clan_creation_payment_state_transition_guard
            BEFORE UPDATE OF state ON clan_creation_payment_operations
            WHEN NOT (
                (OLD.state = 'PREPARED' AND NEW.state IN ('CALLING', 'FAILED_NO_EFFECT'))
                OR (OLD.state = 'CALLING' AND NEW.state IN ('DEBIT_CONFIRMED', 'FAILED_NO_EFFECT', 'UNKNOWN'))
                OR (OLD.state = 'DEBIT_CONFIRMED' AND NEW.state = 'COMMITTED')
                OR (OLD.state = 'UNKNOWN' AND NEW.state IN ('DEBIT_CONFIRMED', 'FAILED_NO_EFFECT'))
                OR (OLD.state = NEW.state)
            ) OR julianday(NEW.updated_at) < julianday(OLD.updated_at)
            BEGIN SELECT RAISE(ABORT, 'invalid clan creation payment state transition or timestamp'); END
            """;
    private static final String CLAN_CREATION_EVENTS_INSERT_GUARD_TRIGGER_DDL = """
            CREATE TRIGGER clan_creation_payment_events_insert_guard
            BEFORE INSERT ON clan_creation_payment_events
            WHEN NOT EXISTS (
                SELECT 1 FROM clan_creation_payment_operations o
                WHERE o.operation_id = NEW.operation_id AND o.state = NEW.to_state
                  AND ((NEW.from_state IS NULL AND NOT EXISTS (
                        SELECT 1 FROM clan_creation_payment_events e WHERE e.operation_id = NEW.operation_id))
                    OR NEW.from_state = (SELECT e.to_state FROM clan_creation_payment_events e
                        WHERE e.operation_id = NEW.operation_id ORDER BY e.event_id DESC LIMIT 1))
            )
            BEGIN SELECT RAISE(ABORT, 'clan creation payment event does not match operation state'); END
            """;
    private static final String CLAN_CREATION_EVENTS_NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER clan_creation_payment_events_no_update
            BEFORE UPDATE ON clan_creation_payment_events
            BEGIN SELECT RAISE(ABORT, 'clan creation payment events are append-only'); END
            """;
    private static final String CLAN_CREATION_EVENTS_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_creation_payment_events_no_delete
            BEFORE DELETE ON clan_creation_payment_events
            BEGIN SELECT RAISE(ABORT, 'clan creation payment events are append-only'); END
            """;
    private static final String CLAN_ELECTION_OWNER_BLOCKS_INSERT_GUARD_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_owner_blocks_insert_guard
            BEFORE INSERT ON clan_election_owner_blocks
            WHEN NOT EXISTS (SELECT 1 FROM clan_elections e WHERE e.election_id = NEW.election_id
                AND e.phase = 'GLOBAL_TIE_BREAK' AND julianday(e.closes_at) <= julianday(NEW.blocked_at))
            BEGIN SELECT RAISE(ABORT, 'election is not eligible for owner block'); END
            """;
    private static final String CLAN_ELECTION_OWNER_BLOCKS_NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_owner_blocks_no_update
            BEFORE UPDATE ON clan_election_owner_blocks
            BEGIN SELECT RAISE(ABORT, 'clan election owner blocks are immutable'); END
            """;
    private static final String CLAN_ELECTION_OWNER_BLOCKS_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_owner_blocks_no_delete
            BEFORE DELETE ON clan_election_owner_blocks
            BEGIN SELECT RAISE(ABORT, 'clan election owner blocks are immutable'); END
            """;
    private static final String CLAN_ELECTION_CANDIDATES_INSERT_GUARD_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_candidates_insert_guard
            BEFORE INSERT ON clan_election_candidates
            WHEN NOT EXISTS (SELECT 1 FROM clan_elections e WHERE e.election_id = NEW.election_id AND e.phase = NEW.phase)
              OR (NEW.phase = 'LOCAL' AND EXISTS (SELECT 1 FROM clan_election_events ev WHERE ev.election_id = NEW.election_id AND ev.event_type = 'CREATED'))
              OR (NEW.phase = 'GLOBAL_TIE_BREAK' AND EXISTS (SELECT 1 FROM clan_election_events ev WHERE ev.election_id = NEW.election_id AND ev.event_type = 'GLOBAL_TIE_BREAK_STARTED'))
            BEGIN SELECT RAISE(ABORT, 'clan election candidate snapshot is sealed'); END
            """;
    private static final String CLAN_ELECTION_CANDIDATES_NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_candidates_no_update
            BEFORE UPDATE ON clan_election_candidates
            BEGIN SELECT RAISE(ABORT, 'clan election candidates are immutable'); END
            """;
    private static final String CLAN_ELECTION_CANDIDATES_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_candidates_no_delete
            BEFORE DELETE ON clan_election_candidates
            BEGIN SELECT RAISE(ABORT, 'clan election candidates are immutable'); END
            """;
    private static final String CLAN_ELECTION_VOTES_INSERT_GUARD_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_votes_insert_guard
            BEFORE INSERT ON clan_election_votes
            WHEN NOT EXISTS (SELECT 1 FROM clan_elections e WHERE e.election_id = NEW.election_id
                AND e.phase = NEW.phase AND julianday(e.closes_at) > julianday(NEW.voted_at))
            BEGIN SELECT RAISE(ABORT, 'clan election voting phase is closed or changed'); END
            """;
    private static final String CLAN_ELECTION_VOTES_NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_votes_no_update
            BEFORE UPDATE ON clan_election_votes
            BEGIN SELECT RAISE(ABORT, 'clan election votes are immutable'); END
            """;
    private static final String CLAN_ELECTION_VOTES_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_votes_no_delete
            BEFORE DELETE ON clan_election_votes
            BEGIN SELECT RAISE(ABORT, 'clan election votes are immutable'); END
            """;
    private static final String CLAN_ELECTION_EVENTS_NO_UPDATE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_events_no_update
            BEFORE UPDATE ON clan_election_events
            BEGIN SELECT RAISE(ABORT, 'clan election events are append-only'); END
            """;
    private static final String CLAN_ELECTION_EVENTS_NO_DELETE_TRIGGER_DDL = """
            CREATE TRIGGER clan_election_events_no_delete
            BEFORE DELETE ON clan_election_events
            BEGIN SELECT RAISE(ABORT, 'clan election events are append-only'); END
            """;

    private final Connection connection;
    private final SqliteTransactionControl transactionControl;
    private ConnectionState connectionState = ConnectionState.OPEN;
    private Throwable connectionFailure;

    private SqliteClanStore(
            Connection connection,
            SqliteTransactionControl transactionControl) {
        this.connection = connection;
        this.transactionControl = transactionControl;
    }

    public static SqliteClanStore open(Path databasePath) {
        return open(databasePath, SqliteTransactionControl.JDBC, SqliteMigrationHook.NONE);
    }

    static SqliteClanStore open(
            Path databasePath,
            SqliteTransactionControl transactionControl,
            SqliteMigrationHook migrationHook) {
        if (databasePath == null) {
            throw new NullPointerException("databasePath");
        }
        if (transactionControl == null || migrationHook == null) {
            throw new NullPointerException("transactionControl and migrationHook");
        }

        Path absolutePath = databasePath.toAbsolutePath().normalize();
        boolean existed = Files.exists(absolutePath);
        boolean createdByThisOpen = false;
        Connection connection = null;
        SqliteClanStore store = null;
        try {
            Path parent = absolutePath.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            if (!existed) {
                try {
                    Files.createFile(absolutePath);
                    createdByThisOpen = true;
                } catch (FileAlreadyExistsException exception) {
                    existed = true;
                }
            }
            if (existed && Files.size(absolutePath) == 0) {
                throw new StorageException("Existing SQLite database is empty: " + absolutePath);
            }

            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:" + absolutePath);
            store = new SqliteClanStore(connection, transactionControl);
            store.checkDatabaseIntegrity();
            store.configureConnection();
            store.migrate(existed, migrationHook);
            return store;
        } catch (ClassNotFoundException | SQLException | IOException exception) {
            closeAfterOpenFailure(connection, exception);
            throw new StorageException("Could not open SQLite clan store: " + absolutePath, exception);
        } catch (RuntimeException exception) {
            boolean closedCleanly = closeAfterOpenFailure(connection, exception);
            if (createdByThisOpen
                    && exception instanceof InitialMigrationException
                    && store != null
                    && store.connectionState == ConnectionState.OPEN
                    && closedCleanly) {
                deleteDatabaseCreatedByFailedMigration(absolutePath, exception);
            }
            throw exception;
        }
    }

    /**
     * Persists a deputy's withdrawal request. The requester is also the beneficiary; only a
     * separate authorization layer may approve or decline it. This method never moves money.
     */
    public synchronized ClanBankWithdrawalRequestResult createClanBankWithdrawalRequest(
            UUID requestId, String idempotencyKey, UUID clanId, UUID requesterId,
            BigDecimal amount, String reason, Instant createdAt, Instant expiresAt) {
        ensureOpen();
        if (requestId == null || idempotencyKey == null || idempotencyKey.isBlank() || clanId == null
                || requesterId == null || amount == null || amount.signum() <= 0 || reason == null
                || reason.isBlank() || reason.length() > 500 || createdAt == null || expiresAt == null
                || !expiresAt.equals(createdAt.plusSeconds(86_400))) throw new IllegalArgumentException("Bank withdrawal request must expire exactly 24 hours after creation");
        BigDecimal normalized = amount.stripTrailingZeros();
        if (normalized.scale() > 8) throw new IllegalArgumentException("Bank amount supports at most 8 decimal places");
        String amountText = normalized.toPlainString();
        return inWriteTransaction("Could not create clan bank withdrawal request", () -> {
            try (PreparedStatement existing = connection.prepareStatement("""
                    SELECT request_id, clan_id, requester_id, amount, reason, created_at, expires_at, status
                    FROM clan_bank_withdrawal_requests WHERE idempotency_key = ?
                    """)) {
                existing.setString(1, idempotencyKey);
                try (ResultSet row = existing.executeQuery()) {
                    if (row.next()) {
                        boolean same = row.getString("clan_id").equals(clanId.toString())
                                && row.getString("requester_id").equals(requesterId.toString())
                                && new BigDecimal(row.getString("amount")).compareTo(normalized) == 0
                                && row.getString("reason").equals(reason)
                                && row.getString("created_at").equals(createdAt.toString())
                                && row.getString("expires_at").equals(expiresAt.toString());
                        return new ClanBankWithdrawalRequestResult(same
                                ? ClanBankWithdrawalRequestStatus.DUPLICATE
                                : ClanBankWithdrawalRequestStatus.IDEMPOTENCY_CONFLICT,
                                same ? readBankWithdrawalRequest(UUID.fromString(row.getString("request_id"))).orElseThrow() : null);
                    }
                }
            }
            try (PreparedStatement clan = connection.prepareStatement("SELECT 1 FROM clans WHERE id = ?")) {
                clan.setString(1, clanId.toString());
                try (ResultSet row = clan.executeQuery()) {
                    if (!row.next()) return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.CLAN_NOT_FOUND, null);
                }
            }
            try (PreparedStatement role = connection.prepareStatement(
                    "SELECT role FROM clan_members WHERE clan_id = ? AND player_id = ?")) {
                role.setString(1, clanId.toString()); role.setString(2, requesterId.toString());
                try (ResultSet row = role.executeQuery()) {
                    if (!row.next() || !"DEPUTY".equals(row.getString(1)))
                        return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.NOT_AUTHORIZED, null);
                }
            }
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_bank_withdrawal_requests(request_id, idempotency_key, clan_id, requester_id,
                        beneficiary_id, amount, reason, status, created_at, expires_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?, ?)
                    """)) {
                insert.setString(1, requestId.toString()); insert.setString(2, idempotencyKey);
                insert.setString(3, clanId.toString()); insert.setString(4, requesterId.toString());
                insert.setString(5, requesterId.toString()); insert.setString(6, amountText); insert.setString(7, reason);
                insert.setString(8, createdAt.toString()); insert.setString(9, expiresAt.toString());
                insert.setString(10, createdAt.toString()); insert.executeUpdate();
            }
            insertClanBankWithdrawalRequestEvent(requestId, null, ClanBankWithdrawalRequestStatus.PENDING,
                    requesterId, "REQUEST_CREATED", createdAt);
            return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.CREATED,
                    readBankWithdrawalRequest(requestId).orElseThrow());
        });
    }

    /** Leader-only authorization must be checked by the application layer before calling this method. */
    public synchronized ClanBankWithdrawalRequestResult resolveClanBankWithdrawalRequest(
            UUID requestId, UUID actorId, ClanBankWithdrawalRequestStatus resolution, Instant now, String details) {
        ensureOpen();
        if (requestId == null || actorId == null || now == null
                || (resolution != ClanBankWithdrawalRequestStatus.APPROVED
                    && resolution != ClanBankWithdrawalRequestStatus.DECLINED
                    && resolution != ClanBankWithdrawalRequestStatus.EXPIRED)
                || details != null && details.length() > 500) throw new IllegalArgumentException("Invalid withdrawal request resolution");
        return inWriteTransaction("Could not resolve clan bank withdrawal request", () -> {
            ClanBankWithdrawalRequest current = readBankWithdrawalRequest(requestId).orElse(null);
            if (current == null) return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.NOT_FOUND, null);
            if (current.status() != ClanBankWithdrawalRequestStatus.PENDING)
                return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.ALREADY_RESOLVED, current);
            try (PreparedStatement role = connection.prepareStatement(
                    "SELECT role FROM clan_members WHERE clan_id = ? AND player_id = ?")) {
                role.setString(1, current.clanId().toString()); role.setString(2, actorId.toString());
                try (ResultSet row = role.executeQuery()) {
                    if (!row.next() || !"LEADER".equals(row.getString(1)))
                        return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.NOT_AUTHORIZED, current);
                }
            }
            ClanBankWithdrawalRequestStatus actual = resolution;
            if (now.compareTo(current.expiresAt()) >= 0) actual = ClanBankWithdrawalRequestStatus.EXPIRED;
            else if (resolution == ClanBankWithdrawalRequestStatus.EXPIRED)
                return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.NOT_EXPIRED, current);
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_bank_withdrawal_requests SET status = ?, updated_at = ?
                    WHERE request_id = ? AND status = 'PENDING'
                    """)) {
                update.setString(1, actual.name()); update.setString(2, now.toString()); update.setString(3, requestId.toString());
                if (update.executeUpdate() != 1) return new ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus.ALREADY_RESOLVED,
                        readBankWithdrawalRequest(requestId).orElse(null));
            }
            insertClanBankWithdrawalRequestEvent(requestId, ClanBankWithdrawalRequestStatus.PENDING, actual,
                    actorId, details, now);
            return new ClanBankWithdrawalRequestResult(actual, readBankWithdrawalRequest(requestId).orElseThrow());
        });
    }

    /** Expires every due pending request in one local transaction; this never moves bank funds. */
    public synchronized int expireDueClanBankWithdrawalRequests(Instant now, UUID systemActorId) {
        return expireDueClanBankWithdrawalRequestsDetailed(now, systemActorId).size();
    }

    public synchronized List<ClanBankWithdrawalRequest> expireDueClanBankWithdrawalRequestsDetailed(
            Instant now, UUID systemActorId) {
        ensureOpen();
        if (now == null || systemActorId == null) throw new IllegalArgumentException("now and systemActorId are required");
        return inWriteTransaction("Could not expire clan bank withdrawal requests", () -> {
            List<UUID> due = new ArrayList<>();
            try (PreparedStatement select = connection.prepareStatement("""
                    SELECT request_id FROM clan_bank_withdrawal_requests
                    WHERE status = 'PENDING' AND julianday(expires_at) <= julianday(?)
                    ORDER BY expires_at, request_id
                    """)) {
                select.setString(1, now.toString());
                try (ResultSet rows = select.executeQuery()) {
                    while (rows.next()) due.add(UUID.fromString(rows.getString(1)));
                }
            }
            List<ClanBankWithdrawalRequest> expired = new ArrayList<>();
            for (UUID requestId : due) {
                try (PreparedStatement update = connection.prepareStatement("""
                        UPDATE clan_bank_withdrawal_requests SET status = 'EXPIRED', updated_at = ?
                        WHERE request_id = ? AND status = 'PENDING' AND julianday(expires_at) <= julianday(?)
                        """)) {
                    update.setString(1, now.toString()); update.setString(2, requestId.toString());
                    update.setString(3, now.toString());
                    if (update.executeUpdate() == 1) {
                        insertClanBankWithdrawalRequestEvent(requestId, ClanBankWithdrawalRequestStatus.PENDING,
                                ClanBankWithdrawalRequestStatus.EXPIRED, systemActorId, "AUTOMATIC_EXPIRY", now);
                        expired.add(readBankWithdrawalRequest(requestId).orElseThrow());
                    }
                }
            }
            return List.copyOf(expired);
        });
    }

    public synchronized List<ClanBankWithdrawalRequest> findClanBankWithdrawalRequests(UUID clanId, boolean pendingOnly) {
        ensureOpen();
        if (clanId == null) throw new IllegalArgumentException("clanId is required");
        List<ClanBankWithdrawalRequest> requests = new ArrayList<>();
        String sql = "SELECT request_id FROM clan_bank_withdrawal_requests WHERE clan_id = ?"
                + (pendingOnly ? " AND status = 'PENDING'" : "") + " ORDER BY created_at, request_id";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, clanId.toString());
            try (ResultSet rows = statement.executeQuery()) {
                while (rows.next()) readBankWithdrawalRequest(UUID.fromString(rows.getString(1))).ifPresent(requests::add);
            }
            return List.copyOf(requests);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan bank withdrawal requests", exception);
        }
    }

    private Optional<ClanBankWithdrawalRequest> readBankWithdrawalRequest(UUID requestId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT request_id, clan_id, requester_id, beneficiary_id, amount, reason, status, created_at, expires_at, updated_at, payment_operation_id
                FROM clan_bank_withdrawal_requests WHERE request_id = ?
                """)) {
            statement.setString(1, requestId.toString());
            try (ResultSet row = statement.executeQuery()) {
                if (!row.next()) return Optional.empty();
                return Optional.of(new ClanBankWithdrawalRequest(UUID.fromString(row.getString("request_id")),
                        UUID.fromString(row.getString("clan_id")), UUID.fromString(row.getString("requester_id")),
                        UUID.fromString(row.getString("beneficiary_id")), new BigDecimal(row.getString("amount")),
                        row.getString("reason"), ClanBankWithdrawalRequestStatus.valueOf(row.getString("status")),
                        Instant.parse(row.getString("created_at")), Instant.parse(row.getString("expires_at")),
                        Instant.parse(row.getString("updated_at")), row.getString("payment_operation_id") == null
                                ? null : UUID.fromString(row.getString("payment_operation_id"))));
            }
        }
    }

    private void insertClanBankWithdrawalRequestEvent(UUID requestId, ClanBankWithdrawalRequestStatus from,
            ClanBankWithdrawalRequestStatus to, UUID actorId, String details, Instant occurredAt) throws SQLException {
        try (PreparedStatement event = connection.prepareStatement("""
                INSERT INTO clan_bank_withdrawal_request_events(request_id, from_status, to_status, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            event.setString(1, requestId.toString()); event.setString(2, from == null ? null : from.name());
            event.setString(3, to.name()); event.setString(4, actorId.toString()); event.setString(5, details);
            event.setString(6, occurredAt.toString()); event.executeUpdate();
        }
    }

    public enum ClanBankWithdrawalRequestStatus {
        CREATED, DUPLICATE, IDEMPOTENCY_CONFLICT, CLAN_NOT_FOUND, PENDING, APPROVED, DECLINED, EXPIRED,
        NOT_FOUND, ALREADY_RESOLVED, NOT_EXPIRED, NOT_AUTHORIZED
    }
    public record ClanBankWithdrawalRequest(UUID requestId, UUID clanId, UUID requesterId, UUID beneficiaryId,
            BigDecimal amount, String reason, ClanBankWithdrawalRequestStatus status,
            Instant createdAt, Instant expiresAt, Instant updatedAt, UUID paymentOperationId) { }
    public record ClanBankWithdrawalRequestResult(ClanBankWithdrawalRequestStatus status, ClanBankWithdrawalRequest request) { }

    /** Reads the local clan-bank balance without contacting the external economy provider. */
    public synchronized ClanStoragePurchaseResult purchaseClanStoragePage(UUID clanId, UUID actorId,
            int requestedPage, Instant now) {
        ensureOpen();
        if (clanId == null || actorId == null || now == null || requestedPage < 2 || requestedPage > 10)
            return new ClanStoragePurchaseResult(ClanStoragePurchaseStatus.INVALID_INPUT, requestedPage,
                    BigDecimal.ZERO, BigDecimal.ZERO, 0, null);
        return inWriteTransaction("Could not purchase clan storage page", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return storagePurchaseResult(ClanStoragePurchaseStatus.CLAN_NOT_FOUND, requestedPage);
            if (!"LEADER".equals(clanMemberRole(clanId, actorId)))
                return storagePurchaseResult(ClanStoragePurchaseStatus.LEADER_ONLY, requestedPage);
            int currentPageCount;
            try (PreparedStatement account = connection.prepareStatement(
                    "SELECT page_count FROM clan_storage_accounts WHERE clan_id = ?")) {
                account.setString(1, clanId.toString());
                try (ResultSet row = account.executeQuery()) {
                    if (!row.next()) return storagePurchaseResult(ClanStoragePurchaseStatus.STORAGE_NOT_INITIALIZED, requestedPage);
                    currentPageCount = row.getInt(1);
                }
            }
            long totalXp;
            try (PreparedStatement clan = connection.prepareStatement("SELECT total_xp FROM clans WHERE id = ?")) {
                clan.setString(1, clanId.toString());
                try (ResultSet row = clan.executeQuery()) {
                    if (!row.next()) return storagePurchaseResult(ClanStoragePurchaseStatus.CLAN_NOT_FOUND, requestedPage);
                    totalXp = row.getLong(1);
                }
            }
            int clanLevel = com.skyworldclans.clan.policy.ClanLevelPolicy.levelForXp(totalXp);
            String idempotencyKey = "storage-page-purchase:" + clanId + ":" + requestedPage;
            String reason = "STORAGE_PAGE_PURCHASE page=" + requestedPage;
            BigDecimal originalPrice = BigDecimal.valueOf(100_000L).multiply(BigDecimal.valueOf(2L).pow(requestedPage - 2));
            int discount = clanLevel >= 8 ? 10 : clanLevel >= 4 ? 5 : 0;
            BigDecimal chargedPrice = originalPrice.multiply(BigDecimal.valueOf(100 - discount)).movePointLeft(2);
            try (PreparedStatement existing = connection.prepareStatement("""
                    SELECT clan_id, actor_id, transaction_type, amount, reason
                    FROM clan_bank_transactions WHERE idempotency_key = ?
                    """)) {
                existing.setString(1, idempotencyKey);
                try (ResultSet row = existing.executeQuery()) {
                    if (row.next()) {
                        boolean sameClanAndType = clanId.toString().equals(row.getString("clan_id"))
                                && "ADJUSTMENT".equals(row.getString("transaction_type"));
                        if (!sameClanAndType) return storagePurchaseResult(ClanStoragePurchaseStatus.IDEMPOTENCY_CONFLICT, requestedPage);
                        ClanStoragePage purchased = readClanStoragePage(clanId, requestedPage).orElse(null);
                        if (purchased != null)
                            return new ClanStoragePurchaseResult(ClanStoragePurchaseStatus.DUPLICATE, requestedPage,
                                    purchased.originalPrice(), purchased.chargedPrice(), purchased.discountPercent(), clanBankBalance(clanId));
                        return storagePurchaseResult(ClanStoragePurchaseStatus.IDEMPOTENCY_CONFLICT, requestedPage);
                    }
                }
            }
            if (requestedPage <= currentPageCount) {
                if (exists("SELECT 1 FROM clan_storage_pages WHERE clan_id = ? AND page_number = ?",
                        clanId.toString(), Integer.toString(requestedPage)))
                    return storagePurchaseResult(ClanStoragePurchaseStatus.ALREADY_PURCHASED, requestedPage);
                return storagePurchaseResult(ClanStoragePurchaseStatus.STORAGE_CORRUPT, requestedPage);
            }
            if (currentPageCount >= 10) return storagePurchaseResult(ClanStoragePurchaseStatus.MAX_PAGES, requestedPage);
            if (requestedPage != currentPageCount + 1)
                return storagePurchaseResult(ClanStoragePurchaseStatus.INVALID_PAGE_SEQUENCE, requestedPage);
            BigDecimal balance;
            long bankRevision;
            try (PreparedStatement account = connection.prepareStatement(
                    "SELECT balance, revision FROM clan_bank_accounts WHERE clan_id = ?")) {
                account.setString(1, clanId.toString());
                try (ResultSet row = account.executeQuery()) {
                    if (!row.next()) return storagePurchaseResult(ClanStoragePurchaseStatus.BANK_NOT_INITIALIZED, requestedPage);
                    balance = new BigDecimal(row.getString("balance")); bankRevision = row.getLong("revision");
                }
            }
            BigDecimal reserved = BigDecimal.ZERO;
            try (PreparedStatement reservations = connection.prepareStatement("""
                    SELECT amount FROM clan_bank_reservations WHERE clan_id = ? AND state = 'RESERVED'
                    """)) {
                reservations.setString(1, clanId.toString());
                try (ResultSet rows = reservations.executeQuery()) {
                    while (rows.next()) reserved = reserved.add(new BigDecimal(rows.getString(1)));
                }
            }
            BigDecimal available = balance.subtract(reserved);
            if (available.compareTo(chargedPrice) < 0)
                return new ClanStoragePurchaseResult(ClanStoragePurchaseStatus.INSUFFICIENT_FUNDS,
                        requestedPage, originalPrice, chargedPrice, discount, balance);
            BigDecimal balanceAfter = balance.subtract(chargedPrice).stripTrailingZeros();
            try (PreparedStatement updateBank = connection.prepareStatement("""
                    UPDATE clan_bank_accounts SET balance = ?, revision = revision + 1, updated_at = ?
                    WHERE clan_id = ? AND revision = ? AND balance = ?
                    """)) {
                updateBank.setString(1, balanceAfter.toPlainString()); updateBank.setString(2, now.toString());
                updateBank.setString(3, clanId.toString()); updateBank.setLong(4, bankRevision);
                updateBank.setString(5, balance.toPlainString());
                if (updateBank.executeUpdate() != 1) throw new SQLException("Clan bank balance changed during page purchase");
            }
            try (PreparedStatement updateStorage = connection.prepareStatement("""
                    UPDATE clan_storage_accounts SET page_count = ?, revision = revision + 1, updated_at = ?
                    WHERE clan_id = ? AND page_count = ?
                    """)) {
                updateStorage.setInt(1, requestedPage); updateStorage.setString(2, now.toString());
                updateStorage.setString(3, clanId.toString()); updateStorage.setInt(4, currentPageCount);
                if (updateStorage.executeUpdate() != 1) throw new SQLException("Clan storage page count changed during purchase");
            }
            try (PreparedStatement page = connection.prepareStatement("""
                    INSERT INTO clan_storage_pages(clan_id, page_number, contents, revision, created_by, created_at,
                        original_price, charged_price, discount_percent)
                    VALUES (?, ?, X'', 0, ?, ?, ?, ?, ?)
                    """)) {
                page.setString(1, clanId.toString()); page.setInt(2, requestedPage); page.setString(3, actorId.toString());
                page.setString(4, now.toString()); page.setString(5, originalPrice.toPlainString());
                page.setString(6, chargedPrice.toPlainString()); page.setInt(7, discount); page.executeUpdate();
            }
            insertClanStorageContentEvent(clanId, requestedPage, actorId, "SNAPSHOT", 0, new byte[0], now);
            try (PreparedStatement ledger = connection.prepareStatement("""
                    INSERT INTO clan_bank_transactions(transaction_id, idempotency_key, clan_id, actor_id,
                        transaction_type, amount, balance_after, reason, approved_by, occurred_at)
                    VALUES (?, ?, ?, ?, 'ADJUSTMENT', ?, ?, ?, NULL, ?)
                    """)) {
                ledger.setString(1, UUID.randomUUID().toString()); ledger.setString(2, idempotencyKey);
                ledger.setString(3, clanId.toString()); ledger.setString(4, actorId.toString());
                ledger.setString(5, chargedPrice.negate().toPlainString()); ledger.setString(6, balanceAfter.toPlainString());
                ledger.setString(7, reason); ledger.setString(8, now.toString()); ledger.executeUpdate();
            }
            try (PreparedStatement event = connection.prepareStatement("""
                    INSERT INTO clan_storage_events(clan_id, actor_id, event_type, page_number,
                        original_price, charged_price, discount_percent, occurred_at)
                    VALUES (?, ?, 'PAGE_PURCHASED', ?, ?, ?, ?, ?)
                    """)) {
                event.setString(1, clanId.toString()); event.setString(2, actorId.toString());
                event.setInt(3, requestedPage); event.setString(4, originalPrice.toPlainString());
                event.setString(5, chargedPrice.toPlainString()); event.setInt(6, discount);
                event.setString(7, now.toString()); event.executeUpdate();
            }
            return new ClanStoragePurchaseResult(ClanStoragePurchaseStatus.PURCHASED, requestedPage,
                    originalPrice, chargedPrice, discount, balanceAfter);
        });
    }

    private ClanStoragePurchaseResult storagePurchaseResult(ClanStoragePurchaseStatus status, int pageNumber) {
        return new ClanStoragePurchaseResult(status, pageNumber, BigDecimal.ZERO, BigDecimal.ZERO, 0, null);
    }

    public synchronized ClanStorageContentSaveResult saveClanStoragePageContents(UUID clanId, int pageNumber,
            UUID actorId, long expectedRevision, byte[] contents, Instant now) {
        ensureOpen();
        if (clanId == null || actorId == null || now == null || contents == null
                || pageNumber < 1 || pageNumber > 10 || expectedRevision < 0)
            return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.INVALID_INPUT, expectedRevision);
        byte[] safeContents = contents.clone();
        return inWriteTransaction("Could not save clan storage page contents", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.CLAN_NOT_FOUND, expectedRevision);
            if (clanMemberRole(clanId, actorId) == null)
                return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.NOT_A_MEMBER, expectedRevision);
            if (exists("SELECT 1 FROM clan_storage_transfer_operations WHERE clan_id = ? AND page_number = ? AND state = 'PREPARED'",
                    clanId.toString(), Integer.toString(pageNumber)))
                return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.TRANSFER_PENDING, expectedRevision);
            long currentRevision;
            byte[] currentContents;
            try (PreparedStatement page = connection.prepareStatement("""
                    SELECT revision, contents FROM clan_storage_pages WHERE clan_id = ? AND page_number = ?
                    """)) {
                page.setString(1, clanId.toString()); page.setInt(2, pageNumber);
                try (ResultSet row = page.executeQuery()) {
                    if (!row.next()) return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.PAGE_NOT_FOUND, expectedRevision);
                    currentRevision = row.getLong("revision"); currentContents = row.getBytes("contents");
                }
            }
            if (currentRevision != expectedRevision)
                return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.REVISION_CONFLICT, currentRevision);
            if (java.util.Arrays.equals(currentContents, safeContents))
                return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.UNCHANGED, currentRevision);
            Instant lastEventAt;
            try (PreparedStatement latest = connection.prepareStatement("""
                    SELECT occurred_at FROM clan_storage_content_events
                    WHERE clan_id = ? AND page_number = ? ORDER BY revision DESC LIMIT 1
                    """)) {
                latest.setString(1, clanId.toString()); latest.setInt(2, pageNumber);
                try (ResultSet row = latest.executeQuery()) {
                    if (!row.next()) return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.HISTORY_MISSING, currentRevision);
                    lastEventAt = Instant.parse(row.getString(1));
                }
            }
            if (now.isBefore(lastEventAt))
                return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.TIMESTAMP_OUT_OF_ORDER, currentRevision);
            if (currentRevision == Long.MAX_VALUE)
                return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.REVISION_EXHAUSTED, currentRevision);
            long nextRevision = currentRevision + 1;
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_storage_pages SET contents = ?, revision = ?
                    WHERE clan_id = ? AND page_number = ? AND revision = ?
                    """)) {
                update.setBytes(1, safeContents); update.setLong(2, nextRevision);
                update.setString(3, clanId.toString()); update.setInt(4, pageNumber); update.setLong(5, currentRevision);
                if (update.executeUpdate() != 1)
                    return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.REVISION_CONFLICT, currentRevision);
            }
            insertClanStorageContentEvent(clanId, pageNumber, actorId, "CONTENT_SAVED", nextRevision, safeContents, now);
            return new ClanStorageContentSaveResult(ClanStorageContentSaveStatus.SAVED, nextRevision);
        });
    }

    private void insertClanStorageContentEvent(UUID clanId, int pageNumber, UUID actorId, String eventType,
            long revision, byte[] contents, Instant now) throws SQLException {
        try (PreparedStatement event = connection.prepareStatement("""
                INSERT INTO clan_storage_content_events(clan_id, page_number, actor_id, event_type,
                    revision, content_sha256, content_size, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """)) {
            event.setString(1, clanId.toString()); event.setInt(2, pageNumber); event.setString(3, actorId.toString());
            event.setString(4, eventType); event.setLong(5, revision); event.setString(6, sha256(contents));
            event.setLong(7, contents.length); event.setString(8, now.toString()); event.executeUpdate();
        }
    }

    public enum ClanStorageContentSaveStatus {
        SAVED, UNCHANGED, REVISION_CONFLICT, INVALID_INPUT, CLAN_NOT_FOUND, NOT_A_MEMBER, PAGE_NOT_FOUND,
        HISTORY_MISSING, TIMESTAMP_OUT_OF_ORDER, REVISION_EXHAUSTED, TRANSFER_PENDING
    }
    public record ClanStorageContentSaveResult(ClanStorageContentSaveStatus status, long currentRevision) { }

    /** Persists a two-resource transfer intent before the Paper adapter mutates player inventory. */
    public synchronized ClanStorageTransferResult prepareClanStorageTransfer(UUID operationId, UUID clanId,
            int pageNumber, UUID actorId, String movementType, String itemType, int amount,
            long expectedRevision, byte[] beforePlayerInventory, byte[] afterPlayerInventory,
            byte[] beforePageContents, byte[] afterPageContents, Instant now) {
        ensureOpen();
        if (operationId == null || clanId == null || actorId == null || now == null
                || pageNumber < 1 || pageNumber > 10 || expectedRevision < 0 || expectedRevision == Long.MAX_VALUE
                || amount < 1 || amount > 2304
                || movementType == null || !(movementType.equals("DEPOSIT") || movementType.equals("WITHDRAWAL"))
                || itemType == null || !itemType.matches("[a-z0-9_.-]+:[a-z0-9_./-]{1,120}")
                || !validStorageSnapshot(beforePlayerInventory) || !validStorageSnapshot(afterPlayerInventory)
                || !validStorageSnapshot(beforePageContents) || !validStorageSnapshot(afterPageContents))
            return new ClanStorageTransferResult(ClanStorageTransferStatus.INVALID_INPUT, null);
        byte[] beforePlayer = beforePlayerInventory.clone();
        byte[] afterPlayer = afterPlayerInventory.clone();
        byte[] beforePage = beforePageContents.clone();
        byte[] afterPage = afterPageContents.clone();
        String beforePlayerHash = sha256(beforePlayer), afterPlayerHash = sha256(afterPlayer);
        String beforePageHash = sha256(beforePage), afterPageHash = sha256(afterPage);
        if (beforePlayerHash.equals(afterPlayerHash) || beforePageHash.equals(afterPageHash))
            return new ClanStorageTransferResult(ClanStorageTransferStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not prepare clan storage escrow transfer", () -> {
            try (PreparedStatement existing = connection.prepareStatement("""
                    SELECT * FROM clan_storage_transfer_operations WHERE operation_id = ?
                    """)) {
                existing.setString(1, operationId.toString());
                try (ResultSet row = existing.executeQuery()) {
                    if (row.next()) {
                        boolean same = row.getString("clan_id").equals(clanId.toString())
                                && row.getInt("page_number") == pageNumber
                                && row.getString("actor_id").equals(actorId.toString())
                                && row.getString("movement_type").equals(movementType)
                                && row.getString("item_type").equals(itemType)
                                && row.getInt("amount") == amount
                                && row.getLong("expected_revision") == expectedRevision
                                && row.getString("before_player_sha256").equals(beforePlayerHash)
                                && row.getString("after_player_sha256").equals(afterPlayerHash)
                                && row.getString("before_page_sha256").equals(beforePageHash)
                                && row.getString("after_page_sha256").equals(afterPageHash);
                        return new ClanStorageTransferResult(same ? ClanStorageTransferStatus.DUPLICATE
                                : ClanStorageTransferStatus.IDEMPOTENCY_CONFLICT, readTransferOperation(row));
                    }
                }
            }
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanStorageTransferResult(ClanStorageTransferStatus.CLAN_NOT_FOUND, null);
            if (clanMemberRole(clanId, actorId) == null)
                return new ClanStorageTransferResult(ClanStorageTransferStatus.NOT_A_MEMBER, null);
            try (PreparedStatement page = connection.prepareStatement("""
                    SELECT contents, revision FROM clan_storage_pages WHERE clan_id = ? AND page_number = ?
                    """)) {
                page.setString(1, clanId.toString()); page.setInt(2, pageNumber);
                try (ResultSet row = page.executeQuery()) {
                    if (!row.next()) return new ClanStorageTransferResult(ClanStorageTransferStatus.PAGE_NOT_FOUND, null);
                    if (row.getLong("revision") != expectedRevision)
                        return new ClanStorageTransferResult(ClanStorageTransferStatus.REVISION_CONFLICT, null);
                    if (!java.util.Arrays.equals(row.getBytes("contents"), beforePage))
                        return new ClanStorageTransferResult(ClanStorageTransferStatus.PAGE_CONTENT_CONFLICT, null);
                }
            }
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_storage_transfer_operations(operation_id, clan_id, page_number, actor_id,
                        movement_type, item_type, amount, expected_revision, before_player_sha256,
                        after_player_sha256, before_page_sha256, after_page_sha256, before_player_inventory,
                        after_player_inventory, before_page_contents, after_page_contents, state, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PREPARED', ?, ?)
                    """)) {
                insert.setString(1, operationId.toString()); insert.setString(2, clanId.toString());
                insert.setInt(3, pageNumber); insert.setString(4, actorId.toString());
                insert.setString(5, movementType); insert.setString(6, itemType); insert.setInt(7, amount);
                insert.setLong(8, expectedRevision); insert.setString(9, beforePlayerHash);
                insert.setString(10, afterPlayerHash); insert.setString(11, beforePageHash);
                insert.setString(12, afterPageHash); insert.setBytes(13, beforePlayer);
                insert.setBytes(14, afterPlayer); insert.setBytes(15, beforePage); insert.setBytes(16, afterPage);
                insert.setString(17, now.toString()); insert.setString(18, now.toString());
                insert.executeUpdate();
            } catch (SQLException constraint) {
                if (isConstraintViolation(constraint))
                    return new ClanStorageTransferResult(ClanStorageTransferStatus.BUSY, null);
                throw constraint;
            }
            insertClanStorageTransferEvent(operationId, null, "PREPARED", actorId, "TRANSFER_PREPARED", now);
            return new ClanStorageTransferResult(ClanStorageTransferStatus.PREPARED,
                    findClanStorageTransfer(operationId).orElseThrow());
        });
    }

    /** Resolves a prepared escrow operation by comparing the live player inventory snapshot. */
    public synchronized ClanStorageTransferResult resolveClanStorageTransfer(UUID operationId,
            UUID actorId, byte[] observedPlayerInventory, Instant now) {
        ensureOpen();
        if (operationId == null || actorId == null || observedPlayerInventory == null || now == null
                || !validStorageSnapshot(observedPlayerInventory))
            return new ClanStorageTransferResult(ClanStorageTransferStatus.INVALID_INPUT, null);
        byte[] observed = observedPlayerInventory.clone();
        String observedHash = sha256(observed);
        return inWriteTransaction("Could not resolve clan storage escrow transfer", () -> {
            ClanStorageTransferOperation operation = findClanStorageTransfer(operationId).orElse(null);
            if (operation == null) return new ClanStorageTransferResult(ClanStorageTransferStatus.NOT_FOUND, null);
            if (!operation.actorId().equals(actorId))
                return new ClanStorageTransferResult(ClanStorageTransferStatus.NOT_A_MEMBER, operation);
            if (operation.state().equals("COMMITTED"))
                return new ClanStorageTransferResult(ClanStorageTransferStatus.DUPLICATE, operation);
            if (!operation.state().equals("PREPARED"))
                return new ClanStorageTransferResult(operation.state().equals("ABORTED")
                        ? ClanStorageTransferStatus.ABORTED : ClanStorageTransferStatus.MANUAL_REVIEW, operation);
            if (now.isBefore(operation.updatedAt()))
                return new ClanStorageTransferResult(ClanStorageTransferStatus.TIMESTAMP_OUT_OF_ORDER, operation);
            if (observedHash.equals(operation.beforePlayerSha256())) {
                transitionClanStorageTransfer(operationId, "ABORTED", actorId, "PLAYER_INVENTORY_UNCHANGED", now);
                return new ClanStorageTransferResult(ClanStorageTransferStatus.ABORTED,
                        findClanStorageTransfer(operationId).orElseThrow());
            }
            if (!observedHash.equals(operation.afterPlayerSha256())) {
                transitionClanStorageTransfer(operationId, "MANUAL_REVIEW", actorId,
                        "PLAYER_INVENTORY_MATCHES_NEITHER_SNAPSHOT", now);
                return new ClanStorageTransferResult(ClanStorageTransferStatus.MANUAL_REVIEW,
                        findClanStorageTransfer(operationId).orElseThrow());
            }
            Instant lastContentEvent;
            try (PreparedStatement latest = connection.prepareStatement("""
                    SELECT occurred_at FROM clan_storage_content_events
                    WHERE clan_id = ? AND page_number = ? ORDER BY revision DESC LIMIT 1
                    """)) {
                latest.setString(1, operation.clanId().toString()); latest.setInt(2, operation.pageNumber());
                try (ResultSet row = latest.executeQuery()) {
                    if (!row.next()) throw new StorageException("Clan storage content history is missing");
                    lastContentEvent = Instant.parse(row.getString(1));
                }
            }
            if (now.isBefore(lastContentEvent))
                return new ClanStorageTransferResult(ClanStorageTransferStatus.TIMESTAMP_OUT_OF_ORDER, operation);
            long nextRevision = operation.expectedRevision() + 1;
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_storage_pages SET contents = ?, revision = ?
                    WHERE clan_id = ? AND page_number = ? AND revision = ? AND contents = ?
                    """)) {
                update.setBytes(1, operation.afterPageContents()); update.setLong(2, nextRevision);
                update.setString(3, operation.clanId().toString()); update.setInt(4, operation.pageNumber());
                update.setLong(5, operation.expectedRevision()); update.setBytes(6, operation.beforePageContents());
                if (update.executeUpdate() != 1) {
                    transitionClanStorageTransfer(operationId, "MANUAL_REVIEW", actorId,
                            "PAGE_REVISION_OR_CONTENT_CONFLICT", now);
                    return new ClanStorageTransferResult(ClanStorageTransferStatus.MANUAL_REVIEW,
                            findClanStorageTransfer(operationId).orElseThrow());
                }
            }
            insertClanStorageContentEvent(operation.clanId(), operation.pageNumber(), actorId,
                    "CONTENT_SAVED", nextRevision, operation.afterPageContents(), now);
            try (PreparedStatement receipt = connection.prepareStatement("""
                    INSERT INTO clan_storage_committed_operations(operation_id, clan_id, page_number, actor_id,
                        movement_type, item_type, amount, expected_revision, result_revision, contents_sha256, occurred_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                receipt.setString(1, operationId.toString()); receipt.setString(2, operation.clanId().toString());
                receipt.setInt(3, operation.pageNumber()); receipt.setString(4, actorId.toString());
                receipt.setString(5, operation.movementType()); receipt.setString(6, operation.itemType());
                receipt.setInt(7, operation.amount()); receipt.setLong(8, operation.expectedRevision());
                receipt.setLong(9, nextRevision); receipt.setString(10, operation.afterPageSha256());
                receipt.setString(11, now.toString()); receipt.executeUpdate();
            }
            try (PreparedStatement movement = connection.prepareStatement("""
                    INSERT INTO clan_storage_item_movements(operation_id, clan_id, page_number, actor_id,
                        movement_type, item_type, amount, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                movement.setString(1, operationId.toString()); movement.setString(2, operation.clanId().toString());
                movement.setInt(3, operation.pageNumber()); movement.setString(4, actorId.toString());
                movement.setString(5, operation.movementType()); movement.setString(6, operation.itemType());
                movement.setInt(7, operation.amount()); movement.setString(8, now.toString()); movement.executeUpdate();
            }
            transitionClanStorageTransfer(operationId, "COMMITTED", actorId, "PLAYER_INVENTORY_MATCHES_AFTER_SNAPSHOT", now);
            return new ClanStorageTransferResult(ClanStorageTransferStatus.COMMITTED,
                    findClanStorageTransfer(operationId).orElseThrow());
        });
    }

    public synchronized List<ClanStorageTransferOperation> pendingClanStorageTransfers(UUID actorId) {
        ensureOpen();
        if (actorId == null) return List.of();
        List<ClanStorageTransferOperation> result = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT * FROM clan_storage_transfer_operations WHERE actor_id = ? AND state = 'PREPARED'
                ORDER BY created_at, operation_id
                """)) {
            statement.setString(1, actorId.toString());
            try (ResultSet rows = statement.executeQuery()) {
                while (rows.next()) result.add(readTransferOperation(rows));
            }
            return List.copyOf(result);
        } catch (SQLException exception) {
            throw storageFailure("Could not read pending clan storage transfers", exception);
        }
    }

    public synchronized List<ClanStorageTransferOperation> clanStorageTransfersRequiringReview(int limit) {
        ensureOpen();
        if (limit < 1 || limit > 500) throw new IllegalArgumentException("limit must be between 1 and 500");
        List<ClanStorageTransferOperation> result = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT * FROM clan_storage_transfer_operations WHERE state = 'MANUAL_REVIEW'
                ORDER BY updated_at, operation_id LIMIT ?
                """)) {
            statement.setInt(1, limit);
            try (ResultSet rows = statement.executeQuery()) {
                while (rows.next()) result.add(readTransferOperation(rows));
            }
            return List.copyOf(result);
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan storage transfers requiring review", exception);
        }
    }

    private Optional<ClanStorageTransferOperation> findClanStorageTransfer(UUID operationId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT * FROM clan_storage_transfer_operations WHERE operation_id = ?")) {
            statement.setString(1, operationId.toString());
            try (ResultSet row = statement.executeQuery()) {
                return row.next() ? Optional.of(readTransferOperation(row)) : Optional.empty();
            }
        }
    }

    private static ClanStorageTransferOperation readTransferOperation(ResultSet row) throws SQLException {
        return new ClanStorageTransferOperation(UUID.fromString(row.getString("operation_id")),
                UUID.fromString(row.getString("clan_id")), row.getInt("page_number"),
                UUID.fromString(row.getString("actor_id")), row.getString("movement_type"),
                row.getString("item_type"), row.getInt("amount"), row.getLong("expected_revision"),
                row.getString("before_player_sha256"), row.getString("after_player_sha256"),
                row.getString("before_page_sha256"), row.getString("after_page_sha256"),
                row.getBytes("before_player_inventory"), row.getBytes("after_player_inventory"),
                row.getBytes("before_page_contents"), row.getBytes("after_page_contents"),
                row.getString("state"), Instant.parse(row.getString("created_at")), Instant.parse(row.getString("updated_at")));
    }

    private void insertClanStorageTransferEvent(UUID operationId, String fromState, String toState,
            UUID actorId, String details, Instant now) throws SQLException {
        try (PreparedStatement event = connection.prepareStatement("""
                INSERT INTO clan_storage_transfer_events(operation_id, from_state, to_state, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            event.setString(1, operationId.toString()); event.setString(2, fromState); event.setString(3, toState);
            event.setString(4, actorId.toString()); event.setString(5, details); event.setString(6, now.toString());
            event.executeUpdate();
        }
    }

    private void transitionClanStorageTransfer(UUID operationId, String newState, UUID actorId,
            String details, Instant now) throws SQLException {
        String oldState;
        try (PreparedStatement select = connection.prepareStatement(
                "SELECT state FROM clan_storage_transfer_operations WHERE operation_id = ?")) {
            select.setString(1, operationId.toString());
            try (ResultSet row = select.executeQuery()) {
                if (!row.next()) throw new StorageException("Clan storage transfer operation disappeared");
                oldState = row.getString(1);
            }
        }
        try (PreparedStatement update = connection.prepareStatement("""
                UPDATE clan_storage_transfer_operations SET state = ?, updated_at = ?
                WHERE operation_id = ? AND state = 'PREPARED'
                """)) {
            update.setString(1, newState); update.setString(2, now.toString()); update.setString(3, operationId.toString());
            if (update.executeUpdate() != 1) throw new StorageException("Clan storage transfer state changed concurrently");
        }
        insertClanStorageTransferEvent(operationId, oldState, newState, actorId, details, now);
    }

    private static boolean validStorageSnapshot(byte[] snapshot) {
        return snapshot != null && snapshot.length <= 2 * 1024 * 1024;
    }

    public enum ClanStorageTransferStatus { PREPARED, DUPLICATE, IDEMPOTENCY_CONFLICT, INVALID_INPUT,
        CLAN_NOT_FOUND, NOT_A_MEMBER, PAGE_NOT_FOUND, REVISION_CONFLICT, PAGE_CONTENT_CONFLICT,
        BUSY, NOT_FOUND, ABORTED, COMMITTED, MANUAL_REVIEW, TIMESTAMP_OUT_OF_ORDER }
    public record ClanStorageTransferResult(ClanStorageTransferStatus status, ClanStorageTransferOperation operation) { }
    public record ClanStorageTransferOperation(UUID operationId, UUID clanId, int pageNumber, UUID actorId,
            String movementType, String itemType, int amount, long expectedRevision,
            String beforePlayerSha256, String afterPlayerSha256, String beforePageSha256, String afterPageSha256,
            byte[] beforePlayerInventory, byte[] afterPlayerInventory, byte[] beforePageContents,
            byte[] afterPageContents, String state, Instant createdAt, Instant updatedAt) {
        public ClanStorageTransferOperation {
            beforePlayerInventory = beforePlayerInventory.clone(); afterPlayerInventory = afterPlayerInventory.clone();
            beforePageContents = beforePageContents.clone(); afterPageContents = afterPageContents.clone();
        }
        @Override public byte[] beforePlayerInventory() { return beforePlayerInventory.clone(); }
        @Override public byte[] afterPlayerInventory() { return afterPlayerInventory.clone(); }
        @Override public byte[] beforePageContents() { return beforePageContents.clone(); }
        @Override public byte[] afterPageContents() { return afterPageContents.clone(); }
    }

    /**
     * Atomically commits a complete serialized Bukkit inventory snapshot and its item-movement
     * receipt. The page revision update, immutable operation receipt, content history and legacy
     * movement event share one SQLite transaction. Callers must mutate the player inventory only
     * after this method returns COMMITTED; on an ambiguous caller timeout, retry with the same
     * operation UUID and identical arguments.
     */
    public synchronized ClanStorageCommitResult commitClanStorageMovement(UUID operationId, UUID clanId,
            int pageNumber, UUID actorId, String movementType, String itemType, int amount,
            long expectedRevision, byte[] contents, Instant occurredAt) {
        ensureOpen();
        if (operationId == null || clanId == null || actorId == null || occurredAt == null || contents == null
                || pageNumber < 1 || pageNumber > 10 || amount < 1 || amount > 2304 || expectedRevision < 0
                || movementType == null || !(movementType.equals("DEPOSIT") || movementType.equals("WITHDRAWAL"))
                || itemType == null || !itemType.matches("[a-z0-9_.-]+:[a-z0-9_./-]{1,120}")
                || expectedRevision == Long.MAX_VALUE)
            return new ClanStorageCommitResult(ClanStorageCommitStatus.INVALID_INPUT, expectedRevision);
        byte[] safeContents = contents.clone();
        String digest = sha256(safeContents);
        return inWriteTransaction("Could not atomically commit clan storage movement", () -> {
            try (PreparedStatement existing = connection.prepareStatement("""
                    SELECT clan_id, page_number, actor_id, movement_type, item_type, amount,
                           expected_revision, result_revision, contents_sha256, occurred_at
                    FROM clan_storage_committed_operations WHERE operation_id = ?
                    """)) {
                existing.setString(1, operationId.toString());
                try (ResultSet row = existing.executeQuery()) {
                    if (row.next()) {
                        boolean same = row.getString("clan_id").equals(clanId.toString())
                                && row.getInt("page_number") == pageNumber
                                && row.getString("actor_id").equals(actorId.toString())
                                && row.getString("movement_type").equals(movementType)
                                && row.getString("item_type").equals(itemType)
                                && row.getInt("amount") == amount
                                && row.getLong("expected_revision") == expectedRevision
                                && row.getString("contents_sha256").equals(digest)
                                && row.getString("occurred_at").equals(occurredAt.toString());
                        return new ClanStorageCommitResult(same ? ClanStorageCommitStatus.DUPLICATE
                                : ClanStorageCommitStatus.IDEMPOTENCY_CONFLICT, row.getLong("result_revision"));
                    }
                }
            }
            // v18 legacy receipts do not include the serialized snapshot digest/revision identity;
            // never reinterpret one as a safely replayable v19 operation.
            if (exists("SELECT 1 FROM clan_storage_item_movements WHERE operation_id = ?", operationId.toString()))
                return new ClanStorageCommitResult(ClanStorageCommitStatus.IDEMPOTENCY_CONFLICT, expectedRevision);
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanStorageCommitResult(ClanStorageCommitStatus.CLAN_NOT_FOUND, expectedRevision);
            if (clanMemberRole(clanId, actorId) == null)
                return new ClanStorageCommitResult(ClanStorageCommitStatus.NOT_A_MEMBER, expectedRevision);
            if (exists("SELECT 1 FROM clan_storage_transfer_operations WHERE clan_id = ? AND page_number = ? AND state = 'PREPARED'",
                    clanId.toString(), Integer.toString(pageNumber)))
                return new ClanStorageCommitResult(ClanStorageCommitStatus.TRANSFER_PENDING, expectedRevision);
            long currentRevision;
            try (PreparedStatement page = connection.prepareStatement("""
                    SELECT revision FROM clan_storage_pages WHERE clan_id = ? AND page_number = ?
                    """)) {
                page.setString(1, clanId.toString()); page.setInt(2, pageNumber);
                try (ResultSet row = page.executeQuery()) {
                    if (!row.next()) return new ClanStorageCommitResult(ClanStorageCommitStatus.PAGE_NOT_FOUND, expectedRevision);
                    currentRevision = row.getLong(1);
                }
            }
            if (currentRevision != expectedRevision)
                return new ClanStorageCommitResult(ClanStorageCommitStatus.REVISION_CONFLICT, currentRevision);
            Instant lastEventAt;
            try (PreparedStatement latest = connection.prepareStatement("""
                    SELECT occurred_at FROM clan_storage_content_events
                    WHERE clan_id = ? AND page_number = ? ORDER BY revision DESC LIMIT 1
                    """)) {
                latest.setString(1, clanId.toString()); latest.setInt(2, pageNumber);
                try (ResultSet row = latest.executeQuery()) {
                    if (!row.next()) throw new StorageException("Clan storage content history is missing");
                    lastEventAt = Instant.parse(row.getString(1));
                }
            }
            if (occurredAt.isBefore(lastEventAt))
                return new ClanStorageCommitResult(ClanStorageCommitStatus.TIMESTAMP_OUT_OF_ORDER, currentRevision);
            long nextRevision = currentRevision + 1;
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_storage_pages SET contents = ?, revision = ?
                    WHERE clan_id = ? AND page_number = ? AND revision = ?
                    """)) {
                update.setBytes(1, safeContents); update.setLong(2, nextRevision);
                update.setString(3, clanId.toString()); update.setInt(4, pageNumber); update.setLong(5, currentRevision);
                if (update.executeUpdate() != 1)
                    return new ClanStorageCommitResult(ClanStorageCommitStatus.REVISION_CONFLICT, currentRevision);
            }
            insertClanStorageContentEvent(clanId, pageNumber, actorId, "CONTENT_SAVED", nextRevision, safeContents, occurredAt);
            try (PreparedStatement receipt = connection.prepareStatement("""
                    INSERT INTO clan_storage_committed_operations(operation_id, clan_id, page_number, actor_id,
                        movement_type, item_type, amount, expected_revision, result_revision, contents_sha256, occurred_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                receipt.setString(1, operationId.toString()); receipt.setString(2, clanId.toString());
                receipt.setInt(3, pageNumber); receipt.setString(4, actorId.toString());
                receipt.setString(5, movementType); receipt.setString(6, itemType); receipt.setInt(7, amount);
                receipt.setLong(8, expectedRevision); receipt.setLong(9, nextRevision);
                receipt.setString(10, digest); receipt.setString(11, occurredAt.toString());
                receipt.executeUpdate();
            }
            try (PreparedStatement movement = connection.prepareStatement("""
                    INSERT INTO clan_storage_item_movements(operation_id, clan_id, page_number, actor_id,
                        movement_type, item_type, amount, occurred_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                movement.setString(1, operationId.toString()); movement.setString(2, clanId.toString());
                movement.setInt(3, pageNumber); movement.setString(4, actorId.toString());
                movement.setString(5, movementType); movement.setString(6, itemType);
                movement.setInt(7, amount); movement.setString(8, occurredAt.toString());
                movement.executeUpdate();
            }
            return new ClanStorageCommitResult(ClanStorageCommitStatus.COMMITTED, nextRevision);
        });
    }

    public enum ClanStorageCommitStatus { COMMITTED, DUPLICATE, IDEMPOTENCY_CONFLICT, INVALID_INPUT,
        CLAN_NOT_FOUND, NOT_A_MEMBER, PAGE_NOT_FOUND, REVISION_CONFLICT, TIMESTAMP_OUT_OF_ORDER, TRANSFER_PENDING }
    public record ClanStorageCommitResult(ClanStorageCommitStatus status, long currentRevision) { }

    /** Records one committed item movement; operation IDs make retries harmless. */
    public synchronized ClanStorageMovementResult recordClanStorageMovement(UUID operationId, UUID clanId,
            int pageNumber, UUID actorId, String movementType, String itemType, int amount, Instant occurredAt) {
        ensureOpen();
        if (operationId == null || clanId == null || actorId == null || occurredAt == null
                || pageNumber < 1 || pageNumber > 10 || amount < 1 || amount > 2304
                || movementType == null || !(movementType.equals("DEPOSIT") || movementType.equals("WITHDRAWAL"))
                || itemType == null || !itemType.matches("[a-z0-9_.-]+:[a-z0-9_./-]{1,120}"))
            return new ClanStorageMovementResult(ClanStorageMovementStatus.INVALID_INPUT, -1L);
        return inWriteTransaction("Could not record clan storage item movement", () -> {
            try (PreparedStatement existing = connection.prepareStatement("""
                    SELECT event_id, clan_id, page_number, actor_id, movement_type, item_type, amount, occurred_at
                    FROM clan_storage_item_movements WHERE operation_id = ?
                    """)) {
                existing.setString(1, operationId.toString());
                try (ResultSet row = existing.executeQuery()) {
                    if (row.next()) {
                        boolean same = row.getString("clan_id").equals(clanId.toString())
                                && row.getInt("page_number") == pageNumber
                                && row.getString("actor_id").equals(actorId.toString())
                                && row.getString("movement_type").equals(movementType)
                                && row.getString("item_type").equals(itemType)
                                && row.getInt("amount") == amount
                                && row.getString("occurred_at").equals(occurredAt.toString());
                        return new ClanStorageMovementResult(same ? ClanStorageMovementStatus.DUPLICATE
                                : ClanStorageMovementStatus.IDEMPOTENCY_CONFLICT, row.getLong("event_id"));
                    }
                }
            }
            if (!exists("SELECT 1 FROM clan_storage_pages WHERE clan_id = ? AND page_number = ?",
                    clanId.toString(), Integer.toString(pageNumber)))
                return new ClanStorageMovementResult(ClanStorageMovementStatus.PAGE_NOT_FOUND, -1L);
            if (clanMemberRole(clanId, actorId) == null)
                return new ClanStorageMovementResult(ClanStorageMovementStatus.NOT_A_MEMBER, -1L);
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_storage_item_movements(operation_id, clan_id, page_number, actor_id,
                        movement_type, item_type, amount, occurred_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, Statement.RETURN_GENERATED_KEYS)) {
                insert.setString(1, operationId.toString()); insert.setString(2, clanId.toString());
                insert.setInt(3, pageNumber); insert.setString(4, actorId.toString());
                insert.setString(5, movementType); insert.setString(6, itemType);
                insert.setInt(7, amount); insert.setString(8, occurredAt.toString());
                insert.executeUpdate();
                try (ResultSet keys = insert.getGeneratedKeys()) {
                    return new ClanStorageMovementResult(ClanStorageMovementStatus.RECORDED,
                            keys.next() ? keys.getLong(1) : -1L);
                }
            }
        });
    }

    public enum ClanStorageMovementStatus { RECORDED, DUPLICATE, IDEMPOTENCY_CONFLICT, INVALID_INPUT, PAGE_NOT_FOUND, NOT_A_MEMBER }
    public record ClanStorageMovementResult(ClanStorageMovementStatus status, long eventId) { }
    public record ClanStorageItemMovement(long eventId, UUID operationId, UUID clanId, int pageNumber,
            UUID actorId, String movementType, String itemType, int amount, Instant occurredAt) { }

    /** Returns the most recent append-only item movements for a clan, newest first. */
    public synchronized List<ClanStorageItemMovement> findClanStorageMovements(UUID clanId, int limit) {
        ensureOpen();
        if (clanId == null) return List.of();
        if (limit < 1 || limit > 200) throw new IllegalArgumentException("limit must be between 1 and 200");
        List<ClanStorageItemMovement> result = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT event_id, operation_id, clan_id, page_number, actor_id, movement_type,
                       item_type, amount, occurred_at
                FROM clan_storage_item_movements WHERE clan_id = ?
                ORDER BY event_id DESC LIMIT ?
                """)) {
            statement.setString(1, clanId.toString());
            statement.setInt(2, limit);
            try (ResultSet row = statement.executeQuery()) {
                while (row.next()) {
                    result.add(new ClanStorageItemMovement(row.getLong("event_id"),
                            UUID.fromString(row.getString("operation_id")), clanId,
                            row.getInt("page_number"), UUID.fromString(row.getString("actor_id")),
                            row.getString("movement_type"), row.getString("item_type"),
                            row.getInt("amount"), Instant.parse(row.getString("occurred_at"))));
                }
            }
            return List.copyOf(result);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan storage item movements", exception);
        }
    }

    public synchronized Optional<ClanStoragePage> findClanStoragePage(UUID clanId, int pageNumber) {
        ensureOpen();
        if (clanId == null || pageNumber < 1 || pageNumber > 10) return Optional.empty();
        try { return readClanStoragePage(clanId, pageNumber); }
        catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan storage page", exception);
        }
    }

    private Optional<ClanStoragePage> readClanStoragePage(UUID clanId, int pageNumber) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT contents, revision, created_by, created_at, original_price, charged_price, discount_percent
                FROM clan_storage_pages WHERE clan_id = ? AND page_number = ?
                """)) {
            statement.setString(1, clanId.toString()); statement.setInt(2, pageNumber);
            try (ResultSet row = statement.executeQuery()) {
                if (!row.next()) return Optional.empty();
                return Optional.of(new ClanStoragePage(clanId, pageNumber, row.getBytes("contents"), row.getLong("revision"),
                        UUID.fromString(row.getString("created_by")), Instant.parse(row.getString("created_at")),
                        new BigDecimal(row.getString("original_price")), new BigDecimal(row.getString("charged_price")),
                        row.getInt("discount_percent")));
            }
        }
    }

    public synchronized int clanStoragePageCount(UUID clanId) {
        ensureOpen();
        if (clanId == null) return 0;
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT page_count FROM clan_storage_accounts WHERE clan_id = ?")) {
            statement.setString(1, clanId.toString());
            try (ResultSet row = statement.executeQuery()) { return row.next() ? row.getInt(1) : 0; }
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan storage page count", exception);
        }
    }

    public enum ClanStoragePurchaseStatus {
        PURCHASED, DUPLICATE, ALREADY_PURCHASED, INVALID_INPUT, CLAN_NOT_FOUND, LEADER_ONLY,
        STORAGE_NOT_INITIALIZED, BANK_NOT_INITIALIZED, INVALID_PAGE_SEQUENCE, MAX_PAGES,
        INSUFFICIENT_FUNDS, IDEMPOTENCY_CONFLICT, STORAGE_CORRUPT
    }
    public record ClanStoragePurchaseResult(ClanStoragePurchaseStatus status, int pageNumber,
            BigDecimal originalPrice, BigDecimal chargedPrice, int discountPercent, BigDecimal bankBalanceAfter) { }
    public record ClanStoragePage(UUID clanId, int pageNumber, byte[] contents, long revision, UUID createdBy,
            Instant createdAt, BigDecimal originalPrice, BigDecimal chargedPrice, int discountPercent) {
        public ClanStoragePage { contents = contents == null ? new byte[0] : contents.clone(); }
        @Override public byte[] contents() { return contents.clone(); }
    }

    // ---------------------------------------------------------------------
    // Clan wars and war fund escrow (schema v21)
    // ---------------------------------------------------------------------

    public enum ClanWarStatus { PENDING, ACTIVE, FINISHED, CANCELLED }

    public record ClanWar(UUID warId, UUID attackerClanId, UUID defenderClanId, ClanWarStatus state,
            UUID declaredBy, Instant declaredAt, UUID acceptedBy, Instant acceptedAt,
            Instant startedAt, Instant endedAt, UUID winnerClanId, String outcome,
            int targetKills, long durationSeconds, int attackerKills, int defenderKills, long revision) {
        public boolean involves(UUID clanId) {
            return attackerClanId.equals(clanId) || defenderClanId.equals(clanId);
        }
        public UUID opponentOf(UUID clanId) {
            if (attackerClanId.equals(clanId)) return defenderClanId;
            if (defenderClanId.equals(clanId)) return attackerClanId;
            throw new IllegalArgumentException("Clan is not part of this war");
        }
    }

    public record ClanWarFund(UUID warId, UUID clanId, BigDecimal amount) { }

    public enum ClanWarResultStatus {
        CREATED, UPDATED, ALREADY_FINISHED, INVALID_INPUT, CLAN_NOT_FOUND, SAME_CLAN,
        NOT_LEADER, OPEN_WAR_EXISTS, NOT_FOUND, STATE_CONFLICT, INSUFFICIENT_BANK_FUNDS,
        STORAGE_ERROR
    }

    public record ClanWarResult(ClanWarResultStatus status, ClanWar war) { }

    public synchronized ClanWarResult declareClanWar(UUID warId, UUID attackerClanId, UUID defenderClanId,
            UUID actorId, int targetKills, long durationSeconds, Instant now) {
        ensureOpen();
        if (warId == null || attackerClanId == null || defenderClanId == null || actorId == null || now == null
                || targetKills < 1 || targetKills > 1_000_000
                || durationSeconds < 60 || durationSeconds > 2_592_000)
            return new ClanWarResult(ClanWarResultStatus.INVALID_INPUT, null);
        if (attackerClanId.equals(defenderClanId))
            return new ClanWarResult(ClanWarResultStatus.SAME_CLAN, null);
        return inWriteTransaction("Could not declare clan war", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", attackerClanId.toString())
                    || !exists("SELECT 1 FROM clans WHERE id = ?", defenderClanId.toString()))
                return new ClanWarResult(ClanWarResultStatus.CLAN_NOT_FOUND, null);
            if (!"LEADER".equals(clanMemberRole(attackerClanId, actorId)))
                return new ClanWarResult(ClanWarResultStatus.NOT_LEADER, null);
            if (exists("""
                    SELECT 1 FROM clan_wars WHERE state IN ('PENDING', 'ACTIVE')
                    AND (attacker_clan_id = ? OR defender_clan_id = ? OR attacker_clan_id = ? OR defender_clan_id = ?)
                    """, attackerClanId.toString(), attackerClanId.toString(),
                    defenderClanId.toString(), defenderClanId.toString()))
                return new ClanWarResult(ClanWarResultStatus.OPEN_WAR_EXISTS, null);
            String pairKey = pairKey(attackerClanId, defenderClanId);
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_wars(war_id, attacker_clan_id, defender_clan_id, pair_key, state,
                        declared_by, declared_at, target_kills, duration_seconds, attacker_kills,
                        defender_kills, revision)
                    VALUES (?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, 0, 0, 0)
                    """)) {
                insert.setString(1, warId.toString()); insert.setString(2, attackerClanId.toString());
                insert.setString(3, defenderClanId.toString()); insert.setString(4, pairKey);
                insert.setString(5, actorId.toString()); insert.setString(6, now.toString());
                insert.setInt(7, targetKills); insert.setLong(8, durationSeconds);
                insert.executeUpdate();
            }
            appendClanWarEvent(warId, "DECLARED", actorId,
                    "attacker=" + attackerClanId + ";defender=" + defenderClanId
                            + ";targetKills=" + targetKills + ";duration=" + durationSeconds, now);
            return new ClanWarResult(ClanWarResultStatus.CREATED, readClanWar(warId).orElseThrow());
        });
    }

    public synchronized ClanWarResult acceptClanWar(UUID warId, UUID actorId, Instant now) {
        ensureOpen();
        if (warId == null || actorId == null || now == null)
            return new ClanWarResult(ClanWarResultStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not accept clan war", () -> {
            ClanWar war = readClanWar(warId).orElse(null);
            if (war == null) return new ClanWarResult(ClanWarResultStatus.NOT_FOUND, null);
            if (war.state() != ClanWarStatus.PENDING)
                return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, war);
            if (!"LEADER".equals(clanMemberRole(war.defenderClanId(), actorId)))
                return new ClanWarResult(ClanWarResultStatus.NOT_LEADER, war);
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_wars SET state = 'ACTIVE', accepted_by = ?, accepted_at = ?, started_at = ?,
                        revision = revision + 1
                    WHERE war_id = ? AND state = 'PENDING'
                    """)) {
                update.setString(1, actorId.toString()); update.setString(2, now.toString());
                update.setString(3, now.toString()); update.setString(4, warId.toString());
                if (update.executeUpdate() != 1)
                    return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, readClanWar(warId).orElse(null));
            }
            appendClanWarEvent(warId, "ACCEPTED", actorId, "started", now);
            return new ClanWarResult(ClanWarResultStatus.UPDATED, readClanWar(warId).orElseThrow());
        });
    }

    public synchronized ClanWarResult cancelClanWar(UUID warId, UUID actorId, Instant now) {
        ensureOpen();
        if (warId == null || actorId == null || now == null)
            return new ClanWarResult(ClanWarResultStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not cancel clan war", () -> {
            ClanWar war = readClanWar(warId).orElse(null);
            if (war == null) return new ClanWarResult(ClanWarResultStatus.NOT_FOUND, null);
            if (war.state() != ClanWarStatus.PENDING)
                return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, war);
            boolean attackerLeader = "LEADER".equals(clanMemberRole(war.attackerClanId(), actorId));
            boolean defenderLeader = "LEADER".equals(clanMemberRole(war.defenderClanId(), actorId));
            if (!attackerLeader && !defenderLeader)
                return new ClanWarResult(ClanWarResultStatus.NOT_LEADER, war);
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_wars SET state = 'CANCELLED', outcome = 'CANCELLED', ended_at = ?,
                        revision = revision + 1
                    WHERE war_id = ? AND state = 'PENDING'
                    """)) {
                update.setString(1, now.toString()); update.setString(2, warId.toString());
                if (update.executeUpdate() != 1)
                    return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, readClanWar(warId).orElse(null));
            }
            appendClanWarEvent(warId, "CANCELLED", actorId, "before acceptance", now);
            return new ClanWarResult(ClanWarResultStatus.UPDATED, readClanWar(warId).orElseThrow());
        });
    }

    /** Debits a leader's clan bank into the war fund in one SQLite transaction. */
    public synchronized ClanWarResult contributeToWarFund(UUID warId, UUID contributionId, UUID actorId,
            BigDecimal amount, Instant now) {
        ensureOpen();
        if (warId == null || contributionId == null || actorId == null || now == null || amount == null
                || amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 8)
            return new ClanWarResult(ClanWarResultStatus.INVALID_INPUT, null);
        BigDecimal normalized = amount.stripTrailingZeros();
        return inWriteTransaction("Could not contribute to clan war fund", () -> {
            ClanWar war = readClanWar(warId).orElse(null);
            if (war == null) return new ClanWarResult(ClanWarResultStatus.NOT_FOUND, null);
            if (war.state() != ClanWarStatus.ACTIVE)
                return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, war);
            UUID clanId;
            if ("LEADER".equals(clanMemberRole(war.attackerClanId(), actorId))) clanId = war.attackerClanId();
            else if ("LEADER".equals(clanMemberRole(war.defenderClanId(), actorId))) clanId = war.defenderClanId();
            else return new ClanWarResult(ClanWarResultStatus.NOT_LEADER, war);
            String key = "war-fund:" + contributionId;
            if (exists("SELECT 1 FROM clan_bank_transactions WHERE idempotency_key = ?", key)) {
                return new ClanWarResult(ClanWarResultStatus.UPDATED, war);
            }
            String balanceText = readBankBalance(clanId);
            BigDecimal balance = new BigDecimal(balanceText);
            BigDecimal reserved = new BigDecimal(readBankReservedBalance(clanId));
            BigDecimal available = balance.subtract(reserved);
            if (available.compareTo(normalized) < 0)
                return new ClanWarResult(ClanWarResultStatus.INSUFFICIENT_BANK_FUNDS, war);
            BigDecimal newBalance = balance.subtract(normalized).stripTrailingZeros();
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_bank_accounts SET balance = ?, revision = revision + 1, updated_at = ?
                    WHERE clan_id = ?
                    """)) {
                update.setString(1, newBalance.toPlainString()); update.setString(2, now.toString());
                update.setString(3, clanId.toString());
                if (update.executeUpdate() != 1) throw new StorageException("Clan bank account is missing");
            }
            insertWarBankLedger(contributionId, key, clanId, actorId, "WAR_FUND",
                    normalized.negate(), newBalance, "War fund contribution", now);
            BigDecimal currentFund = readWarFund(warId, clanId).orElse(BigDecimal.ZERO);
            BigDecimal updatedFund = currentFund.add(normalized).stripTrailingZeros();
            try (PreparedStatement fund = connection.prepareStatement("""
                    INSERT INTO clan_war_funds(war_id, clan_id, amount, updated_at) VALUES (?, ?, ?, ?)
                    ON CONFLICT(war_id, clan_id) DO UPDATE SET amount = excluded.amount, updated_at = excluded.updated_at
                    """)) {
                fund.setString(1, warId.toString()); fund.setString(2, clanId.toString());
                fund.setString(3, updatedFund.toPlainString()); fund.setString(4, now.toString());
                fund.executeUpdate();
            }
            appendClanWarEvent(warId, "FUND_CONTRIBUTED", actorId,
                    "clan=" + clanId + ";amount=" + normalized.toPlainString(), now);
            return new ClanWarResult(ClanWarResultStatus.UPDATED, war);
        });
    }

    /** Records one kill for the killer's side and finishes the war at the configured target. */
    public synchronized ClanWarResult recordClanWarKill(UUID warId, UUID killerClanId, UUID killerPlayerId,
            Instant now) {
        ensureOpen();
        if (warId == null || killerClanId == null || now == null)
            return new ClanWarResult(ClanWarResultStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not record clan war kill", () -> {
            ClanWar war = readClanWar(warId).orElse(null);
            if (war == null) return new ClanWarResult(ClanWarResultStatus.NOT_FOUND, null);
            if (war.state() != ClanWarStatus.ACTIVE)
                return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, war);
            boolean attacker = war.attackerClanId().equals(killerClanId);
            if (!attacker && !war.defenderClanId().equals(killerClanId))
                return new ClanWarResult(ClanWarResultStatus.INVALID_INPUT, war);
            int newKills;
            try (PreparedStatement update = connection.prepareStatement(attacker
                    ? "UPDATE clan_wars SET attacker_kills = attacker_kills + 1, revision = revision + 1 WHERE war_id = ? AND state = 'ACTIVE'"
                    : "UPDATE clan_wars SET defender_kills = defender_kills + 1, revision = revision + 1 WHERE war_id = ? AND state = 'ACTIVE'")) {
                update.setString(1, warId.toString());
                if (update.executeUpdate() != 1)
                    return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, readClanWar(warId).orElse(null));
            }
            ClanWar updated = readClanWar(warId).orElseThrow();
            newKills = attacker ? updated.attackerKills() : updated.defenderKills();
            appendClanWarEvent(warId, "KILL", killerPlayerId,
                    "killerClan=" + killerClanId + ";kills=" + newKills, now);
            if (newKills >= updated.targetKills()) {
                return settleClanWar(warId, killerClanId, "WIN", now);
            }
            return new ClanWarResult(ClanWarResultStatus.UPDATED, updated);
        });
    }

    /** Leader capitulation: the opposing clan wins the whole fund. */
    public synchronized ClanWarResult surrenderClanWar(UUID warId, UUID actorId, Instant now) {
        ensureOpen();
        if (warId == null || actorId == null || now == null)
            return new ClanWarResult(ClanWarResultStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not surrender clan war", () -> {
            ClanWar war = readClanWar(warId).orElse(null);
            if (war == null) return new ClanWarResult(ClanWarResultStatus.NOT_FOUND, null);
            if (war.state() == ClanWarStatus.FINISHED || war.state() == ClanWarStatus.CANCELLED)
                return new ClanWarResult(ClanWarResultStatus.ALREADY_FINISHED, war);
            if (war.state() != ClanWarStatus.ACTIVE)
                return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, war);
            UUID winner;
            if ("LEADER".equals(clanMemberRole(war.attackerClanId(), actorId))) winner = war.defenderClanId();
            else if ("LEADER".equals(clanMemberRole(war.defenderClanId(), actorId))) winner = war.attackerClanId();
            else return new ClanWarResult(ClanWarResultStatus.NOT_LEADER, war);
            appendClanWarEvent(warId, "SURRENDERED", actorId, "winner=" + winner, now);
            return settleClanWar(warId, winner, "WIN", now);
        });
    }

    /** Finishes all active wars whose duration expired; higher kills wins, equal kills is a draw. */
    public synchronized List<ClanWar> resolveDueClanWars(Instant now) {
        ensureOpen();
        if (now == null) throw new IllegalArgumentException("now is required");
        List<ClanWar> due = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_wars WHERE state = 'ACTIVE' ORDER BY started_at")) {
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) {
                    ClanWar war = readClanWarRow(rows);
                    Instant deadline = war.startedAt() == null ? null
                            : war.startedAt().plusSeconds(war.durationSeconds());
                    if (deadline != null && !now.isBefore(deadline)) due.add(war);
                }
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read due clan wars", exception);
        }
        List<ClanWar> resolved = new ArrayList<>();
        for (ClanWar war : due) {
            ClanWarResult result = inWriteTransaction("Could not settle expired clan war", () -> {
                ClanWar current = readClanWar(war.warId()).orElse(null);
                if (current == null || current.state() != ClanWarStatus.ACTIVE)
                    return new ClanWarResult(ClanWarResultStatus.STATE_CONFLICT, current);
                if (current.attackerKills() > current.defenderKills())
                    return settleClanWar(current.warId(), current.attackerClanId(), "WIN", now);
                if (current.defenderKills() > current.attackerKills())
                    return settleClanWar(current.warId(), current.defenderClanId(), "WIN", now);
                return settleClanWar(current.warId(), null, "DRAW", now);
            });
            if (result.war() != null) resolved.add(result.war());
        }
        return List.copyOf(resolved);
    }

    private ClanWarResult settleClanWar(UUID warId, UUID winnerClanId, String outcome, Instant now) throws SQLException {
        ClanWar war = readClanWar(warId).orElse(null);
        if (war == null) return new ClanWarResult(ClanWarResultStatus.NOT_FOUND, null);
        if (war.state() != ClanWarStatus.ACTIVE)
            return new ClanWarResult(ClanWarResultStatus.ALREADY_FINISHED, war);
        Map<UUID, BigDecimal> funds = new java.util.LinkedHashMap<>();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT clan_id, amount FROM clan_war_funds WHERE war_id = ?")) {
            query.setString(1, warId.toString());
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) funds.put(UUID.fromString(rows.getString(1)),
                        new BigDecimal(rows.getString(2)));
            }
        }
        if ("WIN".equals(outcome)) {
            if (winnerClanId == null) throw new StorageException("War winner is required for a win");
            BigDecimal total = funds.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add);
            if (total.signum() > 0) {
                creditWarBank(winnerClanId, total, "war-prize:" + warId,
                        "War prize for " + warId, now);
            }
            appendClanWarEvent(warId, "FINISHED", null, "winner=" + winnerClanId
                    + ";prize=" + total.toPlainString(), now);
        } else if ("DRAW".equals(outcome)) {
            for (Map.Entry<UUID, BigDecimal> entry : funds.entrySet()) {
                if (entry.getValue().signum() > 0) {
                    creditWarBank(entry.getKey(), entry.getValue(),
                            "war-refund:" + warId + ":" + entry.getKey(),
                            "War fund refund for " + warId, now);
                }
            }
            appendClanWarEvent(warId, "FINISHED", null, "draw;refunded", now);
        } else {
            throw new IllegalArgumentException("Unsupported war outcome " + outcome);
        }
        try (PreparedStatement update = connection.prepareStatement("""
                UPDATE clan_wars SET state = 'FINISHED', winner_clan_id = ?, outcome = ?, ended_at = ?,
                    revision = revision + 1
                WHERE war_id = ? AND state = 'ACTIVE'
                """)) {
            update.setString(1, winnerClanId == null ? null : winnerClanId.toString());
            update.setString(2, outcome); update.setString(3, now.toString()); update.setString(4, warId.toString());
            if (update.executeUpdate() != 1) throw new StorageException("Clan war state changed concurrently");
        }
        return new ClanWarResult(ClanWarResultStatus.UPDATED, readClanWar(warId).orElseThrow());
    }

    private void creditWarBank(UUID clanId, BigDecimal amount, String idempotencyKey,
            String reason, Instant now) throws SQLException {
        if (exists("SELECT 1 FROM clan_bank_transactions WHERE idempotency_key = ?", idempotencyKey)) return;
        BigDecimal balance = new BigDecimal(readBankBalance(clanId));
        BigDecimal updated = balance.add(amount).stripTrailingZeros();
        try (PreparedStatement update = connection.prepareStatement("""
                INSERT INTO clan_bank_accounts(clan_id, balance, revision, updated_at) VALUES (?, ?, 1, ?)
                ON CONFLICT(clan_id) DO UPDATE SET balance = excluded.balance,
                    revision = clan_bank_accounts.revision + 1, updated_at = excluded.updated_at
                """)) {
            update.setString(1, clanId.toString()); update.setString(2, updated.toPlainString());
            update.setString(3, now.toString()); update.executeUpdate();
        }
        // War payouts are performed by the server, not by a player; the ledger still requires
        // a non-null actor, so the reserved all-zero UUID marks a system-initiated movement.
        insertWarBankLedger(UUID.randomUUID(), idempotencyKey, clanId, SYSTEM_ACTOR_ID, "WAR_PRIZE",
                amount, updated, reason, now);
    }

    private void insertWarBankLedger(UUID transactionId, String idempotencyKey, UUID clanId, UUID actorId,
            String type, BigDecimal signedAmount, BigDecimal balanceAfter, String reason, Instant now)
            throws SQLException {
        try (PreparedStatement ledger = connection.prepareStatement("""
                INSERT INTO clan_bank_transactions(transaction_id, idempotency_key, clan_id, actor_id,
                    transaction_type, amount, balance_after, reason, approved_by, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)
                """)) {
            ledger.setString(1, transactionId.toString()); ledger.setString(2, idempotencyKey);
            ledger.setString(3, clanId.toString());
            ledger.setString(4, (actorId == null ? SYSTEM_ACTOR_ID : actorId).toString());
            ledger.setString(5, type); ledger.setString(6, signedAmount.stripTrailingZeros().toPlainString());
            ledger.setString(7, balanceAfter.stripTrailingZeros().toPlainString());
            ledger.setString(8, reason); ledger.setString(9, now.toString());
            ledger.executeUpdate();
        }
    }

    private Optional<BigDecimal> readWarFund(UUID warId, UUID clanId) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT amount FROM clan_war_funds WHERE war_id = ? AND clan_id = ?")) {
            query.setString(1, warId.toString()); query.setString(2, clanId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(new BigDecimal(row.getString(1))) : Optional.empty();
            }
        }
    }

    /** Returns the total escrowed war fund held for one clan. */
    public synchronized BigDecimal clanWarFundAmount(UUID clanId) {
        ensureOpen();
        if (clanId == null) return BigDecimal.ZERO;
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT amount FROM clan_war_funds WHERE clan_id = ?")) {
            query.setString(1, clanId.toString());
            BigDecimal total = BigDecimal.ZERO;
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) total = total.add(new BigDecimal(rows.getString(1)));
            }
            return total.stripTrailingZeros();
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan war fund", exception);
        }
    }

    public synchronized Optional<ClanWar> findClanWar(UUID warId) {
        ensureOpen();
        if (warId == null) return Optional.empty();
        try { return readClanWar(warId); }
        catch (SQLException exception) { throw storageFailure("Could not read clan war", exception); }
    }

    /** Number of settled wars won by a clan; used for the approved war-win achievements. */
    public synchronized int countClanWarWins(UUID clanId) {
        ensureOpen();
        if (clanId == null) return 0;
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT COUNT(*) FROM clan_wars WHERE state = 'FINISHED' AND winner_clan_id = ?")) {
            query.setString(1, clanId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? row.getInt(1) : 0;
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not count clan war wins", exception);
        }
    }

    public synchronized int countActiveClanWars() {
        ensureOpen();
        try (Statement statement = connection.createStatement();
             ResultSet row = statement.executeQuery(
                     "SELECT COUNT(*) FROM clan_wars WHERE state IN ('PENDING', 'ACTIVE')")) {
            return row.next() ? row.getInt(1) : 0;
        } catch (SQLException exception) {
            throw storageFailure("Could not count active clan wars", exception);
        }
    }

    public synchronized int countStorageTransfersForReview() {
        ensureOpen();
        try (Statement statement = connection.createStatement();
             ResultSet row = statement.executeQuery(
                     "SELECT COUNT(*) FROM clan_storage_transfer_operations WHERE state = 'MANUAL_REVIEW'")) {
            return row.next() ? row.getInt(1) : 0;
        } catch (SQLException exception) {
            throw storageFailure("Could not count storage transfers for review", exception);
        }
    }

    public synchronized Optional<ClanWar> findOpenClanWar(UUID clanId) {
        ensureOpen();
        if (clanId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_wars WHERE state IN ('PENDING', 'ACTIVE')
                AND (attacker_clan_id = ? OR defender_clan_id = ?) ORDER BY declared_at LIMIT 1
                """)) {
            query.setString(1, clanId.toString()); query.setString(2, clanId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readClanWarRow(row)) : Optional.empty();
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read open clan war", exception);
        }
    }

    public synchronized List<ClanWar> findClanWars(UUID clanId, int limit) {
        ensureOpen();
        if (clanId == null) return List.of();
        if (limit < 1 || limit > 200) throw new IllegalArgumentException("limit must be between 1 and 200");
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_wars WHERE attacker_clan_id = ? OR defender_clan_id = ?
                ORDER BY declared_at DESC LIMIT ?
                """)) {
            query.setString(1, clanId.toString()); query.setString(2, clanId.toString());
            query.setInt(3, limit);
            List<ClanWar> wars = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) wars.add(readClanWarRow(rows));
            }
            return List.copyOf(wars);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan wars", exception);
        }
    }

    public synchronized List<ClanWar> listOpenClanWars(int limit) {
        ensureOpen();
        if (limit < 1 || limit > 200) throw new IllegalArgumentException("limit must be between 1 and 200");
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_wars WHERE state IN ('PENDING', 'ACTIVE')
                ORDER BY declared_at LIMIT ?
                """)) {
            query.setInt(1, limit);
            List<ClanWar> wars = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) wars.add(readClanWarRow(rows));
            }
            return List.copyOf(wars);
        } catch (SQLException exception) {
            throw storageFailure("Could not list open clan wars", exception);
        }
    }

    private Optional<ClanWar> readClanWar(UUID warId) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM clan_wars WHERE war_id = ?")) {
            query.setString(1, warId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readClanWarRow(row)) : Optional.empty();
            }
        }
    }

    private static ClanWar readClanWarRow(ResultSet row) throws SQLException {
        String acceptedBy = row.getString("accepted_by");
        String acceptedAt = row.getString("accepted_at");
        String startedAt = row.getString("started_at");
        String endedAt = row.getString("ended_at");
        String winner = row.getString("winner_clan_id");
        return new ClanWar(UUID.fromString(row.getString("war_id")),
                UUID.fromString(row.getString("attacker_clan_id")),
                UUID.fromString(row.getString("defender_clan_id")),
                ClanWarStatus.valueOf(row.getString("state")),
                UUID.fromString(row.getString("declared_by")), Instant.parse(row.getString("declared_at")),
                acceptedBy == null ? null : UUID.fromString(acceptedBy),
                acceptedAt == null ? null : Instant.parse(acceptedAt),
                startedAt == null ? null : Instant.parse(startedAt),
                endedAt == null ? null : Instant.parse(endedAt),
                winner == null ? null : UUID.fromString(winner),
                row.getString("outcome"), row.getInt("target_kills"), row.getLong("duration_seconds"),
                row.getInt("attacker_kills"), row.getInt("defender_kills"), row.getLong("revision"));
    }

    private void appendClanWarEvent(UUID warId, String eventType, UUID actorId, String details, Instant now)
            throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_war_events(war_id, event_type, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, warId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setString(4, details); insert.setString(5, now.toString());
            insert.executeUpdate();
        }
    }

    private static String pairKey(UUID first, UUID second) {
        String left = first.toString();
        String right = second.toString();
        return left.compareTo(right) <= 0 ? left + ":" + right : right + ":" + left;
    }

    // ---------------------------------------------------------------------
    // Clan chat mutes, warnings and warning cases (schema v22)
    // ---------------------------------------------------------------------

    public record ClanChatMute(UUID clanId, UUID playerId, UUID mutedBy, Instant mutedAt,
            Instant expiresAt, String reason) {
        public boolean isExpired(Instant now) { return expiresAt != null && !now.isBefore(expiresAt); }
    }

    public record ClanWarning(UUID warningId, UUID clanId, UUID playerId, UUID issuedBy,
            Instant issuedAt, String reason, UUID removedBy, Instant removedAt) {
        public boolean active() { return removedAt == null; }
    }

    public enum ClanWarningCaseStatus { OPEN, ESCALATED_TO_LEADER }

    public record ClanWarningCase(UUID caseId, UUID clanId, UUID playerId, Instant createdAt,
            Instant deadlineAt, ClanWarningCaseStatus status, Instant escalatedAt,
            List<UUID> warningIds) { }

    public enum ModerationStatus {
        APPLIED, CLEARED, NOT_FOUND, INVALID_INPUT, CLAN_NOT_FOUND, NOT_A_MEMBER,
        CASE_EXISTS, NO_ACTIVE_WARNING, DUPLICATE
    }

    public synchronized ModerationStatus setClanChatMute(UUID clanId, UUID playerId, UUID actorId,
            Instant expiresAt, String reason, Instant now) {
        ensureOpen();
        if (clanId == null || playerId == null || actorId == null || now == null
                || reason == null || reason.isBlank() || reason.length() > 200)
            return ModerationStatus.INVALID_INPUT;
        // A null expiry is the leader's approved indefinite mute; any other expiry must be future.
        if (expiresAt != null && !expiresAt.isAfter(now)) return ModerationStatus.INVALID_INPUT;
        return inWriteTransaction("Could not mute clan chat member", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return ModerationStatus.CLAN_NOT_FOUND;
            if (clanMemberRole(clanId, playerId) == null) return ModerationStatus.NOT_A_MEMBER;
            try (PreparedStatement upsert = connection.prepareStatement("""
                    INSERT INTO clan_chat_mutes(clan_id, player_id, muted_by, muted_at, expires_at, reason)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(clan_id, player_id) DO UPDATE SET muted_by = excluded.muted_by,
                        muted_at = excluded.muted_at, expires_at = excluded.expires_at,
                        reason = excluded.reason
                    """)) {
                upsert.setString(1, clanId.toString()); upsert.setString(2, playerId.toString());
                upsert.setString(3, actorId.toString()); upsert.setString(4, now.toString());
                upsert.setString(5, expiresAt == null ? null : expiresAt.toString()); upsert.setString(6, reason);
                upsert.executeUpdate();
            }
            appendMuteEvent(clanId, playerId, actorId, "MUTED", expiresAt, reason, now);
            return ModerationStatus.APPLIED;
        });
    }

    public synchronized ModerationStatus clearClanChatMute(UUID clanId, UUID playerId, UUID actorId,
            String eventType, String reason, Instant now) {
        ensureOpen();
        if (clanId == null || playerId == null || actorId == null || now == null)
            return ModerationStatus.INVALID_INPUT;
        return inWriteTransaction("Could not clear clan chat mute", () -> {
            try (PreparedStatement delete = connection.prepareStatement(
                    "DELETE FROM clan_chat_mutes WHERE clan_id = ? AND player_id = ?")) {
                delete.setString(1, clanId.toString()); delete.setString(2, playerId.toString());
                if (delete.executeUpdate() != 1) return ModerationStatus.NOT_FOUND;
            }
            appendMuteEvent(clanId, playerId, actorId, eventType, null, reason, now);
            return ModerationStatus.CLEARED;
        });
    }

    /** Removes all mutes and active warnings for a player who left or was kicked. */
    public synchronized void clearModerationOnDeparture(UUID clanId, UUID playerId, UUID actorId, Instant now) {
        ensureOpen();
        if (clanId == null || playerId == null || now == null) return;
        inWriteTransaction("Could not clear clan moderation on departure", () -> {
            try (PreparedStatement mute = connection.prepareStatement(
                    "DELETE FROM clan_chat_mutes WHERE clan_id = ? AND player_id = ?")) {
                mute.setString(1, clanId.toString()); mute.setString(2, playerId.toString());
                if (mute.executeUpdate() > 0) {
                    appendMuteEvent(clanId, playerId, actorId == null ? SYSTEM_ACTOR_ID : actorId,
                            "CLEARED_ON_LEAVE", null, "membership ended", now);
                }
            }
            return null;
        });
    }

    public synchronized Optional<ClanChatMute> findClanChatMute(UUID clanId, UUID playerId) {
        ensureOpen();
        if (clanId == null || playerId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT clan_id, player_id, muted_by, muted_at, expires_at, reason
                FROM clan_chat_mutes WHERE clan_id = ? AND player_id = ?
                """)) {
            query.setString(1, clanId.toString()); query.setString(2, playerId.toString());
            try (ResultSet row = query.executeQuery()) {
                if (!row.next()) return Optional.empty();
                String expires = row.getString("expires_at");
                return Optional.of(new ClanChatMute(UUID.fromString(row.getString("clan_id")), playerId,
                        UUID.fromString(row.getString("muted_by")), Instant.parse(row.getString("muted_at")),
                        expires == null ? null : Instant.parse(expires), row.getString("reason")));
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan chat mute", exception);
        }
    }

    public synchronized List<ClanChatMute> listClanChatMutes(UUID clanId) {
        ensureOpen();
        if (clanId == null) return List.of();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT clan_id, player_id, muted_by, muted_at, expires_at, reason
                FROM clan_chat_mutes WHERE clan_id = ? ORDER BY muted_at
                """)) {
            query.setString(1, clanId.toString());
            List<ClanChatMute> mutes = new ArrayList<>();
            try (ResultSet row = query.executeQuery()) {
                while (row.next()) {
                    String expires = row.getString("expires_at");
                    mutes.add(new ClanChatMute(clanId, UUID.fromString(row.getString("player_id")),
                            UUID.fromString(row.getString("muted_by")), Instant.parse(row.getString("muted_at")),
                            expires == null ? null : Instant.parse(expires), row.getString("reason")));
                }
            }
            return List.copyOf(mutes);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan chat mutes", exception);
        }
    }

    private void appendMuteEvent(UUID clanId, UUID playerId, UUID actorId, String eventType,
            Instant expiresAt, String reason, Instant now) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_chat_mute_events(clan_id, player_id, actor_id, event_type,
                    expires_at, reason, occurred_at) VALUES (?, ?, ?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, clanId.toString()); insert.setString(2, playerId.toString());
            insert.setString(3, actorId.toString()); insert.setString(4, eventType);
            insert.setString(5, expiresAt == null ? null : expiresAt.toString());
            insert.setString(6, reason); insert.setString(7, now.toString());
            insert.executeUpdate();
        }
    }

    public synchronized ModerationStatus issueClanWarning(UUID warningId, UUID clanId, UUID playerId,
            UUID actorId, String reason, Instant now) {
        ensureOpen();
        if (warningId == null || clanId == null || playerId == null || actorId == null || now == null
                || reason == null || reason.isBlank() || reason.length() > 200)
            return ModerationStatus.INVALID_INPUT;
        return inWriteTransaction("Could not issue clan warning", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return ModerationStatus.CLAN_NOT_FOUND;
            if (clanMemberRole(clanId, playerId) == null) return ModerationStatus.NOT_A_MEMBER;
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_warnings(warning_id, clan_id, player_id, issued_by, issued_at, reason)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """)) {
                insert.setString(1, warningId.toString()); insert.setString(2, clanId.toString());
                insert.setString(3, playerId.toString()); insert.setString(4, actorId.toString());
                insert.setString(5, now.toString()); insert.setString(6, reason);
                insert.executeUpdate();
            }
            return ModerationStatus.APPLIED;
        });
    }

    public synchronized List<ClanWarning> listClanWarnings(UUID clanId, UUID playerId, boolean activeOnly) {
        ensureOpen();
        if (clanId == null) return List.of();
        StringBuilder sql = new StringBuilder("""
                SELECT warning_id, clan_id, player_id, issued_by, issued_at, reason, removed_by, removed_at
                FROM clan_warnings WHERE clan_id = ?
                """);
        if (playerId != null) sql.append(" AND player_id = ?");
        if (activeOnly) sql.append(" AND removed_at IS NULL");
        sql.append(" ORDER BY issued_at DESC");
        try (PreparedStatement query = connection.prepareStatement(sql.toString())) {
            query.setString(1, clanId.toString());
            if (playerId != null) query.setString(2, playerId.toString());
            List<ClanWarning> warnings = new ArrayList<>();
            try (ResultSet row = query.executeQuery()) {
                while (row.next()) {
                    String removedBy = row.getString("removed_by");
                    String removedAt = row.getString("removed_at");
                    warnings.add(new ClanWarning(UUID.fromString(row.getString("warning_id")), clanId,
                            UUID.fromString(row.getString("player_id")),
                            UUID.fromString(row.getString("issued_by")),
                            Instant.parse(row.getString("issued_at")), row.getString("reason"),
                            removedBy == null ? null : UUID.fromString(removedBy),
                            removedAt == null ? null : Instant.parse(removedAt)));
                }
            }
            return List.copyOf(warnings);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan warnings", exception);
        }
    }

    /** Removes the newest active warning for a player; an existing case is left untouched. */
    public synchronized ModerationStatus removeLatestClanWarning(UUID clanId, UUID playerId,
            UUID actorId, Instant now) {
        ensureOpen();
        if (clanId == null || playerId == null || actorId == null || now == null)
            return ModerationStatus.INVALID_INPUT;
        return inWriteTransaction("Could not remove clan warning", () -> {
            String warningId;
            try (PreparedStatement query = connection.prepareStatement("""
                    SELECT warning_id FROM clan_warnings
                    WHERE clan_id = ? AND player_id = ? AND removed_at IS NULL
                    ORDER BY issued_at DESC LIMIT 1
                    """)) {
                query.setString(1, clanId.toString()); query.setString(2, playerId.toString());
                try (ResultSet row = query.executeQuery()) {
                    if (!row.next()) return ModerationStatus.NO_ACTIVE_WARNING;
                    warningId = row.getString(1);
                }
            }
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_warnings SET removed_by = ?, removed_at = ?
                    WHERE warning_id = ? AND removed_at IS NULL
                    """)) {
                update.setString(1, actorId.toString()); update.setString(2, now.toString());
                update.setString(3, warningId);
                if (update.executeUpdate() != 1) return ModerationStatus.NOT_FOUND;
            }
            return ModerationStatus.CLEARED;
        });
    }

    /**
     * Creates the deputy case once three warnings are active inside the 12-hour window that
     * starts at the earliest of those warnings. Nothing is ever auto-punished.
     */
    public synchronized Optional<UUID> openWarningCaseIfEligible(UUID clanId, UUID playerId, Instant now) {
        ensureOpen();
        if (clanId == null || playerId == null || now == null) return Optional.empty();
        return inWriteTransaction("Could not open clan warning case", () -> {
            if (exists("SELECT 1 FROM clan_warning_cases WHERE clan_id = ? AND player_id = ?",
                    clanId.toString(), playerId.toString())) return Optional.empty();
            Instant windowStart = now.minusSeconds(12L * 60 * 60);
            List<UUID> inside = new ArrayList<>();
            try (PreparedStatement query = connection.prepareStatement("""
                    SELECT warning_id, issued_at FROM clan_warnings
                    WHERE clan_id = ? AND player_id = ? AND removed_at IS NULL
                    ORDER BY issued_at
                    """)) {
                query.setString(1, clanId.toString()); query.setString(2, playerId.toString());
                List<Instant> times = new ArrayList<>();
                try (ResultSet row = query.executeQuery()) {
                    while (row.next()) {
                        UUID id = UUID.fromString(row.getString("warning_id"));
                        Instant at = Instant.parse(row.getString("issued_at"));
                        if (!at.isBefore(windowStart)) { inside.add(id); times.add(at); }
                    }
                }
                if (inside.size() < 3) return Optional.empty();
                // The window is measured from the first warning of the qualifying trio.
                Instant first = times.get(times.size() - 3);
                if (now.isAfter(first.plusSeconds(12L * 60 * 60))) return Optional.empty();
                UUID caseId = UUID.randomUUID();
                try (PreparedStatement insert = connection.prepareStatement("""
                        INSERT INTO clan_warning_cases(case_id, clan_id, player_id, created_at,
                            deadline_at, status, warning_ids) VALUES (?, ?, ?, ?, ?, 'OPEN', ?)
                        """)) {
                    insert.setString(1, caseId.toString()); insert.setString(2, clanId.toString());
                    insert.setString(3, playerId.toString()); insert.setString(4, now.toString());
                    insert.setString(5, now.plusSeconds(24L * 60 * 60).toString());
                    insert.setString(6, inside.stream().map(UUID::toString)
                            .collect(java.util.stream.Collectors.joining(",")));
                    insert.executeUpdate();
                }
                appendCaseEvent(caseId, "CREATED", null, "warnings=" + inside.size(), now);
                return Optional.of(caseId);
            }
        });
    }

    /** Moves overdue open cases to the leader. No sanction is applied automatically. */
    public synchronized List<UUID> escalateDueWarningCases(Instant now) {
        ensureOpen();
        if (now == null) throw new IllegalArgumentException("now is required");
        return inWriteTransaction("Could not escalate clan warning cases", () -> {
            List<UUID> escalated = new ArrayList<>();
            List<UUID> due = new ArrayList<>();
            try (PreparedStatement query = connection.prepareStatement("""
                    SELECT case_id FROM clan_warning_cases WHERE status = 'OPEN' AND julianday(deadline_at) <= julianday(?)
                    """)) {
                query.setString(1, now.toString());
                try (ResultSet row = query.executeQuery()) {
                    while (row.next()) due.add(UUID.fromString(row.getString(1)));
                }
            }
            for (UUID caseId : due) {
                try (PreparedStatement update = connection.prepareStatement("""
                        UPDATE clan_warning_cases SET status = 'ESCALATED_TO_LEADER', escalated_at = ?
                        WHERE case_id = ? AND status = 'OPEN'
                        """)) {
                    update.setString(1, now.toString()); update.setString(2, caseId.toString());
                    if (update.executeUpdate() == 1) {
                        appendCaseEvent(caseId, "ESCALATED", null, "24h without decision", now);
                        escalated.add(caseId);
                    }
                }
            }
            return List.copyOf(escalated);
        });
    }

    public synchronized List<ClanWarningCase> listWarningCases(UUID clanId) {
        ensureOpen();
        if (clanId == null) return List.of();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT case_id, clan_id, player_id, created_at, deadline_at, status, escalated_at, warning_ids
                FROM clan_warning_cases WHERE clan_id = ? ORDER BY created_at DESC
                """)) {
            query.setString(1, clanId.toString());
            List<ClanWarningCase> cases = new ArrayList<>();
            try (ResultSet row = query.executeQuery()) {
                while (row.next()) {
                    String escalated = row.getString("escalated_at");
                    String ids = row.getString("warning_ids");
                    List<UUID> warningIds = ids == null || ids.isBlank() ? List.of()
                            : java.util.Arrays.stream(ids.split(",")).map(UUID::fromString).toList();
                    cases.add(new ClanWarningCase(UUID.fromString(row.getString("case_id")), clanId,
                            UUID.fromString(row.getString("player_id")),
                            Instant.parse(row.getString("created_at")), Instant.parse(row.getString("deadline_at")),
                            ClanWarningCaseStatus.valueOf(row.getString("status")),
                            escalated == null ? null : Instant.parse(escalated), warningIds));
                }
            }
            return List.copyOf(cases);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan warning cases", exception);
        }
    }

    private void appendCaseEvent(UUID caseId, String eventType, UUID actorId, String details, Instant now)
            throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_warning_case_events(case_id, event_type, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, caseId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setString(4, details); insert.setString(5, now.toString());
            insert.executeUpdate();
        }
    }

    // ---------------------------------------------------------------------
    // Clan rewards: personal payouts and bank-funded rewards (schema v23)
    // ---------------------------------------------------------------------

    public record ClanRewardOperation(UUID operationId, UUID clanId, UUID issuerId, UUID recipientId,
            String source, BigDecimal amount, String state, String reason, UUID approvedBy,
            Instant createdAt, Instant updatedAt) { }

    public enum ClanRewardState {
        PREPARED, DEBIT_CALLING, DEBIT_CONFIRMED, CREDIT_CALLING, COMPLETED,
        FAILED_NO_EFFECT, MANUAL_REVIEW
    }

    public enum ClanRewardPrepareStatus { CREATED, DUPLICATE, IDEMPOTENCY_CONFLICT, INVALID_INPUT, STORAGE_ERROR }

    public record ClanRewardPrepareResult(ClanRewardPrepareStatus status, ClanRewardOperation operation) { }

    /** Creates a durable reward intent; no money has moved yet. */
    public synchronized ClanRewardPrepareResult prepareClanReward(UUID operationId, String idempotencyKey,
            UUID clanId, UUID issuerId, UUID recipientId, String source, BigDecimal amount,
            String reason, Instant now) {
        ensureOpen();
        if (operationId == null || idempotencyKey == null || idempotencyKey.isBlank() || clanId == null
                || issuerId == null || recipientId == null || now == null || amount == null
                || amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 8
                || amount.stripTrailingZeros().toPlainString().length() > 40
                || source == null || !(source.equals("PERSONAL") || source.equals("BANK")))
            return new ClanRewardPrepareResult(ClanRewardPrepareStatus.INVALID_INPUT, null);
        BigDecimal normalized = amount.stripTrailingZeros();
        return inWriteTransaction("Could not prepare clan reward", () -> {
            try (PreparedStatement existing = connection.prepareStatement(
                    "SELECT * FROM clan_reward_operations WHERE idempotency_key = ?")) {
                existing.setString(1, idempotencyKey);
                try (ResultSet row = existing.executeQuery()) {
                    if (row.next()) {
                        ClanRewardOperation stored = readRewardOperation(row);
                        boolean same = stored.clanId().equals(clanId)
                                && stored.issuerId().equals(issuerId)
                                && stored.recipientId().equals(recipientId)
                                && stored.source().equals(source)
                                && stored.amount().compareTo(normalized) == 0;
                        return new ClanRewardPrepareResult(same ? ClanRewardPrepareStatus.DUPLICATE
                                : ClanRewardPrepareStatus.IDEMPOTENCY_CONFLICT, stored);
                    }
                }
            }
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanRewardPrepareResult(ClanRewardPrepareStatus.INVALID_INPUT, null);
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_reward_operations(operation_id, idempotency_key, clan_id, issuer_id,
                        recipient_id, source, amount, state, reason, approved_by, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'PREPARED', ?, NULL, ?, ?)
                    """)) {
                insert.setString(1, operationId.toString()); insert.setString(2, idempotencyKey);
                insert.setString(3, clanId.toString()); insert.setString(4, issuerId.toString());
                insert.setString(5, recipientId.toString()); insert.setString(6, source);
                insert.setString(7, normalized.toPlainString()); insert.setString(8, reason);
                insert.setString(9, now.toString()); insert.setString(10, now.toString());
                insert.executeUpdate();
            }
            appendRewardEvent(operationId, null, "PREPARED", issuerId, source, now);
            return new ClanRewardPrepareResult(ClanRewardPrepareStatus.CREATED,
                    readRewardOperation(operationId).orElseThrow());
        });
    }

    /**
     * Advances one reward operation. Only forward edges are permitted, and every terminal state is
     * final. Money is debited from the clan bank in the same transaction when a BANK reward moves
     * past DEBIT_CONFIRMED, so an unconfirmed external debit is never charged twice.
     */
    public synchronized ClanRewardPrepareResult transitionClanReward(UUID operationId, ClanRewardState expected,
            ClanRewardState target, UUID actorId, String details, Instant now) {
        ensureOpen();
        if (operationId == null || expected == null || target == null || now == null)
            return new ClanRewardPrepareResult(ClanRewardPrepareStatus.INVALID_INPUT, null);
        if (!allowedRewardTransition(expected, target))
            return new ClanRewardPrepareResult(ClanRewardPrepareStatus.INVALID_INPUT,
                    findClanReward(operationId).orElse(null));
        return inWriteTransaction("Could not advance clan reward", () -> {
            ClanRewardOperation operation = readRewardOperation(operationId).orElse(null);
            if (operation == null) return new ClanRewardPrepareResult(
                    ClanRewardPrepareStatus.INVALID_INPUT, null);
            if (!operation.state().equals(expected.name()))
                return new ClanRewardPrepareResult(ClanRewardPrepareStatus.IDEMPOTENCY_CONFLICT, operation);
            if (operation.state().equals("COMPLETED") || operation.state().equals("FAILED_NO_EFFECT")
                    || operation.state().equals("MANUAL_REVIEW"))
                return new ClanRewardPrepareResult(ClanRewardPrepareStatus.IDEMPOTENCY_CONFLICT, operation);
            if (target == ClanRewardState.DEBIT_CONFIRMED && operation.source().equals("BANK")) {
                String key = "reward-bank-debit:" + operationId;
                if (!exists("SELECT 1 FROM clan_bank_transactions WHERE idempotency_key = ?", key)) {
                    BigDecimal balance = new BigDecimal(readBankBalance(operation.clanId()));
                    BigDecimal reserved = new BigDecimal(readBankReservedBalance(operation.clanId()));
                    if (balance.subtract(reserved).compareTo(operation.amount()) < 0)
                        return new ClanRewardPrepareResult(ClanRewardPrepareStatus.STORAGE_ERROR, operation);
                    BigDecimal updated = balance.subtract(operation.amount()).stripTrailingZeros();
                    try (PreparedStatement account = connection.prepareStatement("""
                            UPDATE clan_bank_accounts SET balance = ?, revision = revision + 1, updated_at = ?
                            WHERE clan_id = ?
                            """)) {
                        account.setString(1, updated.toPlainString()); account.setString(2, now.toString());
                        account.setString(3, operation.clanId().toString());
                        if (account.executeUpdate() != 1)
                            throw new StorageException("Clan bank account is missing");
                    }
                    insertWarBankLedger(UUID.randomUUID(), key, operation.clanId(), operation.issuerId(),
                            "REWARD", operation.amount().negate(), updated,
                            "Bank reward for " + operation.recipientId(), now);
                }
            }
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_reward_operations SET state = ?, updated_at = ?
                    WHERE operation_id = ? AND state = ?
                    """)) {
                update.setString(1, target.name()); update.setString(2, now.toString());
                update.setString(3, operationId.toString()); update.setString(4, expected.name());
                if (update.executeUpdate() != 1)
                    return new ClanRewardPrepareResult(ClanRewardPrepareStatus.IDEMPOTENCY_CONFLICT,
                            readRewardOperation(operationId).orElse(null));
            }
            appendRewardEvent(operationId, expected.name(), target.name(), actorId, details, now);
            return new ClanRewardPrepareResult(ClanRewardPrepareStatus.CREATED,
                    readRewardOperation(operationId).orElseThrow());
        });
    }

    private static boolean allowedRewardTransition(ClanRewardState from, ClanRewardState to) {
        return switch (from) {
            case PREPARED -> to == ClanRewardState.DEBIT_CALLING || to == ClanRewardState.FAILED_NO_EFFECT
                    || to == ClanRewardState.MANUAL_REVIEW;
            case DEBIT_CALLING -> to == ClanRewardState.DEBIT_CONFIRMED
                    || to == ClanRewardState.FAILED_NO_EFFECT || to == ClanRewardState.MANUAL_REVIEW;
            case DEBIT_CONFIRMED -> to == ClanRewardState.CREDIT_CALLING || to == ClanRewardState.MANUAL_REVIEW;
            case CREDIT_CALLING -> to == ClanRewardState.COMPLETED || to == ClanRewardState.MANUAL_REVIEW
                    || to == ClanRewardState.FAILED_NO_EFFECT;
            case COMPLETED, FAILED_NO_EFFECT, MANUAL_REVIEW -> false;
        };
    }

    public synchronized Optional<ClanRewardOperation> findClanReward(UUID operationId) {
        ensureOpen();
        if (operationId == null) return Optional.empty();
        try { return readRewardOperation(operationId); }
        catch (SQLException exception) { throw storageFailure("Could not read clan reward", exception); }
    }

    public synchronized List<ClanRewardOperation> findClanRewards(UUID clanId, int limit) {
        ensureOpen();
        if (clanId == null) return List.of();
        if (limit < 1 || limit > 200) throw new IllegalArgumentException("limit must be between 1 and 200");
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_reward_operations WHERE clan_id = ?
                ORDER BY created_at DESC, operation_id LIMIT ?
                """)) {
            query.setString(1, clanId.toString()); query.setInt(2, limit);
            List<ClanRewardOperation> rewards = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) rewards.add(readRewardOperation(rows));
            }
            return List.copyOf(rewards);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan rewards", exception);
        }
    }

    /** Counts successful ordinary bank rewards issued by one deputy during the UTC day of {@code now}. */
    public synchronized int countDeputyOrdinaryRewardsToday(UUID clanId, UUID deputyId, Instant now) {
        ensureOpen();
        if (clanId == null || deputyId == null || now == null) return 0;
        Instant dayStart = now.atZone(java.time.ZoneOffset.UTC).toLocalDate().atStartOfDay()
                .toInstant(java.time.ZoneOffset.UTC);
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT COUNT(*) FROM clan_reward_operations
                WHERE clan_id = ? AND issuer_id = ? AND source = 'BANK'
                  AND state IN ('CREDIT_CALLING', 'COMPLETED') AND julianday(created_at) >= julianday(?)
                """)) {
            query.setString(1, clanId.toString()); query.setString(2, deputyId.toString());
            query.setString(3, dayStart.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? row.getInt(1) : 0;
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not count deputy rewards", exception);
        }
    }

    /**
     * Weights an interrupted reward operation. An ambiguous external debit or credit is never
     * replayed: it is frozen for manual review with full context preserved.
     */
    public synchronized List<ClanRewardOperation> recoverClanRewardsAfterRestart(Instant now) {
        ensureOpen();
        if (now == null) throw new IllegalArgumentException("now is required");
        List<ClanRewardOperation> pending = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_reward_operations
                WHERE state NOT IN ('COMPLETED', 'FAILED_NO_EFFECT', 'MANUAL_REVIEW')
                ORDER BY created_at
                """)) {
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) pending.add(readRewardOperation(rows));
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read pending clan rewards", exception);
        }
        List<ClanRewardOperation> recovered = new ArrayList<>();
        for (ClanRewardOperation operation : pending) {
            ClanRewardState from = ClanRewardState.valueOf(operation.state());
            ClanRewardState target = switch (from) {
                // The provider call may or may not have happened: never retry, freeze it.
                case DEBIT_CALLING, CREDIT_CALLING -> ClanRewardState.MANUAL_REVIEW;
                // Nothing external happened yet, so this is a safe no-effect terminal state.
                case PREPARED, DEBIT_CONFIRMED -> ClanRewardState.MANUAL_REVIEW;
                default -> null;
            };
            if (target == null) continue;
            var result = transitionClanReward(operation.operationId(), from, target, SYSTEM_ACTOR_ID,
                    "RECOVERED_AFTER_RESTART", now);
            if (result.operation() != null) recovered.add(result.operation());
        }
        return List.copyOf(recovered);
    }

    private Optional<ClanRewardOperation> readRewardOperation(UUID operationId) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_reward_operations WHERE operation_id = ?")) {
            query.setString(1, operationId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readRewardOperation(row)) : Optional.empty();
            }
        }
    }

    private static ClanRewardOperation readRewardOperation(ResultSet row) throws SQLException {
        String approvedBy = row.getString("approved_by");
        return new ClanRewardOperation(UUID.fromString(row.getString("operation_id")),
                UUID.fromString(row.getString("clan_id")), UUID.fromString(row.getString("issuer_id")),
                UUID.fromString(row.getString("recipient_id")), row.getString("source"),
                new BigDecimal(row.getString("amount")), row.getString("state"), row.getString("reason"),
                approvedBy == null ? null : UUID.fromString(approvedBy),
                Instant.parse(row.getString("created_at")), Instant.parse(row.getString("updated_at")));
    }

    private void appendRewardEvent(UUID operationId, String fromState, String toState, UUID actorId,
            String details, Instant now) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_reward_events(operation_id, from_state, to_state, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, operationId.toString()); insert.setString(2, fromState);
            insert.setString(3, toState);
            insert.setString(4, actorId == null ? null : actorId.toString());
            insert.setString(5, details); insert.setString(6, now.toString());
            insert.executeUpdate();
        }
    }

    // ---------------------------------------------------------------------
    // Large reward requests and the approved weekly quota (schema v25)
    // ---------------------------------------------------------------------

    public record ClanRewardRequest(UUID requestId, UUID clanId, UUID deputyId, UUID recipientId,
            BigDecimal amount, String reason, String status, Instant createdAt, Instant expiresAt,
            UUID decidedBy, Instant decidedAt, UUID operationId) { }

    public enum ClanRewardRequestStatus { CREATED, DUPLICATE, INVALID_INPUT, CLAN_NOT_FOUND, NOT_A_MEMBER,
        PENDING, APPROVED, DECLINED, EXPIRED, NOT_FOUND, QUOTA_EXHAUSTED, ALREADY_RESOLVED, STORAGE_ERROR }

    public record ClanRewardRequestResult(ClanRewardRequestStatus status, ClanRewardRequest request) { }

    public synchronized ClanRewardRequestResult createRewardRequest(UUID requestId, UUID clanId, UUID deputyId,
            UUID recipientId, BigDecimal amount, String reason, Instant now) {
        ensureOpen();
        if (requestId == null || clanId == null || deputyId == null || recipientId == null || now == null
                || amount == null || amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 8
                || reason == null || reason.isBlank() || reason.trim().length() > 500)
            return new ClanRewardRequestResult(ClanRewardRequestStatus.INVALID_INPUT, null);
        BigDecimal normalized = amount.stripTrailingZeros();
        return inWriteTransaction("Could not create clan reward request", () -> {
            if (!"DEPUTY".equals(clanMemberRole(clanId, deputyId)))
                return new ClanRewardRequestResult(ClanRewardRequestStatus.NOT_A_MEMBER, null);
            if (clanMemberRole(clanId, recipientId) == null)
                return new ClanRewardRequestResult(ClanRewardRequestStatus.NOT_A_MEMBER, null);
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_reward_requests(request_id, clan_id, deputy_id, recipient_id, amount,
                        reason, status, created_at, expires_at)
                    VALUES (?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)
                    """)) {
                insert.setString(1, requestId.toString()); insert.setString(2, clanId.toString());
                insert.setString(3, deputyId.toString()); insert.setString(4, recipientId.toString());
                insert.setString(5, normalized.toPlainString()); insert.setString(6, reason.trim());
                insert.setString(7, now.toString());
                insert.setString(8, now.plusSeconds(86_400).toString());
                insert.executeUpdate();
            } catch (SQLException constraint) {
                if (isConstraintViolation(constraint))
                    return new ClanRewardRequestResult(ClanRewardRequestStatus.DUPLICATE, null);
                throw constraint;
            }
            appendRewardRequestEvent(requestId, "CREATED", deputyId, normalized.toPlainString(), now);
            return new ClanRewardRequestResult(ClanRewardRequestStatus.CREATED,
                    readRewardRequest(requestId).orElseThrow());
        });
    }

    public synchronized ClanRewardRequestResult resolveRewardRequest(UUID requestId, UUID leaderId,
            boolean approve, Instant now) {
        ensureOpen();
        if (requestId == null || leaderId == null || now == null)
            return new ClanRewardRequestResult(ClanRewardRequestStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not resolve clan reward request", () -> {
            ClanRewardRequest request = readRewardRequest(requestId).orElse(null);
            if (request == null) return new ClanRewardRequestResult(ClanRewardRequestStatus.NOT_FOUND, null);
            if (!"LEADER".equals(clanMemberRole(request.clanId(), leaderId)))
                return new ClanRewardRequestResult(ClanRewardRequestStatus.NOT_A_MEMBER, request);
            if (!"PENDING".equals(request.status()))
                return new ClanRewardRequestResult(ClanRewardRequestStatus.ALREADY_RESOLVED, request);
            if (!now.isBefore(request.expiresAt())) {
                markRewardRequest(requestId, "EXPIRED", null, now, null);
                return new ClanRewardRequestResult(ClanRewardRequestStatus.EXPIRED,
                        readRewardRequest(requestId).orElse(request));
            }
            if (approve && approvedLargeRewardsThisWeek(request.clanId(), now) >= 3)
                return new ClanRewardRequestResult(ClanRewardRequestStatus.QUOTA_EXHAUSTED, request);
            markRewardRequest(requestId, approve ? "APPROVED" : "DECLINED", leaderId, now, null);
            return new ClanRewardRequestResult(approve ? ClanRewardRequestStatus.APPROVED
                    : ClanRewardRequestStatus.DECLINED, readRewardRequest(requestId).orElse(request));
        });
    }

    /** Records the payout operation that was started for an approved request. */
    public synchronized ClanRewardRequestResult attachRewardRequestOperation(UUID requestId, UUID operationId,
            Instant now) {
        ensureOpen();
        if (requestId == null || operationId == null || now == null)
            return new ClanRewardRequestResult(ClanRewardRequestStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not attach reward request operation", () -> {
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_reward_requests SET operation_id = ?
                    WHERE request_id = ? AND status = 'APPROVED' AND operation_id IS NULL
                    """)) {
                update.setString(1, operationId.toString()); update.setString(2, requestId.toString());
                update.executeUpdate();
            }
            return new ClanRewardRequestResult(ClanRewardRequestStatus.APPROVED,
                    readRewardRequest(requestId).orElse(null));
        });
    }

    /** Pending requests past their 24-hour deadline become EXPIRED without moving money. */
    public synchronized List<UUID> expireDueRewardRequests(Instant now) {
        ensureOpen();
        if (now == null) throw new IllegalArgumentException("now is required");
        return inWriteTransaction("Could not expire clan reward requests", () -> {
            List<UUID> expired = new ArrayList<>();
            List<UUID> due = new ArrayList<>();
            try (PreparedStatement query = connection.prepareStatement("""
                    SELECT request_id FROM clan_reward_requests
                    WHERE status = 'PENDING' AND julianday(expires_at) <= julianday(?)
                    """)) {
                query.setString(1, now.toString());
                try (ResultSet rows = query.executeQuery()) {
                    while (rows.next()) due.add(UUID.fromString(rows.getString(1)));
                }
            }
            for (UUID id : due) {
                markRewardRequest(id, "EXPIRED", null, now, null);
                expired.add(id);
            }
            return List.copyOf(expired);
        });
    }

    private void markRewardRequest(UUID requestId, String status, UUID actorId, Instant now, UUID operationId)
            throws SQLException {
        try (PreparedStatement update = connection.prepareStatement("""
                UPDATE clan_reward_requests SET status = ?, decided_by = ?, decided_at = ?, operation_id = ?
                WHERE request_id = ? AND status = 'PENDING'
                """)) {
            update.setString(1, status);
            update.setString(2, "EXPIRED".equals(status) ? null : actorId == null ? null : actorId.toString());
            update.setString(3, "EXPIRED".equals(status) ? null : now.toString());
            update.setString(4, operationId == null ? null : operationId.toString());
            update.setString(5, requestId.toString());
            update.executeUpdate();
        }
        appendRewardRequestEvent(requestId, status,
                "EXPIRED".equals(status) ? null : actorId, status, now);
    }

    /** Counts approved large rewards in the rolling seven-day window (owner decision #4). */
    public synchronized int approvedLargeRewardsThisWeek(UUID clanId, Instant now) {
        ensureOpen();
        if (clanId == null || now == null) return 0;
        Instant windowStart = now.minusSeconds(7L * 24 * 60 * 60);
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT COUNT(*) FROM clan_reward_requests
                WHERE clan_id = ? AND status = 'APPROVED' AND julianday(decided_at) >= julianday(?)
                """)) {
            query.setString(1, clanId.toString()); query.setString(2, windowStart.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? row.getInt(1) : 0;
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not count approved large rewards", exception);
        }
    }

    public synchronized List<ClanRewardRequest> findRewardRequests(UUID clanId, boolean pendingOnly) {
        ensureOpen();
        if (clanId == null) return List.of();
        String sql = "SELECT * FROM clan_reward_requests WHERE clan_id = ?"
                + (pendingOnly ? " AND status = 'PENDING'" : "") + " ORDER BY created_at DESC";
        try (PreparedStatement query = connection.prepareStatement(sql)) {
            query.setString(1, clanId.toString());
            List<ClanRewardRequest> requests = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) requests.add(readRewardRequestRow(rows));
            }
            return List.copyOf(requests);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan reward requests", exception);
        }
    }

    public synchronized Optional<ClanRewardRequest> findRewardRequest(UUID requestId) {
        ensureOpen();
        if (requestId == null) return Optional.empty();
        try { return readRewardRequest(requestId); }
        catch (SQLException exception) { throw storageFailure("Could not read clan reward request", exception); }
    }

    private Optional<ClanRewardRequest> readRewardRequest(UUID requestId) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_reward_requests WHERE request_id = ?")) {
            query.setString(1, requestId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readRewardRequestRow(row)) : Optional.empty();
            }
        }
    }

    private static ClanRewardRequest readRewardRequestRow(ResultSet row) throws SQLException {
        String decidedBy = row.getString("decided_by");
        String decidedAt = row.getString("decided_at");
        String operationId = row.getString("operation_id");
        return new ClanRewardRequest(UUID.fromString(row.getString("request_id")),
                UUID.fromString(row.getString("clan_id")), UUID.fromString(row.getString("deputy_id")),
                UUID.fromString(row.getString("recipient_id")), new BigDecimal(row.getString("amount")),
                row.getString("reason"), row.getString("status"),
                Instant.parse(row.getString("created_at")), Instant.parse(row.getString("expires_at")),
                decidedBy == null ? null : UUID.fromString(decidedBy),
                decidedAt == null ? null : Instant.parse(decidedAt),
                operationId == null ? null : UUID.fromString(operationId));
    }

    private void appendRewardRequestEvent(UUID requestId, String eventType, UUID actorId, String details,
            Instant now) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_reward_request_events(request_id, event_type, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, requestId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setString(4, details); insert.setString(5, now.toString());
            insert.executeUpdate();
        }
    }

    // ---------------------------------------------------------------------
    // Reports, sanctions and appeals (schema v26)
    // ---------------------------------------------------------------------

    public enum ClanReportStatus { NEW, UNDER_REVIEW, NEEDS_EVIDENCE, ACCEPTED, REJECTED }
    public enum ClanReportCategory { RULES, ABUSE, BANK_FRAUD, CHAT_HARASSMENT }
    public enum ClanSanctionKind { WARNING, FINAL_WARNING, TEMPORARY_FUNCTION_BLOCK }
    public enum ClanSanctionScope { CLAN_CHAT, CLAN_BANK, CLAN_REQUESTS, CLAN_WARS, ALL }
    public enum ClanAppealStatus { PENDING, ACCEPTED, REJECTED }

    public record ClanReport(UUID reportId, UUID clanId, UUID authorId, String authorName,
            boolean anonymous, ClanReportCategory category, String reason, ClanReportStatus status,
            UUID assignedTo, Instant createdAt, Instant updatedAt) { }
    public record ClanReportEvidence(long evidenceId, UUID reportId, String url, String description,
            Instant createdAt) { }
    public record ClanSanction(UUID sanctionId, UUID clanId, UUID targetId, UUID issuedBy,
            ClanSanctionKind kind, ClanSanctionScope scope, String reason, Instant issuedAt,
            Instant expiresAt, boolean ownerIssued, UUID revokedBy, Instant revokedAt) {
        public boolean activeAt(Instant now) {
            return revokedAt == null && (expiresAt == null || now.isBefore(expiresAt));
        }
    }
    public record ClanAppeal(UUID appealId, UUID sanctionId, UUID clanId, UUID submittedBy,
            Instant submittedAt, String reason, String evidence, ClanAppealStatus status,
            UUID decidedBy, Instant decidedAt, String decisionNote, boolean ownerOverride) { }

    public enum ReportStatus { CREATED, DUPLICATE, INVALID_INPUT, NOT_FOUND, UPDATED, UNAUTHORIZED, STORAGE_ERROR }

    public synchronized ReportStatus createClanReport(UUID reportId, UUID clanId, UUID authorId,
            String authorName, boolean anonymous, String category, String reason,
            List<String> evidenceUrls, Instant now) {
        ensureOpen();
        if (reportId == null || clanId == null || authorId == null || authorName == null || now == null
                || category == null || !Set.of("RULES", "ABUSE", "BANK_FRAUD", "CHAT_HARASSMENT").contains(category)
                || reason == null || reason.isBlank() || reason.trim().length() > 2000
                || evidenceUrls == null) return ReportStatus.INVALID_INPUT;
        return inWriteTransaction("Could not create clan report", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString())) return ReportStatus.NOT_FOUND;
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_reports(report_id, clan_id, author_id, author_name, anonymous,
                        category, reason, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'NEW', ?, ?)
                    """)) {
                insert.setString(1, reportId.toString()); insert.setString(2, clanId.toString());
                insert.setString(3, authorId.toString()); insert.setString(4, authorName);
                insert.setInt(5, anonymous ? 1 : 0); insert.setString(6, category);
                insert.setString(7, reason.trim()); insert.setString(8, now.toString());
                insert.setString(9, now.toString());
                insert.executeUpdate();
            } catch (SQLException constraint) {
                if (isConstraintViolation(constraint)) return ReportStatus.DUPLICATE;
                throw constraint;
            }
            for (String url : evidenceUrls) {
                if (!validEvidenceUrl(url)) {
                    throw new StorageException("Invalid evidence URL: " + url);
                }
                insertReportEvidence(reportId, url, null, now);
            }
            appendReportEvent(reportId, "CREATED", authorId, category + ";anonymous=" + anonymous, now);
            return ReportStatus.CREATED;
        });
    }

    public synchronized ReportStatus addReportEvidence(UUID reportId, String url, String description, Instant now) {
        ensureOpen();
        if (reportId == null || now == null || !validEvidenceUrl(url)
                || (description != null && description.length() > 300)) return ReportStatus.INVALID_INPUT;
        return inWriteTransaction("Could not add report evidence", () -> {
            if (!exists("SELECT 1 FROM clan_reports WHERE report_id = ?", reportId.toString()))
                return ReportStatus.NOT_FOUND;
            insertReportEvidence(reportId, url, description, now);
            appendReportEvent(reportId, "EVIDENCE_ADDED", null, url, now);
            return ReportStatus.UPDATED;
        });
    }

    public synchronized ReportStatus updateReportStatus(UUID reportId, UUID actorId, String status,
            String note, Instant now) {
        ensureOpen();
        if (reportId == null || now == null || status == null
                || !Set.of("NEW", "UNDER_REVIEW", "NEEDS_EVIDENCE", "ACCEPTED", "REJECTED").contains(status))
            return ReportStatus.INVALID_INPUT;
        return inWriteTransaction("Could not update clan report", () -> {
            if (!exists("SELECT 1 FROM clan_reports WHERE report_id = ?", reportId.toString()))
                return ReportStatus.NOT_FOUND;
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_reports SET status = ?, assigned_to = COALESCE(?, assigned_to), updated_at = ?
                    WHERE report_id = ?
                    """)) {
                update.setString(1, status); update.setString(2, actorId == null ? null : actorId.toString());
                update.setString(3, now.toString()); update.setString(4, reportId.toString());
                update.executeUpdate();
            }
            appendReportEvent(reportId, "STATUS_" + status, actorId, note, now);
            return ReportStatus.UPDATED;
        });
    }

    public synchronized Optional<ClanReport> findClanReport(UUID reportId) {
        ensureOpen();
        if (reportId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_reports WHERE report_id = ?")) {
            query.setString(1, reportId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readClanReportRow(row)) : Optional.empty();
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan report", exception);
        }
    }

    public synchronized List<ClanReport> findClanReports(String status, int limit) {
        ensureOpen();
        if (limit < 1 || limit > 500) throw new IllegalArgumentException("limit must be between 1 and 500");
        String sql = "SELECT * FROM clan_reports"
                + (status == null ? "" : " WHERE status = ?")
                + " ORDER BY created_at DESC LIMIT ?";
        try (PreparedStatement query = connection.prepareStatement(sql)) {
            int index = 1;
            if (status != null) query.setString(index++, status);
            query.setInt(index, limit);
            List<ClanReport> reports = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) reports.add(readClanReportRow(rows));
            }
            return List.copyOf(reports);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan reports", exception);
        }
    }

    public synchronized List<ClanReportEvidence> findReportEvidence(UUID reportId) {
        ensureOpen();
        if (reportId == null) return List.of();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_report_evidence WHERE report_id = ? ORDER BY evidence_id")) {
            query.setString(1, reportId.toString());
            List<ClanReportEvidence> evidence = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) evidence.add(new ClanReportEvidence(rows.getLong("evidence_id"),
                        reportId, rows.getString("url"), rows.getString("description"),
                        Instant.parse(rows.getString("created_at"))));
            }
            return List.copyOf(evidence);
        } catch (SQLException exception) {
            throw storageFailure("Could not read report evidence", exception);
        }
    }

    /** Owner-only: returns the author identity and records an auditable view of it. */
    public synchronized Optional<ClanReport> revealReportAuthor(UUID reportId, UUID viewerId, Instant now) {
        ensureOpen();
        if (reportId == null || viewerId == null || now == null) return Optional.empty();
        Optional<ClanReport> report = findClanReport(reportId);
        if (report.isEmpty()) return Optional.empty();
        inWriteTransaction("Could not audit identity view", () -> {
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_report_identity_views(report_id, viewer_id, occurred_at)
                    VALUES (?, ?, ?)
                    """)) {
                insert.setString(1, reportId.toString()); insert.setString(2, viewerId.toString());
                insert.setString(3, now.toString()); insert.executeUpdate();
            }
            appendReportEvent(reportId, "IDENTITY_VIEWED", viewerId, "owner", now);
            return null;
        });
        return report;
    }

    public synchronized ReportStatus createClanSanction(UUID sanctionId, UUID clanId, UUID targetId,
            UUID issuedBy, String kind, String scope, String reason, Instant issuedAt, Instant expiresAt,
            boolean ownerIssued) {
        ensureOpen();
        if (sanctionId == null || targetId == null || issuedBy == null || issuedAt == null
                || kind == null || !Set.of("WARNING", "FINAL_WARNING", "TEMPORARY_FUNCTION_BLOCK").contains(kind)
                || scope == null || !Set.of("CLAN_CHAT", "CLAN_BANK", "CLAN_REQUESTS", "CLAN_WARS", "ALL").contains(scope)
                || reason == null || reason.isBlank() || reason.trim().length() > 500
                || (expiresAt != null && !expiresAt.isAfter(issuedAt)))
            return ReportStatus.INVALID_INPUT;
        return inWriteTransaction("Could not issue clan sanction", () -> {
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_sanctions(sanction_id, clan_id, target_id, issued_by, kind, scope,
                        reason, issued_at, expires_at, owner_issued)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                insert.setString(1, sanctionId.toString());
                insert.setString(2, clanId == null ? null : clanId.toString());
                insert.setString(3, targetId.toString()); insert.setString(4, issuedBy.toString());
                insert.setString(5, kind); insert.setString(6, scope); insert.setString(7, reason.trim());
                insert.setString(8, issuedAt.toString());
                insert.setString(9, expiresAt == null ? null : expiresAt.toString());
                insert.setInt(10, ownerIssued ? 1 : 0);
                insert.executeUpdate();
            }
            appendSanctionEvent(sanctionId, "ISSUED", issuedBy, kind + ":" + scope, issuedAt);
            return ReportStatus.CREATED;
        });
    }

    public synchronized ReportStatus revokeClanSanction(UUID sanctionId, UUID actorId, Instant now) {
        ensureOpen();
        if (sanctionId == null || actorId == null || now == null) return ReportStatus.INVALID_INPUT;
        return inWriteTransaction("Could not revoke clan sanction", () -> {
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_sanctions SET revoked_by = ?, revoked_at = ?
                    WHERE sanction_id = ? AND revoked_at IS NULL
                    """)) {
                update.setString(1, actorId.toString()); update.setString(2, now.toString());
                update.setString(3, sanctionId.toString());
                if (update.executeUpdate() != 1) return ReportStatus.NOT_FOUND;
            }
            appendSanctionEvent(sanctionId, "REVOKED", actorId, "revoked", now);
            return ReportStatus.UPDATED;
        });
    }

    public synchronized Optional<ClanSanction> findClanSanction(UUID sanctionId) {
        ensureOpen();
        if (sanctionId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_sanctions WHERE sanction_id = ?")) {
            query.setString(1, sanctionId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readClanSanctionRow(row)) : Optional.empty();
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan sanction", exception);
        }
    }

    /** Active (not revoked, not expired) sanctions for a player. */
    public synchronized List<ClanSanction> findActiveClanSanctions(UUID targetId, Instant now) {
        ensureOpen();
        if (targetId == null || now == null) return List.of();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_sanctions WHERE target_id = ? AND revoked_at IS NULL
                ORDER BY issued_at DESC
                """)) {
            query.setString(1, targetId.toString());
            List<ClanSanction> sanctions = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) {
                    ClanSanction sanction = readClanSanctionRow(rows);
                    if (sanction.activeAt(now)) sanctions.add(sanction);
                }
            }
            return List.copyOf(sanctions);
        } catch (SQLException exception) {
            throw storageFailure("Could not read active clan sanctions", exception);
        }
    }

    public synchronized List<ClanSanction> findClanSanctions(UUID targetId, int limit) {
        ensureOpen();
        if (limit < 1 || limit > 500) throw new IllegalArgumentException("limit must be between 1 and 500");
        String sql = "SELECT * FROM clan_sanctions"
                + (targetId == null ? "" : " WHERE target_id = ?")
                + " ORDER BY issued_at DESC LIMIT ?";
        try (PreparedStatement query = connection.prepareStatement(sql)) {
            int index = 1;
            if (targetId != null) query.setString(index++, targetId.toString());
            query.setInt(index, limit);
            List<ClanSanction> sanctions = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) sanctions.add(readClanSanctionRow(rows));
            }
            return List.copyOf(sanctions);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan sanctions", exception);
        }
    }

    public synchronized ReportStatus createClanAppeal(UUID appealId, UUID sanctionId, UUID clanId,
            UUID submittedBy, String reason, String evidence, Instant now) {
        ensureOpen();
        if (appealId == null || sanctionId == null || submittedBy == null || now == null
                || reason == null || reason.isBlank() || reason.trim().length() > 2000
                || (evidence != null && evidence.length() > 2000)) return ReportStatus.INVALID_INPUT;
        return inWriteTransaction("Could not create clan appeal", () -> {
            if (!exists("SELECT 1 FROM clan_sanctions WHERE sanction_id = ?", sanctionId.toString()))
                return ReportStatus.NOT_FOUND;
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_appeals(appeal_id, sanction_id, clan_id, submitted_by, submitted_at,
                        reason, evidence, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING')
                    """)) {
                insert.setString(1, appealId.toString()); insert.setString(2, sanctionId.toString());
                insert.setString(3, clanId == null ? null : clanId.toString());
                insert.setString(4, submittedBy.toString()); insert.setString(5, now.toString());
                insert.setString(6, reason.trim());
                insert.setString(7, evidence == null ? null : evidence.trim());
                insert.executeUpdate();
            } catch (SQLException constraint) {
                if (isConstraintViolation(constraint)) return ReportStatus.DUPLICATE;
                throw constraint;
            }
            appendAppealEvent(appealId, "CREATED", submittedBy, "pending", now);
            return ReportStatus.CREATED;
        });
    }

    public synchronized ReportStatus decideClanAppeal(UUID appealId, UUID actorId, boolean accept,
            String note, Instant now) {
        ensureOpen();
        if (appealId == null || actorId == null || now == null) return ReportStatus.INVALID_INPUT;
        return inWriteTransaction("Could not decide clan appeal", () -> {
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_appeals SET status = ?, decided_by = ?, decided_at = ?, decision_note = ?
                    WHERE appeal_id = ? AND status = 'PENDING'
                    """)) {
                update.setString(1, accept ? "ACCEPTED" : "REJECTED");
                update.setString(2, actorId.toString()); update.setString(3, now.toString());
                update.setString(4, note); update.setString(5, appealId.toString());
                if (update.executeUpdate() != 1) return ReportStatus.UPDATED;
            }
            appendAppealEvent(appealId, accept ? "ACCEPTED" : "REJECTED", actorId, note, now);
            return ReportStatus.UPDATED;
        });
    }

    public synchronized List<ClanAppeal> findClanAppeals(String status, int limit) {
        ensureOpen();
        if (limit < 1 || limit > 500) throw new IllegalArgumentException("limit must be between 1 and 500");
        String sql = "SELECT * FROM clan_appeals" + (status == null ? "" : " WHERE status = ?")
                + " ORDER BY submitted_at DESC LIMIT ?";
        try (PreparedStatement query = connection.prepareStatement(sql)) {
            int index = 1;
            if (status != null) query.setString(index++, status);
            query.setInt(index, limit);
            List<ClanAppeal> appeals = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) appeals.add(readClanAppealRow(rows));
            }
            return List.copyOf(appeals);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan appeals", exception);
        }
    }

    public synchronized Optional<ClanAppeal> findClanAppeal(UUID appealId) {
        ensureOpen();
        if (appealId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_appeals WHERE appeal_id = ?")) {
            query.setString(1, appealId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readClanAppealRow(row)) : Optional.empty();
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan appeal", exception);
        }
    }

    private void insertReportEvidence(UUID reportId, String url, String description, Instant now)
            throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_report_evidence(report_id, url, description, created_at)
                VALUES (?, ?, ?, ?)
                """)) {
            insert.setString(1, reportId.toString()); insert.setString(2, url);
            insert.setString(3, description); insert.setString(4, now.toString());
            insert.executeUpdate();
        }
    }

    private static boolean validEvidenceUrl(String url) {
        if (url == null || url.length() < 8 || url.length() > 500) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        return (lower.startsWith("http://") || lower.startsWith("https://"))
                && !url.contains(" ") && url.contains(".");
    }

    private void appendReportEvent(UUID reportId, String eventType, UUID actorId, String details, Instant now)
            throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_report_events(report_id, event_type, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, reportId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setString(4, details); insert.setString(5, now.toString());
            insert.executeUpdate();
        }
    }

    private void appendSanctionEvent(UUID sanctionId, String eventType, UUID actorId, String details, Instant now)
            throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_sanction_events(sanction_id, event_type, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, sanctionId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setString(4, details); insert.setString(5, now.toString());
            insert.executeUpdate();
        }
    }

    private void appendAppealEvent(UUID appealId, String eventType, UUID actorId, String details, Instant now)
            throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_appeal_events(appeal_id, event_type, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, appealId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setString(4, details); insert.setString(5, now.toString());
            insert.executeUpdate();
        }
    }

    private static ClanReport readClanReportRow(ResultSet row) throws SQLException {
        String assigned = row.getString("assigned_to");
        return new ClanReport(UUID.fromString(row.getString("report_id")),
                UUID.fromString(row.getString("clan_id")), UUID.fromString(row.getString("author_id")),
                row.getString("author_name"), row.getInt("anonymous") == 1,
                ClanReportCategory.valueOf(row.getString("category")), row.getString("reason"),
                ClanReportStatus.valueOf(row.getString("status")),
                assigned == null ? null : UUID.fromString(assigned),
                Instant.parse(row.getString("created_at")), Instant.parse(row.getString("updated_at")));
    }

    private static ClanSanction readClanSanctionRow(ResultSet row) throws SQLException {
        String clanId = row.getString("clan_id");
        String expiresAt = row.getString("expires_at");
        String revokedBy = row.getString("revoked_by");
        String revokedAt = row.getString("revoked_at");
        return new ClanSanction(UUID.fromString(row.getString("sanction_id")),
                clanId == null ? null : UUID.fromString(clanId),
                UUID.fromString(row.getString("target_id")), UUID.fromString(row.getString("issued_by")),
                ClanSanctionKind.valueOf(row.getString("kind")),
                ClanSanctionScope.valueOf(row.getString("scope")), row.getString("reason"),
                Instant.parse(row.getString("issued_at")),
                expiresAt == null ? null : Instant.parse(expiresAt),
                row.getInt("owner_issued") == 1,
                revokedBy == null ? null : UUID.fromString(revokedBy),
                revokedAt == null ? null : Instant.parse(revokedAt));
    }

    private static ClanAppeal readClanAppealRow(ResultSet row) throws SQLException {
        String clanId = row.getString("clan_id");
        String decidedBy = row.getString("decided_by");
        String decidedAt = row.getString("decided_at");
        return new ClanAppeal(UUID.fromString(row.getString("appeal_id")),
                UUID.fromString(row.getString("sanction_id")),
                clanId == null ? null : UUID.fromString(clanId),
                UUID.fromString(row.getString("submitted_by")),
                Instant.parse(row.getString("submitted_at")), row.getString("reason"),
                row.getString("evidence"), ClanAppealStatus.valueOf(row.getString("status")),
                decidedBy == null ? null : UUID.fromString(decidedBy),
                decidedAt == null ? null : Instant.parse(decidedAt),
                row.getString("decision_note"), row.getInt("owner_override") == 1);
    }

    /** Reports submitted by one player, newest first. */
    public synchronized List<ClanReport> findClanReportsByAuthor(UUID authorId, int limit) {
        ensureOpen();
        if (authorId == null) return List.of();
        if (limit < 1 || limit > 100) throw new IllegalArgumentException("limit must be between 1 and 100");
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_reports WHERE author_id = ? ORDER BY created_at DESC LIMIT ?
                """)) {
            query.setString(1, authorId.toString()); query.setInt(2, limit);
            List<ClanReport> reports = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) reports.add(readClanReportRow(rows));
            }
            return List.copyOf(reports);
        } catch (SQLException exception) {
            throw storageFailure("Could not list reports by author", exception);
        }
    }

    // ---------------------------------------------------------------------
    // Clan quests (schema v27): 3 daily, 3 weekly, 1 special
    // ---------------------------------------------------------------------

    public enum ClanQuestCategory { DAILY, WEEKLY, SPECIAL }
    public enum ClanQuestDifficulty { EASY, MEDIUM, HARD }
    public enum ClanQuestMetric { MINE_BLOCK, KILL_MOB, COLLECT_ITEM, WIN_WAR }
    public enum ClanQuestStatus { ACTIVE, COMPLETED, EXPIRED }

    public record ClanQuest(UUID questId, UUID clanId, ClanQuestCategory category,
            ClanQuestDifficulty difficulty, ClanQuestMetric metric, int targetAmount, int progress,
            int requiredContributors, ClanQuestStatus status, String periodKey, int slot,
            long xpAwarded, Instant issuedAt, Instant expiresAt, Instant completedAt) { }

    public enum QuestProgressStatus { ADVANCED, COMPLETED, NOT_FOUND, NOT_ACTIVE, INACTIVE, STORAGE_ERROR }

    public record QuestProgressResult(QuestProgressStatus status, ClanQuest quest, boolean completed) { }

    public synchronized void insertClanQuest(UUID questId, UUID clanId, String category, String difficulty,
            String metric, int targetAmount, int requiredContributors, String periodKey, int slot,
            Instant issuedAt, Instant expiresAt) {
        ensureOpen();
        inWriteTransaction("Could not create clan quest", () -> {
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_quests(quest_id, clan_id, category, difficulty, metric, target_amount,
                        progress, required_contributors, status, period_key, slot, xp_awarded,
                        issued_at, expires_at)
                    VALUES (?, ?, ?, ?, ?, ?, 0, ?, 'ACTIVE', ?, ?, 0, ?, ?)
                    """)) {
                insert.setString(1, questId.toString()); insert.setString(2, clanId.toString());
                insert.setString(3, category); insert.setString(4, difficulty);
                insert.setString(5, metric); insert.setInt(6, targetAmount);
                insert.setInt(7, requiredContributors); insert.setString(8, periodKey);
                insert.setInt(9, slot); insert.setString(10, issuedAt.toString());
                insert.setString(11, expiresAt.toString());
                insert.executeUpdate();
            } catch (SQLException constraint) {
                if (isConstraintViolation(constraint)) return null;
                throw constraint;
            }
            appendQuestEvent(questId, "CREATED", null, 0, category + ":" + difficulty + ":" + metric, issuedAt);
            return null;
        });
    }

    public synchronized List<ClanQuest> findClanQuests(UUID clanId, boolean activeOnly) {
        ensureOpen();
        if (clanId == null) return List.of();
        String sql = "SELECT * FROM clan_quests WHERE clan_id = ?"
                + (activeOnly ? " AND status = 'ACTIVE'" : "")
                + " ORDER BY category, slot";
        try (PreparedStatement query = connection.prepareStatement(sql)) {
            query.setString(1, clanId.toString());
            List<ClanQuest> quests = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) quests.add(readClanQuestRow(rows));
            }
            return List.copyOf(quests);
        } catch (SQLException exception) {
            throw storageFailure("Could not list clan quests", exception);
        }
    }

    public synchronized int countClanQuestContributors(UUID questId) {
        ensureOpen();
        if (questId == null) return 0;
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT COUNT(*) FROM clan_quest_contributors WHERE quest_id = ?")) {
            query.setString(1, questId.toString());
            try (ResultSet row = query.executeQuery()) { return row.next() ? row.getInt(1) : 0; }
        } catch (SQLException exception) {
            throw storageFailure("Could not count quest contributors", exception);
        }
    }

    /**
     * Applies progress from one player. Completion requires both the target amount and the
     * approved minimum number of distinct contributors; XP is awarded by the caller afterwards.
     */
    public synchronized QuestProgressResult applyClanQuestProgress(UUID questId, UUID playerId, int amount,
            Instant now) {
        ensureOpen();
        if (questId == null || playerId == null || amount <= 0 || now == null)
            return new QuestProgressResult(QuestProgressStatus.NOT_FOUND, null, false);
        return inWriteTransaction("Could not apply clan quest progress", () -> {
            ClanQuest quest = readClanQuest(questId).orElse(null);
            if (quest == null) return new QuestProgressResult(QuestProgressStatus.NOT_FOUND, null, false);
            if (quest.status() != ClanQuestStatus.ACTIVE)
                return new QuestProgressResult(QuestProgressStatus.NOT_ACTIVE, quest, false);
            if (!now.isBefore(quest.expiresAt())) {
                try (PreparedStatement expire = connection.prepareStatement(
                        "UPDATE clan_quests SET status = 'EXPIRED' WHERE quest_id = ? AND status = 'ACTIVE'")) {
                    expire.setString(1, questId.toString()); expire.executeUpdate();
                }
                appendQuestEvent(questId, "EXPIRED", null, 0, "deadline", now);
                return new QuestProgressResult(QuestProgressStatus.NOT_ACTIVE,
                        readClanQuest(questId).orElse(quest), false);
            }
            int next = Math.min(quest.targetAmount(), quest.progress() + amount);
            try (PreparedStatement update = connection.prepareStatement(
                    "UPDATE clan_quests SET progress = ? WHERE quest_id = ? AND status = 'ACTIVE'")) {
                update.setInt(1, next); update.setString(2, questId.toString());
                update.executeUpdate();
            }
            try (PreparedStatement contributor = connection.prepareStatement("""
                    INSERT INTO clan_quest_contributors(quest_id, player_id, amount) VALUES (?, ?, ?)
                    ON CONFLICT(quest_id, player_id) DO UPDATE SET amount = amount + excluded.amount
                    """)) {
                contributor.setString(1, questId.toString()); contributor.setString(2, playerId.toString());
                contributor.setInt(3, amount); contributor.executeUpdate();
            }
            appendQuestEvent(questId, "PROGRESS", playerId, amount, "progress=" + next, now);
            int contributors = countClanQuestContributors(questId);
            boolean completed = next >= quest.targetAmount()
                    && contributors >= quest.requiredContributors();
            if (completed) {
                try (PreparedStatement complete = connection.prepareStatement("""
                        UPDATE clan_quests SET status = 'COMPLETED', completed_at = ?
                        WHERE quest_id = ? AND status = 'ACTIVE'
                        """)) {
                    complete.setString(1, now.toString()); complete.setString(2, questId.toString());
                    complete.executeUpdate();
                }
                appendQuestEvent(questId, "COMPLETED", null, 0,
                        "contributors=" + contributors, now);
            }
            ClanQuest updated = readClanQuest(questId).orElse(quest);
            return new QuestProgressResult(completed ? QuestProgressStatus.COMPLETED
                    : QuestProgressStatus.ADVANCED, updated, completed);
        });
    }

    /** Marks XP as paid exactly once for a completed quest. */
    public synchronized boolean markClanQuestXpAwarded(UUID questId, long xp, Instant now) {
        ensureOpen();
        if (questId == null || xp < 0 || now == null) return false;
        return inWriteTransaction("Could not mark quest XP", () -> {
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_quests SET xp_awarded = ?
                    WHERE quest_id = ? AND status = 'COMPLETED' AND xp_awarded = 0
                    """)) {
                update.setLong(1, xp); update.setString(2, questId.toString());
                if (update.executeUpdate() != 1) return false;
            }
            appendQuestEvent(questId, "XP_AWARDED", null, (int) Math.min(xp, Integer.MAX_VALUE),
                    "xp=" + xp, now);
            return true;
        });
    }

    /** Expires active quests past their deadline; returns the affected quest ids. */
    public synchronized List<UUID> expireDueClanQuests(Instant now) {
        ensureOpen();
        if (now == null) throw new IllegalArgumentException("now is required");
        return inWriteTransaction("Could not expire clan quests", () -> {
            List<UUID> due = new ArrayList<>();
            try (PreparedStatement query = connection.prepareStatement("""
                    SELECT quest_id FROM clan_quests WHERE status = 'ACTIVE' AND julianday(expires_at) <= julianday(?)
                    """)) {
                query.setString(1, now.toString());
                try (ResultSet rows = query.executeQuery()) {
                    while (rows.next()) due.add(UUID.fromString(rows.getString(1)));
                }
            }
            for (UUID id : due) {
                try (PreparedStatement update = connection.prepareStatement(
                        "UPDATE clan_quests SET status = 'EXPIRED' WHERE quest_id = ? AND status = 'ACTIVE'")) {
                    update.setString(1, id.toString()); update.executeUpdate();
                }
                appendQuestEvent(id, "EXPIRED", null, 0, "deadline", now);
            }
            return List.copyOf(due);
        });
    }

    private Optional<ClanQuest> readClanQuest(UUID questId) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_quests WHERE quest_id = ?")) {
            query.setString(1, questId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readClanQuestRow(row)) : Optional.empty();
            }
        }
    }

    private static ClanQuest readClanQuestRow(ResultSet row) throws SQLException {
        String completedAt = row.getString("completed_at");
        return new ClanQuest(UUID.fromString(row.getString("quest_id")),
                UUID.fromString(row.getString("clan_id")),
                ClanQuestCategory.valueOf(row.getString("category")),
                ClanQuestDifficulty.valueOf(row.getString("difficulty")),
                ClanQuestMetric.valueOf(row.getString("metric")),
                row.getInt("target_amount"), row.getInt("progress"),
                row.getInt("required_contributors"),
                ClanQuestStatus.valueOf(row.getString("status")), row.getString("period_key"),
                row.getInt("slot"), row.getLong("xp_awarded"),
                Instant.parse(row.getString("issued_at")), Instant.parse(row.getString("expires_at")),
                completedAt == null ? null : Instant.parse(completedAt));
    }

    private void appendQuestEvent(UUID questId, String eventType, UUID actorId, int amount,
            String details, Instant now) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_quest_events(quest_id, event_type, actor_id, amount, details, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, questId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setInt(4, amount); insert.setString(5, details); insert.setString(6, now.toString());
            insert.executeUpdate();
        }
    }

    // ---------------------------------------------------------------------
    // Tournaments and building-tournament voting (schema v28)
    // ---------------------------------------------------------------------

    public record ClanTournament(UUID tournamentId, String discipline, String name, String state,
            int teamSize, UUID createdBy, Instant createdAt, Instant registrationClosesAt,
            Instant votingClosesAt, int voteMinimum, int voteDurationMinutes, String votePermission,
            int votePoints, boolean allowAbstain, boolean hideResults, UUID winnerClanId,
            Instant endedAt) { }

    public record ClanTournamentVote(UUID voteId, UUID tournamentId, UUID voterId, UUID clanId,
            int points, Instant createdAt, UUID revokedBy, Instant revokedAt, String revokedReason) { }

    public enum TournamentStatus { CREATED, UPDATED, NOT_FOUND, INVALID_INPUT, STATE_CONFLICT,
        ALREADY_VOTED, NOT_ELIGIBLE, REGISTRATION_BLOCKED, STORAGE_ERROR }

    public record TournamentResult(TournamentStatus status, ClanTournament tournament) { }

    public synchronized TournamentResult insertTournament(UUID tournamentId, String discipline, String name,
            int teamSize, UUID createdBy, int voteMinimum, int voteDurationMinutes, String votePermission,
            int votePoints, boolean allowAbstain, boolean hideResults, Instant now) {
        ensureOpen();
        if (tournamentId == null || discipline == null || name == null || createdBy == null || now == null
                || teamSize <= 0 || voteMinimum < 0 || voteDurationMinutes < 1 || votePoints < 1
                || votePermission == null || votePermission.isBlank()
                || !Set.of("PVP", "PARKOUR", "BUILDING", "RESOURCE_GATHERING", "TREASURE_HUNT")
                        .contains(discipline))
            return new TournamentResult(TournamentStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not create tournament", () -> {
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_tournaments(tournament_id, discipline, name, state, team_size,
                        created_by, created_at, vote_minimum, vote_duration_minutes, vote_permission,
                        vote_points, vote_allow_abstain, vote_hide_results)
                    VALUES (?, ?, ?, 'DRAFT', ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                insert.setString(1, tournamentId.toString()); insert.setString(2, discipline);
                insert.setString(3, name.trim()); insert.setInt(4, teamSize);
                insert.setString(5, createdBy.toString()); insert.setString(6, now.toString());
                insert.setInt(7, voteMinimum); insert.setInt(8, voteDurationMinutes);
                insert.setString(9, votePermission); insert.setInt(10, votePoints);
                insert.setInt(11, allowAbstain ? 1 : 0); insert.setInt(12, hideResults ? 1 : 0);
                insert.executeUpdate();
            }
            appendTournamentEvent(tournamentId, "CREATED", createdBy, discipline, now);
            return new TournamentResult(TournamentStatus.CREATED,
                    readTournament(tournamentId).orElseThrow());
        });
    }

    /**
     * Registration may only open once the owner approves the entry-fee policy. Until then the
     * tournament stays in DRAFT and nothing is charged or promised.
     */
    public synchronized TournamentResult openTournamentRegistration(UUID tournamentId, UUID actorId,
            Instant closesAt, Instant now) {
        ensureOpen();
        if (tournamentId == null || actorId == null || closesAt == null || now == null
                || !closesAt.isAfter(now)) return new TournamentResult(TournamentStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not open tournament registration", () -> {
            ClanTournament tournament = readTournament(tournamentId).orElse(null);
            if (tournament == null) return new TournamentResult(TournamentStatus.NOT_FOUND, null);
            if (!"DRAFT".equals(tournament.state()))
                return new TournamentResult(TournamentStatus.STATE_CONFLICT, tournament);
            // Owner decision pending: registration conditions are not approved.
            return new TournamentResult(TournamentStatus.REGISTRATION_BLOCKED, tournament);
        });
    }

    public synchronized Optional<ClanTournament> findTournament(UUID tournamentId) {
        ensureOpen();
        if (tournamentId == null) return Optional.empty();
        try { return readTournament(tournamentId); }
        catch (SQLException exception) { throw storageFailure("Could not read tournament", exception); }
    }

    public synchronized List<ClanTournament> findTournaments(String state, int limit) {
        ensureOpen();
        if (limit < 1 || limit > 100) throw new IllegalArgumentException("limit must be between 1 and 100");
        String sql = "SELECT * FROM clan_tournaments" + (state == null ? "" : " WHERE state = ?")
                + " ORDER BY created_at DESC LIMIT ?";
        try (PreparedStatement query = connection.prepareStatement(sql)) {
            int index = 1;
            if (state != null) query.setString(index++, state);
            query.setInt(index, limit);
            List<ClanTournament> tournaments = new ArrayList<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) tournaments.add(readTournamentRow(rows));
            }
            return List.copyOf(tournaments);
        } catch (SQLException exception) {
            throw storageFailure("Could not list tournaments", exception);
        }
    }

    public synchronized TournamentStatus castTournamentVote(UUID voteId, UUID tournamentId, UUID voterId,
            UUID clanId, int points, Instant now) {
        ensureOpen();
        if (voteId == null || tournamentId == null || voterId == null || clanId == null || now == null
                || points < 1) return TournamentStatus.INVALID_INPUT;
        return inWriteTransaction("Could not cast tournament vote", () -> {
            ClanTournament tournament = readTournament(tournamentId).orElse(null);
            if (tournament == null) return TournamentStatus.NOT_FOUND;
            if (!"REGISTRATION_CLOSED".equals(tournament.state()) && !"RUNNING".equals(tournament.state()))
                return TournamentStatus.STATE_CONFLICT;
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_tournament_votes(vote_id, tournament_id, voter_id, clan_id, points, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """)) {
                insert.setString(1, voteId.toString()); insert.setString(2, tournamentId.toString());
                insert.setString(3, voterId.toString()); insert.setString(4, clanId.toString());
                insert.setInt(5, points); insert.setString(6, now.toString());
                insert.executeUpdate();
            } catch (SQLException constraint) {
                if (isConstraintViolation(constraint)) return TournamentStatus.ALREADY_VOTED;
                throw constraint;
            }
            appendTournamentEvent(tournamentId, "VOTE", voterId, "clan=" + clanId, now);
            return TournamentStatus.CREATED;
        });
    }

    public synchronized Optional<ClanTournamentVote> findTournamentVote(UUID tournamentId, UUID voterId) {
        ensureOpen();
        if (tournamentId == null || voterId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT * FROM clan_tournament_votes WHERE tournament_id = ? AND voter_id = ?
                """)) {
            query.setString(1, tournamentId.toString()); query.setString(2, voterId.toString());
            try (ResultSet row = query.executeQuery()) {
                if (!row.next()) return Optional.empty();
                String revokedBy = row.getString("revoked_by");
                String revokedAt = row.getString("revoked_at");
                return Optional.of(new ClanTournamentVote(UUID.fromString(row.getString("vote_id")),
                        tournamentId, voterId, UUID.fromString(row.getString("clan_id")),
                        row.getInt("points"), Instant.parse(row.getString("created_at")),
                        revokedBy == null ? null : UUID.fromString(revokedBy),
                        revokedAt == null ? null : Instant.parse(revokedAt),
                        row.getString("revoked_reason")));
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not read tournament vote", exception);
        }
    }

    /** Vote tally per clan; revoked votes are excluded. */
    public synchronized Map<UUID, Integer> tournamentTally(UUID tournamentId) {
        ensureOpen();
        if (tournamentId == null) return Map.of();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT clan_id, SUM(points) AS total FROM clan_tournament_votes
                WHERE tournament_id = ? AND revoked_at IS NULL GROUP BY clan_id
                """)) {
            query.setString(1, tournamentId.toString());
            Map<UUID, Integer> tally = new java.util.LinkedHashMap<>();
            try (ResultSet rows = query.executeQuery()) {
                while (rows.next()) tally.put(UUID.fromString(rows.getString("clan_id")),
                        rows.getInt("total"));
            }
            return Map.copyOf(tally);
        } catch (SQLException exception) {
            throw storageFailure("Could not tally tournament votes", exception);
        }
    }

    /** Owner/admin annuls a suspicious vote with a reason; the vote row is retained. */
    public synchronized TournamentStatus revokeTournamentVote(UUID tournamentId, UUID voterId, UUID actorId,
            String reason, Instant now) {
        ensureOpen();
        if (tournamentId == null || voterId == null || actorId == null || now == null
                || reason == null || reason.isBlank() || reason.length() > 300)
            return TournamentStatus.INVALID_INPUT;
        return inWriteTransaction("Could not revoke tournament vote", () -> {
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_tournament_votes SET revoked_by = ?, revoked_at = ?, revoked_reason = ?
                    WHERE tournament_id = ? AND voter_id = ? AND revoked_at IS NULL
                    """)) {
                update.setString(1, actorId.toString()); update.setString(2, now.toString());
                update.setString(3, reason); update.setString(4, tournamentId.toString());
                update.setString(5, voterId.toString());
                if (update.executeUpdate() != 1) return TournamentStatus.NOT_FOUND;
            }
            appendTournamentEvent(tournamentId, "VOTE_REVOKED", actorId, reason, now);
            return TournamentStatus.UPDATED;
        });
    }

    /** Owner-controlled state change (close registration, run, finish, cancel); audited. */
    public synchronized TournamentStatus setTournamentState(UUID tournamentId, String state, UUID actorId,
            Instant now) {
        ensureOpen();
        if (tournamentId == null || state == null || now == null
                || !Set.of("REGISTRATION_CLOSED", "RUNNING", "FINISHED", "CANCELLED").contains(state))
            return TournamentStatus.INVALID_INPUT;
        return inWriteTransaction("Could not change tournament state", () -> {
            ClanTournament tournament = readTournament(tournamentId).orElse(null);
            if (tournament == null) return TournamentStatus.NOT_FOUND;
            if ("FINISHED".equals(tournament.state()) || "CANCELLED".equals(tournament.state()))
                return TournamentStatus.STATE_CONFLICT;
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_tournaments SET state = ?, registration_closes_at = COALESCE(registration_closes_at, ?),
                        voting_closes_at = COALESCE(voting_closes_at, ?)
                    WHERE tournament_id = ? AND state = ?
                    """)) {
                String closes = now.plusSeconds(tournament.voteDurationMinutes() * 60L).toString();
                update.setString(1, state);
                update.setString(2, "REGISTRATION_CLOSED".equals(state) ? now.toString() : null);
                update.setString(3, "REGISTRATION_CLOSED".equals(state) ? closes : null);
                update.setString(4, tournamentId.toString()); update.setString(5, tournament.state());
                if (update.executeUpdate() != 1)
                    return TournamentStatus.STATE_CONFLICT;
            }
            appendTournamentEvent(tournamentId, "STATE_" + state, actorId, "state", now);
            return TournamentStatus.UPDATED;
        });
    }

    private Optional<ClanTournament> readTournament(UUID tournamentId) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT * FROM clan_tournaments WHERE tournament_id = ?")) {
            query.setString(1, tournamentId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(readTournamentRow(row)) : Optional.empty();
            }
        }
    }

    private static ClanTournament readTournamentRow(ResultSet row) throws SQLException {
        String registrationCloses = row.getString("registration_closes_at");
        String votingCloses = row.getString("voting_closes_at");
        String winner = row.getString("winner_clan_id");
        String endedAt = row.getString("ended_at");
        return new ClanTournament(UUID.fromString(row.getString("tournament_id")),
                row.getString("discipline"), row.getString("name"), row.getString("state"),
                row.getInt("team_size"), UUID.fromString(row.getString("created_by")),
                Instant.parse(row.getString("created_at")),
                registrationCloses == null ? null : Instant.parse(registrationCloses),
                votingCloses == null ? null : Instant.parse(votingCloses),
                row.getInt("vote_minimum"), row.getInt("vote_duration_minutes"),
                row.getString("vote_permission"), row.getInt("vote_points"),
                row.getInt("vote_allow_abstain") == 1, row.getInt("vote_hide_results") == 1,
                winner == null ? null : UUID.fromString(winner),
                endedAt == null ? null : Instant.parse(endedAt));
    }

    private void appendTournamentEvent(UUID tournamentId, String eventType, UUID actorId, String details,
            Instant now) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_tournament_events(tournament_id, event_type, actor_id, details, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, tournamentId.toString()); insert.setString(2, eventType);
            insert.setString(3, actorId == null ? null : actorId.toString());
            insert.setString(4, details); insert.setString(5, now.toString());
            insert.executeUpdate();
        }
    }

    /**
     * Deletes a clan at the leader's confirmed request. The specification makes deletion
     * irreversible: no money, items or upgrades are returned. Every owned row is removed in one
     * transaction, including wars, rewards and quests that do not cascade automatically.
     */
    public synchronized boolean deleteClan(UUID clanId, UUID leaderId, Instant now) {
        ensureOpen();
        if (clanId == null || leaderId == null || now == null) return false;
        return inWriteTransaction("Could not delete clan", () -> {
            if (!"LEADER".equals(clanMemberRole(clanId, leaderId))) return false;
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString())) return false;
            String id = clanId.toString();
            // Immutable history (journals, receipts, wars) is never deleted: it is the audit trail
            // the specification keeps after deletion. Active state is removed, the clan row becomes
            // a tombstone so foreign keys stay valid and backups remain meaningful.
            try (PreparedStatement cancel = connection.prepareStatement("""
                    UPDATE clan_wars SET state = 'CANCELLED', outcome = 'CANCELLED', ended_at = ?,
                        revision = revision + 1
                    WHERE (attacker_clan_id = ? OR defender_clan_id = ?) AND state IN ('PENDING', 'ACTIVE')
                    """)) {
                cancel.setString(1, now.toString()); cancel.setString(2, id); cancel.setString(3, id);
                cancel.executeUpdate();
            }
            // Home points are closed with an explicit DELETE event so their append-only history stays
            // consistent while the point itself disappears.
            for (ClanHomePoint point : findClanHomePoints(clanId)) {
                insertClanHomeEvent(clanId, point.slot(), leaderId, ClanHomeEventType.DELETE,
                        point.name(), point.worldId(), point.x(), point.y(), point.z(),
                        point.yaw(), point.pitch(), now);
            }
            for (String sql : List.of(
                    "DELETE FROM clan_members WHERE clan_id = ?",
                    "DELETE FROM clan_home_points WHERE clan_id = ?",
                    "DELETE FROM clan_home_slots WHERE clan_id = ?",
                    "DELETE FROM clan_chat_mutes WHERE clan_id = ?",
                    "DELETE FROM clan_bank_reservations WHERE clan_id = ?",
                    "DELETE FROM clan_bank_accounts WHERE clan_id = ?")) {
                String table = sql.substring("DELETE FROM ".length(), sql.indexOf(" WHERE"));
                if (!tableExists(table)) continue;
                try (PreparedStatement delete = connection.prepareStatement(sql)) {
                    delete.setString(1, id);
                    delete.executeUpdate();
                }
            }
            // Rows with append-only histories are expired instead of deleted, preserving the trail.
            try (PreparedStatement quests = connection.prepareStatement("""
                    UPDATE clan_quests SET status = 'EXPIRED' WHERE clan_id = ? AND status = 'ACTIVE'
                    """)) {
                quests.setString(1, id); quests.executeUpdate();
            }
            try (PreparedStatement rewards = connection.prepareStatement("""
                    UPDATE clan_reward_requests SET status = 'EXPIRED', decided_at = NULL
                    WHERE clan_id = ? AND status = 'PENDING'
                    """)) {
                rewards.setString(1, id); rewards.executeUpdate();
            }
            // Storage pages keep their last consistent snapshot: the page revision and its content
            // history must stay equal, and the tombstoned clan no longer exposes the GUI.
            try (PreparedStatement tombstone = connection.prepareStatement("""
                    UPDATE clans SET name = 'Deleted clan', tag = ?, tag_key = ?, revision = revision + 1
                    WHERE id = ?
                    """)) {
                String suffix = id.replace("-", "").substring(0, 8).toUpperCase(java.util.Locale.ROOT);
                tombstone.setString(1, "DEL" + suffix.substring(0, 2));
                tombstone.setString(2, "deleted:" + id);
                tombstone.setString(3, id);
                if (tombstone.executeUpdate() != 1) throw new StorageException("Clan disappeared during deletion");
            }
            appendClanDeletionAudit(clanId, leaderId, now);
            return true;
        });
    }

    private void appendClanDeletionAudit(UUID clanId, UUID actorId, Instant now) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_admin_audit(event_type, clan_id, actor_id, details, occurred_at)
                VALUES ('CLAN_DELETED', ?, ?, ?, ?)
                """)) {
            insert.setString(1, clanId.toString());
            insert.setString(2, actorId == null ? null : actorId.toString());
            insert.setString(3, "irreversible deletion by leader");
            insert.setString(4, now.toString());
            insert.executeUpdate();
        }
    }

    private boolean tableExists(String table) throws SQLException {
        return exists("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", table);
    }

    public synchronized BigDecimal clanBankBalance(UUID clanId) {
        ensureOpen();
        if (clanId == null) throw new IllegalArgumentException("clanId is required");
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT balance FROM clan_bank_accounts WHERE clan_id = ?")) {
            statement.setString(1, clanId.toString());
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? new BigDecimal(result.getString(1)) : BigDecimal.ZERO;
            }
        } catch (SQLException | NumberFormatException exception) {
            throw storageFailure("Could not read clan bank balance", exception);
        }
    }

    /** Returns spendable bank funds after outstanding withdrawal reservations. */
    public synchronized BigDecimal clanBankAvailableBalance(UUID clanId) {
        ensureOpen();
        if (clanId == null) throw new IllegalArgumentException("clanId is required");
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT balance, reserved_balance FROM clan_bank_accounts WHERE clan_id = ?")) {
            statement.setString(1, clanId.toString());
            try (ResultSet row = statement.executeQuery()) {
                if (!row.next()) return BigDecimal.ZERO;
                BigDecimal available = new BigDecimal(row.getString("balance"))
                        .subtract(new BigDecimal(row.getString("reserved_balance")));
                if (available.signum() < 0) throw new StorageException("Clan bank reserved balance exceeds its balance");
                return available;
            }
        } catch (SQLException | NumberFormatException exception) {
            throw storageFailure("Could not read available clan bank balance", exception);
        }
    }

    /**
     * Applies an already-authorized local bank movement atomically with its immutable ledger row.
     * External Vault calls must be coordinated by a separate durable operation journal.
     */
    public synchronized ClanBankMovementResult recordClanBankMovement(
            UUID transactionId, String idempotencyKey, UUID clanId, UUID actorId,
            String transactionType, BigDecimal signedAmount, String reason, UUID approvedBy, Instant occurredAt) {
        ensureOpen();
        if (transactionId == null || clanId == null || actorId == null || occurredAt == null
                || idempotencyKey == null || idempotencyKey.isBlank() || transactionType == null
                || signedAmount == null || signedAmount.signum() == 0
                || !Set.of("DEPOSIT", "WITHDRAWAL", "REWARD", "QUEST_REWARD", "WAR_FUND", "WAR_PRIZE", "ADJUSTMENT").contains(transactionType)) {
            throw new IllegalArgumentException("Invalid clan bank movement");
        }
        if ((Set.of("DEPOSIT", "QUEST_REWARD", "WAR_PRIZE").contains(transactionType) && signedAmount.signum() < 0)
                || (Set.of("WITHDRAWAL", "REWARD", "WAR_FUND").contains(transactionType) && signedAmount.signum() > 0)) {
            throw new IllegalArgumentException("Bank movement sign does not match transaction type");
        }
        BigDecimal amount = signedAmount.stripTrailingZeros();
        if (amount.scale() > 8) throw new IllegalArgumentException("Bank amount supports at most 8 decimal places");
        String amountText = amount.toPlainString();
        return inWriteTransaction("Could not record clan bank movement", () -> {
            try (PreparedStatement existing = connection.prepareStatement(
                    "SELECT transaction_id, clan_id, actor_id, transaction_type, amount, balance_after, reason, approved_by FROM clan_bank_transactions WHERE idempotency_key = ?")) {
                existing.setString(1, idempotencyKey);
                try (ResultSet result = existing.executeQuery()) {
                    if (result.next()) {
                        boolean same = result.getString("clan_id").equals(clanId.toString())
                                && result.getString("actor_id").equals(actorId.toString())
                                && result.getString("transaction_type").equals(transactionType)
                                && new BigDecimal(result.getString("amount")).compareTo(amount) == 0
                                && Objects.equals(result.getString("approved_by"), approvedBy == null ? null : approvedBy.toString());
                        return new ClanBankMovementResult(same ? ClanBankMovementStatus.DUPLICATE : ClanBankMovementStatus.IDEMPOTENCY_CONFLICT,
                                same ? new BigDecimal(result.getString("balance_after")) : null);
                    }
                }
            }
            try (PreparedStatement clan = connection.prepareStatement("SELECT 1 FROM clans WHERE id = ?")) {
                clan.setString(1, clanId.toString());
                try (ResultSet result = clan.executeQuery()) {
                    if (!result.next()) return new ClanBankMovementResult(ClanBankMovementStatus.CLAN_NOT_FOUND, null);
                }
            }
            String currentText = readBankBalance(clanId);
            BigDecimal next = new BigDecimal(currentText).add(amount);
            BigDecimal reserved = new BigDecimal(readBankReservedBalance(clanId));
            if (next.compareTo(reserved) < 0)
                return new ClanBankMovementResult(ClanBankMovementStatus.INSUFFICIENT_BANK_FUNDS, new BigDecimal(currentText));
            String nextText = next.stripTrailingZeros().toPlainString();
            try (PreparedStatement account = connection.prepareStatement("""
                    INSERT INTO clan_bank_accounts(clan_id, balance, revision, updated_at) VALUES (?, ?, 1, ?)
                    ON CONFLICT(clan_id) DO UPDATE SET balance = excluded.balance,
                        revision = clan_bank_accounts.revision + 1, updated_at = excluded.updated_at
                    """)) {
                account.setString(1, clanId.toString()); account.setString(2, nextText); account.setString(3, occurredAt.toString());
                account.executeUpdate();
            }
            try (PreparedStatement ledger = connection.prepareStatement("""
                    INSERT INTO clan_bank_transactions(transaction_id, idempotency_key, clan_id, actor_id,
                        transaction_type, amount, balance_after, reason, approved_by, occurred_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                ledger.setString(1, transactionId.toString()); ledger.setString(2, idempotencyKey);
                ledger.setString(3, clanId.toString()); ledger.setString(4, actorId.toString());
                ledger.setString(5, transactionType); ledger.setString(6, amountText); ledger.setString(7, nextText);
                ledger.setString(8, reason); ledger.setString(9, approvedBy == null ? null : approvedBy.toString());
                ledger.setString(10, occurredAt.toString()); ledger.executeUpdate();
            }
            return new ClanBankMovementResult(ClanBankMovementStatus.APPLIED, next);
        });
    }

    /**
     * Creates a durable bank transfer intent. Withdrawals reserve local bank funds in the same
     * transaction; no external provider is called by this method.
     */
    public synchronized ClanBankOperationResult prepareClanBankOperation(
            UUID operationId, String idempotencyKey, UUID businessOperationId, UUID clanId,
            UUID actorId, UUID beneficiaryId, UUID requestId, String operationType,
            BigDecimal amount, Instant now) {
        ensureOpen();
        if (operationId == null || idempotencyKey == null || idempotencyKey.isBlank()
                || businessOperationId == null || clanId == null || actorId == null || beneficiaryId == null
                || now == null || amount == null || amount.signum() <= 0
                || operationType == null || !Set.of("DEPOSIT", "WITHDRAWAL", "LEADER_WITHDRAWAL").contains(operationType))
            throw new IllegalArgumentException("Invalid clan bank operation intent");
        BigDecimal normalized = amount.stripTrailingZeros();
        if (normalized.scale() > 8) throw new IllegalArgumentException("Bank amount supports at most 8 decimal places");
        if ((operationType.equals("DEPOSIT") && (requestId != null || !actorId.equals(beneficiaryId)))
                || (operationType.equals("WITHDRAWAL") && requestId == null)
                || (operationType.equals("LEADER_WITHDRAWAL") && (requestId != null || !actorId.equals(beneficiaryId))))
            throw new IllegalArgumentException("Bank operation participants do not match its type");
        return inWriteTransaction("Could not prepare clan bank operation", () -> {
            ClanBankOperation businessDuplicate = readClanBankOperationByBusinessId(businessOperationId).orElse(null);
            if (businessDuplicate != null) {
                boolean sameBusinessPayload = businessDuplicate.clanId().equals(clanId)
                        && businessDuplicate.actorId().equals(actorId)
                        && businessDuplicate.beneficiaryId().equals(beneficiaryId)
                        && Objects.equals(businessDuplicate.requestId(), requestId)
                        && businessDuplicate.operationType().equals(operationType)
                        && businessDuplicate.amount().compareTo(normalized) == 0;
                return new ClanBankOperationResult(sameBusinessPayload ? ClanBankOperationStatus.DUPLICATE
                        : ClanBankOperationStatus.BUSINESS_OPERATION_CONFLICT, businessDuplicate);
            }
            ClanBankOperation duplicate = readClanBankOperationByKey(idempotencyKey).orElse(null);
            if (duplicate != null) {
                boolean same = duplicate.businessOperationId().equals(businessOperationId)
                        && duplicate.clanId().equals(clanId) && duplicate.actorId().equals(actorId)
                        && duplicate.beneficiaryId().equals(beneficiaryId)
                        && Objects.equals(duplicate.requestId(), requestId)
                        && duplicate.operationType().equals(operationType)
                        && duplicate.amount().compareTo(normalized) == 0;
                return new ClanBankOperationResult(same ? ClanBankOperationStatus.DUPLICATE
                        : ClanBankOperationStatus.IDEMPOTENCY_CONFLICT, duplicate);
            }
            try (PreparedStatement clan = connection.prepareStatement("SELECT 1 FROM clans WHERE id = ?")) {
                clan.setString(1, clanId.toString());
                try (ResultSet row = clan.executeQuery()) {
                    if (!row.next()) return new ClanBankOperationResult(ClanBankOperationStatus.CLAN_NOT_FOUND, null);
                }
            }
            try (PreparedStatement role = connection.prepareStatement(
                    "SELECT role FROM clan_members WHERE clan_id = ? AND player_id = ?")) {
                role.setString(1, clanId.toString()); role.setString(2, actorId.toString());
                try (ResultSet row = role.executeQuery()) {
                    String roleName = row.next() ? row.getString(1) : null;
                    if (roleName == null || (operationType.equals("WITHDRAWAL") || operationType.equals("LEADER_WITHDRAWAL"))
                            && !"LEADER".equals(roleName))
                        return new ClanBankOperationResult(ClanBankOperationStatus.NOT_AUTHORIZED, null);
                }
            }
            if (operationType.equals("DEPOSIT") || operationType.equals("LEADER_WITHDRAWAL")) {
                try (PreparedStatement active = connection.prepareStatement("""
                        SELECT operation_id FROM clan_bank_operations
                        WHERE clan_id = ? AND actor_id = ? AND operation_type = ?
                          AND state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'UNKNOWN')
                        ORDER BY created_at DESC LIMIT 1
                        """)) {
                    active.setString(1, clanId.toString()); active.setString(2, actorId.toString());
                    active.setString(3, operationType);
                    try (ResultSet row = active.executeQuery()) {
                        if (row.next()) return new ClanBankOperationResult(ClanBankOperationStatus.ACTOR_OPERATION_IN_PROGRESS,
                                readClanBankOperation(UUID.fromString(row.getString(1))).orElse(null));
                    }
                }
            }
            String reason = null;
            if (operationType.equals("WITHDRAWAL")) {
                ClanBankWithdrawalRequest request = readBankWithdrawalRequest(requestId).orElse(null);
                if (request == null || !request.clanId().equals(clanId)
                        || !request.beneficiaryId().equals(beneficiaryId)
                        || request.status() != ClanBankWithdrawalRequestStatus.APPROVED
                        || request.amount().compareTo(normalized) != 0)
                    return new ClanBankOperationResult(ClanBankOperationStatus.REQUEST_NOT_APPROVED, null);
                try (PreparedStatement linked = connection.prepareStatement(
                        "SELECT payment_operation_id FROM clan_bank_withdrawal_requests WHERE request_id = ?")) {
                    linked.setString(1, requestId.toString());
                    try (ResultSet row = linked.executeQuery()) {
                        if (!row.next()) return new ClanBankOperationResult(ClanBankOperationStatus.REQUEST_NOT_APPROVED, null);
                        String previousOperationId = row.getString(1);
                        if (previousOperationId != null) {
                            ClanBankOperation previous = readClanBankOperation(UUID.fromString(previousOperationId)).orElse(null);
                            if (previous == null || previous.state() != ClanBankOperationState.FAILED_NO_EFFECT)
                                return new ClanBankOperationResult(ClanBankOperationStatus.REQUEST_ALREADY_LINKED, previous);
                        }
                    }
                }
                try (PreparedStatement beneficiary = connection.prepareStatement(
                        "SELECT 1 FROM clan_members WHERE clan_id = ? AND player_id = ?")) {
                    beneficiary.setString(1, clanId.toString()); beneficiary.setString(2, beneficiaryId.toString());
                    try (ResultSet row = beneficiary.executeQuery()) {
                        if (!row.next()) return new ClanBankOperationResult(ClanBankOperationStatus.REQUEST_NOT_APPROVED, null);
                    }
                }
                reason = request.reason();
            }
            boolean reserve = !operationType.equals("DEPOSIT");
            if (reserve) {
                BigDecimal balance = new BigDecimal(readBankBalance(clanId));
                BigDecimal reserved = new BigDecimal(readBankReservedBalance(clanId));
                if (balance.subtract(reserved).compareTo(normalized) < 0)
                    return new ClanBankOperationResult(ClanBankOperationStatus.INSUFFICIENT_BANK_FUNDS, null);
                writeBankAccount(clanId, balance, reserved.add(normalized), now);
            }
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_bank_operations(operation_id, idempotency_key, business_operation_id, clan_id,
                        actor_id, beneficiary_id, request_id, operation_type, amount, state, diagnostic, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'PREPARED', ?, ?, ?)
                    """)) {
                insert.setString(1, operationId.toString()); insert.setString(2, idempotencyKey);
                insert.setString(3, businessOperationId.toString()); insert.setString(4, clanId.toString());
                insert.setString(5, actorId.toString()); insert.setString(6, beneficiaryId.toString());
                insert.setString(7, requestId == null ? null : requestId.toString()); insert.setString(8, operationType);
                insert.setString(9, normalized.toPlainString()); insert.setString(10, reason);
                insert.setString(11, now.toString()); insert.setString(12, now.toString()); insert.executeUpdate();
            }
            insertClanBankOperationEvent(operationId, null, ClanBankOperationState.PREPARED, "INTENT_RECORDED", now);
            if (reserve) {
                try (PreparedStatement reservation = connection.prepareStatement("""
                        INSERT INTO clan_bank_reservations(operation_id, clan_id, amount, state, created_at, updated_at)
                        VALUES (?, ?, ?, 'RESERVED', ?, ?)
                        """)) {
                    reservation.setString(1, operationId.toString()); reservation.setString(2, clanId.toString());
                    reservation.setString(3, normalized.toPlainString()); reservation.setString(4, now.toString());
                    reservation.setString(5, now.toString()); reservation.executeUpdate();
                }
            }
            if (requestId != null) {
                try (PreparedStatement link = connection.prepareStatement("""
                        UPDATE clan_bank_withdrawal_requests SET payment_operation_id = ?
                        WHERE request_id = ? AND status = 'APPROVED'
                          AND (payment_operation_id IS NULL OR payment_operation_id IN (
                              SELECT operation_id FROM clan_bank_operations WHERE state = 'FAILED_NO_EFFECT'))
                        """)) {
                    link.setString(1, operationId.toString()); link.setString(2, requestId.toString());
                    if (link.executeUpdate() != 1) throw new SQLException("Withdrawal request was linked concurrently");
                }
            }
            return new ClanBankOperationResult(ClanBankOperationStatus.PREPARED,
                    readClanBankOperation(operationId).orElseThrow());
        });
    }

    /** Persist CALLING before the caller is permitted to invoke Vault. */
    public synchronized ClanBankOperationResult transitionClanBankOperation(
            UUID operationId, ClanBankOperationState expected, ClanBankOperationState next,
            String evidence, Instant now) {
        ensureOpen();
        if (operationId == null || expected == null || next == null || now == null
                || evidence == null || evidence.isBlank() || evidence.length() > 900
                || !validClanBankOperationTransition(expected, next))
            throw new IllegalArgumentException("Invalid clan bank operation transition");
        return inWriteTransaction("Could not transition clan bank operation", () -> {
            ClanBankOperation current = readClanBankOperation(operationId).orElse(null);
            if (current == null) return new ClanBankOperationResult(ClanBankOperationStatus.NOT_FOUND, null);
            if (current.state() != expected)
                return new ClanBankOperationResult(ClanBankOperationStatus.STATE_CONFLICT, current);
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_bank_operations SET state = ?, diagnostic = ?, updated_at = ?
                    WHERE operation_id = ? AND state = ?
                    """)) {
                update.setString(1, next.name()); update.setString(2, evidence); update.setString(3, now.toString());
                update.setString(4, operationId.toString()); update.setString(5, expected.name());
                if (update.executeUpdate() != 1) return new ClanBankOperationResult(ClanBankOperationStatus.STATE_CONFLICT,
                        readClanBankOperation(operationId).orElse(null));
            }
            if (next == ClanBankOperationState.FAILED_NO_EFFECT) releaseClanBankReservation(operationId, now);
            insertClanBankOperationEvent(operationId, expected, next, evidence, now);
            return new ClanBankOperationResult(ClanBankOperationStatus.UPDATED,
                    readClanBankOperation(operationId).orElseThrow());
        });
    }

    /** Atomically applies a confirmed external transfer to the local bank and immutable ledger. */
    public synchronized ClanBankOperationResult commitConfirmedClanBankOperation(UUID operationId, Instant now) {
        ensureOpen();
        if (operationId == null || now == null) throw new IllegalArgumentException("operationId and now are required");
        return inWriteTransaction("Could not commit confirmed clan bank operation", () -> {
            ClanBankOperation operation = readClanBankOperation(operationId).orElse(null);
            if (operation == null) return new ClanBankOperationResult(ClanBankOperationStatus.NOT_FOUND, null);
            if (operation.state() == ClanBankOperationState.COMMITTED)
                return new ClanBankOperationResult(ClanBankOperationStatus.DUPLICATE, operation);
            if (operation.state() != ClanBankOperationState.EXTERNAL_CONFIRMED)
                return new ClanBankOperationResult(ClanBankOperationStatus.STATE_CONFLICT, operation);
            BigDecimal balance = new BigDecimal(readBankBalance(operation.clanId()));
            BigDecimal reserved = new BigDecimal(readBankReservedBalance(operation.clanId()));
            BigDecimal amount = operation.amount();
            BigDecimal nextBalance;
            BigDecimal nextReserved = reserved;
            boolean withdrawal = !operation.operationType().equals("DEPOSIT");
            if (withdrawal) {
                if (reserved.compareTo(amount) < 0 || balance.compareTo(amount) < 0)
                    throw new StorageException("Confirmed withdrawal has no matching bank reservation");
                nextBalance = balance.subtract(amount);
                nextReserved = reserved.subtract(amount);
                consumeClanBankReservation(operationId, now);
            } else {
                nextBalance = balance.add(amount);
            }
            writeBankAccount(operation.clanId(), nextBalance, nextReserved, now);
            String reason = operation.requestId() == null ? null
                    : readBankWithdrawalRequest(operation.requestId()).map(ClanBankWithdrawalRequest::reason).orElse(null);
            String ledgerType = withdrawal ? "WITHDRAWAL" : "DEPOSIT";
            String signedAmount = (withdrawal ? amount.negate() : amount).stripTrailingZeros().toPlainString();
            try (PreparedStatement ledger = connection.prepareStatement("""
                    INSERT INTO clan_bank_transactions(transaction_id, idempotency_key, clan_id, actor_id,
                        transaction_type, amount, balance_after, reason, approved_by, occurred_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                ledger.setString(1, operationId.toString()); ledger.setString(2, "bank-operation:" + operationId);
                ledger.setString(3, operation.clanId().toString()); ledger.setString(4, operation.actorId().toString());
                ledger.setString(5, ledgerType); ledger.setString(6, signedAmount);
                ledger.setString(7, nextBalance.stripTrailingZeros().toPlainString()); ledger.setString(8, reason);
                ledger.setString(9, withdrawal ? operation.actorId().toString() : null);
                ledger.setString(10, now.toString()); ledger.executeUpdate();
            }
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_bank_operations SET state = 'COMMITTED', updated_at = ?
                    WHERE operation_id = ? AND state = 'EXTERNAL_CONFIRMED'
                    """)) {
                update.setString(1, now.toString()); update.setString(2, operationId.toString());
                if (update.executeUpdate() != 1) throw new SQLException("Confirmed bank operation changed during commit");
            }
            insertClanBankOperationEvent(operationId, ClanBankOperationState.EXTERNAL_CONFIRMED,
                    ClanBankOperationState.COMMITTED, "LOCAL_BANK_COMMIT", now);
            return new ClanBankOperationResult(ClanBankOperationStatus.COMMITTED,
                    readClanBankOperation(operationId).orElseThrow());
        });
    }

    /** Reconciles UNKNOWN only from explicit operator evidence; never calls the provider. */
    public synchronized ClanBankOperationResult reconcileUnknownClanBankOperation(
            UUID operationId, boolean externalEffectConfirmed, String evidence, Instant now) {
        if (evidence == null || evidence.isBlank() || evidence.length() > 870)
            return new ClanBankOperationResult(ClanBankOperationStatus.INVALID_EVIDENCE, null);
        var transition = transitionClanBankOperation(operationId, ClanBankOperationState.UNKNOWN,
                externalEffectConfirmed ? ClanBankOperationState.EXTERNAL_CONFIRMED : ClanBankOperationState.FAILED_NO_EFFECT,
                "CONSOLE_RECONCILIATION: " + evidence, now);
        if (transition.status() != ClanBankOperationStatus.UPDATED) return transition;
        return externalEffectConfirmed ? commitConfirmedClanBankOperation(operationId, now) : transition;
    }

    /**
     * Restart policy: PREPARED is safe to abandon, CALLING becomes UNKNOWN, and a previously
     * confirmed external effect is completed locally. No provider call is repeated.
     */
    public synchronized List<ClanBankOperationResult> recoverClanBankOperationsAfterRestart(Instant now) {
        ensureOpen();
        List<ClanBankOperation> unresolved = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT operation_id FROM clan_bank_operations
                WHERE state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'UNKNOWN') ORDER BY created_at, operation_id
                """); ResultSet rows = statement.executeQuery()) {
            while (rows.next()) readClanBankOperation(UUID.fromString(rows.getString(1))).ifPresent(unresolved::add);
        } catch (SQLException exception) {
            throw storageFailure("Could not enumerate clan bank operations for recovery", exception);
        }
        List<ClanBankOperationResult> results = new ArrayList<>();
        for (ClanBankOperation operation : unresolved) {
            switch (operation.state()) {
                case PREPARED -> results.add(transitionClanBankOperation(operation.operationId(),
                        ClanBankOperationState.PREPARED, ClanBankOperationState.FAILED_NO_EFFECT,
                        "RESTART_BEFORE_EXTERNAL_CALL", now));
                case CALLING -> results.add(transitionClanBankOperation(operation.operationId(),
                        ClanBankOperationState.CALLING, ClanBankOperationState.UNKNOWN,
                        "RESTART_DURING_EXTERNAL_CALL_REQUIRES_RECONCILIATION", now));
                case EXTERNAL_CONFIRMED -> results.add(commitConfirmedClanBankOperation(operation.operationId(), now));
                case UNKNOWN -> results.add(new ClanBankOperationResult(
                        ClanBankOperationStatus.MANUAL_RECONCILIATION_REQUIRED, operation));
                default -> { }
            }
        }
        return List.copyOf(results);
    }

    public synchronized Optional<ClanBankOperation> findClanBankOperation(UUID operationId) {
        ensureOpen();
        try { return readClanBankOperation(operationId); }
        catch (SQLException | RuntimeException exception) { throw storageFailure("Could not read clan bank operation", exception); }
    }

    private Optional<ClanBankOperation> readClanBankOperationByBusinessId(UUID businessId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT operation_id FROM clan_bank_operations WHERE business_operation_id = ? AND state <> 'FAILED_NO_EFFECT'")) {
            statement.setString(1, businessId.toString());
            try (ResultSet row = statement.executeQuery()) {
                return row.next() ? readClanBankOperation(UUID.fromString(row.getString(1))) : Optional.empty();
            }
        }
    }

    private Optional<ClanBankOperation> readClanBankOperationByKey(String key) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT operation_id FROM clan_bank_operations WHERE idempotency_key = ?")) {
            statement.setString(1, key);
            try (ResultSet row = statement.executeQuery()) {
                return row.next() ? readClanBankOperation(UUID.fromString(row.getString(1))) : Optional.empty();
            }
        }
    }

    private Optional<ClanBankOperation> readClanBankOperation(UUID id) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT operation_id, idempotency_key, business_operation_id, clan_id, actor_id, beneficiary_id,
                    request_id, operation_type, amount, state, diagnostic, created_at, updated_at
                FROM clan_bank_operations WHERE operation_id = ?
                """)) {
            statement.setString(1, id.toString());
            try (ResultSet row = statement.executeQuery()) {
                if (!row.next()) return Optional.empty();
                return Optional.of(new ClanBankOperation(UUID.fromString(row.getString("operation_id")),
                        row.getString("idempotency_key"), UUID.fromString(row.getString("business_operation_id")),
                        UUID.fromString(row.getString("clan_id")), UUID.fromString(row.getString("actor_id")),
                        UUID.fromString(row.getString("beneficiary_id")), row.getString("request_id") == null ? null : UUID.fromString(row.getString("request_id")),
                        row.getString("operation_type"), new BigDecimal(row.getString("amount")),
                        ClanBankOperationState.valueOf(row.getString("state")), row.getString("diagnostic"),
                        Instant.parse(row.getString("created_at")), Instant.parse(row.getString("updated_at"))));
            }
        }
    }

    private void insertClanBankOperationEvent(UUID operationId, ClanBankOperationState from,
            ClanBankOperationState to, String evidence, Instant at) throws SQLException {
        try (PreparedStatement event = connection.prepareStatement("""
                INSERT INTO clan_bank_operation_events(operation_id, from_state, to_state, evidence, occurred_at)
                VALUES (?, ?, ?, ?, ?)
                """)) {
            event.setString(1, operationId.toString()); event.setString(2, from == null ? null : from.name());
            event.setString(3, to.name()); event.setString(4, evidence); event.setString(5, at.toString()); event.executeUpdate();
        }
    }

    private void releaseClanBankReservation(UUID operationId, Instant now) throws SQLException {
        try (PreparedStatement reservation = connection.prepareStatement(
                "SELECT clan_id, amount, state FROM clan_bank_reservations WHERE operation_id = ?")) {
            reservation.setString(1, operationId.toString());
            try (ResultSet row = reservation.executeQuery()) {
                if (!row.next() || !"RESERVED".equals(row.getString("state"))) return;
                UUID clanId = UUID.fromString(row.getString("clan_id"));
                BigDecimal amount = new BigDecimal(row.getString("amount"));
                BigDecimal balance = new BigDecimal(readBankBalance(clanId));
                BigDecimal reserved = new BigDecimal(readBankReservedBalance(clanId));
                if (reserved.compareTo(amount) < 0) throw new SQLException("Bank reservation aggregate is inconsistent");
                writeBankAccount(clanId, balance, reserved.subtract(amount), now);
            }
        }
        try (PreparedStatement update = connection.prepareStatement(
                "UPDATE clan_bank_reservations SET state = 'RELEASED', updated_at = ? WHERE operation_id = ? AND state = 'RESERVED'")) {
            update.setString(1, now.toString()); update.setString(2, operationId.toString()); update.executeUpdate();
        }
    }

    private void consumeClanBankReservation(UUID operationId, Instant now) throws SQLException {
        try (PreparedStatement update = connection.prepareStatement(
                "UPDATE clan_bank_reservations SET state = 'CONSUMED', updated_at = ? WHERE operation_id = ? AND state = 'RESERVED'")) {
            update.setString(1, now.toString()); update.setString(2, operationId.toString());
            if (update.executeUpdate() != 1) throw new SQLException("Missing active bank reservation");
        }
    }

    private void writeBankAccount(UUID clanId, BigDecimal balance, BigDecimal reserved, Instant now) throws SQLException {
        if (balance.signum() < 0 || reserved.signum() < 0 || reserved.compareTo(balance) > 0)
            throw new SQLException("Invalid clan bank balance/reservation totals");
        try (PreparedStatement update = connection.prepareStatement("""
                INSERT INTO clan_bank_accounts(clan_id, balance, reserved_balance, revision, updated_at)
                VALUES (?, ?, ?, 1, ?)
                ON CONFLICT(clan_id) DO UPDATE SET balance = excluded.balance,
                    reserved_balance = excluded.reserved_balance, revision = clan_bank_accounts.revision + 1,
                    updated_at = excluded.updated_at
                """)) {
            update.setString(1, clanId.toString()); update.setString(2, balance.stripTrailingZeros().toPlainString());
            update.setString(3, reserved.stripTrailingZeros().toPlainString()); update.setString(4, now.toString());
            update.executeUpdate();
        }
    }

    private String readBankReservedBalance(UUID clanId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT reserved_balance FROM clan_bank_accounts WHERE clan_id = ?")) {
            statement.setString(1, clanId.toString());
            try (ResultSet row = statement.executeQuery()) { return row.next() ? row.getString(1) : "0"; }
        }
    }

    private static boolean validClanBankOperationTransition(ClanBankOperationState from, ClanBankOperationState to) {
        return switch (from) {
            case PREPARED -> to == ClanBankOperationState.CALLING || to == ClanBankOperationState.FAILED_NO_EFFECT;
            case CALLING -> to == ClanBankOperationState.EXTERNAL_CONFIRMED
                    || to == ClanBankOperationState.FAILED_NO_EFFECT || to == ClanBankOperationState.UNKNOWN;
            case EXTERNAL_CONFIRMED -> to == ClanBankOperationState.COMMITTED;
            case UNKNOWN -> to == ClanBankOperationState.EXTERNAL_CONFIRMED || to == ClanBankOperationState.FAILED_NO_EFFECT;
            case COMMITTED, FAILED_NO_EFFECT -> false;
        };
    }

    public enum ClanBankOperationState { PREPARED, CALLING, EXTERNAL_CONFIRMED, COMMITTED, FAILED_NO_EFFECT, UNKNOWN }
    public enum ClanBankOperationStatus {
        PREPARED, UPDATED, COMMITTED, DUPLICATE, IDEMPOTENCY_CONFLICT, CLAN_NOT_FOUND,
        INSUFFICIENT_BANK_FUNDS, REQUEST_NOT_APPROVED, REQUEST_ALREADY_LINKED, NOT_AUTHORIZED,
        ACTOR_OPERATION_IN_PROGRESS, BUSINESS_OPERATION_CONFLICT, NOT_FOUND, STATE_CONFLICT, INVALID_EVIDENCE, MANUAL_RECONCILIATION_REQUIRED
    }
    public record ClanBankOperation(UUID operationId, String idempotencyKey, UUID businessOperationId,
            UUID clanId, UUID actorId, UUID beneficiaryId, UUID requestId, String operationType,
            BigDecimal amount, ClanBankOperationState state, String diagnostic, Instant createdAt, Instant updatedAt) { }
    public record ClanBankOperationResult(ClanBankOperationStatus status, ClanBankOperation operation) { }

    /** Returns recent immutable bank ledger entries, newest first. */
    public synchronized List<ClanBankTransaction> findClanBankTransactions(UUID clanId, int limit) {
        ensureOpen();
        if (clanId == null || limit < 1 || limit > 100)
            throw new IllegalArgumentException("clanId is required and limit must be between 1 and 100");
        List<ClanBankTransaction> transactions = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT transaction_id, actor_id, transaction_type, amount, balance_after, reason, approved_by, occurred_at
                FROM clan_bank_transactions WHERE clan_id = ? ORDER BY occurred_at DESC, transaction_id DESC LIMIT ?
                """)) {
            statement.setString(1, clanId.toString()); statement.setInt(2, limit);
            try (ResultSet rows = statement.executeQuery()) {
                while (rows.next()) transactions.add(new ClanBankTransaction(
                        UUID.fromString(rows.getString("transaction_id")), UUID.fromString(rows.getString("actor_id")),
                        rows.getString("transaction_type"), new BigDecimal(rows.getString("amount")),
                        new BigDecimal(rows.getString("balance_after")), rows.getString("reason"),
                        rows.getString("approved_by") == null ? null : UUID.fromString(rows.getString("approved_by")),
                        Instant.parse(rows.getString("occurred_at"))));
            }
            return List.copyOf(transactions);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan bank transaction history", exception);
        }
    }

    public record ClanBankTransaction(UUID transactionId, UUID actorId, String transactionType,
            BigDecimal amount, BigDecimal balanceAfter, String reason, UUID approvedBy, Instant occurredAt) { }

    private String readBankBalance(UUID clanId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT balance FROM clan_bank_accounts WHERE clan_id = ?")) {
            statement.setString(1, clanId.toString());
            try (ResultSet result = statement.executeQuery()) { return result.next() ? result.getString(1) : "0"; }
        }
    }

    public enum ClanBankMovementStatus { APPLIED, DUPLICATE, IDEMPOTENCY_CONFLICT, CLAN_NOT_FOUND, INSUFFICIENT_BANK_FUNDS }
    public record ClanBankMovementResult(ClanBankMovementStatus status, BigDecimal balance) { }

    @Override
    public synchronized Optional<Clan> findById(UUID clanId) {
        ensureOpen();
        if (clanId == null) {
            return Optional.empty();
        }
        try {
            if (isTombstonedClan(clanId)) return Optional.empty();
            return readClan(clanId).map(StoredClan::clan);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan by id", exception);
        }
    }

        /**
         * Returns the revision number of the clan with the given id.
         * The revision is incremented on each successful capacity purchase commit.
         * Returns empty if the clan does not exist.
         */
        public synchronized Optional<Long> findRevision(UUID clanId) {
            ensureOpen();
            if (clanId == null) {
                return Optional.empty();
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT revision FROM clans WHERE id = ?")) {
                statement.setString(1, clanId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    if (result.next()) {
                        return Optional.of(result.getLong("revision"));
                    }
                    return Optional.empty();
                }
            } catch (SQLException | RuntimeException exception) {
                throw storageFailure("Could not read clan revision by id", exception);
            }
        }

        @Override
        public synchronized Optional<Clan> findByTag(String tag) {
        ensureOpen();
        if (tag == null) {
            return Optional.empty();
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT id FROM clans WHERE tag_key = ?")) {
            statement.setString(1, normalizeTag(tag));
            try (ResultSet result = statement.executeQuery()) {
                return result.next()
                        ? readClan(UUID.fromString(result.getString(1))).map(StoredClan::clan)
                        : Optional.empty();
            }
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan by tag", exception);
        }
    }

    @Override
    public synchronized Optional<Clan> findByPlayerId(UUID playerId) {
        ensureOpen();
        if (playerId == null) {
            return Optional.empty();
        }
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT clan_id FROM clan_members WHERE player_id = ?")) {
            statement.setString(1, playerId.toString());
            try (ResultSet result = statement.executeQuery()) {
                return result.next()
                        ? readClan(UUID.fromString(result.getString(1))).map(StoredClan::clan)
                        : Optional.empty();
            }
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan by member id", exception);
        }
    }

    @Override
    public synchronized CreateStatus createRequest(ClanRequest request) {
        ensureOpen();
        if (request == null || request.status() != ClanRequest.Status.PENDING) {
            return CreateStatus.INVALID_REQUEST;
        }
        return inWriteTransaction("Could not create clan request", () -> {
            expireStaleClanRequests(request.createdAt());
            Optional<StoredClan> stored = readClan(request.clanId());
            if (stored.isEmpty()) return CreateStatus.CLAN_NOT_FOUND;
            Clan clan = stored.get().clan();
            if (exists("SELECT 1 FROM clan_elections WHERE clan_id = ? AND phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')", clan.id().toString())) return CreateStatus.ELECTION_ACTIVE;
            if (request.type() == ClanRequest.Type.APPLICATION && !arePublicApplicationsOpen(clan.id())) {
                return CreateStatus.APPLICATIONS_CLOSED;
            }
            if (clan.member(request.playerId()).isPresent()
                    || exists("SELECT 1 FROM clan_members WHERE player_id = ?", request.playerId().toString())) {
                return CreateStatus.PLAYER_ALREADY_IN_CLAN;
            }
            if (clan.memberCount() >= clan.capacity()) return CreateStatus.CLAN_FULL;
            if (request.type() == ClanRequest.Type.INVITATION) {
                var inviter = clan.member(request.actorId()).orElse(null);
                if (inviter == null || (inviter.role() != ClanRole.LEADER && inviter.role() != ClanRole.DEPUTY)) {
                    return CreateStatus.ACTOR_NOT_AUTHORIZED;
                }
            } else if (!request.actorId().equals(request.playerId())) {
                return CreateStatus.INVALID_REQUEST;
            }
            if (exists("SELECT 1 FROM clan_requests WHERE clan_id = ? AND player_id = ? AND request_type = ? AND status = 'PENDING'",
                    request.clanId().toString(), request.playerId().toString(), request.type().name())) {
                return CreateStatus.DUPLICATE_PENDING_REQUEST;
            }
            try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT INTO clan_requests (request_id, request_type, clan_id, player_id,
                        actor_id, created_at, expires_at, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING')
                    """)) {
                statement.setString(1, request.id().toString());
                statement.setString(2, request.type().name());
                statement.setString(3, request.clanId().toString());
                statement.setString(4, request.playerId().toString());
                statement.setString(5, request.actorId().toString());
                statement.setString(6, request.createdAt().toString());
                statement.setString(7, request.expiresAt().toString());
                statement.executeUpdate();
            }
            insertClanRequestEvent(request.id(), request.type(), null,
                    ClanRequest.Status.PENDING, request.actorId(), request.createdAt());
            return CreateStatus.CREATED;
        });
    }

    @Override
    public synchronized List<ClanRequest> listPendingRequestsForPlayer(
            UUID playerId, ClanRequest.Type type, Instant now) {
        ensureOpen();
        if (playerId == null || type == null || now == null) return List.of();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT * FROM clan_requests
                WHERE player_id = ? AND request_type = ? AND status = 'PENDING' AND julianday(expires_at) > julianday(?)
                ORDER BY julianday(created_at), request_id
                """)) {
            statement.setString(1, playerId.toString());
            statement.setString(2, type.name());
            statement.setString(3, now.toString());
            try (ResultSet result = statement.executeQuery()) {
                List<ClanRequest> requests = new ArrayList<>();
                while (result.next()) requests.add(readClanRequest(result));
                return List.copyOf(requests);
            }
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not list player clan requests", exception);
        }
    }

    @Override
    public synchronized List<ClanRequest> listPendingRequests(
            UUID clanId, ClanRequest.Type type, Instant now) {
        ensureOpen();
        if (clanId == null || type == null || now == null) return List.of();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT * FROM clan_requests
                WHERE clan_id = ? AND request_type = ? AND status = 'PENDING' AND julianday(expires_at) > julianday(?)
                ORDER BY julianday(created_at), request_id
                """)) {
            statement.setString(1, clanId.toString());
            statement.setString(2, type.name());
            statement.setString(3, now.toString());
            try (ResultSet result = statement.executeQuery()) {
                List<ClanRequest> requests = new ArrayList<>();
                while (result.next()) requests.add(readClanRequest(result));
                return List.copyOf(requests);
            }
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not list clan requests", exception);
        }
    }

    @Override
    public synchronized ResolveStatus resolveRequest(
            UUID requestId, UUID actorId, boolean accept, Instant now) {
        ensureOpen();
        if (requestId == null || actorId == null || now == null) return ResolveStatus.NOT_FOUND;
        return inWriteTransaction("Could not resolve clan request", () -> {
            ClanRequest request;
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM clan_requests WHERE request_id = ?")) {
                statement.setString(1, requestId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) return ResolveStatus.NOT_FOUND;
                    request = readClanRequest(result);
                }
            }
            if (request.status() != ClanRequest.Status.PENDING) return ResolveStatus.NOT_PENDING;
            if (!request.expiresAt().isAfter(now)) {
                return updateClanRequestStatus(request, ClanRequest.Status.EXPIRED, null, now)
                        ? ResolveStatus.EXPIRED : ResolveStatus.CONCURRENT_MODIFICATION;
            }
            Optional<StoredClan> stored = readClan(request.clanId());
            if (stored.isEmpty()) return ResolveStatus.NOT_FOUND;
            Clan clan = stored.get().clan();
            if (exists("SELECT 1 FROM clan_elections WHERE clan_id = ? AND phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')", clan.id().toString())) return ResolveStatus.ELECTION_ACTIVE;
            if (request.type() == ClanRequest.Type.INVITATION) {
                if (!request.playerId().equals(actorId)) return ResolveStatus.NOT_AUTHORIZED;
            } else {
                var reviewer = clan.member(actorId).orElse(null);
                if (reviewer == null || (reviewer.role() != ClanRole.LEADER
                        && reviewer.role() != ClanRole.DEPUTY)) return ResolveStatus.NOT_AUTHORIZED;
            }
            ClanRequest.Status next = accept ? ClanRequest.Status.ACCEPTED : ClanRequest.Status.DECLINED;
            Clan updated = null;
            if (accept) {
                if (exists("SELECT 1 FROM clan_members WHERE player_id = ?", request.playerId().toString())) {
                    return ResolveStatus.PLAYER_ALREADY_IN_CLAN;
                }
                if (exists("SELECT 1 FROM clan_creation_payment_operations WHERE creator_id = ? AND state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')", request.playerId().toString())) {
                    return ResolveStatus.PLAYER_HAS_PENDING_CREATION;
                }
                if (clan.memberCount() >= clan.capacity()) return ResolveStatus.CLAN_FULL;
                Map<UUID, ClanMember> members = new HashMap<>(clan.members());
                members.put(request.playerId(), new ClanMember(
                        request.playerId(), ClanRole.MEMBER, now, null));
                updated = new Clan(clan.id(), clan.name(), clan.tag(), clan.createdAt(),
                        clan.capacity(), members, clan.totalXp(), clan.tagline());
                if (!new ClanMembershipStateValidator().validate(updated, false).isEmpty()) {
                    throw new StorageException("Clan request would create invalid membership state");
                }
            }
            if (!updateClanRequestStatus(request, next, actorId, now)) {
                return ResolveStatus.CONCURRENT_MODIFICATION;
            }
            if (updated != null) {
                try (PreparedStatement delete = connection.prepareStatement(
                        "DELETE FROM clan_members WHERE clan_id = ?")) {
                    delete.setString(1, clan.id().toString());
                    delete.executeUpdate();
                }
                insertMembers(updated);
                awardMembershipAchievementsInTransaction(clan.id(), now);
            }
            return accept ? ResolveStatus.ACCEPTED : ResolveStatus.DECLINED;
        });
    }

    @Override
    public synchronized boolean arePublicApplicationsOpen(UUID clanId) {
        ensureOpen();
        if (clanId == null) return false;
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT public_applications_open FROM clan_settings WHERE clan_id = ?")) {
            statement.setString(1, clanId.toString());
            try (ResultSet result = statement.executeQuery()) {
                return result.next() && result.getInt(1) == 1;
            }
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan application setting", exception);
        }
    }

    @Override
    public synchronized SettingStatus setPublicApplicationsOpen(
            UUID clanId, UUID actorId, boolean open) {
        ensureOpen();
        if (clanId == null || actorId == null) return SettingStatus.CLAN_NOT_FOUND;
        return inWriteTransaction("Could not update clan application setting", () -> {
            Optional<StoredClan> clan = readClan(clanId);
            if (clan.isEmpty()) return SettingStatus.CLAN_NOT_FOUND;
            if (!isLeader(clan.get().clan(), actorId)) return SettingStatus.NOT_LEADER;
            try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT INTO clan_settings(clan_id, public_applications_open) VALUES (?, ?)
                    ON CONFLICT(clan_id) DO UPDATE SET public_applications_open = excluded.public_applications_open
                    """)) {
                statement.setString(1, clanId.toString());
                statement.setInt(2, open ? 1 : 0);
                statement.executeUpdate();
            }
            return SettingStatus.UPDATED;
        });
    }

    @Override
    public synchronized ClanXpAwardResult awardClanXp(
            UUID clanId, ClanXpEventType type, UUID actorId,
            String idempotencyKey, Instant occurredAt) {
        ensureOpen();
        if (clanId == null || type == null || idempotencyKey == null
                || idempotencyKey.isBlank() || occurredAt == null) {
            return xpResult(ClanXpAwardResult.Status.INVALID_INPUT, null);
        }
        return inWriteTransaction("Could not award clan XP", () ->
                awardClanXpInTransaction(clanId, type, actorId, idempotencyKey, occurredAt));
    }

    private ClanXpAwardResult awardClanXpInTransaction(UUID clanId, ClanXpEventType type,
            UUID actorId, String idempotencyKey, Instant occurredAt) throws SQLException {
        try (PreparedStatement existing = connection.prepareStatement("""
                SELECT clan_id, event_type, actor_id, amount
                FROM clan_xp_events WHERE idempotency_key = ?
                """)) {
            existing.setString(1, idempotencyKey);
            try (ResultSet result = existing.executeQuery()) {
                if (result.next()) {
                    String storedActor = result.getString("actor_id");
                    boolean samePayload = clanId.toString().equals(result.getString("clan_id"))
                            && type.name().equals(result.getString("event_type"))
                            && java.util.Objects.equals(actorId == null ? null : actorId.toString(), storedActor)
                            && type.amount() == result.getLong("amount");
                    if (!samePayload) return xpResult(ClanXpAwardResult.Status.IDEMPOTENCY_KEY_CONFLICT, null);
                    Optional<StoredClan> duplicateClan = readClan(clanId);
                    return duplicateClan.map(value -> xpResult(ClanXpAwardResult.Status.DUPLICATE, value.clan().totalXp()))
                            .orElseGet(() -> xpResult(ClanXpAwardResult.Status.CLAN_NOT_FOUND, null));
                }
            }
        }
        Optional<StoredClan> stored = readClan(clanId);
        if (stored.isEmpty()) return xpResult(ClanXpAwardResult.Status.CLAN_NOT_FOUND, null);
        long updatedXp;
        try { updatedXp = Math.addExact(stored.get().clan().totalXp(), type.amount()); }
        catch (ArithmeticException exception) { return xpResult(ClanXpAwardResult.Status.XP_OVERFLOW, null); }
        try (PreparedStatement update = connection.prepareStatement(
                "UPDATE clans SET total_xp = ? WHERE id = ? AND total_xp = ?")) {
            update.setLong(1, updatedXp); update.setString(2, clanId.toString());
            update.setLong(3, stored.get().clan().totalXp());
            if (update.executeUpdate() != 1) throw new StorageException("Clan XP update lost its expected snapshot");
        }
        try (PreparedStatement event = connection.prepareStatement("""
                INSERT INTO clan_xp_events(clan_id, event_type, actor_id, amount, idempotency_key, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            event.setString(1, clanId.toString()); event.setString(2, type.name());
            event.setString(3, actorId == null ? null : actorId.toString());
            event.setLong(4, type.amount()); event.setString(5, idempotencyKey);
            event.setString(6, occurredAt.toString()); event.executeUpdate();
        }
        long finalXp = updatedXp;
        if (type != ClanXpEventType.LEVEL_TEN_ACHIEVEMENT
                && com.skyworldclans.clan.policy.ClanLevelPolicy.levelForXp(stored.get().clan().totalXp()) < 10
                && com.skyworldclans.clan.policy.ClanLevelPolicy.levelForXp(updatedXp) == 10) {
            ClanXpAwardResult achievement = awardClanXpInTransaction(clanId,
                    ClanXpEventType.LEVEL_TEN_ACHIEVEMENT, null,
                    "clan-achievement:" + clanId + ":LEVEL_TEN_ACHIEVEMENT", occurredAt);
            if (achievement.status() != ClanXpAwardResult.Status.AWARDED
                    && achievement.status() != ClanXpAwardResult.Status.DUPLICATE
                    && achievement.status() != ClanXpAwardResult.Status.XP_OVERFLOW) {
                throw new StorageException("Could not record level-10 achievement: " + achievement.status());
            }
            if (achievement.totalXp().isPresent()) finalXp = achievement.totalXp().getAsLong();
        }
        return xpResult(ClanXpAwardResult.Status.AWARDED, finalXp);
    }

    /** Reconciles one-time recruitment/member-peak achievements from the current member count. */
    public synchronized void reconcileMembershipAchievements(UUID clanId, Instant now) {
        ensureOpen();
        if (clanId == null || now == null) return;
        inWriteTransaction("Could not reconcile clan achievements", () -> {
            awardMembershipAchievementsInTransaction(clanId, now);
            awardLevelTenAchievementInTransaction(clanId, now);
            return null;
        });
    }

    public synchronized List<UUID> allClanIds() {
        ensureOpen();
        List<UUID> ids = new ArrayList<>();
        try (Statement statement = connection.createStatement(); ResultSet rows = statement.executeQuery(
                "SELECT id FROM clans WHERE tag_key NOT LIKE 'deleted:%' ORDER BY id")) {
            while (rows.next()) ids.add(UUID.fromString(rows.getString(1)));
            return List.copyOf(ids);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not list clan identifiers", exception);
        }
    }

    public synchronized void reconcileAllMembershipAchievements(Instant now) {
        ensureOpen();
        if (now == null) return;
        inWriteTransaction("Could not reconcile all clan membership achievements", () -> {
            List<UUID> clanIds = new ArrayList<>();
            try (Statement statement = connection.createStatement();
                 ResultSet rows = statement.executeQuery("SELECT id FROM clans ORDER BY id")) {
                while (rows.next()) clanIds.add(UUID.fromString(rows.getString(1)));
            }
            for (UUID clanId : clanIds) {
                awardMembershipAchievementsInTransaction(clanId, now);
                awardLevelTenAchievementInTransaction(clanId, now);
            }
            return null;
        });
    }

    private void awardLevelTenAchievementInTransaction(UUID clanId, Instant now) throws SQLException {
        Optional<StoredClan> stored = readClan(clanId);
        if (stored.isPresent() && com.skyworldclans.clan.policy.ClanLevelPolicy.levelForXp(
                stored.get().clan().totalXp()) == 10) {
            awardMembershipAchievement(clanId, ClanXpEventType.LEVEL_TEN_ACHIEVEMENT, now);
        }
    }

    private void awardMembershipAchievement(UUID clanId, ClanXpEventType type, Instant now) throws SQLException {
        ClanXpAwardResult result = awardClanXpInTransaction(clanId, type, null,
                "clan-achievement:" + clanId + ":" + type.name(), now);
        if (result.status() != ClanXpAwardResult.Status.AWARDED
                && result.status() != ClanXpAwardResult.Status.DUPLICATE
                && result.status() != ClanXpAwardResult.Status.XP_OVERFLOW) {
            throw new StorageException("Could not reconcile membership achievement " + type + ": " + result.status());
        }
    }

    private void awardMembershipAchievementsInTransaction(UUID clanId, Instant now) throws SQLException {
        Optional<StoredClan> stored = readClan(clanId);
        if (stored.isEmpty()) return;
        int members = stored.get().clan().memberCount();
        if (members < 2) return;
        awardMembershipAchievement(clanId, ClanXpEventType.FIRST_RECRUIT_JOINED, now);
        int[] thresholds = {5, 10, 25, 40, 50};
        ClanXpEventType[] rewards = {ClanXpEventType.MEMBER_PEAK_5, ClanXpEventType.MEMBER_PEAK_10,
                ClanXpEventType.MEMBER_PEAK_25, ClanXpEventType.MEMBER_PEAK_40, ClanXpEventType.MEMBER_PEAK_50};
        for (int i = 0; i < thresholds.length; i++) {
            if (members >= thresholds[i]) {
                awardMembershipAchievement(clanId, rewards[i], now);
            }
        }
    }

    public synchronized ElectionCreateStatus createElection(UUID electionId, UUID clanId,
            String type, UUID startedBy, Instant startedAt, Instant closesAt, List<UUID> candidates) {
        if (electionId == null || clanId == null || startedBy == null || startedAt == null
                || closesAt == null || type == null || !Set.of("DEPARTURE", "COUP").contains(type)
                || candidates == null || candidates.isEmpty() || candidates.stream().anyMatch(java.util.Objects::isNull)
                || candidates.stream().distinct().count() != candidates.size() || !closesAt.isAfter(startedAt)) {
            return ElectionCreateStatus.INVALID;
        }
        return inWriteTransaction("Could not create clan election", () -> {
            if (readClan(clanId).isEmpty()) return ElectionCreateStatus.CLAN_NOT_FOUND;
            if (exists("SELECT 1 FROM clan_elections WHERE clan_id = ? AND phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')",
                    clanId.toString())) return ElectionCreateStatus.ACTIVE_ELECTION_EXISTS;
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_elections(election_id, clan_id, election_type, phase, started_by, started_at, closes_at)
                    VALUES (?, ?, ?, 'LOCAL', ?, ?, ?)
                    """)) {
                insert.setString(1, electionId.toString()); insert.setString(2, clanId.toString());
                insert.setString(3, type); insert.setString(4, startedBy.toString());
                insert.setString(5, startedAt.toString()); insert.setString(6, closesAt.toString());
                try { insert.executeUpdate(); } catch (SQLException exception) {
                    if (exception.getMessage() != null && exception.getMessage().toLowerCase(Locale.ROOT).contains("unique")) return ElectionCreateStatus.ACTIVE_ELECTION_EXISTS;
                    throw exception;
                }
            }
            insertElectionCandidates(electionId, "LOCAL", candidates);
            appendElectionEvent(electionId, "CREATED", startedBy, type, startedAt);
            return ElectionCreateStatus.CREATED;
        });
    }

    public synchronized ElectionVoteStatus castElectionVote(UUID electionId, String phase,
            UUID voterId, UUID candidateId, Instant votedAt) {
        if (electionId == null || voterId == null || candidateId == null || votedAt == null
                || !Set.of("LOCAL", "GLOBAL_TIE_BREAK").contains(phase)) return ElectionVoteStatus.INVALID;
        return inWriteTransaction("Could not record clan election vote", () -> {
            String currentPhase;
            String closesAt;
            try (PreparedStatement query = connection.prepareStatement("SELECT phase, closes_at FROM clan_elections WHERE election_id = ?")) {
                query.setString(1, electionId.toString());
                try (ResultSet row = query.executeQuery()) {
                    if (!row.next()) return ElectionVoteStatus.NOT_FOUND;
                    currentPhase = row.getString("phase"); closesAt = row.getString("closes_at");
                }
            }
            if (!phase.equals(currentPhase)) return ElectionVoteStatus.PHASE_CHANGED;
            if (!Instant.parse(closesAt).isAfter(votedAt)) return ElectionVoteStatus.PHASE_CLOSED;
            try (PreparedStatement insert = connection.prepareStatement("INSERT INTO clan_election_votes(election_id, phase, voter_id, candidate_id, voted_at) VALUES (?, ?, ?, ?, ?)")) {
                insert.setString(1, electionId.toString()); insert.setString(2, phase);
                insert.setString(3, voterId.toString()); insert.setString(4, candidateId.toString()); insert.setString(5, votedAt.toString());
                try { insert.executeUpdate(); } catch (SQLException exception) {
                    String message = exception.getMessage() == null ? "" : exception.getMessage().toLowerCase(Locale.ROOT);
                    if (message.contains("unique")) return ElectionVoteStatus.ALREADY_VOTED;
                    if (message.contains("foreign key")) return ElectionVoteStatus.INVALID_CANDIDATE;
                    throw exception;
                }
            }
            appendElectionEvent(electionId, "VOTE_CAST", voterId, phase + ":" + candidateId, votedAt);
            return ElectionVoteStatus.VOTED;
        });
    }

    public synchronized void recordCombatLogDamage(UUID attackerId, UUID victimId, Instant occurredAt) {
        ensureOpen();
        if (attackerId == null || victimId == null || attackerId.equals(victimId) || occurredAt == null)
            throw new IllegalArgumentException("Two distinct players and an event time are required");
        inWriteTransaction("Could not record combat log damage", () -> {
            upsertCombatLogTag(attackerId, victimId, occurredAt);
            upsertCombatLogTag(victimId, attackerId, occurredAt);
            return null;
        });
    }

    private void upsertCombatLogTag(UUID playerId, UUID opponentId, Instant occurredAt) throws SQLException {
        Instant effectiveAt = occurredAt;
        Optional<CombatLogSession> current = readCombatLogSession(playerId);
        if (current.isPresent()) {
            CombatLogSession previous = current.get();
            if (effectiveAt.isBefore(previous.updatedAt())) effectiveAt = previous.updatedAt();
            if (previous.status() == CombatLogSessionStatus.ACTIVE && !previous.expiresAt().isAfter(effectiveAt)) {
                updateCombatLogSessionState(previous, CombatLogSessionStatus.EXPIRED, previous.expiresAt());
                insertCombatLogEvent(playerId, previous.opponentId(), CombatLogEventType.EXPIRED,
                        previous.expiresAt(), previous.expiresAt(), "TIMER_ELAPSED_BEFORE_NEW_HIT");
                if (effectiveAt.isBefore(previous.expiresAt())) effectiveAt = previous.expiresAt();
            }
        }
        Instant expiresAt = effectiveAt.plusSeconds(30);
        try (PreparedStatement upsert = connection.prepareStatement("""
                INSERT INTO clan_combat_log_sessions(player_id, opponent_id, last_hit_at, expires_at, status, updated_at)
                VALUES (?, ?, ?, ?, 'ACTIVE', ?)
                ON CONFLICT(player_id) DO UPDATE SET opponent_id = excluded.opponent_id,
                    last_hit_at = excluded.last_hit_at, expires_at = excluded.expires_at,
                    status = 'ACTIVE', updated_at = excluded.updated_at
                """)) {
            upsert.setString(1, playerId.toString()); upsert.setString(2, opponentId.toString());
            upsert.setString(3, effectiveAt.toString()); upsert.setString(4, expiresAt.toString());
            upsert.setString(5, effectiveAt.toString()); upsert.executeUpdate();
        }
        insertCombatLogEvent(playerId, opponentId, CombatLogEventType.TAGGED, effectiveAt, expiresAt, "PVP_DAMAGE");
    }

    /** Returns true only when this quit is an active in-combat logout. */
    public synchronized boolean markCombatLogQuit(UUID playerId, Instant occurredAt) {
        ensureOpen();
        if (playerId == null || occurredAt == null) return false;
        return inWriteTransaction("Could not process combat log quit", () -> {
            CombatLogSession session = readCombatLogSession(playerId).orElse(null);
            if (session == null || session.status() != CombatLogSessionStatus.ACTIVE) return false;
            Instant at = occurredAt.isBefore(session.updatedAt()) ? session.updatedAt() : occurredAt;
            if (!session.expiresAt().isAfter(at)) {
                updateCombatLogSessionState(session, CombatLogSessionStatus.EXPIRED, at);
                insertCombatLogEvent(playerId, session.opponentId(), CombatLogEventType.EXPIRED,
                        at, session.expiresAt(), "TIMER_ELAPSED_BEFORE_QUIT");
                return false;
            }
            updateCombatLogSessionState(session, CombatLogSessionStatus.LOGOUT_VIOLATION, at);
            insertCombatLogEvent(playerId, session.opponentId(), CombatLogEventType.LOGOUT_VIOLATION,
                    at, session.expiresAt(), "PLAYER_QUIT_DURING_COMBAT");
            return true;
        });
    }

    public synchronized boolean clearCombatLogOnDeath(UUID playerId, Instant occurredAt) {
        ensureOpen();
        if (playerId == null || occurredAt == null) return false;
        return inWriteTransaction("Could not clear combat log on death", () -> {
            CombatLogSession session = readCombatLogSession(playerId).orElse(null);
            if (session == null || session.status() != CombatLogSessionStatus.ACTIVE) return false;
            Instant at = occurredAt.isBefore(session.updatedAt()) ? session.updatedAt() : occurredAt;
            if (!session.expiresAt().isAfter(at)) {
                updateCombatLogSessionState(session, CombatLogSessionStatus.EXPIRED, at);
                insertCombatLogEvent(playerId, session.opponentId(), CombatLogEventType.EXPIRED,
                        at, session.expiresAt(), "TIMER_ELAPSED_BEFORE_DEATH");
                return false;
            }
            updateCombatLogSessionState(session, CombatLogSessionStatus.CLEARED, at);
            insertCombatLogEvent(playerId, session.opponentId(), CombatLogEventType.CLEARED,
                    at, session.expiresAt(), "PLAYER_DIED");
            return true;
        });
    }

    public synchronized int expireDueCombatLogSessions(Instant now) {
        ensureOpen();
        if (now == null) return 0;
        try (PreparedStatement check = connection.prepareStatement("""
                SELECT 1 FROM clan_combat_log_sessions
                WHERE status = 'ACTIVE' AND julianday(expires_at) <= julianday(?) LIMIT 1
                """)) {
            check.setString(1, now.toString());
            try (ResultSet row = check.executeQuery()) {
                if (!row.next()) return 0;
            }
        } catch (SQLException exception) {
            throw storageFailure("Could not check due combat log sessions", exception);
        }
        return inWriteTransaction("Could not expire combat log sessions", () -> {
            List<UUID> due = new ArrayList<>();
            try (PreparedStatement select = connection.prepareStatement("""
                    SELECT player_id FROM clan_combat_log_sessions
                    WHERE status = 'ACTIVE' AND julianday(expires_at) <= julianday(?)
                    ORDER BY expires_at, player_id
                    """)) {
                select.setString(1, now.toString());
                try (ResultSet rows = select.executeQuery()) {
                    while (rows.next()) due.add(UUID.fromString(rows.getString(1)));
                }
            }
            int expired = 0;
            for (UUID playerId : due) {
                CombatLogSession session = readCombatLogSession(playerId).orElse(null);
                if (session == null || session.status() != CombatLogSessionStatus.ACTIVE) continue;
                Instant at = now.isBefore(session.updatedAt()) ? session.updatedAt() : now;
                updateCombatLogSessionState(session, CombatLogSessionStatus.EXPIRED, at);
                insertCombatLogEvent(playerId, session.opponentId(), CombatLogEventType.EXPIRED,
                        at, session.expiresAt(), "COMBAT_TIMER_ELAPSED");
                expired++;
            }
            return expired;
        });
    }

    /** Active combat at process shutdown is never converted into an automatic logout penalty. */
    public synchronized int recoverCombatLogAfterRestart(Instant now) {
        ensureOpen();
        if (now == null) throw new IllegalArgumentException("now is required");
        return inWriteTransaction("Could not recover combat log sessions", () -> {
            List<UUID> active = new ArrayList<>();
            try (PreparedStatement select = connection.prepareStatement(
                    "SELECT player_id FROM clan_combat_log_sessions WHERE status = 'ACTIVE' ORDER BY player_id");
                 ResultSet rows = select.executeQuery()) {
                while (rows.next()) active.add(UUID.fromString(rows.getString(1)));
            }
            int recovered = 0;
            for (UUID playerId : active) {
                CombatLogSession session = readCombatLogSession(playerId).orElse(null);
                if (session == null || session.status() != CombatLogSessionStatus.ACTIVE) continue;
                Instant at = now.isBefore(session.updatedAt()) ? session.updatedAt() : now;
                if (!session.expiresAt().isAfter(at)) {
                    updateCombatLogSessionState(session, CombatLogSessionStatus.EXPIRED, at);
                    insertCombatLogEvent(playerId, session.opponentId(), CombatLogEventType.EXPIRED,
                            at, session.expiresAt(), "TIMER_ELAPSED_BEFORE_RESTART");
                } else {
                    updateCombatLogSessionState(session, CombatLogSessionStatus.INTERRUPTED_REVIEW, at);
                    insertCombatLogEvent(playerId, session.opponentId(), CombatLogEventType.INTERRUPTED_REVIEW,
                            at, session.expiresAt(), "SERVER_RESTART_REQUIRES_REVIEW");
                    recovered++;
                }
            }
            return recovered;
        });
    }

    public synchronized List<CombatLogSession> findCombatLogSessions(CombatLogSessionStatus status, int limit) {
        ensureOpen();
        if (status == null || limit < 1 || limit > 100)
            throw new IllegalArgumentException("status is required and limit must be between 1 and 100");
        List<CombatLogSession> sessions = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT player_id FROM clan_combat_log_sessions WHERE status = ?
                ORDER BY updated_at DESC, player_id LIMIT ?
                """)) {
            statement.setString(1, status.name()); statement.setInt(2, limit);
            try (ResultSet rows = statement.executeQuery()) {
                while (rows.next()) {
                    UUID playerId = UUID.fromString(rows.getString(1));
                    readCombatLogSession(playerId).ifPresent(sessions::add);
                }
            }
            return List.copyOf(sessions);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not list combat log sessions", exception);
        }
    }

    public synchronized Optional<CombatLogSession> findCombatLogSession(UUID playerId) {
        ensureOpen();
        if (playerId == null) return Optional.empty();
        try { return readCombatLogSession(playerId); }
        catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read combat log session", exception);
        }
    }

    private Optional<CombatLogSession> readCombatLogSession(UUID playerId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT player_id, opponent_id, last_hit_at, expires_at, status, updated_at
                FROM clan_combat_log_sessions WHERE player_id = ?
                """)) {
            statement.setString(1, playerId.toString());
            try (ResultSet row = statement.executeQuery()) {
                if (!row.next()) return Optional.empty();
                return Optional.of(new CombatLogSession(UUID.fromString(row.getString("player_id")),
                        UUID.fromString(row.getString("opponent_id")), Instant.parse(row.getString("last_hit_at")),
                        Instant.parse(row.getString("expires_at")), CombatLogSessionStatus.valueOf(row.getString("status")),
                        Instant.parse(row.getString("updated_at"))));
            }
        }
    }

    private void updateCombatLogSessionState(CombatLogSession session, CombatLogSessionStatus status, Instant at) throws SQLException {
        try (PreparedStatement update = connection.prepareStatement("""
                UPDATE clan_combat_log_sessions SET status = ?, updated_at = ?
                WHERE player_id = ? AND status = 'ACTIVE'
                """)) {
            update.setString(1, status.name()); update.setString(2, at.toString());
            update.setString(3, session.playerId().toString());
            if (update.executeUpdate() != 1) throw new SQLException("Combat log session changed concurrently");
        }
    }

    private void insertCombatLogEvent(UUID playerId, UUID opponentId, CombatLogEventType type,
            Instant occurredAt, Instant expiresAt, String details) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_combat_log_events(player_id, opponent_id, event_type, occurred_at, expires_at, details)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, playerId.toString()); insert.setString(2, opponentId.toString());
            insert.setString(3, type.name()); insert.setString(4, occurredAt.toString());
            insert.setString(5, expiresAt.toString()); insert.setString(6, details); insert.executeUpdate();
        }
    }

    public enum CombatLogSessionStatus { ACTIVE, EXPIRED, LOGOUT_VIOLATION, INTERRUPTED_REVIEW, CLEARED }
    public enum CombatLogEventType { TAGGED, EXPIRED, LOGOUT_VIOLATION, INTERRUPTED_REVIEW, CLEARED }
    public record CombatLogSession(UUID playerId, UUID opponentId, Instant lastHitAt, Instant expiresAt,
            CombatLogSessionStatus status, Instant updatedAt) { }

    public static final int MAX_HOME_POINTS = 2;
    public static final BigDecimal SECOND_HOME_POINT_PRICE = new BigDecimal("200000");

    public synchronized ClanHomeResult setClanHomePoint(UUID clanId, UUID actorId, int slot, String initialName,
            UUID worldId, double x, double y, double z, float yaw, float pitch, Instant now) {
        ensureOpen();
        if (clanId == null || actorId == null || worldId == null || now == null || slot < 1 || slot > MAX_HOME_POINTS
                || !validHomeName(initialName) || !finite(x, y, z, yaw, pitch))
            return new ClanHomeResult(ClanHomeStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not save clan home point", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanHomeResult(ClanHomeStatus.CLAN_NOT_FOUND, null);
            String role = clanMemberRole(clanId, actorId);
            if (!"LEADER".equals(role) && !"DEPUTY".equals(role))
                return new ClanHomeResult(ClanHomeStatus.NOT_AUTHORIZED, null);
            if (slot > 1 && !homeSlotOwned(clanId, slot))
                return new ClanHomeResult(ClanHomeStatus.SLOT_NOT_PURCHASED, null);
            ClanHomePoint current = readClanHomePoint(clanId, slot).orElse(null);
            String name = current == null ? initialName.trim() : current.name();
            if (current == null) {
                try (PreparedStatement insert = connection.prepareStatement("""
                        INSERT INTO clan_home_points(clan_id, slot, name, world_id, x, y, z, yaw, pitch,
                            created_by, created_at, updated_by, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """)) {
                    insert.setString(1, clanId.toString()); insert.setInt(2, slot); insert.setString(3, name);
                    insert.setString(4, worldId.toString()); insert.setDouble(5, x); insert.setDouble(6, y);
                    insert.setDouble(7, z); insert.setFloat(8, yaw); insert.setFloat(9, pitch);
                    insert.setString(10, actorId.toString()); insert.setString(11, now.toString());
                    insert.setString(12, actorId.toString()); insert.setString(13, now.toString());
                    insert.executeUpdate();
                }
            } else {
                try (PreparedStatement update = connection.prepareStatement("""
                        UPDATE clan_home_points SET world_id = ?, x = ?, y = ?, z = ?, yaw = ?, pitch = ?,
                            updated_by = ?, updated_at = ? WHERE clan_id = ? AND slot = ?
                        """)) {
                    update.setString(1, worldId.toString()); update.setDouble(2, x); update.setDouble(3, y);
                    update.setDouble(4, z); update.setFloat(5, yaw); update.setFloat(6, pitch);
                    update.setString(7, actorId.toString()); update.setString(8, now.toString());
                    update.setString(9, clanId.toString()); update.setInt(10, slot); update.executeUpdate();
                }
            }
            insertClanHomeEvent(clanId, slot, actorId, ClanHomeEventType.SET, name, worldId, x, y, z, yaw, pitch, now);
            return new ClanHomeResult(ClanHomeStatus.SAVED, readClanHomePoint(clanId, slot).orElseThrow());
        });
    }

    public synchronized ClanHomeResult setClanHomePoint(UUID clanId, UUID actorId, String initialName,
            UUID worldId, double x, double y, double z, float yaw, float pitch, Instant now) {
        return setClanHomePoint(clanId, actorId, 1, initialName, worldId, x, y, z, yaw, pitch, now);
    }

    /** Buys the second home point slot from the clan bank for the approved price. Leader only. */
    public synchronized ClanHomeResult purchaseSecondHomePoint(UUID clanId, UUID leaderId, Instant now) {
        ensureOpen();
        if (clanId == null || leaderId == null || now == null)
            return new ClanHomeResult(ClanHomeStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not purchase second clan home point", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanHomeResult(ClanHomeStatus.CLAN_NOT_FOUND, null);
            if (!"LEADER".equals(clanMemberRole(clanId, leaderId)))
                return new ClanHomeResult(ClanHomeStatus.LEADER_ONLY, null);
            if (homeSlotOwned(clanId, 2))
                return new ClanHomeResult(ClanHomeStatus.ALREADY_PURCHASED, null);
            String key = "home-slot-purchase:" + clanId + ":2";
            if (exists("SELECT 1 FROM clan_bank_transactions WHERE idempotency_key = ?", key)) {
                return new ClanHomeResult(ClanHomeStatus.ALREADY_PURCHASED, null);
            }
            BigDecimal balance = new BigDecimal(readBankBalance(clanId));
            BigDecimal reserved = new BigDecimal(readBankReservedBalance(clanId));
            if (balance.subtract(reserved).compareTo(SECOND_HOME_POINT_PRICE) < 0)
                return new ClanHomeResult(ClanHomeStatus.INSUFFICIENT_BANK_FUNDS, null);
            BigDecimal updated = balance.subtract(SECOND_HOME_POINT_PRICE).stripTrailingZeros();
            try (PreparedStatement account = connection.prepareStatement("""
                    UPDATE clan_bank_accounts SET balance = ?, revision = revision + 1, updated_at = ?
                    WHERE clan_id = ?
                    """)) {
                account.setString(1, updated.toPlainString()); account.setString(2, now.toString());
                account.setString(3, clanId.toString());
                if (account.executeUpdate() != 1) throw new StorageException("Clan bank account is missing");
            }
            insertWarBankLedger(UUID.randomUUID(), key, clanId, leaderId, "ADJUSTMENT",
                    SECOND_HOME_POINT_PRICE.negate(), updated, "Second home point purchase", now);
            try (PreparedStatement slot = connection.prepareStatement("""
                    INSERT INTO clan_home_slots(clan_id, slot, purchased_by, purchased_at, price_paid)
                    VALUES (?, 2, ?, ?, ?)
                    """)) {
                slot.setString(1, clanId.toString()); slot.setString(2, leaderId.toString());
                slot.setString(3, now.toString()); slot.setString(4, SECOND_HOME_POINT_PRICE.toPlainString());
                slot.executeUpdate();
            }
            insertClanHomeEvent(clanId, 2, leaderId, ClanHomeEventType.PURCHASE, "Вторая точка",
                    new UUID(0L, 0L), 0, 0, 0, 0, 0, now);
            return new ClanHomeResult(ClanHomeStatus.PURCHASED, null);
        });
    }

    public synchronized ClanHomeResult renameClanHomePoint(UUID clanId, UUID actorId, int slot, String newName, Instant now) {
        ensureOpen();
        if (clanId == null || actorId == null || now == null || slot < 1 || slot > MAX_HOME_POINTS
                || !validHomeName(newName))
            return new ClanHomeResult(ClanHomeStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not rename clan home point", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanHomeResult(ClanHomeStatus.CLAN_NOT_FOUND, null);
            String role = clanMemberRole(clanId, actorId);
            if (!"LEADER".equals(role) && !"DEPUTY".equals(role))
                return new ClanHomeResult(ClanHomeStatus.NOT_AUTHORIZED, null);
            ClanHomePoint current = readClanHomePoint(clanId, slot).orElse(null);
            if (current == null) return new ClanHomeResult(ClanHomeStatus.HOME_NOT_SET, null);
            String name = newName.trim();
            try (PreparedStatement update = connection.prepareStatement("""
                    UPDATE clan_home_points SET name = ?, updated_by = ?, updated_at = ?
                    WHERE clan_id = ? AND slot = ?
                    """)) {
                update.setString(1, name); update.setString(2, actorId.toString());
                update.setString(3, now.toString()); update.setString(4, clanId.toString());
                update.setInt(5, slot); update.executeUpdate();
            }
            insertClanHomeEvent(clanId, slot, actorId, ClanHomeEventType.RENAME, name, current.worldId(),
                    current.x(), current.y(), current.z(), current.yaw(), current.pitch(), now);
            return new ClanHomeResult(ClanHomeStatus.RENAMED, readClanHomePoint(clanId, slot).orElseThrow());
        });
    }

    public synchronized ClanHomeResult renameClanHomePoint(UUID clanId, UUID actorId, String newName, Instant now) {
        return renameClanHomePoint(clanId, actorId, 1, newName, now);
    }

    public synchronized ClanHomeResult deleteClanHomePoint(UUID clanId, UUID actorId, int slot, Instant now) {
        ensureOpen();
        if (clanId == null || actorId == null || now == null || slot < 1 || slot > MAX_HOME_POINTS)
            return new ClanHomeResult(ClanHomeStatus.INVALID_INPUT, null);
        return inWriteTransaction("Could not delete clan home point", () -> {
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                return new ClanHomeResult(ClanHomeStatus.CLAN_NOT_FOUND, null);
            if (!"LEADER".equals(clanMemberRole(clanId, actorId)))
                return new ClanHomeResult(ClanHomeStatus.LEADER_ONLY, null);
            ClanHomePoint current = readClanHomePoint(clanId, slot).orElse(null);
            if (current == null) return new ClanHomeResult(ClanHomeStatus.HOME_NOT_SET, null);
            insertClanHomeEvent(clanId, slot, actorId, ClanHomeEventType.DELETE, current.name(), current.worldId(),
                    current.x(), current.y(), current.z(), current.yaw(), current.pitch(), now);
            try (PreparedStatement delete = connection.prepareStatement(
                    "DELETE FROM clan_home_points WHERE clan_id = ? AND slot = ?")) {
                delete.setString(1, clanId.toString()); delete.setInt(2, slot);
                delete.executeUpdate();
            }
            return new ClanHomeResult(ClanHomeStatus.DELETED, current);
        });
    }

    public synchronized ClanHomeResult deleteClanHomePoint(UUID clanId, UUID actorId, Instant now) {
        return deleteClanHomePoint(clanId, actorId, 1, now);
    }

    public synchronized Optional<ClanHomePoint> findClanHomePoint(UUID clanId) {
        return findClanHomePoint(clanId, 1);
    }

    public synchronized Optional<ClanHomePoint> findClanHomePoint(UUID clanId, int slot) {
        ensureOpen();
        if (clanId == null || slot < 1 || slot > MAX_HOME_POINTS) return Optional.empty();
        try { return readClanHomePoint(clanId, slot); }
        catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read clan home point", exception);
        }
    }

    public synchronized List<ClanHomePoint> findClanHomePoints(UUID clanId) {
        ensureOpen();
        if (clanId == null) return List.of();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT clan_id, slot, name, world_id, x, y, z, yaw, pitch, created_by, created_at,
                       updated_by, updated_at
                FROM clan_home_points WHERE clan_id = ? ORDER BY slot
                """)) {
            statement.setString(1, clanId.toString());
            List<ClanHomePoint> points = new ArrayList<>();
            try (ResultSet row = statement.executeQuery()) {
                while (row.next()) points.add(readClanHomePointRow(row));
            }
            return List.copyOf(points);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not list clan home points", exception);
        }
    }

    /** True when the clan owns the slot: slot 1 is always free, slot 2 must be purchased. */
    public synchronized boolean homeSlotOwned(UUID clanId, int slot) {
        ensureOpen();
        if (clanId == null) return false;
        if (slot == 1) return true;
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT 1 FROM clan_home_slots WHERE clan_id = ? AND slot = ?")) {
            statement.setString(1, clanId.toString()); statement.setInt(2, slot);
            try (ResultSet row = statement.executeQuery()) { return row.next(); }
        } catch (SQLException exception) {
            throw storageFailure("Could not read clan home slots", exception);
        }
    }

    private String clanMemberRole(UUID clanId, UUID playerId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT role FROM clan_members WHERE clan_id = ? AND player_id = ?")) {
            statement.setString(1, clanId.toString()); statement.setString(2, playerId.toString());
            try (ResultSet row = statement.executeQuery()) { return row.next() ? row.getString(1) : null; }
        }
    }

    private Optional<ClanHomePoint> readClanHomePoint(UUID clanId, int slot) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT clan_id, slot, name, world_id, x, y, z, yaw, pitch, created_by, created_at,
                       updated_by, updated_at
                FROM clan_home_points WHERE clan_id = ? AND slot = ?
                """)) {
            statement.setString(1, clanId.toString()); statement.setInt(2, slot);
            try (ResultSet row = statement.executeQuery()) {
                return row.next() ? Optional.of(readClanHomePointRow(row)) : Optional.empty();
            }
        }
    }

    private static ClanHomePoint readClanHomePointRow(ResultSet row) throws SQLException {
        return new ClanHomePoint(UUID.fromString(row.getString("clan_id")), row.getInt("slot"),
                row.getString("name"), UUID.fromString(row.getString("world_id")),
                row.getDouble("x"), row.getDouble("y"), row.getDouble("z"),
                row.getFloat("yaw"), row.getFloat("pitch"),
                UUID.fromString(row.getString("created_by")), Instant.parse(row.getString("created_at")),
                UUID.fromString(row.getString("updated_by")), Instant.parse(row.getString("updated_at")));
    }

    private void insertClanHomeEvent(UUID clanId, int slot, UUID actorId, ClanHomeEventType type, String name,
            UUID worldId, double x, double y, double z, float yaw, float pitch, Instant now) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("""
                INSERT INTO clan_home_events(clan_id, slot, actor_id, event_type, home_name, world_id,
                    x, y, z, yaw, pitch, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """)) {
            insert.setString(1, clanId.toString()); insert.setInt(2, slot);
            insert.setString(3, actorId.toString());
            insert.setString(4, type.name()); insert.setString(5, name); insert.setString(6, worldId.toString());
            insert.setDouble(7, x); insert.setDouble(8, y); insert.setDouble(9, z);
            insert.setFloat(10, yaw); insert.setFloat(11, pitch); insert.setString(12, now.toString());
            insert.executeUpdate();
        }
    }

    private static boolean validHomeName(String name) {
        return name != null && !name.isBlank() && name.trim().codePointCount(0, name.trim().length()) <= 32;
    }

    private static boolean finite(double x, double y, double z, float yaw, float pitch) {
        return Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(z)
                && Float.isFinite(yaw) && Float.isFinite(pitch);
    }

    public enum ClanHomeStatus { SAVED, RENAMED, DELETED, PURCHASED, ALREADY_PURCHASED, SLOT_NOT_PURCHASED,
        INSUFFICIENT_BANK_FUNDS, CLAN_NOT_FOUND, HOME_NOT_SET, INVALID_INPUT, NOT_AUTHORIZED, LEADER_ONLY }
    public enum ClanHomeEventType { SET, RENAME, DELETE, PURCHASE }
    public record ClanHomePoint(UUID clanId, int slot, String name, UUID worldId, double x, double y, double z,
            float yaw, float pitch, UUID createdBy, Instant createdAt, UUID updatedBy, Instant updatedAt) { }
    public record ClanHomeResult(ClanHomeStatus status, ClanHomePoint point) { }

    public synchronized void recordPlayerActivity(UUID playerId, Instant occurredAt) {
        ensureOpen();
        if (playerId == null || occurredAt == null || occurredAt.toEpochMilli() < 0) return;
        inWriteTransaction("Could not record player activity", () -> {
            try (PreparedStatement upsert = connection.prepareStatement("""
                    INSERT INTO clan_player_activity(player_id, last_seen_epoch_millis) VALUES (?, ?)
                    ON CONFLICT(player_id) DO UPDATE SET last_seen_epoch_millis = MAX(
                        clan_player_activity.last_seen_epoch_millis, excluded.last_seen_epoch_millis)
                    """)) {
                upsert.setString(1, playerId.toString());
                upsert.setLong(2, occurredAt.toEpochMilli());
                upsert.executeUpdate();
            }
            return null;
        });
    }

    public synchronized void recordOnlineMemberActivity(Collection<UUID> playerIds, Instant seenAt) {
        ensureOpen();
        if (playerIds == null || playerIds.isEmpty() || seenAt == null) return;
        long epochMillis = seenAt.toEpochMilli();
        inWriteTransaction("Could not record online clan member activity", () -> {
            try (PreparedStatement upsert = connection.prepareStatement("""
                    INSERT INTO clan_player_activity(player_id, last_seen_epoch_millis)
                    SELECT ?, ? WHERE EXISTS (SELECT 1 FROM clan_members WHERE player_id = ?)
                    ON CONFLICT(player_id) DO UPDATE SET
                        last_seen_epoch_millis = MAX(clan_player_activity.last_seen_epoch_millis,
                                                      excluded.last_seen_epoch_millis)
                    """)) {
                for (UUID playerId : playerIds) {
                    if (playerId == null) continue;
                    upsert.setString(1, playerId.toString());
                    upsert.setLong(2, epochMillis);
                    upsert.setString(3, playerId.toString());
                    upsert.addBatch();
                }
                upsert.executeBatch();
            }
            return null;
        });
    }

    public synchronized Optional<Instant> lastPlayerActivity(UUID playerId) {
        ensureOpen();
        if (playerId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT last_seen_epoch_millis FROM clan_player_activity WHERE player_id = ?")) {
            query.setString(1, playerId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() ? Optional.of(Instant.ofEpochMilli(row.getLong(1))) : Optional.empty();
            }
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read player activity", exception);
        }
    }

    public synchronized Optional<CompletedCoupSnapshot> latestCompletedCoup(UUID clanId) {
        ensureOpen();
        if (clanId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement("SELECT winner_id, completed_at FROM clan_elections WHERE clan_id = ? AND election_type = 'COUP' AND phase = 'COMPLETED' ORDER BY julianday(completed_at) DESC LIMIT 1")) {
            query.setString(1, clanId.toString());
            try (ResultSet row = query.executeQuery()) {
                if (!row.next()) return Optional.empty();
                String winner = row.getString("winner_id");
                String completed = row.getString("completed_at");
                if (winner == null || completed == null) throw new StorageException("Completed coup is missing its result");
                return Optional.of(new CompletedCoupSnapshot(UUID.fromString(winner), Instant.parse(completed)));
            }
        } catch (SQLException | RuntimeException exception) {
            if (exception instanceof StorageException storageException) throw storageException;
            throw new StorageException("Could not read latest completed coup", exception);
        }
    }

    public record CompletedCoupSnapshot(UUID winnerId, Instant completedAt) { }

    public synchronized int schemaVersion() {
        ensureOpen();
        try { return pragmaInt("PRAGMA user_version"); }
        catch (SQLException exception) { throw storageFailure("Could not read SQLite schema version", exception); }
    }

    public synchronized int countClans() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clans WHERE tag_key NOT LIKE 'deleted:%'");
    }

    public synchronized int countMembers() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clan_members");
    }

    public synchronized int countActiveElections() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clan_elections WHERE phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')");
    }

    public synchronized int countUnresolvedBankOperations() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clan_bank_operations WHERE state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'UNKNOWN')");
    }

    public synchronized int countUnknownBankOperations() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clan_bank_operations WHERE state = 'UNKNOWN'");
    }

    public synchronized int countInterruptedCombatLogSessions() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clan_combat_log_sessions WHERE status = 'INTERRUPTED_REVIEW'");
    }

    public synchronized int countStoragePages() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clan_storage_pages");
    }

    public synchronized int countUnresolvedCreationPayments() {
        ensureOpen();
        return scalarInt("SELECT COUNT(*) FROM clan_creation_payment_operations WHERE state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')");
    }

    private int scalarInt(String sql) {
        try (Statement statement = connection.createStatement(); ResultSet row = statement.executeQuery(sql)) {
            return row.next() ? row.getInt(1) : 0;
        } catch (SQLException exception) { throw new StorageException("Could not read SQLite count", exception); }
    }

    public synchronized ElectionTransitionStatus blockElectionForOwnerDecision(UUID electionId, Instant now) {
        if (electionId == null || now == null) return ElectionTransitionStatus.INVALID;
        return inWriteTransaction("Could not block tied clan election for owner decision", () -> {
            String phase; String closesAt;
            try (PreparedStatement query = connection.prepareStatement(
                    "SELECT phase, closes_at FROM clan_elections WHERE election_id = ?")) {
                query.setString(1, electionId.toString());
                try (ResultSet row = query.executeQuery()) {
                    if (!row.next()) return ElectionTransitionStatus.NOT_ACTIVE;
                    phase = row.getString("phase"); closesAt = row.getString("closes_at");
                }
            }
            if (!"GLOBAL_TIE_BREAK".equals(phase)) return ElectionTransitionStatus.NOT_ACTIVE;
            if (Instant.parse(closesAt).isAfter(now)) return ElectionTransitionStatus.NOT_DUE;
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_election_owner_blocks(election_id, blocked_at, reason)
                    VALUES (?, ?, 'GLOBAL_TIE_REMAINS_TIED') ON CONFLICT(election_id) DO NOTHING
                    """)) {
                insert.setString(1, electionId.toString());
                insert.setString(2, now.toString());
                insert.executeUpdate();
            }
            return ElectionTransitionStatus.UPDATED;
        });
    }

    public synchronized boolean isElectionBlockedForOwnerDecision(UUID clanId) {
        ensureOpen();
        if (clanId == null) return false;
        try {
            return exists("SELECT 1 FROM clan_elections e JOIN clan_election_owner_blocks b ON b.election_id = e.election_id "
                    + "WHERE e.clan_id = ? AND e.phase = 'GLOBAL_TIE_BREAK'",
                    clanId.toString());
        } catch (SQLException exception) {
            throw new StorageException("Could not read owner-blocked election state", exception);
        }
    }

    public synchronized List<UUID> dueElectionClanIds(Instant now) {
        ensureOpen();
        if (now == null) return List.of();
        List<UUID> result = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement("""
                SELECT clan_id FROM clan_elections
                WHERE phase IN ('LOCAL', 'GLOBAL_TIE_BREAK') AND julianday(closes_at) <= julianday(?)
                  AND NOT EXISTS (SELECT 1 FROM clan_election_owner_blocks b
                      WHERE b.election_id = clan_elections.election_id)
                ORDER BY julianday(closes_at)
                """)) {
            query.setString(1, now.toString());
            try (ResultSet rows = query.executeQuery()) { while (rows.next()) result.add(UUID.fromString(rows.getString(1))); }
            return List.copyOf(result);
        } catch (SQLException | RuntimeException exception) { throw new StorageException("Could not list due clan elections", exception); }
    }

    public synchronized Optional<ElectionSnapshot> findActiveElection(UUID clanId) {
        ensureOpen();
        if (clanId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement("SELECT election_id, clan_id, election_type, phase, started_by, started_at, closes_at FROM clan_elections WHERE clan_id = ? AND phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')")) {
            query.setString(1, clanId.toString());
            try (ResultSet row = query.executeQuery()) {
                if (!row.next()) return Optional.empty();
                UUID id = UUID.fromString(row.getString("election_id"));
                String phase = row.getString("phase");
                List<UUID> candidates = electionCandidates(id, phase);
                return Optional.of(new ElectionSnapshot(id, clanId, row.getString("election_type"), phase,
                        UUID.fromString(row.getString("started_by")), Instant.parse(row.getString("started_at")),
                        Instant.parse(row.getString("closes_at")), candidates));
            }
        } catch (SQLException | RuntimeException exception) {
            if (exception instanceof StorageException storageException) throw storageException;
            throw new StorageException("Could not read active clan election", exception);
        }
    }

    public synchronized List<UUID> electionCandidates(UUID electionId, String phase) {
        ensureOpen();
        if (electionId == null || !Set.of("LOCAL", "GLOBAL_TIE_BREAK").contains(phase)) return List.of();
        List<UUID> result = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement("SELECT candidate_id FROM clan_election_candidates WHERE election_id = ? AND phase = ? ORDER BY candidate_id")) {
            query.setString(1, electionId.toString()); query.setString(2, phase);
            try (ResultSet rows = query.executeQuery()) { while (rows.next()) result.add(UUID.fromString(rows.getString(1))); }
            return List.copyOf(result);
        } catch (SQLException | RuntimeException exception) { throw new StorageException("Could not read clan election candidates", exception); }
    }

    public record ElectionSnapshot(UUID id, UUID clanId, String type, String phase, UUID startedBy,
            Instant startedAt, Instant closesAt, List<UUID> candidates) {
        public ElectionSnapshot { candidates = List.copyOf(candidates); }
    }

    public synchronized Map<UUID, Integer> electionTally(UUID electionId, String phase) {
        ensureOpen();
        if (electionId == null || !Set.of("LOCAL", "GLOBAL_TIE_BREAK").contains(phase)) return Map.of();
        Map<UUID, Integer> tally = new HashMap<>();
        try (PreparedStatement query = connection.prepareStatement("SELECT candidate_id, COUNT(*) AS votes FROM clan_election_votes WHERE election_id = ? AND phase = ? GROUP BY candidate_id")) {
            query.setString(1, electionId.toString()); query.setString(2, phase);
            try (ResultSet rows = query.executeQuery()) { while (rows.next()) tally.put(UUID.fromString(rows.getString("candidate_id")), rows.getInt("votes")); }
            return Map.copyOf(tally);
        } catch (SQLException exception) { throw new StorageException("Could not read clan election tally", exception); }
    }

    public synchronized ElectionTransitionStatus advanceElectionToTieBreak(UUID electionId,
            List<UUID> tiedCandidates, Instant now, Instant closesAt) {
        if (electionId == null || tiedCandidates == null || tiedCandidates.size() < 2 || now == null
                || closesAt == null || !closesAt.isAfter(now)) return ElectionTransitionStatus.INVALID;
        return inWriteTransaction("Could not advance clan election to global tie-break", () -> {
            for (UUID candidate : tiedCandidates) {
                if (!exists("SELECT 1 FROM clan_election_candidates WHERE election_id = ? AND phase = 'LOCAL' AND candidate_id = ?", electionId.toString(), candidate.toString())) return ElectionTransitionStatus.INVALID;
            }
            try (PreparedStatement update = connection.prepareStatement("UPDATE clan_elections SET phase = 'GLOBAL_TIE_BREAK', closes_at = ? WHERE election_id = ? AND phase = 'LOCAL' AND julianday(closes_at) <= julianday(?)")) {
                update.setString(1, closesAt.toString()); update.setString(2, electionId.toString()); update.setString(3, now.toString());
                if (update.executeUpdate() != 1) return ElectionTransitionStatus.NOT_ACTIVE;
            }
            insertElectionCandidates(electionId, "GLOBAL_TIE_BREAK", tiedCandidates);
            appendElectionEvent(electionId, "GLOBAL_TIE_BREAK_STARTED", null, tiedCandidates.toString(), now);
            return ElectionTransitionStatus.UPDATED;
        });
    }

    /** Applies the elected leadership outcome and closes the election in the same SQLite transaction. */
    public synchronized ElectionTransitionStatus completeElectionWithOutcome(
            UUID electionId, UUID winnerId, Instant now) {
        if (electionId == null || winnerId == null || now == null) return ElectionTransitionStatus.INVALID;
        return inWriteTransaction("Could not atomically apply clan election result", () -> {
            UUID clanId; UUID startedBy; String type; String phase; Instant closesAt;
            try (PreparedStatement query = connection.prepareStatement("SELECT clan_id, started_by, election_type, phase, closes_at FROM clan_elections WHERE election_id = ?")) {
                query.setString(1, electionId.toString());
                try (ResultSet row = query.executeQuery()) {
                    if (!row.next()) return ElectionTransitionStatus.NOT_ACTIVE;
                    clanId = UUID.fromString(row.getString("clan_id"));
                    startedBy = UUID.fromString(row.getString("started_by"));
                    type = row.getString("election_type"); phase = row.getString("phase");
                    closesAt = Instant.parse(row.getString("closes_at"));
                }
            }
            if (!Set.of("LOCAL", "GLOBAL_TIE_BREAK").contains(phase)) return ElectionTransitionStatus.NOT_ACTIVE;
            if (closesAt.isAfter(now)) return ElectionTransitionStatus.NOT_DUE;
            if (!exists("SELECT 1 FROM clan_election_candidates WHERE election_id = ? AND phase = ? AND candidate_id = ?",
                    electionId.toString(), phase, winnerId.toString())) return ElectionTransitionStatus.INVALID;
            Optional<StoredClan> stored = readClan(clanId);
            if (stored.isEmpty()) return ElectionTransitionStatus.CLAN_NOT_FOUND;
            Clan clan = stored.get().clan();
            Map<UUID, ClanMember> members = new HashMap<>(clan.members());
            if (type.equals("DEPARTURE")) {
                ClanMember departing = members.get(startedBy);
                ClanMember winner = members.get(winnerId);
                if (departing == null || departing.role() != ClanRole.LEADER || winner == null || winnerId.equals(startedBy)) {
                    return ElectionTransitionStatus.MEMBERSHIP_CONFLICT;
                }
                members.remove(startedBy);
                members.put(winnerId, winner.withRole(ClanRole.LEADER, null));
                for (Map.Entry<UUID, ClanMember> entry : new HashMap<>(members).entrySet()) {
                    ClanMember member = entry.getValue();
                    if (member.role() == ClanRole.MODERATOR && winnerId.equals(member.appointedByDeputyId())) {
                        members.put(entry.getKey(), member.withRole(ClanRole.MODERATOR, null));
                    }
                }
            } else {
                ClanMember incumbent = members.values().stream().filter(m -> m.role() == ClanRole.LEADER).findFirst().orElse(null);
                ClanMember winner = members.get(winnerId);
                if (incumbent == null || winner == null || (winner.role() != ClanRole.LEADER && winner.role() != ClanRole.DEPUTY)) {
                    return ElectionTransitionStatus.MEMBERSHIP_CONFLICT;
                }
                if (!incumbent.playerId().equals(winnerId)) {
                    members.put(incumbent.playerId(), incumbent.withRole(ClanRole.MEMBER, null));
                    members.put(winnerId, winner.withRole(ClanRole.LEADER, null));
                    for (Map.Entry<UUID, ClanMember> entry : new HashMap<>(members).entrySet()) {
                        ClanMember member = entry.getValue();
                        if (member.role() == ClanRole.MODERATOR && winnerId.equals(member.appointedByDeputyId())) {
                            members.put(entry.getKey(), member.withRole(ClanRole.MODERATOR, null));
                        }
                    }
                }
            }
            Clan updated = new Clan(clan.id(), clan.name(), clan.tag(), clan.createdAt(), clan.capacity(),
                    members, clan.totalXp(), clan.tagline());
            if (!new ClanMembershipStateValidator().validate(updated, false).isEmpty()) {
                return ElectionTransitionStatus.MEMBERSHIP_CONFLICT;
            }
            try (PreparedStatement delete = connection.prepareStatement("DELETE FROM clan_members WHERE clan_id = ?")) {
                delete.setString(1, clanId.toString()); delete.executeUpdate();
            }
            insertMembers(updated);
            try (PreparedStatement update = connection.prepareStatement("UPDATE clan_elections SET phase = 'COMPLETED', winner_id = ?, completed_at = ? WHERE election_id = ? AND phase = ?")) {
                update.setString(1, winnerId.toString()); update.setString(2, now.toString());
                update.setString(3, electionId.toString()); update.setString(4, phase);
                if (update.executeUpdate() != 1) throw new SQLException("Election phase changed during completion");
            }
            appendElectionEvent(electionId, "COMPLETED", winnerId, winnerId.toString(), now);
            appendElectionEvent(electionId, "LEADERSHIP_APPLIED", winnerId, type + ":" + clanId, now);
            return ElectionTransitionStatus.UPDATED;
        });
    }

    public enum ElectionCreateStatus { CREATED, ACTIVE_ELECTION_EXISTS, CLAN_NOT_FOUND, INVALID }
    public enum ElectionVoteStatus { VOTED, ALREADY_VOTED, INVALID_CANDIDATE, NOT_FOUND, PHASE_CHANGED, PHASE_CLOSED, INVALID }
    public enum ElectionTransitionStatus { UPDATED, NOT_ACTIVE, NOT_DUE, INVALID, CLAN_NOT_FOUND, MEMBERSHIP_CONFLICT }

    private void insertElectionCandidates(UUID electionId, String phase, List<UUID> candidates) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("INSERT INTO clan_election_candidates(election_id, phase, candidate_id) VALUES (?, ?, ?)")) {
            for (UUID candidate : candidates) {
                insert.setString(1, electionId.toString()); insert.setString(2, phase); insert.setString(3, candidate.toString()); insert.addBatch();
            }
            insert.executeBatch();
        }
    }

    private void appendElectionEvent(UUID electionId, String type, UUID actor, String details, Instant at) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("INSERT INTO clan_election_events(election_id, event_type, actor_id, details, occurred_at) VALUES (?, ?, ?, ?, ?)")) {
            insert.setString(1, electionId.toString()); insert.setString(2, type);
            insert.setString(3, actor == null ? null : actor.toString()); insert.setString(4, details); insert.setString(5, at.toString()); insert.executeUpdate();
        }
    }

    private static ClanXpAwardResult xpResult(
            ClanXpAwardResult.Status status, Long totalXp) {
        return new ClanXpAwardResult(status,
                totalXp == null ? java.util.OptionalLong.empty() : java.util.OptionalLong.of(totalXp),
                totalXp == null ? 0 : ClanLevelPolicy.levelForXp(totalXp));
    }

    private void expireStaleClanRequests(Instant now) throws SQLException {
        List<ClanRequest> stale = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT * FROM clan_requests WHERE status = 'PENDING' AND julianday(expires_at) <= julianday(?)
                ORDER BY request_id
                """)) {
            statement.setString(1, now.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) stale.add(readClanRequest(result));
            }
        }
        for (ClanRequest request : stale) {
            updateClanRequestStatus(request, ClanRequest.Status.EXPIRED, null, now);
        }
    }

    private boolean updateClanRequestStatus(
            ClanRequest request, ClanRequest.Status next, UUID actorId, Instant now) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                UPDATE clan_requests SET status = ? WHERE request_id = ? AND status = 'PENDING'
                """)) {
            statement.setString(1, next.name());
            statement.setString(2, request.id().toString());
            if (statement.executeUpdate() != 1) return false;
        }
        insertClanRequestEvent(request.id(), request.type(), request.status(), next, actorId, now);
        return true;
    }

    private void insertClanRequestEvent(UUID requestId, ClanRequest.Type type,
            ClanRequest.Status from, ClanRequest.Status to, UUID actorId, Instant at) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO clan_request_events
                    (request_id, request_type, from_status, to_status, actor_id, occurred_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """)) {
            statement.setString(1, requestId.toString());
            statement.setString(2, type.name());
            statement.setString(3, from == null ? null : from.name());
            statement.setString(4, to.name());
            statement.setString(5, actorId == null ? null : actorId.toString());
            statement.setString(6, at.toString());
            statement.executeUpdate();
        }
    }

    private static ClanRequest readClanRequest(ResultSet result) throws SQLException {
        return new ClanRequest(UUID.fromString(result.getString("request_id")),
                ClanRequest.Type.valueOf(result.getString("request_type")),
                UUID.fromString(result.getString("clan_id")),
                UUID.fromString(result.getString("player_id")),
                UUID.fromString(result.getString("actor_id")),
                Instant.parse(result.getString("created_at")),
                Instant.parse(result.getString("expires_at")),
                ClanRequest.Status.valueOf(result.getString("status")));
    }

    @Override
    public synchronized ClanCreationPaymentJournal.CreationPrepareResult prepare(ClanCreationPaymentOperation operation) {
        ensureOpen();
        if (operation == null) throw new IllegalArgumentException("operation is required");
        if (operation.state() != ClanCreationPaymentState.PREPARED
                || !operation.createdAt().equals(operation.updatedAt()))
            throw new IllegalArgumentException("A new clan creation payment must start in PREPARED state");
        return inWriteTransaction("Could not prepare clan creation payment", () -> {
            Optional<ClanCreationPaymentOperation> existing = findClanCreationPaymentByKey(operation.idempotencyKey());
            if (existing.isPresent()) {
                ClanCreationPaymentOperation value = existing.get();
                return new ClanCreationPaymentJournal.CreationPrepareResult(
                        sameClanCreationPaymentPayload(value, operation)
                                ? ClanCreationPaymentJournal.CreationPrepareStatus.DUPLICATE
                                : ClanCreationPaymentJournal.CreationPrepareStatus.IDEMPOTENCY_CONFLICT,
                        Optional.of(value));
            }
            if (exists("SELECT 1 FROM clan_creation_payment_operations WHERE operation_id = ?", operation.operationId().toString()))
                return new ClanCreationPaymentJournal.CreationPrepareResult(ClanCreationPaymentJournal.CreationPrepareStatus.OPERATION_CONFLICT, Optional.empty());
            if (exists("SELECT 1 FROM clans WHERE id = ?", operation.clanId().toString()))
                return new ClanCreationPaymentJournal.CreationPrepareResult(ClanCreationPaymentJournal.CreationPrepareStatus.OPERATION_CONFLICT, Optional.empty());
            if (exists("SELECT 1 FROM clan_members WHERE player_id = ?", operation.creatorId().toString()))
                return new ClanCreationPaymentJournal.CreationPrepareResult(ClanCreationPaymentJournal.CreationPrepareStatus.PLAYER_ALREADY_IN_CLAN, Optional.empty());
            if (exists("SELECT 1 FROM clans WHERE tag_key = ?", normalizeTag(operation.tag())))
                return new ClanCreationPaymentJournal.CreationPrepareResult(ClanCreationPaymentJournal.CreationPrepareStatus.TAG_TAKEN, Optional.empty());
            if (exists("SELECT 1 FROM clan_creation_payment_operations WHERE clan_tag = ? COLLATE NOCASE AND state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')", operation.tag()))
                return new ClanCreationPaymentJournal.CreationPrepareResult(ClanCreationPaymentJournal.CreationPrepareStatus.TAG_TAKEN, Optional.empty());
            if (exists("SELECT 1 FROM clan_creation_payment_operations WHERE creator_id = ? AND state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')", operation.creatorId().toString()))
                return new ClanCreationPaymentJournal.CreationPrepareResult(ClanCreationPaymentJournal.CreationPrepareStatus.PLAYER_HAS_UNRESOLVED_CREATION, Optional.empty());
            try (PreparedStatement insert = connection.prepareStatement("""
                    INSERT INTO clan_creation_payment_operations
                    (operation_id, idempotency_key, creator_id, clan_id, clan_name, clan_tag, clan_slogan,
                     clan_created_at, amount_units, state, diagnostic, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                insert.setString(1, operation.operationId().toString());
                insert.setString(2, operation.idempotencyKey());
                insert.setString(3, operation.creatorId().toString());
                insert.setString(4, operation.clanId().toString());
                insert.setString(5, operation.name());
                insert.setString(6, operation.tag());
                insert.setString(7, operation.slogan());
                insert.setString(8, operation.clanCreatedAt().toString());
                insert.setLong(9, operation.amountUnits());
                insert.setString(10, operation.state().name());
                insert.setString(11, operation.diagnostic());
                insert.setString(12, operation.createdAt().toString());
                insert.setString(13, operation.updatedAt().toString());
                insert.executeUpdate();
            }
            appendClanCreationPaymentEvent(operation.operationId(), null, operation.state(), operation.diagnostic(), operation.createdAt());
            return new ClanCreationPaymentJournal.CreationPrepareResult(
                    ClanCreationPaymentJournal.CreationPrepareStatus.CREATED, Optional.of(operation));
        });
    }

    @Override
    public synchronized Optional<ClanCreationPaymentOperation> findCreationByIdempotencyKey(String idempotencyKey) {
        ensureOpen();
        if (idempotencyKey == null || idempotencyKey.isBlank()) return Optional.empty();
        try { return findClanCreationPaymentByKey(idempotencyKey); }
        catch (SQLException | RuntimeException exception) { throw storageFailure("Could not read clan creation payment", exception); }
    }

    @Override
    public synchronized Optional<ClanCreationPaymentOperation> findCreationById(UUID operationId) {
        ensureOpen();
        if (operationId == null) return Optional.empty();
        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM clan_creation_payment_operations WHERE operation_id = ?")) {
            query.setString(1, operationId.toString());
            try (ResultSet row = query.executeQuery()) { return row.next() ? Optional.of(readClanCreationPayment(row)) : Optional.empty(); }
        } catch (SQLException | RuntimeException exception) { throw storageFailure("Could not read clan creation payment", exception); }
    }

    @Override
    public synchronized List<ClanCreationPaymentOperation> findUnresolvedCreations() {
        ensureOpen();
        List<ClanCreationPaymentOperation> result = new ArrayList<>();
        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM clan_creation_payment_operations WHERE state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN') ORDER BY created_at, operation_id");
             ResultSet rows = query.executeQuery()) {
            while (rows.next()) result.add(readClanCreationPayment(rows));
            return List.copyOf(result);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not list unresolved clan creation payments", exception);
        }
    }

    @Override
    public synchronized ClanCreationPaymentJournal.CreationTransitionResult transition(UUID operationId,
            ClanCreationPaymentState expected, ClanCreationPaymentState next, String diagnostic, Instant at) {
        ensureOpen();
        if (operationId == null || expected == null || next == null || at == null
                || (diagnostic != null && diagnostic.length() > 1000))
            return new ClanCreationPaymentJournal.CreationTransitionResult(ClanCreationPaymentJournal.CreationTransitionStatus.INVALID_TRANSITION, Optional.empty());
        if (!validClanCreationPaymentTransition(expected, next))
            return new ClanCreationPaymentJournal.CreationTransitionResult(ClanCreationPaymentJournal.CreationTransitionStatus.INVALID_TRANSITION, Optional.empty());
        return inWriteTransaction("Could not transition clan creation payment", () -> {
            ClanCreationPaymentOperation current = findClanCreationPaymentById(operationId).orElse(null);
            if (current == null) return new ClanCreationPaymentJournal.CreationTransitionResult(ClanCreationPaymentJournal.CreationTransitionStatus.NOT_FOUND, Optional.empty());
            if (current.state() != expected || at.isBefore(current.updatedAt()))
                return new ClanCreationPaymentJournal.CreationTransitionResult(ClanCreationPaymentJournal.CreationTransitionStatus.STATE_CONFLICT, Optional.of(current));
            try (PreparedStatement update = connection.prepareStatement("UPDATE clan_creation_payment_operations SET state = ?, diagnostic = ?, updated_at = ? WHERE operation_id = ? AND state = ?")) {
                update.setString(1, next.name()); update.setString(2, diagnostic); update.setString(3, at.toString());
                update.setString(4, operationId.toString()); update.setString(5, expected.name());
                if (update.executeUpdate() != 1) return new ClanCreationPaymentJournal.CreationTransitionResult(ClanCreationPaymentJournal.CreationTransitionStatus.STATE_CONFLICT, findClanCreationPaymentById(operationId));
            }
            appendClanCreationPaymentEvent(operationId, expected, next, diagnostic, at);
            return new ClanCreationPaymentJournal.CreationTransitionResult(ClanCreationPaymentJournal.CreationTransitionStatus.UPDATED,
                    Optional.of(current.withState(next, diagnostic, at)));
        });
    }

    @Override
    public synchronized ClanCreationPaymentJournal.CreationCommitResult commitPaidClan(UUID operationId, Clan clan, Instant at) {
        ensureOpen();
        if (operationId == null || clan == null || at == null)
            return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.CLAN_MISMATCH, Optional.empty());
        return inWriteTransaction("Could not commit paid clan creation", () -> {
            ClanCreationPaymentOperation operation = findClanCreationPaymentById(operationId).orElse(null);
            if (operation == null) return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.NOT_FOUND, Optional.empty());
            if (operation.state() != ClanCreationPaymentState.DEBIT_CONFIRMED)
                return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.NOT_DEBIT_CONFIRMED, Optional.empty());
            if (!clan.id().equals(operation.clanId()) || !clan.name().equals(operation.name())
                    || !clan.tag().equals(operation.tag()) || !Objects.equals(clan.tagline(), operation.slogan())
                    || !clan.createdAt().equals(operation.clanCreatedAt()) || clan.memberCount() != 1
                    || clan.capacity() != ClanCapacityPolicy.initialCapacity() || clan.totalXp() != 0
                    || clan.leader().filter(leader -> leader.playerId().equals(operation.creatorId())).isEmpty()
                    || !new ClanMembershipStateValidator().validate(clan, false).isEmpty())
                return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.CLAN_MISMATCH, Optional.empty());
            if (exists("SELECT 1 FROM clans WHERE id = ?", clan.id().toString()))
                return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.CLAN_ID_CONFLICT, Optional.empty());
            if (exists("SELECT 1 FROM clans WHERE tag_key = ?", normalizeTag(clan.tag())))
                return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.TAG_CONFLICT, Optional.empty());
            if (exists("SELECT 1 FROM clan_members WHERE player_id = ?", operation.creatorId().toString()))
                return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.MEMBER_CONFLICT, Optional.empty());
            insertClan(clan);
            try (PreparedStatement update = connection.prepareStatement("UPDATE clan_creation_payment_operations SET state = 'COMMITTED', updated_at = ?, diagnostic = NULL WHERE operation_id = ? AND state = 'DEBIT_CONFIRMED'")) {
                update.setString(1, at.toString()); update.setString(2, operationId.toString());
                if (update.executeUpdate() != 1) throw new SQLException("Clan creation payment state changed during commit");
            }
            appendClanCreationPaymentEvent(operationId, ClanCreationPaymentState.DEBIT_CONFIRMED,
                    ClanCreationPaymentState.COMMITTED, null, at);
            return new ClanCreationPaymentJournal.CreationCommitResult(ClanCreationPaymentJournal.CreationCommitStatus.COMMITTED, Optional.of(clan));
        });
    }

    private Optional<ClanCreationPaymentOperation> findClanCreationPaymentByKey(String key) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM clan_creation_payment_operations WHERE idempotency_key = ?")) {
            query.setString(1, key);
            try (ResultSet row = query.executeQuery()) { return row.next() ? Optional.of(readClanCreationPayment(row)) : Optional.empty(); }
        }
    }

    private Optional<ClanCreationPaymentOperation> findClanCreationPaymentById(UUID id) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement("SELECT * FROM clan_creation_payment_operations WHERE operation_id = ?")) {
            query.setString(1, id.toString());
            try (ResultSet row = query.executeQuery()) { return row.next() ? Optional.of(readClanCreationPayment(row)) : Optional.empty(); }
        }
    }

    private static ClanCreationPaymentOperation readClanCreationPayment(ResultSet row) throws SQLException {
        return new ClanCreationPaymentOperation(UUID.fromString(row.getString("operation_id")),
                row.getString("idempotency_key"), UUID.fromString(row.getString("creator_id")),
                UUID.fromString(row.getString("clan_id")), row.getString("clan_name"), row.getString("clan_tag"),
                row.getString("clan_slogan"), Instant.parse(row.getString("clan_created_at")),
                row.getLong("amount_units"), ClanCreationPaymentState.valueOf(row.getString("state")),
                row.getString("diagnostic"), Instant.parse(row.getString("created_at")),
                Instant.parse(row.getString("updated_at")));
    }

    private void appendClanCreationPaymentEvent(UUID operationId, ClanCreationPaymentState from,
            ClanCreationPaymentState to, String diagnostic, Instant at) throws SQLException {
        try (PreparedStatement insert = connection.prepareStatement("INSERT INTO clan_creation_payment_events(operation_id, from_state, to_state, diagnostic, occurred_at) VALUES (?, ?, ?, ?, ?)")) {
            insert.setString(1, operationId.toString()); insert.setString(2, from == null ? null : from.name());
            insert.setString(3, to.name()); insert.setString(4, diagnostic); insert.setString(5, at.toString());
            insert.executeUpdate();
        }
    }

    private static boolean sameClanCreationPaymentPayload(ClanCreationPaymentOperation left, ClanCreationPaymentOperation right) {
        return left.operationId().equals(right.operationId()) && left.creatorId().equals(right.creatorId())
                && left.clanId().equals(right.clanId()) && left.name().equals(right.name())
                && left.tag().equals(right.tag()) && Objects.equals(left.slogan(), right.slogan())
                && left.clanCreatedAt().equals(right.clanCreatedAt()) && left.amountUnits() == right.amountUnits();
    }

    private static boolean validClanCreationPaymentTransition(ClanCreationPaymentState from, ClanCreationPaymentState to) {
        return switch (from) {
            case PREPARED -> to == ClanCreationPaymentState.CALLING
                    || to == ClanCreationPaymentState.FAILED_NO_EFFECT;
            case CALLING -> to == ClanCreationPaymentState.DEBIT_CONFIRMED
                    || to == ClanCreationPaymentState.FAILED_NO_EFFECT || to == ClanCreationPaymentState.UNKNOWN;
            case UNKNOWN -> to == ClanCreationPaymentState.DEBIT_CONFIRMED
                    || to == ClanCreationPaymentState.FAILED_NO_EFFECT;
            case DEBIT_CONFIRMED -> to == ClanCreationPaymentState.COMMITTED;
            case COMMITTED, FAILED_NO_EFFECT -> false;
        };
    }

    @Override
    public synchronized RegistrationStatus registerIfAvailable(Clan clan) {
        ensureOpen();
        if (clan == null) {
            return RegistrationStatus.CLAN_REQUIRED;
        }
        return inWriteTransaction("Could not register clan", () -> {
            if (exists("SELECT 1 FROM clans WHERE id = ?", clan.id().toString())) {
                return RegistrationStatus.CLAN_ID_CONFLICT;
            }
            if (exists("SELECT 1 FROM clan_creation_payment_operations WHERE clan_id = ? AND state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')", clan.id().toString())) {
                return RegistrationStatus.CLAN_ID_CONFLICT;
            }
            if (exists("SELECT 1 FROM clans WHERE tag_key = ?", normalizeTag(clan.tag()))) {
                return RegistrationStatus.TAG_CONFLICT;
            }
            if (exists("SELECT 1 FROM clan_creation_payment_operations WHERE clan_tag = ? COLLATE NOCASE AND state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')", clan.tag())) {
                return RegistrationStatus.TAG_CONFLICT;
            }
            for (UUID playerId : clan.members().keySet()) {
                if (exists("SELECT 1 FROM clan_members WHERE player_id = ?", playerId.toString())
                        || exists("SELECT 1 FROM clan_creation_payment_operations WHERE creator_id = ? AND state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')", playerId.toString())) {
                    return RegistrationStatus.MEMBER_CONFLICT;
                }
            }
            insertClan(clan);
            return RegistrationStatus.REGISTERED;
        });
    }

    @Override
    public synchronized CapacityUpdateStatus updateCapacityIfUnchanged(
            Clan expectedClan,
            UUID leaderId,
            Clan updatedClan) {
        ensureOpen();
        if (expectedClan == null || leaderId == null || updatedClan == null) {
            return CapacityUpdateStatus.INVALID_UPDATE;
        }
        return inWriteTransaction("Could not update clan capacity", () -> {
            Optional<StoredClan> currentOptional = readClan(expectedClan.id());
            if (currentOptional.isEmpty()) {
                return CapacityUpdateStatus.CLAN_NOT_FOUND;
            }
            StoredClan stored = currentOptional.get();
            Clan current = stored.clan();
            if (!isLeader(current, leaderId)) {
                return CapacityUpdateStatus.LEADER_CHANGED;
            }
            if (!current.equals(expectedClan)) {
                return CapacityUpdateStatus.STATE_CONFLICT;
            }
            if (!isValidExpansion(expectedClan, updatedClan)) {
                return CapacityUpdateStatus.INVALID_UPDATE;
            }
            int changed = updateCapacity(
                    current.id(), stored.revision(), updatedClan.capacity());
            return changed == 1
                    ? CapacityUpdateStatus.UPDATED
                    : CapacityUpdateStatus.STATE_CONFLICT;
        });
    }

    @Override
    public synchronized MembershipUpdateStatus updateMembershipIfUnchanged(
            Clan expectedClan,
            Clan updatedClan) {
        ensureOpen();
        if (!isMembershipOnlyUpdate(expectedClan, updatedClan)
                || !new ClanMembershipStateValidator().validate(updatedClan, false).isEmpty()) {
            return MembershipUpdateStatus.INVALID_UPDATE;
        }
        return inWriteTransaction("Could not update clan membership", () -> {
            Optional<StoredClan> currentOptional = readClan(expectedClan.id());
            if (currentOptional.isEmpty()) {
                return MembershipUpdateStatus.CLAN_NOT_FOUND;
            }
            Clan current = currentOptional.get().clan();
            if (!current.equals(expectedClan)) {
                return MembershipUpdateStatus.STATE_CONFLICT;
            }
            for (UUID playerId : updatedClan.members().keySet()) {
                if (!expectedClan.members().containsKey(playerId)
                        && exists("SELECT 1 FROM clan_members WHERE player_id = ? AND clan_id <> ?",
                                playerId.toString(), expectedClan.id().toString())) {
                    return MembershipUpdateStatus.MEMBER_CONFLICT;
                }
            }
            try (PreparedStatement delete = connection.prepareStatement(
                    "DELETE FROM clan_members WHERE clan_id = ?")) {
                delete.setString(1, expectedClan.id().toString());
                delete.executeUpdate();
            }
            insertMembers(updatedClan);
            // revision is deliberately reserved for capacity-purchase CAS/evidence in schema v4.
            return MembershipUpdateStatus.UPDATED;
        });
    }

    private static boolean isMembershipOnlyUpdate(Clan expectedClan, Clan updatedClan) {
        return expectedClan != null && updatedClan != null
                && expectedClan.id().equals(updatedClan.id())
                && expectedClan.name().equals(updatedClan.name())
                && expectedClan.tag().equals(updatedClan.tag())
                && expectedClan.createdAt().equals(updatedClan.createdAt())
                && expectedClan.capacity() == updatedClan.capacity()
                && expectedClan.totalXp() == updatedClan.totalXp()
                && java.util.Objects.equals(expectedClan.tagline(), updatedClan.tagline())
                && !expectedClan.members().equals(updatedClan.members());
    }

    @Override
    public synchronized PrepareResult prepare(CapacityPurchaseIntent intent) {
        ensureOpen();
        if (intent == null) {
            throw new NullPointerException("intent");
        }
        return inWriteTransaction("Could not prepare capacity purchase", () -> {
            Optional<CapacityPurchaseOperation> byKey =
                    findPurchaseBy("idempotency_key", intent.idempotencyKey());
            if (byKey.isPresent()) {
                CapacityPurchaseOperation existing = byKey.get();
                boolean samePayload = findPurchaseFingerprint(intent.idempotencyKey())
                        .filter(CapacityPurchaseFingerprint.of(intent)::equals)
                        .isPresent();
                return new PrepareResult(
                        samePayload ? PrepareStatus.DUPLICATE_REQUEST
                                : PrepareStatus.IDEMPOTENCY_KEY_CONFLICT,
                        Optional.of(existing));
            }
            if (findPurchaseBy("operation_id", intent.operationId().toString()).isPresent()) {
                return new PrepareResult(
                        PrepareStatus.OPERATION_ID_CONFLICT, Optional.empty());
            }
            Optional<CapacityPurchaseOperation> byBusinessId =
                    findPurchaseBy("business_operation_id", intent.businessOperationId());
            if (byBusinessId.isPresent()
                    || findAppliedOperationId(intent.businessOperationId()).isPresent()) {
                return new PrepareResult(
                        PrepareStatus.BUSINESS_OPERATION_CONFLICT, byBusinessId);
            }
            int expectedAmount = ClanCapacityPolicy.nextExpansionCost(
                    intent.expectedClan().capacity()).orElseThrow(() ->
                    new IllegalArgumentException("Clan has no next capacity expansion"));
            if (!ClanCapacityPolicy.canExpandTo(
                    intent.expectedClan().capacity(), intent.targetCapacity())
                    || intent.amount() != expectedAmount) {
                throw new IllegalArgumentException("Invalid capacity purchase intent");
            }

            Optional<StoredClan> current = readClan(intent.expectedClan().id());
            if (current.isEmpty()) {
                return new PrepareResult(PrepareStatus.CLAN_NOT_FOUND, Optional.empty());
            }
            StoredClan stored = current.get();
            if (!isLeader(stored.clan(), intent.actorId())) {
                return new PrepareResult(PrepareStatus.LEADER_CHANGED, Optional.empty());
            }
            if (stored.revision() != intent.expectedRevision()
                    || !stored.clan().equals(intent.expectedClan())) {
                return new PrepareResult(PrepareStatus.STATE_CONFLICT, Optional.empty());
            }

            try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT INTO capacity_purchase_operations (
                        operation_id, idempotency_key, business_operation_id,
                        clan_id, actor_id, expected_capacity, target_capacity,
                        expected_revision, amount, payload_fingerprint,
                        state, provider_operation_id,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)
                    """)) {
                String now = Instant.now().toString();
                statement.setString(1, intent.operationId().toString());
                statement.setString(2, intent.idempotencyKey());
                statement.setString(3, intent.businessOperationId());
                statement.setString(4, intent.expectedClan().id().toString());
                statement.setString(5, intent.actorId().toString());
                statement.setInt(6, intent.expectedClan().capacity());
                statement.setInt(7, intent.targetCapacity());
                statement.setLong(8, stored.revision());
                statement.setLong(9, intent.amount());
                statement.setString(10, CapacityPurchaseFingerprint.of(intent));
                statement.setString(11, CapacityPurchaseState.PREPARED.name());
                statement.setString(12, now);
                statement.setString(13, now);
                statement.executeUpdate();
            }
            insertPurchaseEvent(
                    intent.operationId(),
                    null,
                    CapacityPurchaseState.PREPARED,
                    null,
                    null);
            return new PrepareResult(
                    PrepareStatus.CREATED,
                    findPurchaseBy("operation_id", intent.operationId().toString()));
        });
    }

    @Override
    public synchronized Optional<CapacityPurchaseOperation> findByIdempotencyKey(
            String idempotencyKey) {
        ensureOpen();
        if (idempotencyKey == null) {
            return Optional.empty();
        }
        try {
            return findPurchaseBy("idempotency_key", idempotencyKey);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not find purchase by idempotency key", exception);
        }
    }

    @Override
    public synchronized Optional<CapacityPurchaseOperation> findByBusinessOperationId(
            String businessOperationId) {
        ensureOpen();
        if (businessOperationId == null) {
            return Optional.empty();
        }
        try {
            return findPurchaseBy("business_operation_id", businessOperationId);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not find purchase by business operation id", exception);
        }
    }

    @Override
    public synchronized List<CapacityPurchaseOperation> findByState(CapacityPurchaseState state) {
        ensureOpen();
        if (state == null) {
            return List.of();
        }

        try {
            validatePurchaseJournalConsistency();
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not validate capacity purchase journal", exception);
        }

        List<CapacityPurchaseOperation> operations = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT * FROM capacity_purchase_operations
                WHERE state = ?
                ORDER BY julianday(created_at), operation_id
                """)) {
            statement.setString(1, state.name());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    String operationIdText = result.getString("operation_id");
                    try {
                        operations.add(new CapacityPurchaseOperation(
                                UUID.fromString(operationIdText),
                                result.getString("idempotency_key"),
                                result.getString("business_operation_id"),
                                UUID.fromString(result.getString("clan_id")),
                                UUID.fromString(result.getString("actor_id")),
                                result.getInt("expected_capacity"),
                                result.getInt("target_capacity"),
                                result.getLong("expected_revision"),
                                result.getLong("amount"),
                                CapacityPurchaseState.valueOf(result.getString("state")),
                                result.getString("provider_operation_id"),
                                Instant.parse(result.getString("created_at")),
                                Instant.parse(result.getString("updated_at"))));
                    } catch (RuntimeException exception) {
                        throw new StorageException(
                                "Corrupt capacity purchase history for operation "
                                        + operationIdText + ": invalid operation record",
                                exception);
                    }
                }
            }
            return List.copyOf(operations);
        } catch (SQLException | RuntimeException exception) {
            if (exception instanceof StorageException storageException) {
                throw storageException;
            }
            throw storageFailure("Could not find purchases by state", exception);
        }
    }

    public synchronized List<CapacityPurchaseOperation> findUnresolved() {
        ensureOpen();
        List<CapacityPurchaseOperation> operations = new ArrayList<>();
        try {
            validatePurchaseJournalConsistency();
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not validate capacity purchase journal", exception);
        }
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT operation_id FROM capacity_purchase_operations
                WHERE state NOT IN (?, ?, ?)
                ORDER BY julianday(created_at), operation_id
                """)) {
            statement.setString(1, CapacityPurchaseState.COMMITTED.name());
            statement.setString(2, CapacityPurchaseState.FAILED_NO_EFFECT.name());
            statement.setString(3, CapacityPurchaseState.COMPENSATED.name());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    findPurchaseBy("operation_id", result.getString(1)).ifPresent(operations::add);
                }
            }
            return List.copyOf(operations);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not list unresolved purchases", exception);
        }
    }

    @Override
    public synchronized List<CapacityPurchaseEvent> listEvents(UUID operationId) {
        ensureOpen();
        if (operationId == null) {
            return List.of();
        }
        List<CapacityPurchaseEvent> events = new ArrayList<>();
        try {
            if (findPurchaseBy("operation_id", operationId.toString()).isEmpty()) {
                return List.of();
            }
            try (PreparedStatement statement = connection.prepareStatement("""
                SELECT event_id, from_state, to_state, evidence, evidence_provenance,
                    provider_operation_id, occurred_at
                FROM capacity_purchase_events
                WHERE operation_id = ?
                ORDER BY event_id
                """)) {
                statement.setString(1, operationId.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        events.add(new CapacityPurchaseEvent(
                                result.getLong("event_id"),
                                operationId,
                                parseStateOrNull(result.getString("from_state")),
                                CapacityPurchaseState.valueOf(result.getString("to_state")),
                                parseEvidenceOrNull(result.getString("evidence")),
                                CapacityPurchaseEvidenceProvenance.valueOf(
                                        result.getString("evidence_provenance")),
                                Instant.parse(result.getString("occurred_at")),
                                result.getString("provider_operation_id")));
                    }
                }
            }
            return List.copyOf(events);
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not read capacity purchase events", exception);
        }
    }

    @Override
    public synchronized TransitionResult transition(
            UUID operationId,
            CapacityPurchaseState expectedState,
            CapacityPurchaseState nextState,
            CapacityPurchaseTransitionEvidence evidence,
            String providerOperationId) {
        ensureOpen();
        if (operationId == null || expectedState == null || nextState == null || evidence == null) {
            throw new NullPointerException("operationId, states and evidence are required");
        }
        return inWriteTransaction("Could not transition capacity purchase", () -> {
            Optional<CapacityPurchaseOperation> operation =
                    findPurchaseBy("operation_id", operationId.toString());
            if (operation.isEmpty()) {
                return new TransitionResult(
                        TransitionStatus.OPERATION_NOT_FOUND, Optional.empty());
            }
            CapacityPurchaseOperation current = operation.get();
            if (current.state() != expectedState) {
                return new TransitionResult(TransitionStatus.STATE_CONFLICT, operation);
            }
            CapacityPurchaseTransitionPolicy.Result decision =
                    CapacityPurchaseTransitionPolicy.evaluate(expectedState, nextState, evidence);
            if (decision != CapacityPurchaseTransitionPolicy.Result.ALLOWED
                    || nextState == CapacityPurchaseState.COMMITTED) {
                TransitionStatus status = switch (decision) {
                    case ALLOWED, INVALID_TRANSITION -> TransitionStatus.INVALID_TRANSITION;
                    case EVIDENCE_REQUIRED -> TransitionStatus.EVIDENCE_REQUIRED;
                    case UNEXPECTED_EVIDENCE -> TransitionStatus.UNEXPECTED_EVIDENCE;
                };
                return new TransitionResult(status, operation);
            }
            try (PreparedStatement statement = connection.prepareStatement("""
                    UPDATE capacity_purchase_operations
                    SET state = ?, provider_operation_id = ?, updated_at = ?
                    WHERE operation_id = ? AND state = ?
                    """)) {
                statement.setString(1, nextState.name());
                statement.setString(2, providerOperationId);
                statement.setString(3, Instant.now().toString());
                statement.setString(4, operationId.toString());
                statement.setString(5, expectedState.name());
                if (statement.executeUpdate() != 1) {
                    return new TransitionResult(
                            TransitionStatus.STATE_CONFLICT,
                            findPurchaseBy("operation_id", operationId.toString()));
                }
            }
            insertPurchaseEvent(operationId, expectedState, nextState, evidence, providerOperationId);
            return new TransitionResult(
                    TransitionStatus.UPDATED,
                    findPurchaseBy("operation_id", operationId.toString()));
        });
    }

    @Override
    public synchronized CommitResult commitCapacityPurchase(UUID operationId) {
        ensureOpen();
        if (operationId == null) {
            throw new NullPointerException("operationId");
        }
        return inWriteTransaction("Could not commit capacity purchase", () -> {
            Optional<CapacityPurchaseOperation> operationOptional =
                    findPurchaseBy("operation_id", operationId.toString());
            if (operationOptional.isEmpty()) {
                return new CommitResult(CommitStatus.OPERATION_NOT_FOUND, Optional.empty());
            }
            CapacityPurchaseOperation operation = operationOptional.get();
            if (operation.state() == CapacityPurchaseState.COMMITTED) {
                return new CommitResult(
                        CommitStatus.ALREADY_COMMITTED, operationOptional);
            }
            if (operation.state() != CapacityPurchaseState.DEBIT_CONFIRMED) {
                return new CommitResult(CommitStatus.WRONG_STATE, operationOptional);
            }
            if (CapacityPurchaseTransitionPolicy.evaluate(
                    operation.state(),
                    CapacityPurchaseState.COMMITTED,
                    CapacityPurchaseTransitionEvidence.ATOMIC_CAPACITY_COMMIT)
                    != CapacityPurchaseTransitionPolicy.Result.ALLOWED) {
                return new CommitResult(CommitStatus.WRONG_STATE, operationOptional);
            }
            if (!purchaseHistoryIsFullyRecorded(operationId)) {
                // Schema v1-v3 rows never stored evidence; continuing such an operation would turn
                // an unverifiable history into a commit that looks confirmed. Fail closed instead.
                return new CommitResult(
                        CommitStatus.HISTORY_EVIDENCE_UNVERIFIABLE, operationOptional);
            }
            Optional<UUID> applied =
                    findAppliedOperationId(operation.businessOperationId());
            if (applied.isPresent()) {
                return new CommitResult(
                        CommitStatus.BUSINESS_OPERATION_CONFLICT, operationOptional);
            }

            Optional<StoredClan> currentOptional = readClan(operation.clanId());
            if (currentOptional.isEmpty()) {
                return new CommitResult(CommitStatus.CLAN_NOT_FOUND, operationOptional);
            }
            StoredClan current = currentOptional.get();
            if (!isLeader(current.clan(), operation.actorId())) {
                return new CommitResult(CommitStatus.LEADER_CHANGED, operationOptional);
            }
            if (current.revision() != operation.expectedRevision()
                    || current.clan().capacity() != operation.expectedCapacity()) {
                return new CommitResult(CommitStatus.STATE_CONFLICT, operationOptional);
            }

            Clan expanded;
            try {
                expanded = current.clan().withExpandedCapacity(operation.targetCapacity());
            } catch (IllegalArgumentException exception) {
                return new CommitResult(CommitStatus.STATE_CONFLICT, operationOptional);
            }
            if (updateCapacity(
                    operation.clanId(),
                    operation.expectedRevision(),
                    operation.targetCapacity()) != 1) {
                return new CommitResult(CommitStatus.STATE_CONFLICT, operationOptional);
            }
            try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT INTO applied_business_operations (
                        business_operation_id, operation_id, clan_id,
                        from_capacity, to_capacity, committed_at,
                        expected_revision, applied_revision, amount, commit_evidence_provenance
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """)) {
                statement.setString(1, operation.businessOperationId());
                statement.setString(2, operation.operationId().toString());
                statement.setString(3, operation.clanId().toString());
                statement.setInt(4, operation.expectedCapacity());
                statement.setInt(5, expanded.capacity());
                statement.setString(6, Instant.now().toString());
                statement.setLong(7, operation.expectedRevision());
                statement.setLong(8, operation.expectedRevision() + 1);
                statement.setLong(9, operation.amount());
                statement.setString(10, CapacityPurchaseEvidenceProvenance.RECORDED.name());
                statement.executeUpdate();
            }
            try (PreparedStatement statement = connection.prepareStatement("""
                    UPDATE capacity_purchase_operations
                    SET state = ?, updated_at = ?
                    WHERE operation_id = ? AND state = ?
                    """)) {
                statement.setString(1, CapacityPurchaseState.COMMITTED.name());
                statement.setString(2, Instant.now().toString());
                statement.setString(3, operationId.toString());
                statement.setString(4, CapacityPurchaseState.DEBIT_CONFIRMED.name());
                if (statement.executeUpdate() != 1) {
                    throw new SQLException("Purchase state changed during commit");
                }
            }
            insertPurchaseEvent(
                    operationId,
                    CapacityPurchaseState.DEBIT_CONFIRMED,
                    CapacityPurchaseState.COMMITTED,
                    CapacityPurchaseTransitionEvidence.ATOMIC_CAPACITY_COMMIT,
                    operation.providerOperationId());
            return new CommitResult(
                    CommitStatus.COMMITTED,
                    findPurchaseBy("operation_id", operationId.toString()));
        });
    }

    @Override
    public synchronized Optional<UUID> findAppliedOperationId(String businessOperationId) {
        ensureOpen();
        if (businessOperationId == null) {
            return Optional.empty();
        }
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT operation_id FROM applied_business_operations
                WHERE business_operation_id = ?
                """)) {
            statement.setString(1, businessOperationId);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    return Optional.empty();
                }
                // A marker alone proves nothing: it is only meaningful together with its operation,
                // the stored journal and the clan row it claims to have changed.
                UUID markerOperationId = UUID.fromString(result.getString(1));
                findPurchaseBy("operation_id", markerOperationId.toString());
                return Optional.of(markerOperationId);
            }
        } catch (SQLException | RuntimeException exception) {
            throw storageFailure("Could not find applied business operation", exception);
        }
    }

    /**
     * Creates a consistent standalone snapshot of the live database, including committed WAL
     * content. The destination must not already exist; the source connection remains open.
     */
    public synchronized Path backupTo(Path backupPath) {
        ensureOpen();
        if (backupPath == null) {
            throw new NullPointerException("backupPath");
        }
        Path target = backupPath.toAbsolutePath().normalize();
        if (Files.exists(target)) {
            throw new StorageException("Backup destination already exists: " + target);
        }
        boolean backupCreated = false;
        try {
            Path parent = target.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            String escapedPath = target.toString().replace("'", "''");
            try (Statement statement = connection.createStatement()) {
                statement.execute("VACUUM INTO '" + escapedPath + "'");
            }
            backupCreated = true;
            if (!Files.isRegularFile(target) || Files.size(target) == 0) {
                throw new StorageException("SQLite backup is missing or empty: " + target);
            }
            verifyBackup(target);
            return target;
        } catch (SQLException | IOException exception) {
            if (backupCreated) {
                deleteFailedBackup(target, exception);
            }
            throw new StorageException("Could not create SQLite backup: " + target, exception);
        } catch (RuntimeException exception) {
            if (backupCreated) {
                deleteFailedBackup(target, exception);
            }
            throw exception;
        }
    }

    private static void verifyBackup(Path backupPath) throws SQLException {
        try (Connection backup = DriverManager.getConnection("jdbc:sqlite:" + backupPath);
             Statement statement = backup.createStatement()) {
            try (ResultSet result = statement.executeQuery("PRAGMA integrity_check")) {
                if (!result.next() || !"ok".equalsIgnoreCase(result.getString(1))) {
                    throw new SQLException("SQLite backup integrity_check failed");
                }
                while (result.next()) {
                    if (!"ok".equalsIgnoreCase(result.getString(1))) {
                        throw new SQLException("SQLite backup integrity_check reported corruption");
                    }
                }
            }
            try (ResultSet result = statement.executeQuery("PRAGMA foreign_key_check")) {
                if (result.next()) {
                    throw new SQLException("SQLite backup contains foreign-key violations");
                }
            }
            try (ResultSet result = statement.executeQuery("PRAGMA user_version")) {
                if (!result.next() || result.getInt(1) != SCHEMA_VERSION) {
                    throw new SQLException("SQLite backup has an unexpected schema version");
                }
            }
        }
    }

    private static void deleteFailedBackup(Path target, RuntimeException original) {
        try {
            Files.deleteIfExists(target);
        } catch (IOException cleanupFailure) {
            original.addSuppressed(cleanupFailure);
        }
    }

    private static void deleteFailedBackup(Path target, Exception original) {
        try {
            Files.deleteIfExists(target);
        } catch (IOException cleanupFailure) {
            original.addSuppressed(cleanupFailure);
        }
    }

    @Override
    public synchronized void close() {
        if (connectionState != ConnectionState.OPEN) {
            return;
        }
        connectionState = ConnectionState.CLOSED;
        try {
            connection.close();
        } catch (SQLException exception) {
            throw storageFailure("Could not close SQLite clan store", exception);
        }
    }

    private void checkDatabaseIntegrity() throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA quick_check")) {
            if (!result.next() || !"ok".equalsIgnoreCase(result.getString(1))) {
                throw new StorageException("SQLite integrity check failed");
            }
        }
    }

    private void configureConnection() throws SQLException {
        execute("PRAGMA foreign_keys = ON");
        execute("PRAGMA busy_timeout = " + BUSY_TIMEOUT_MILLIS);
        String journalMode = pragmaString("PRAGMA journal_mode = WAL");
        execute("PRAGMA synchronous = FULL");
        PragmaSettings settings = pragmaSettings();
        if (settings.foreignKeys() != 1
                || !"wal".equalsIgnoreCase(journalMode)
                || !"wal".equalsIgnoreCase(settings.journalMode())
                || settings.synchronous() != 2
                || settings.busyTimeoutMillis() != BUSY_TIMEOUT_MILLIS) {
            throw new StorageException("SQLite did not accept the required connection settings: "
                    + settings);
        }
    }

    private int pragmaInt(String pragma) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(pragma)) {
            if (!result.next()) {
                throw new SQLException("PRAGMA returned no value: " + pragma);
            }
            return result.getInt(1);
        }
    }

    private String pragmaString(String pragma) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(pragma)) {
            if (!result.next()) {
                throw new SQLException("PRAGMA returned no value: " + pragma);
            }
            return result.getString(1);
        }
    }

    PragmaSettings pragmaSettings() throws SQLException {
        return new PragmaSettings(
                pragmaInt("PRAGMA foreign_keys"),
                pragmaString("PRAGMA journal_mode"),
                pragmaInt("PRAGMA synchronous"),
                pragmaInt("PRAGMA busy_timeout"));
    }

    private void migrate(boolean existed, SqliteMigrationHook migrationHook) throws SQLException {
        int version;
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA user_version")) {
            version = result.next() ? result.getInt(1) : 0;
        }
        if (version > SCHEMA_VERSION) {
            throw new StorageException(
                    "Database schema version " + version + " is newer than supported version "
                            + SCHEMA_VERSION);
        }
        if (version == SCHEMA_VERSION) {
            validateSchema(version);
            return;
        }
        if (version == 0 && (existed || hasUserTables())) {
            throw new StorageException(
                    "Refusing to migrate an existing unversioned SQLite database");
        }

        if (version == 0) {
            try {
                applyMigration(1, migrationHook, () -> {
                    createVersionOneSchema();
                    recordMigration(1);
                    execute("PRAGMA user_version = 1");
                    return null;
                });
            } catch (RuntimeException | Error exception) {
                throw new InitialMigrationException(exception);
            }
            version = 1;
            validateSchema(version);
        } else {
            validateSchema(version);
        }

        if (version < 2) {
            applyMigration(2, migrationHook, () -> {
                execute("""
                        ALTER TABLE capacity_purchase_operations
                        ADD COLUMN payload_fingerprint TEXT NOT NULL DEFAULT ''
                        """);
                recordMigration(2);
                execute("PRAGMA user_version = 2");
                return null;
            });
            version = 2;
        }
        if (version < 3) {
            applyMigration(3, migrationHook, () -> {
                migratePurchaseCompensationStates();
                recordMigration(3);
                execute("PRAGMA user_version = 3");
                return null;
            });
            version = 3;
        }
        if (version < 4) {
            applyMigration(4, migrationHook, () -> {
                migratePurchaseEvidenceHistory();
                recordMigration(4);
                execute("PRAGMA user_version = 4");
                return null;
            });
            version = 4;
        }
        if (version < 5) {
            applyMigration(5, migrationHook, () -> {
                createClanRequestSchema();
                recordMigration(5);
                execute("PRAGMA user_version = 5");
                return null;
            });
            version = 5;
        }
        if (version < 6) {
            applyMigration(6, migrationHook, () -> {
                createClanXpSchema();
                recordMigration(6);
                execute("PRAGMA user_version = 6");
                return null;
            });
            version = 6;
        }
        if (version < 7) {
            applyMigration(7, migrationHook, () -> {
                createClanElectionSchema();
                recordMigration(7);
                execute("PRAGMA user_version = 7");
                return null;
            });
            version = 7;
        }
        if (version < 8) {
            applyMigration(8, migrationHook, () -> {
                createClanActivitySchema();
                recordMigration(8);
                execute("PRAGMA user_version = 8");
                return null;
            });
            version = 8;
        }
        if (version < 9) {
            applyMigration(9, migrationHook, () -> {
                createClanElectionSafetySchema();
                recordMigration(9);
                execute("PRAGMA user_version = 9");
                return null;
            });
            version = 9;
        }
        if (version < 10) {
            applyMigration(10, migrationHook, () -> {
                createClanCreationPaymentSchema();
                recordMigration(10);
                execute("PRAGMA user_version = 10");
                return null;
            });
            version = 10;
        }
        if (version < 11) {
            applyMigration(11, migrationHook, () -> {
                createClanBankSchema();
                recordMigration(11);
                execute("PRAGMA user_version = 11");
                return null;
            });
            version = 11;
        }
        if (version < 12) {
            applyMigration(12, migrationHook, () -> {
                createClanBankWithdrawalRequestSchema();
                recordMigration(12);
                execute("PRAGMA user_version = 12");
                return null;
            });
            version = 12;
        }
        if (version < 13) {
            applyMigration(13, migrationHook, () -> {
                createClanBankOperationSchema();
                recordMigration(13);
                execute("PRAGMA user_version = 13");
                return null;
            });
            version = 13;
        }
        if (version < 14) {
            applyMigration(14, migrationHook, () -> {
                createCombatLogSchema();
                recordMigration(14);
                execute("PRAGMA user_version = 14");
                return null;
            });
            version = 14;
        }
        if (version < 15) {
            applyMigration(15, migrationHook, () -> {
                createClanHomeSchema();
                recordMigration(15);
                execute("PRAGMA user_version = 15");
                return null;
            });
            version = 15;
        }
        if (version < 16) {
            applyMigration(16, migrationHook, () -> {
                createClanStorageSchema();
                recordMigration(16);
                execute("PRAGMA user_version = 16");
                return null;
            });
            version = 16;
        }
        if (version < 17) {
            applyMigration(17, migrationHook, () -> {
                createClanStorageContentHistorySchema();
                recordMigration(17);
                execute("PRAGMA user_version = 17");
                return null;
            });
            version = 17;
        }
        if (version < 18) {
            applyMigration(18, migrationHook, () -> {
                createClanStorageMovementSchema();
                recordMigration(18);
                execute("PRAGMA user_version = 18");
                return null;
            });
            version = 18;
        }
        if (version < 19) {
            applyMigration(19, migrationHook, () -> {
                createClanStorageCommittedOperationSchema();
                recordMigration(19);
                execute("PRAGMA user_version = 19");
                return null;
            });
            version = 19;
        }
        if (version < 20) {
            applyMigration(20, migrationHook, () -> {
                createClanStorageTransferEscrowSchema();
                recordMigration(20);
                execute("PRAGMA user_version = 20");
                return null;
            });
            version = 20;
        }
        if (version < 21) {
            applyMigration(21, migrationHook, () -> {
                createClanWarSchema();
                recordMigration(21);
                execute("PRAGMA user_version = 21");
                return null;
            });
            version = 21;
        }
        if (version < 22) {
            applyMigration(22, migrationHook, () -> {
                createClanModerationSchema();
                recordMigration(22);
                execute("PRAGMA user_version = 22");
                return null;
            });
            version = 22;
        }
        if (version < 23) {
            applyMigration(23, migrationHook, () -> {
                createClanRewardSchema();
                recordMigration(23);
                execute("PRAGMA user_version = 23");
                return null;
            });
            version = 23;
        }
        if (version < 24) {
            applyMigration(24, migrationHook, () -> {
                migrateClanHomeToTwoSlots();
                recordMigration(24);
                execute("PRAGMA user_version = 24");
                return null;
            });
            version = 24;
        }
        if (version < 25) {
            applyMigration(25, migrationHook, () -> {
                createClanRewardRequestSchema();
                recordMigration(25);
                execute("PRAGMA user_version = 25");
                return null;
            });
            version = 25;
        }
        if (version < 26) {
            applyMigration(26, migrationHook, () -> {
                createClanReportSchema();
                recordMigration(26);
                execute("PRAGMA user_version = 26");
                return null;
            });
            version = 26;
        }
        if (version < 27) {
            applyMigration(27, migrationHook, () -> {
                createClanQuestSchema();
                recordMigration(27);
                execute("PRAGMA user_version = 27");
                return null;
            });
            version = 27;
        }
        if (version < 28) {
            applyMigration(28, migrationHook, () -> {
                createClanTournamentSchema();
                recordMigration(28);
                execute("PRAGMA user_version = 28");
                return null;
            });
            version = 28;
        }
        validateSchema(version);
    }

    private void migratePurchaseCompensationStates() throws SQLException {
        execute("""
                CREATE TEMP TABLE saved_capacity_purchase_operations AS
                SELECT * FROM capacity_purchase_operations
                """);
        execute("""
                CREATE TEMP TABLE saved_capacity_purchase_events AS
                SELECT * FROM capacity_purchase_events
                """);
        execute("""
                CREATE TEMP TABLE saved_applied_business_operations AS
                SELECT * FROM applied_business_operations
                """);
        execute("DROP TABLE capacity_purchase_events");
        execute("DROP TABLE applied_business_operations");
        execute("DROP TABLE capacity_purchase_operations");
        execute("""
                CREATE TABLE capacity_purchase_operations (
                    operation_id TEXT PRIMARY KEY NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    business_operation_id TEXT NOT NULL UNIQUE,
                    clan_id TEXT NOT NULL,
                    actor_id TEXT NOT NULL,
                    expected_capacity INTEGER NOT NULL,
                    target_capacity INTEGER NOT NULL,
                    expected_revision INTEGER NOT NULL,
                    amount INTEGER NOT NULL CHECK (amount > 0),
                    payload_fingerprint TEXT NOT NULL DEFAULT '',
                    state TEXT NOT NULL CHECK (state IN (
                        'PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'COMMITTED',
                        'FAILED_NO_EFFECT', 'UNKNOWN', 'COMPENSATION_PENDING',
                        'COMPENSATION_CALLING', 'COMPENSATION_UNKNOWN',
                        'COMPENSATED', 'COMPENSATION_FAILED'
                    )),
                    provider_operation_id TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """);
        execute("""
                INSERT INTO capacity_purchase_operations (
                    operation_id, idempotency_key, business_operation_id, clan_id, actor_id,
                    expected_capacity, target_capacity, expected_revision, amount,
                    payload_fingerprint, state, provider_operation_id, created_at, updated_at
                )
                SELECT operation_id, idempotency_key, business_operation_id, clan_id, actor_id,
                    expected_capacity, target_capacity, expected_revision, amount,
                    payload_fingerprint, state, provider_operation_id, created_at, updated_at
                FROM saved_capacity_purchase_operations
                """);
        execute("""
                CREATE INDEX capacity_purchase_state_idx
                ON capacity_purchase_operations(state, created_at)
                """);
        execute("""
                CREATE TABLE capacity_purchase_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_id TEXT NOT NULL
                        REFERENCES capacity_purchase_operations(operation_id),
                    state TEXT NOT NULL CHECK (state IN (
                        'PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'COMMITTED',
                        'FAILED_NO_EFFECT', 'UNKNOWN', 'COMPENSATION_PENDING',
                        'COMPENSATION_CALLING', 'COMPENSATION_UNKNOWN',
                        'COMPENSATED', 'COMPENSATION_FAILED'
                    )),
                    provider_operation_id TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("""
                INSERT INTO capacity_purchase_events
                SELECT * FROM saved_capacity_purchase_events
                """);
        execute("""
                CREATE INDEX capacity_purchase_events_operation_idx
                ON capacity_purchase_events(operation_id, event_id)
                """);
        execute("""
                CREATE TRIGGER capacity_purchase_events_no_update
                BEFORE UPDATE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER capacity_purchase_events_no_delete
                BEFORE DELETE ON capacity_purchase_events
                BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                """);
        execute("""
                CREATE TABLE applied_business_operations (
                    business_operation_id TEXT PRIMARY KEY NOT NULL,
                    operation_id TEXT NOT NULL UNIQUE
                        REFERENCES capacity_purchase_operations(operation_id),
                    clan_id TEXT NOT NULL REFERENCES clans(id),
                    from_capacity INTEGER NOT NULL,
                    to_capacity INTEGER NOT NULL,
                    committed_at TEXT NOT NULL
                )
                """);
        execute("""
                INSERT INTO applied_business_operations
                SELECT * FROM saved_applied_business_operations
                """);
        execute("DROP TABLE saved_capacity_purchase_events");
        execute("DROP TABLE saved_applied_business_operations");
        execute("DROP TABLE saved_capacity_purchase_operations");
    }

    /**
     * Stores the transition source and evidence with every future event.
     *
     * <p>Existing schema v1-v3 rows never carried these values, so they are copied verbatim and
     * tagged {@code UNVERIFIED_LEGACY} with NULL source and evidence. Nothing is invented for them.
     * {@code event_id} is preserved so the ordering authority of the journal does not change.
     */
    private void migratePurchaseEvidenceHistory() throws SQLException {
        execute("""
                CREATE TEMP TABLE saved_capacity_purchase_events AS
                SELECT * FROM capacity_purchase_events
                """);
        execute("DROP TABLE capacity_purchase_events");
        execute("""
                CREATE TABLE capacity_purchase_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_id TEXT NOT NULL
                        REFERENCES capacity_purchase_operations(operation_id),
                    from_state TEXT CHECK (from_state IS NULL OR from_state IN (%s)),
                    to_state TEXT NOT NULL CHECK (to_state IN (%s)),
                    evidence TEXT CHECK (evidence IS NULL OR evidence IN (%s)),
                    evidence_provenance TEXT NOT NULL
                        CHECK (evidence_provenance IN ('RECORDED', 'UNVERIFIED_LEGACY')),
                    provider_operation_id TEXT,
                    occurred_at TEXT NOT NULL
                )
                """.formatted(
                PURCHASE_STATES.strip(), PURCHASE_STATES.strip(), EVIDENCE_VALUES.strip()));
        execute("""
                INSERT INTO capacity_purchase_events (
                    event_id, operation_id, from_state, to_state, evidence,
                    evidence_provenance, provider_operation_id, occurred_at
                )
                SELECT event_id, operation_id, NULL, state, NULL,
                    'UNVERIFIED_LEGACY', provider_operation_id, occurred_at
                FROM saved_capacity_purchase_events
                ORDER BY event_id
                """);
        execute("""
                CREATE INDEX capacity_purchase_events_operation_idx
                ON capacity_purchase_events(operation_id, event_id)
                """);
        execute(NO_UPDATE_TRIGGER_DDL);
        execute(NO_DELETE_TRIGGER_DDL);
        execute("DROP TABLE saved_capacity_purchase_events");
        execute("ALTER TABLE applied_business_operations ADD COLUMN expected_revision INTEGER");
        execute("ALTER TABLE applied_business_operations ADD COLUMN applied_revision INTEGER");
        execute("ALTER TABLE applied_business_operations ADD COLUMN amount INTEGER");
        execute("""
                ALTER TABLE applied_business_operations
                ADD COLUMN commit_evidence_provenance TEXT NOT NULL DEFAULT 'UNVERIFIED_LEGACY'
                """);
    }

    private void applyMigration(
            int version,
            SqliteMigrationHook migrationHook,
            SqlWork<Void> migration) {
        inWriteTransaction("Could not apply SQLite migration " + version, () -> {
            migration.run();
            migrationHook.afterMigrationStep(version);
            return null;
        });
    }

    private void createVersionOneSchema() throws SQLException {
            execute("""
                    CREATE TABLE schema_migrations (
                        version INTEGER PRIMARY KEY,
                        applied_at TEXT NOT NULL
                    )
                    """);
            execute("""
                    CREATE TABLE clans (
                        id TEXT PRIMARY KEY NOT NULL,
                        name TEXT NOT NULL,
                        tag TEXT NOT NULL,
                        tag_key TEXT NOT NULL UNIQUE,
                        created_at TEXT NOT NULL,
                        capacity INTEGER NOT NULL CHECK (capacity IN (10, 20, 30, 40, 50)),
                        total_xp INTEGER NOT NULL CHECK (total_xp >= 0),
                        tagline TEXT,
                        revision INTEGER NOT NULL CHECK (revision >= 0)
                    )
                    """);
            execute("""
                    CREATE TABLE clan_members (
                        clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                        player_id TEXT NOT NULL UNIQUE,
                        role TEXT NOT NULL CHECK (role IN ('LEADER', 'DEPUTY', 'MODERATOR', 'MEMBER')),
                        membership_started_at TEXT NOT NULL,
                        appointed_by_deputy_id TEXT,
                        PRIMARY KEY (clan_id, player_id)
                    )
                    """);
            execute("""
                    CREATE INDEX clan_members_clan_id_idx ON clan_members(clan_id)
                    """);
            execute("""
                    CREATE TABLE capacity_purchase_operations (
                        operation_id TEXT PRIMARY KEY NOT NULL,
                        idempotency_key TEXT NOT NULL UNIQUE,
                        business_operation_id TEXT NOT NULL UNIQUE,
                        clan_id TEXT NOT NULL,
                        actor_id TEXT NOT NULL,
                        expected_capacity INTEGER NOT NULL,
                        target_capacity INTEGER NOT NULL,
                        expected_revision INTEGER NOT NULL,
                        amount INTEGER NOT NULL CHECK (amount > 0),
                        state TEXT NOT NULL CHECK (state IN (
                            'PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'COMMITTED',
                            'FAILED_NO_EFFECT', 'UNKNOWN', 'COMPENSATION_PENDING',
                            'COMPENSATED', 'COMPENSATION_FAILED'
                        )),
                        provider_operation_id TEXT,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    )
                    """);
            execute("""
                    CREATE INDEX capacity_purchase_state_idx
                    ON capacity_purchase_operations(state, created_at)
                    """);
            execute("""
                    CREATE TABLE capacity_purchase_events (
                        event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        operation_id TEXT NOT NULL
                            REFERENCES capacity_purchase_operations(operation_id),
                        state TEXT NOT NULL CHECK (state IN (
                            'PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'COMMITTED',
                            'FAILED_NO_EFFECT', 'UNKNOWN', 'COMPENSATION_PENDING',
                            'COMPENSATED', 'COMPENSATION_FAILED'
                        )),
                        provider_operation_id TEXT,
                        occurred_at TEXT NOT NULL
                    )
                    """);
            execute("""
                    CREATE INDEX capacity_purchase_events_operation_idx
                    ON capacity_purchase_events(operation_id, event_id)
                    """);
            execute("""
                    CREATE TRIGGER capacity_purchase_events_no_update
                    BEFORE UPDATE ON capacity_purchase_events
                    BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                    """);
            execute("""
                    CREATE TRIGGER capacity_purchase_events_no_delete
                    BEFORE DELETE ON capacity_purchase_events
                    BEGIN SELECT RAISE(ABORT, 'purchase events are append-only'); END
                    """);
            execute("""
                    CREATE TABLE applied_business_operations (
                        business_operation_id TEXT PRIMARY KEY NOT NULL,
                        operation_id TEXT NOT NULL UNIQUE
                            REFERENCES capacity_purchase_operations(operation_id),
                        clan_id TEXT NOT NULL REFERENCES clans(id),
                        from_capacity INTEGER NOT NULL,
                        to_capacity INTEGER NOT NULL,
                        committed_at TEXT NOT NULL
                    )
                    """);
    }

    private void createClanRequestSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_settings (
                    clan_id TEXT PRIMARY KEY NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    public_applications_open INTEGER NOT NULL DEFAULT 1
                        CHECK (public_applications_open IN (0, 1))
                )
                """);
        execute("INSERT INTO clan_settings(clan_id, public_applications_open) SELECT id, 1 FROM clans");
        execute("""
                CREATE TABLE clan_requests (
                    request_id TEXT PRIMARY KEY NOT NULL,
                    request_type TEXT NOT NULL CHECK (request_type IN ('INVITATION', 'APPLICATION')),
                    clan_id TEXT NOT NULL,
                    player_id TEXT NOT NULL,
                    actor_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    status TEXT NOT NULL CHECK (status IN ('PENDING', 'ACCEPTED', 'DECLINED', 'EXPIRED', 'CANCELLED')),
                    CHECK (expires_at > created_at),
                    CHECK (request_type <> 'APPLICATION' OR actor_id = player_id)
                )
                """);
        execute("""
                CREATE UNIQUE INDEX clan_requests_pending_invitation_idx
                ON clan_requests(clan_id, player_id)
                WHERE request_type = 'INVITATION' AND status = 'PENDING'
                """);
        execute("""
                CREATE UNIQUE INDEX clan_requests_pending_application_idx
                ON clan_requests(clan_id, player_id)
                WHERE request_type = 'APPLICATION' AND status = 'PENDING'
                """);
        execute("CREATE INDEX clan_requests_player_idx ON clan_requests(player_id, request_type, status, expires_at)");
        execute("CREATE INDEX clan_requests_clan_idx ON clan_requests(clan_id, request_type, status, expires_at)");
        execute("""
                CREATE TABLE clan_request_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT NOT NULL REFERENCES clan_requests(request_id),
                    request_type TEXT NOT NULL CHECK (request_type IN ('INVITATION', 'APPLICATION')),
                    from_status TEXT,
                    to_status TEXT NOT NULL CHECK (to_status IN ('PENDING', 'ACCEPTED', 'DECLINED', 'EXPIRED', 'CANCELLED')),
                    actor_id TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_request_events_request_idx ON clan_request_events(request_id, event_id)");
        execute(CLAN_REQUEST_NO_UPDATE_TRIGGER_DDL);
        execute(CLAN_REQUEST_NO_DELETE_TRIGGER_DDL);
    }

    private void createClanElectionSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_elections (
                    election_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL,
                    election_type TEXT NOT NULL CHECK (election_type IN ('DEPARTURE', 'COUP')),
                    phase TEXT NOT NULL CHECK (phase IN ('LOCAL', 'GLOBAL_TIE_BREAK', 'COMPLETED', 'CANCELLED')),
                    started_by TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    closes_at TEXT NOT NULL,
                    winner_id TEXT,
                    completed_at TEXT,
                    CHECK (closes_at > started_at),
                    CHECK ((phase = 'COMPLETED' AND winner_id IS NOT NULL AND completed_at IS NOT NULL)
                        OR (phase <> 'COMPLETED' AND winner_id IS NULL AND completed_at IS NULL))
                )
                """);
        execute("CREATE UNIQUE INDEX clan_elections_one_active_per_clan_idx ON clan_elections(clan_id) WHERE phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')");
        execute("CREATE INDEX clan_elections_due_idx ON clan_elections(phase, closes_at)");
        execute("""
                CREATE TABLE clan_election_candidates (
                    election_id TEXT NOT NULL REFERENCES clan_elections(election_id),
                    phase TEXT NOT NULL CHECK (phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')),
                    candidate_id TEXT NOT NULL,
                    PRIMARY KEY (election_id, phase, candidate_id)
                )
                """);
        execute("""
                CREATE TABLE clan_election_votes (
                    election_id TEXT NOT NULL REFERENCES clan_elections(election_id),
                    phase TEXT NOT NULL CHECK (phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')),
                    voter_id TEXT NOT NULL,
                    candidate_id TEXT NOT NULL,
                    voted_at TEXT NOT NULL,
                    PRIMARY KEY (election_id, phase, voter_id),
                    FOREIGN KEY (election_id, phase, candidate_id) REFERENCES clan_election_candidates(election_id, phase, candidate_id)
                )
                """);
        execute("CREATE INDEX clan_election_votes_candidate_idx ON clan_election_votes(election_id, phase, candidate_id)");
        execute("""
                CREATE TABLE clan_election_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    election_id TEXT NOT NULL REFERENCES clan_elections(election_id),
                    event_type TEXT NOT NULL CHECK (event_type IN ('CREATED', 'VOTE_CAST', 'GLOBAL_TIE_BREAK_STARTED', 'COMPLETED', 'LEADERSHIP_APPLIED')),
                    actor_id TEXT,
                    details TEXT NOT NULL,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_election_events_election_idx ON clan_election_events(election_id, event_id)");
        execute(CLAN_ELECTION_EVENTS_NO_UPDATE_TRIGGER_DDL);
        execute(CLAN_ELECTION_EVENTS_NO_DELETE_TRIGGER_DDL);
    }

    private void createClanElectionSafetySchema() throws SQLException {
        execute("""
                CREATE TABLE clan_election_owner_blocks (
                    election_id TEXT PRIMARY KEY NOT NULL REFERENCES clan_elections(election_id),
                    blocked_at TEXT NOT NULL,
                    reason TEXT NOT NULL CHECK (reason = 'GLOBAL_TIE_REMAINS_TIED')
                )
                """);
        execute(CLAN_ELECTION_OWNER_BLOCKS_INSERT_GUARD_TRIGGER_DDL);
        execute(CLAN_ELECTION_OWNER_BLOCKS_NO_UPDATE_TRIGGER_DDL);
        execute(CLAN_ELECTION_OWNER_BLOCKS_NO_DELETE_TRIGGER_DDL);
        execute(CLAN_ELECTION_CANDIDATES_INSERT_GUARD_TRIGGER_DDL);
        execute(CLAN_ELECTION_CANDIDATES_NO_UPDATE_TRIGGER_DDL);
        execute(CLAN_ELECTION_CANDIDATES_NO_DELETE_TRIGGER_DDL);
        execute(CLAN_ELECTION_VOTES_INSERT_GUARD_TRIGGER_DDL);
        execute(CLAN_ELECTION_VOTES_NO_UPDATE_TRIGGER_DDL);
        execute(CLAN_ELECTION_VOTES_NO_DELETE_TRIGGER_DDL);
    }

    private void createClanActivitySchema() throws SQLException {
        execute("""
                CREATE TABLE clan_player_activity (
                    player_id TEXT PRIMARY KEY NOT NULL,
                    last_seen_epoch_millis INTEGER NOT NULL CHECK (last_seen_epoch_millis >= 0)
                )
                """);
    }

    private void createClanXpSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_xp_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    clan_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    actor_id TEXT,
                    amount INTEGER NOT NULL CHECK (amount >= 0),
                    idempotency_key TEXT NOT NULL UNIQUE,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_xp_events_clan_idx ON clan_xp_events(clan_id, event_id)");
        execute(CLAN_XP_NO_UPDATE_TRIGGER_DDL);
        execute(CLAN_XP_NO_DELETE_TRIGGER_DDL);
    }

    private void createClanCreationPaymentSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_creation_payment_operations (
                    operation_id TEXT PRIMARY KEY NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    creator_id TEXT NOT NULL,
                    clan_id TEXT NOT NULL UNIQUE,
                    clan_name TEXT NOT NULL,
                    clan_tag TEXT NOT NULL,
                    clan_slogan TEXT,
                    clan_created_at TEXT NOT NULL,
                    amount_units INTEGER NOT NULL CHECK (amount_units = 1000000),
                    state TEXT NOT NULL CHECK (state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'COMMITTED', 'FAILED_NO_EFFECT', 'UNKNOWN')),
                    diagnostic TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    CHECK (julianday(updated_at) >= julianday(created_at))
                )
                """);
        execute("""
                CREATE UNIQUE INDEX clan_creation_payment_creator_unresolved_idx
                ON clan_creation_payment_operations(creator_id)
                WHERE state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')
                """);
        execute("""
                CREATE UNIQUE INDEX clan_creation_payment_tag_unresolved_idx
                ON clan_creation_payment_operations(clan_tag COLLATE NOCASE)
                WHERE state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')
                """);
        execute("CREATE INDEX clan_creation_payment_state_idx ON clan_creation_payment_operations(state, created_at)");
        execute("""
                CREATE TABLE clan_creation_payment_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_id TEXT NOT NULL REFERENCES clan_creation_payment_operations(operation_id),
                    from_state TEXT,
                    to_state TEXT NOT NULL CHECK (to_state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'COMMITTED', 'FAILED_NO_EFFECT', 'UNKNOWN')),
                    diagnostic TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_creation_payment_events_operation_idx ON clan_creation_payment_events(operation_id, event_id)");
        execute(CLAN_CREATION_OPERATIONS_IMMUTABLE_TRIGGER_DDL);
        execute(CLAN_CREATION_OPERATIONS_NO_DELETE_TRIGGER_DDL);
        execute(CLAN_CREATION_STATE_TRANSITION_TRIGGER_DDL);
        execute(CLAN_CREATION_EVENTS_INSERT_GUARD_TRIGGER_DDL);
        execute(CLAN_CREATION_EVENTS_NO_UPDATE_TRIGGER_DDL);
        execute(CLAN_CREATION_EVENTS_NO_DELETE_TRIGGER_DDL);
    }

    private void createClanBankSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_bank_accounts (
                    clan_id TEXT PRIMARY KEY NOT NULL REFERENCES clans(id),
                    balance TEXT NOT NULL DEFAULT '0' CHECK (length(balance) > 0),
                    revision INTEGER NOT NULL DEFAULT 0 CHECK (revision >= 0),
                    updated_at TEXT NOT NULL
                )
                """);
        execute("""
                CREATE TABLE clan_bank_transactions (
                    transaction_id TEXT PRIMARY KEY NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    clan_id TEXT NOT NULL REFERENCES clans(id),
                    actor_id TEXT NOT NULL,
                    transaction_type TEXT NOT NULL CHECK (transaction_type IN
                        ('DEPOSIT', 'WITHDRAWAL', 'REWARD', 'QUEST_REWARD', 'WAR_FUND', 'WAR_PRIZE', 'ADJUSTMENT')),
                    amount TEXT NOT NULL CHECK (length(amount) > 0),
                    balance_after TEXT NOT NULL CHECK (length(balance_after) > 0),
                    reason TEXT,
                    approved_by TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_bank_transactions_clan_idx ON clan_bank_transactions(clan_id, occurred_at, transaction_id)");
        execute("""
                CREATE TRIGGER clan_bank_transactions_no_update
                BEFORE UPDATE ON clan_bank_transactions
                BEGIN SELECT RAISE(ABORT, 'clan bank transactions are immutable'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_transactions_no_delete
                BEFORE DELETE ON clan_bank_transactions
                BEGIN SELECT RAISE(ABORT, 'clan bank transactions are retained'); END
                """);
    }

    private void createClanBankOperationSchema() throws SQLException {
        execute("ALTER TABLE clan_bank_accounts ADD COLUMN reserved_balance TEXT NOT NULL DEFAULT '0' CHECK (length(reserved_balance) > 0)");
        execute("ALTER TABLE clan_bank_withdrawal_requests ADD COLUMN payment_operation_id TEXT REFERENCES clan_bank_operations(operation_id)");
        execute("CREATE UNIQUE INDEX clan_bank_withdrawal_request_payment_idx ON clan_bank_withdrawal_requests(payment_operation_id) WHERE payment_operation_id IS NOT NULL");
        execute("""
                CREATE TABLE clan_bank_operations (
                    operation_id TEXT PRIMARY KEY NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    business_operation_id TEXT NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id),
                    actor_id TEXT NOT NULL,
                    beneficiary_id TEXT NOT NULL,
                    request_id TEXT REFERENCES clan_bank_withdrawal_requests(request_id),
                    operation_type TEXT NOT NULL CHECK (operation_type IN ('DEPOSIT', 'WITHDRAWAL', 'LEADER_WITHDRAWAL')),
                    amount TEXT NOT NULL CHECK (length(amount) > 0),
                    state TEXT NOT NULL CHECK (state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'COMMITTED', 'FAILED_NO_EFFECT', 'UNKNOWN')),
                    diagnostic TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    CHECK (julianday(updated_at) >= julianday(created_at)),
                    CHECK ((operation_type = 'DEPOSIT' AND request_id IS NULL)
                        OR (operation_type = 'WITHDRAWAL' AND request_id IS NOT NULL)
                        OR (operation_type = 'LEADER_WITHDRAWAL' AND request_id IS NULL AND actor_id = beneficiary_id))
                )
                """);
        execute("CREATE UNIQUE INDEX clan_bank_operations_business_operation_idx ON clan_bank_operations(business_operation_id) WHERE state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'COMMITTED', 'UNKNOWN')");
        execute("CREATE UNIQUE INDEX clan_bank_operations_request_idx ON clan_bank_operations(request_id) WHERE request_id IS NOT NULL AND state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'COMMITTED', 'UNKNOWN')");
        execute("CREATE UNIQUE INDEX clan_bank_operations_actor_unresolved_idx ON clan_bank_operations(clan_id, actor_id, operation_type) WHERE operation_type IN ('DEPOSIT', 'LEADER_WITHDRAWAL') AND state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'UNKNOWN')");
        execute("CREATE INDEX clan_bank_operations_state_idx ON clan_bank_operations(state, created_at)");
        execute("CREATE INDEX clan_bank_operations_clan_idx ON clan_bank_operations(clan_id, created_at, operation_id)");
        execute("""
                CREATE TABLE clan_bank_operation_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_id TEXT NOT NULL REFERENCES clan_bank_operations(operation_id),
                    from_state TEXT,
                    to_state TEXT NOT NULL CHECK (to_state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'COMMITTED', 'FAILED_NO_EFFECT', 'UNKNOWN')),
                    evidence TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_bank_operation_events_idx ON clan_bank_operation_events(operation_id, event_id)");
        execute("""
                CREATE TABLE clan_bank_reservations (
                    operation_id TEXT PRIMARY KEY NOT NULL REFERENCES clan_bank_operations(operation_id),
                    clan_id TEXT NOT NULL REFERENCES clans(id),
                    amount TEXT NOT NULL CHECK (length(amount) > 0),
                    state TEXT NOT NULL CHECK (state IN ('RESERVED', 'CONSUMED', 'RELEASED')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    CHECK (julianday(updated_at) >= julianday(created_at))
                )
                """);
        execute("""
                CREATE TRIGGER clan_bank_operations_intent_immutable
                BEFORE UPDATE ON clan_bank_operations
                WHEN OLD.operation_id <> NEW.operation_id
                  OR OLD.idempotency_key <> NEW.idempotency_key
                  OR OLD.business_operation_id <> NEW.business_operation_id
                  OR OLD.clan_id <> NEW.clan_id
                  OR OLD.actor_id <> NEW.actor_id
                  OR OLD.beneficiary_id <> NEW.beneficiary_id
                  OR OLD.request_id IS NOT NEW.request_id
                  OR OLD.operation_type <> NEW.operation_type
                  OR OLD.amount <> NEW.amount
                  OR OLD.created_at <> NEW.created_at
                BEGIN SELECT RAISE(ABORT, 'clan bank operation intent is immutable'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_operations_state_guard
                BEFORE UPDATE OF state ON clan_bank_operations
                WHEN NOT ((OLD.state = 'PREPARED' AND NEW.state IN ('CALLING', 'FAILED_NO_EFFECT'))
                    OR (OLD.state = 'CALLING' AND NEW.state IN ('EXTERNAL_CONFIRMED', 'FAILED_NO_EFFECT', 'UNKNOWN'))
                    OR (OLD.state = 'EXTERNAL_CONFIRMED' AND NEW.state = 'COMMITTED')
                    OR (OLD.state = 'UNKNOWN' AND NEW.state IN ('EXTERNAL_CONFIRMED', 'FAILED_NO_EFFECT')))
                  OR julianday(NEW.updated_at) < julianday(OLD.updated_at)
                BEGIN SELECT RAISE(ABORT, 'invalid clan bank operation transition'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_operation_events_insert_guard
                BEFORE INSERT ON clan_bank_operation_events
                WHEN NOT EXISTS (
                    SELECT 1 FROM clan_bank_operations o WHERE o.operation_id = NEW.operation_id AND o.state = NEW.to_state
                      AND ((NEW.from_state IS NULL AND NOT EXISTS (SELECT 1 FROM clan_bank_operation_events e WHERE e.operation_id = NEW.operation_id))
                        OR NEW.from_state = (SELECT e.to_state FROM clan_bank_operation_events e WHERE e.operation_id = NEW.operation_id ORDER BY e.event_id DESC LIMIT 1))
                )
                BEGIN SELECT RAISE(ABORT, 'clan bank operation event does not match current state'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_operation_events_no_update
                BEFORE UPDATE ON clan_bank_operation_events
                BEGIN SELECT RAISE(ABORT, 'clan bank operation events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_operation_events_no_delete
                BEFORE DELETE ON clan_bank_operation_events
                BEGIN SELECT RAISE(ABORT, 'clan bank operation events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_reservations_intent_immutable
                BEFORE UPDATE ON clan_bank_reservations
                WHEN OLD.operation_id <> NEW.operation_id OR OLD.clan_id <> NEW.clan_id
                  OR OLD.amount <> NEW.amount OR OLD.created_at <> NEW.created_at
                  OR NOT ((OLD.state = 'RESERVED' AND NEW.state IN ('CONSUMED', 'RELEASED')))
                  OR julianday(NEW.updated_at) < julianday(OLD.updated_at)
                BEGIN SELECT RAISE(ABORT, 'invalid or immutable clan bank reservation change'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_reservations_no_delete
                BEFORE DELETE ON clan_bank_reservations
                BEGIN SELECT RAISE(ABORT, 'clan bank reservations are retained'); END
                """);
    }

    private void createCombatLogSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_combat_log_sessions (
                    player_id TEXT PRIMARY KEY NOT NULL,
                    opponent_id TEXT NOT NULL,
                    last_hit_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'EXPIRED', 'LOGOUT_VIOLATION', 'INTERRUPTED_REVIEW', 'CLEARED')),
                    updated_at TEXT NOT NULL,
                    CHECK (julianday(expires_at) = julianday(last_hit_at) + (30.0 / 86400.0)),
                    CHECK (julianday(updated_at) >= julianday(last_hit_at))
                )
                """);
        execute("""
                CREATE TABLE clan_combat_log_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    player_id TEXT NOT NULL REFERENCES clan_combat_log_sessions(player_id),
                    opponent_id TEXT NOT NULL,
                    event_type TEXT NOT NULL CHECK (event_type IN ('TAGGED', 'EXPIRED', 'LOGOUT_VIOLATION', 'INTERRUPTED_REVIEW', 'CLEARED')),
                    occurred_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    details TEXT
                )
                """);
        execute("CREATE INDEX clan_combat_log_sessions_expiry_idx ON clan_combat_log_sessions(status, expires_at)");
        execute("CREATE INDEX clan_combat_log_events_player_idx ON clan_combat_log_events(player_id, event_id)");
        execute("""
                CREATE TRIGGER clan_combat_log_sessions_state_guard
                BEFORE UPDATE ON clan_combat_log_sessions
                WHEN OLD.player_id <> NEW.player_id
                  OR NOT (NEW.status = 'ACTIVE'
                    OR (OLD.status = 'ACTIVE' AND NEW.status IN ('EXPIRED', 'LOGOUT_VIOLATION', 'INTERRUPTED_REVIEW', 'CLEARED')))
                  OR julianday(NEW.updated_at) < julianday(OLD.updated_at)
                BEGIN SELECT RAISE(ABORT, 'invalid combat log session transition'); END
                """);
        execute("""
                CREATE TRIGGER clan_combat_log_sessions_no_delete
                BEFORE DELETE ON clan_combat_log_sessions
                BEGIN SELECT RAISE(ABORT, 'combat log session history is retained'); END
                """);
        execute("""
                CREATE TRIGGER clan_combat_log_events_no_update
                BEFORE UPDATE ON clan_combat_log_events
                BEGIN SELECT RAISE(ABORT, 'combat log events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_combat_log_events_no_delete
                BEFORE DELETE ON clan_combat_log_events
                BEGIN SELECT RAISE(ABORT, 'combat log events are append-only'); END
                """);
    }

    private void createClanHomeSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_home_points (
                    clan_id TEXT PRIMARY KEY NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 32),
                    world_id TEXT NOT NULL,
                    x REAL NOT NULL,
                    y REAL NOT NULL,
                    z REAL NOT NULL,
                    yaw REAL NOT NULL,
                    pitch REAL NOT NULL,
                    created_by TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_by TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """);
        execute("""
                CREATE TABLE clan_home_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    clan_id TEXT NOT NULL,
                    actor_id TEXT NOT NULL,
                    event_type TEXT NOT NULL CHECK (event_type IN ('SET', 'RENAME', 'DELETE')),
                    home_name TEXT NOT NULL,
                    world_id TEXT NOT NULL,
                    x REAL NOT NULL,
                    y REAL NOT NULL,
                    z REAL NOT NULL,
                    yaw REAL NOT NULL,
                    pitch REAL NOT NULL,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_home_events_clan_idx ON clan_home_events(clan_id, event_id)");
        execute("""
                CREATE TRIGGER clan_home_events_no_update
                BEFORE UPDATE ON clan_home_events
                BEGIN SELECT RAISE(ABORT, 'clan home events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_home_events_no_delete
                BEFORE DELETE ON clan_home_events
                BEGIN SELECT RAISE(ABORT, 'clan home events are append-only'); END
                """);
    }

    private void createClanStorageTransferEscrowSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_storage_transfer_operations (
                    operation_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 10),
                    actor_id TEXT NOT NULL,
                    movement_type TEXT NOT NULL CHECK (movement_type IN ('DEPOSIT', 'WITHDRAWAL')),
                    item_type TEXT NOT NULL CHECK (length(item_type) BETWEEN 1 AND 128),
                    amount INTEGER NOT NULL CHECK (amount BETWEEN 1 AND 2304),
                    expected_revision INTEGER NOT NULL CHECK (expected_revision >= 0),
                    before_player_sha256 TEXT NOT NULL CHECK (length(before_player_sha256) = 64),
                    after_player_sha256 TEXT NOT NULL CHECK (length(after_player_sha256) = 64),
                    before_page_sha256 TEXT NOT NULL CHECK (length(before_page_sha256) = 64),
                    after_page_sha256 TEXT NOT NULL CHECK (length(after_page_sha256) = 64),
                    before_player_inventory BLOB NOT NULL,
                    after_player_inventory BLOB NOT NULL,
                    before_page_contents BLOB NOT NULL,
                    after_page_contents BLOB NOT NULL,
                    state TEXT NOT NULL CHECK (state IN ('PREPARED', 'COMMITTED', 'ABORTED', 'MANUAL_REVIEW')),
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    CHECK (before_player_sha256 <> after_player_sha256),
                    CHECK (before_page_sha256 <> after_page_sha256)
                )
                """);
        execute("CREATE UNIQUE INDEX clan_storage_transfer_pending_page_idx ON clan_storage_transfer_operations(clan_id, page_number) WHERE state = 'PREPARED'");
        execute("CREATE UNIQUE INDEX clan_storage_transfer_pending_actor_idx ON clan_storage_transfer_operations(actor_id) WHERE state = 'PREPARED'");
        execute("""
                CREATE TABLE clan_storage_transfer_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_id TEXT NOT NULL REFERENCES clan_storage_transfer_operations(operation_id) ON DELETE CASCADE,
                    from_state TEXT,
                    to_state TEXT NOT NULL CHECK (to_state IN ('PREPARED', 'COMMITTED', 'ABORTED', 'MANUAL_REVIEW')),
                    actor_id TEXT NOT NULL,
                    details TEXT NOT NULL,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_storage_transfer_events_operation_idx ON clan_storage_transfer_events(operation_id, event_id)");
        execute("""
                CREATE TRIGGER clan_storage_transfer_operations_payload_immutable
                BEFORE UPDATE ON clan_storage_transfer_operations
                WHEN OLD.operation_id IS NOT NEW.operation_id OR OLD.clan_id IS NOT NEW.clan_id
                  OR OLD.page_number IS NOT NEW.page_number OR OLD.actor_id IS NOT NEW.actor_id
                  OR OLD.movement_type IS NOT NEW.movement_type OR OLD.item_type IS NOT NEW.item_type
                  OR OLD.amount IS NOT NEW.amount OR OLD.expected_revision IS NOT NEW.expected_revision
                  OR OLD.before_player_sha256 IS NOT NEW.before_player_sha256
                  OR OLD.after_player_sha256 IS NOT NEW.after_player_sha256
                  OR OLD.before_page_sha256 IS NOT NEW.before_page_sha256
                  OR OLD.after_page_sha256 IS NOT NEW.after_page_sha256
                  OR OLD.before_player_inventory IS NOT NEW.before_player_inventory
                  OR OLD.after_player_inventory IS NOT NEW.after_player_inventory
                  OR OLD.before_page_contents IS NOT NEW.before_page_contents
                  OR OLD.after_page_contents IS NOT NEW.after_page_contents
                  OR OLD.created_at IS NOT NEW.created_at
                BEGIN SELECT RAISE(ABORT, 'clan storage transfer payload is immutable'); END
                """);
        execute("""
                CREATE TRIGGER clan_storage_transfer_operations_state_guard
                BEFORE UPDATE OF state ON clan_storage_transfer_operations
                WHEN NOT (OLD.state = 'PREPARED' AND NEW.state IN ('COMMITTED', 'ABORTED', 'MANUAL_REVIEW'))
                BEGIN SELECT RAISE(ABORT, 'invalid clan storage transfer state transition'); END
                """);
        execute("""
                CREATE TRIGGER clan_storage_transfer_events_no_update
                BEFORE UPDATE ON clan_storage_transfer_events
                BEGIN SELECT RAISE(ABORT, 'clan storage transfer events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_storage_transfer_events_no_delete
                BEFORE DELETE ON clan_storage_transfer_events
                BEGIN SELECT RAISE(ABORT, 'clan storage transfer events are append-only'); END
                """);
    }

    private void createClanWarSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_wars (
                    war_id TEXT PRIMARY KEY NOT NULL,
                    attacker_clan_id TEXT NOT NULL REFERENCES clans(id),
                    defender_clan_id TEXT NOT NULL REFERENCES clans(id),
                    pair_key TEXT NOT NULL,
                    state TEXT NOT NULL CHECK (state IN ('PENDING', 'ACTIVE', 'FINISHED', 'CANCELLED')),
                    declared_by TEXT NOT NULL,
                    declared_at TEXT NOT NULL,
                    accepted_by TEXT,
                    accepted_at TEXT,
                    started_at TEXT,
                    ended_at TEXT,
                    winner_clan_id TEXT REFERENCES clans(id),
                    outcome TEXT CHECK (outcome IS NULL OR outcome IN ('WIN', 'DRAW', 'CANCELLED')),
                    target_kills INTEGER NOT NULL CHECK (target_kills BETWEEN 1 AND 1000000),
                    duration_seconds INTEGER NOT NULL CHECK (duration_seconds BETWEEN 60 AND 2592000),
                    attacker_kills INTEGER NOT NULL DEFAULT 0 CHECK (attacker_kills >= 0),
                    defender_kills INTEGER NOT NULL DEFAULT 0 CHECK (defender_kills >= 0),
                    revision INTEGER NOT NULL DEFAULT 0 CHECK (revision >= 0),
                    CHECK (attacker_clan_id <> defender_clan_id),
                    CHECK (state <> 'FINISHED' OR (outcome IS NOT NULL AND ended_at IS NOT NULL)),
                    CHECK (outcome <> 'WIN' OR winner_clan_id IS NOT NULL)
                )
                """);
        execute("CREATE UNIQUE INDEX clan_wars_one_open_pair_idx ON clan_wars(pair_key) WHERE state IN ('PENDING', 'ACTIVE')");
        execute("CREATE INDEX clan_wars_state_idx ON clan_wars(state, declared_at)");
        execute("CREATE INDEX clan_wars_attacker_idx ON clan_wars(attacker_clan_id, state)");
        execute("CREATE INDEX clan_wars_defender_idx ON clan_wars(defender_clan_id, state)");
        execute("""
                CREATE TABLE clan_war_funds (
                    war_id TEXT NOT NULL REFERENCES clan_wars(war_id),
                    clan_id TEXT NOT NULL REFERENCES clans(id),
                    amount TEXT NOT NULL CHECK (length(amount) > 0),
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (war_id, clan_id)
                )
                """);
        execute("""
                CREATE TABLE clan_war_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    war_id TEXT NOT NULL REFERENCES clan_wars(war_id),
                    event_type TEXT NOT NULL,
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_war_events_war_idx ON clan_war_events(war_id, event_id)");
        execute("""
                CREATE TRIGGER clan_war_events_no_update
                BEFORE UPDATE ON clan_war_events
                BEGIN SELECT RAISE(ABORT, 'clan war events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_war_events_no_delete
                BEFORE DELETE ON clan_war_events
                BEGIN SELECT RAISE(ABORT, 'clan war events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_wars_terminal_state_guard
                BEFORE UPDATE OF state ON clan_wars
                WHEN OLD.state IN ('FINISHED', 'CANCELLED') AND NEW.state <> OLD.state
                BEGIN SELECT RAISE(ABORT, 'finished clan war cannot change state'); END
                """);
    }

    private void createClanModerationSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_chat_mutes (
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    player_id TEXT NOT NULL,
                    muted_by TEXT NOT NULL,
                    muted_at TEXT NOT NULL,
                    expires_at TEXT,
                    reason TEXT NOT NULL CHECK (length(reason) BETWEEN 1 AND 200),
                    PRIMARY KEY (clan_id, player_id)
                )
                """);
        execute("""
                CREATE TABLE clan_chat_mute_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    clan_id TEXT NOT NULL,
                    player_id TEXT NOT NULL,
                    actor_id TEXT NOT NULL,
                    event_type TEXT NOT NULL CHECK (event_type IN ('MUTED', 'UNMUTED', 'EXPIRED', 'CLEARED_ON_LEAVE')),
                    expires_at TEXT,
                    reason TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_chat_mute_events_clan_idx ON clan_chat_mute_events(clan_id, event_id)");
        execute("""
                CREATE TABLE clan_warnings (
                    warning_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    player_id TEXT NOT NULL,
                    issued_by TEXT NOT NULL,
                    issued_at TEXT NOT NULL,
                    reason TEXT NOT NULL CHECK (length(reason) BETWEEN 1 AND 200),
                    removed_by TEXT,
                    removed_at TEXT,
                    CHECK ((removed_by IS NULL) = (removed_at IS NULL))
                )
                """);
        execute("CREATE INDEX clan_warnings_player_idx ON clan_warnings(clan_id, player_id, issued_at)");
        execute("""
                CREATE TABLE clan_warning_cases (
                    case_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    player_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    deadline_at TEXT NOT NULL,
                    status TEXT NOT NULL CHECK (status IN ('OPEN', 'ESCALATED_TO_LEADER')),
                    escalated_at TEXT,
                    warning_ids TEXT NOT NULL,
                    CHECK (julianday(deadline_at) > julianday(created_at)),
                    CHECK (status <> 'ESCALATED_TO_LEADER' OR escalated_at IS NOT NULL)
                )
                """);
        execute("""
                CREATE UNIQUE INDEX clan_warning_cases_one_per_player_idx
                ON clan_warning_cases(clan_id, player_id)
                """);
        execute("""
                CREATE TABLE clan_warning_case_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    case_id TEXT NOT NULL REFERENCES clan_warning_cases(case_id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL CHECK (event_type IN ('CREATED', 'ESCALATED')),
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_warning_case_events_idx ON clan_warning_case_events(case_id, event_id)");
        execute("""
                CREATE TRIGGER clan_chat_mute_events_no_update
                BEFORE UPDATE ON clan_chat_mute_events
                BEGIN SELECT RAISE(ABORT, 'clan mute events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_chat_mute_events_no_delete
                BEFORE DELETE ON clan_chat_mute_events
                BEGIN SELECT RAISE(ABORT, 'clan mute events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_warning_case_events_no_update
                BEFORE UPDATE ON clan_warning_case_events
                BEGIN SELECT RAISE(ABORT, 'clan warning case events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_warning_case_events_no_delete
                BEFORE DELETE ON clan_warning_case_events
                BEGIN SELECT RAISE(ABORT, 'clan warning case events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_warning_cases_no_delete
                BEFORE DELETE ON clan_warning_cases
                BEGIN SELECT RAISE(ABORT, 'clan warning cases cannot be deleted'); END
                """);
    }

    private void createClanRewardSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_reward_operations (
                    operation_id TEXT PRIMARY KEY NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    clan_id TEXT NOT NULL REFERENCES clans(id),
                    issuer_id TEXT NOT NULL,
                    recipient_id TEXT NOT NULL,
                    source TEXT NOT NULL CHECK (source IN ('PERSONAL', 'BANK')),
                    amount TEXT NOT NULL CHECK (length(amount) > 0),
                    state TEXT NOT NULL CHECK (state IN (
                        'PREPARED', 'DEBIT_CALLING', 'DEBIT_CONFIRMED',
                        'CREDIT_CALLING', 'COMPLETED', 'FAILED_NO_EFFECT', 'MANUAL_REVIEW')),
                    reason TEXT,
                    approved_by TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    CHECK (julianday(updated_at) >= julianday(created_at))
                )
                """);
        execute("CREATE INDEX clan_reward_operations_state_idx ON clan_reward_operations(state, created_at)");
        execute("CREATE INDEX clan_reward_operations_clan_idx ON clan_reward_operations(clan_id, created_at)");
        execute("CREATE INDEX clan_reward_operations_issuer_idx ON clan_reward_operations(issuer_id, source, created_at)");
        execute("""
                CREATE TABLE clan_reward_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_id TEXT NOT NULL REFERENCES clan_reward_operations(operation_id),
                    from_state TEXT,
                    to_state TEXT NOT NULL,
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_reward_events_operation_idx ON clan_reward_events(operation_id, event_id)");
        execute("""
                CREATE TRIGGER clan_reward_events_no_update
                BEFORE UPDATE ON clan_reward_events
                BEGIN SELECT RAISE(ABORT, 'clan reward events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_reward_events_no_delete
                BEFORE DELETE ON clan_reward_events
                BEGIN SELECT RAISE(ABORT, 'clan reward events are append-only'); END
                """);
    }

    /**
     * Owner decision #2 (preliminary): a clan may own at most two home points. The first is free,
     * the second is bought from the clan bank for the approved price of home point #2. This
     * migration rebuilds the single-point table and its append-only journal without losing rows.
     */
    private void migrateClanHomeToTwoSlots() throws SQLException {
        execute("""
                CREATE TABLE clan_home_points_v2 (
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    slot INTEGER NOT NULL CHECK (slot IN (1, 2)),
                    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 32),
                    world_id TEXT NOT NULL,
                    x REAL NOT NULL,
                    y REAL NOT NULL,
                    z REAL NOT NULL,
                    yaw REAL NOT NULL,
                    pitch REAL NOT NULL,
                    created_by TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_by TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (clan_id, slot)
                )
                """);
        execute("""
                INSERT INTO clan_home_points_v2(clan_id, slot, name, world_id, x, y, z, yaw, pitch,
                    created_by, created_at, updated_by, updated_at)
                SELECT clan_id, 1, name, world_id, x, y, z, yaw, pitch,
                    created_by, created_at, updated_by, updated_at
                FROM clan_home_points
                """);
        execute("DROP TABLE clan_home_points");
        execute("ALTER TABLE clan_home_points_v2 RENAME TO clan_home_points");
        execute("""
                CREATE TABLE clan_home_slots (
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    slot INTEGER NOT NULL CHECK (slot IN (1, 2)),
                    purchased_by TEXT NOT NULL,
                    purchased_at TEXT NOT NULL,
                    price_paid TEXT NOT NULL CHECK (length(price_paid) > 0),
                    PRIMARY KEY (clan_id, slot)
                )
                """);
        execute("""
                CREATE TABLE clan_home_events_v2 (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    clan_id TEXT NOT NULL,
                    slot INTEGER NOT NULL CHECK (slot IN (1, 2)),
                    actor_id TEXT NOT NULL,
                    event_type TEXT NOT NULL CHECK (event_type IN ('SET', 'RENAME', 'DELETE', 'PURCHASE')),
                    home_name TEXT NOT NULL,
                    world_id TEXT NOT NULL,
                    x REAL NOT NULL,
                    y REAL NOT NULL,
                    z REAL NOT NULL,
                    yaw REAL NOT NULL,
                    pitch REAL NOT NULL,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("""
                INSERT INTO clan_home_events_v2(event_id, clan_id, slot, actor_id, event_type, home_name,
                    world_id, x, y, z, yaw, pitch, occurred_at)
                SELECT event_id, clan_id, 1, actor_id, event_type, home_name,
                    world_id, x, y, z, yaw, pitch, occurred_at
                FROM clan_home_events
                """);
        execute("DROP TABLE clan_home_events");
        execute("ALTER TABLE clan_home_events_v2 RENAME TO clan_home_events");
        execute("CREATE INDEX clan_home_events_clan_idx ON clan_home_events(clan_id, event_id)");
        execute("""
                CREATE TRIGGER clan_home_events_no_update
                BEFORE UPDATE ON clan_home_events
                BEGIN SELECT RAISE(ABORT, 'clan home events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_home_events_no_delete
                BEFORE DELETE ON clan_home_events
                BEGIN SELECT RAISE(ABORT, 'clan home events are append-only'); END
                """);
    }

    private void createClanRewardRequestSchema() throws SQLException {
        // Owner decision #4: the weekly quota of three large rewards is consumed only on approval.
        execute("""
                CREATE TABLE clan_reward_requests (
                    request_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    deputy_id TEXT NOT NULL,
                    recipient_id TEXT NOT NULL,
                    amount TEXT NOT NULL CHECK (length(amount) > 0),
                    reason TEXT NOT NULL CHECK (length(trim(reason)) BETWEEN 1 AND 500),
                    status TEXT NOT NULL CHECK (status IN ('PENDING', 'APPROVED', 'DECLINED', 'EXPIRED')),
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    decided_by TEXT,
                    decided_at TEXT,
                    operation_id TEXT,
                    CHECK (julianday(expires_at) > julianday(created_at)),
                    CHECK ((decided_by IS NULL) = (decided_at IS NULL)),
                    CHECK (status NOT IN ('APPROVED', 'DECLINED') OR decided_at IS NOT NULL)
                )
                """);
        execute("CREATE INDEX clan_reward_requests_clan_idx ON clan_reward_requests(clan_id, created_at)");
        execute("""
                CREATE UNIQUE INDEX clan_reward_requests_pending_idx
                ON clan_reward_requests(clan_id, deputy_id, recipient_id, amount)
                WHERE status = 'PENDING'
                """);
        execute("""
                CREATE TABLE clan_reward_request_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT NOT NULL REFERENCES clan_reward_requests(request_id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL CHECK (event_type IN ('CREATED', 'APPROVED', 'DECLINED', 'EXPIRED')),
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_reward_request_events_idx ON clan_reward_request_events(request_id, event_id)");
        execute("""
                CREATE TRIGGER clan_reward_request_events_no_update
                BEFORE UPDATE ON clan_reward_request_events
                BEGIN SELECT RAISE(ABORT, 'clan reward request events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_reward_request_events_no_delete
                BEFORE DELETE ON clan_reward_request_events
                BEGIN SELECT RAISE(ABORT, 'clan reward request events are append-only'); END
                """);
    }

    private void createClanReportSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_reports (
                    report_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    author_id TEXT NOT NULL,
                    author_name TEXT NOT NULL,
                    anonymous INTEGER NOT NULL CHECK (anonymous IN (0, 1)),
                    category TEXT NOT NULL CHECK (category IN
                        ('RULES', 'ABUSE', 'BANK_FRAUD', 'CHAT_HARASSMENT')),
                    reason TEXT NOT NULL CHECK (length(trim(reason)) BETWEEN 1 AND 2000),
                    status TEXT NOT NULL CHECK (status IN
                        ('NEW', 'UNDER_REVIEW', 'NEEDS_EVIDENCE', 'ACCEPTED', 'REJECTED')),
                    assigned_to TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """);
        execute("""
                CREATE UNIQUE INDEX clan_reports_open_per_author_idx
                ON clan_reports(clan_id, author_id, category)
                WHERE status IN ('NEW', 'UNDER_REVIEW', 'NEEDS_EVIDENCE')
                """);
        execute("CREATE INDEX clan_reports_status_idx ON clan_reports(status, created_at)");
        execute("""
                CREATE TABLE clan_report_evidence (
                    evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    report_id TEXT NOT NULL REFERENCES clan_reports(report_id) ON DELETE CASCADE,
                    url TEXT NOT NULL CHECK (length(url) BETWEEN 8 AND 500),
                    description TEXT CHECK (description IS NULL OR length(description) <= 300),
                    created_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_report_evidence_idx ON clan_report_evidence(report_id, evidence_id)");
        execute("""
                CREATE TABLE clan_report_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    report_id TEXT NOT NULL REFERENCES clan_reports(report_id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL,
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_report_events_idx ON clan_report_events(report_id, event_id)");
        execute("""
                CREATE TABLE clan_report_identity_views (
                    view_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    report_id TEXT NOT NULL REFERENCES clan_reports(report_id) ON DELETE CASCADE,
                    viewer_id TEXT NOT NULL,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("""
                CREATE TABLE clan_sanctions (
                    sanction_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT REFERENCES clans(id) ON DELETE CASCADE,
                    target_id TEXT NOT NULL,
                    issued_by TEXT NOT NULL,
                    kind TEXT NOT NULL CHECK (kind IN ('WARNING', 'FINAL_WARNING', 'TEMPORARY_FUNCTION_BLOCK')),
                    scope TEXT NOT NULL CHECK (scope IN ('CLAN_CHAT', 'CLAN_BANK', 'CLAN_REQUESTS', 'CLAN_WARS', 'ALL')),
                    reason TEXT NOT NULL CHECK (length(trim(reason)) BETWEEN 1 AND 500),
                    issued_at TEXT NOT NULL,
                    expires_at TEXT,
                    owner_issued INTEGER NOT NULL DEFAULT 0 CHECK (owner_issued IN (0, 1)),
                    revoked_by TEXT,
                    revoked_at TEXT,
                    CHECK (expires_at IS NULL OR julianday(expires_at) > julianday(issued_at)),
                    CHECK ((revoked_by IS NULL) = (revoked_at IS NULL))
                )
                """);
        execute("CREATE INDEX clan_sanctions_target_idx ON clan_sanctions(target_id, issued_at)");
        execute("""
                CREATE TABLE clan_sanction_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sanction_id TEXT NOT NULL REFERENCES clan_sanctions(sanction_id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL,
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("""
                CREATE TABLE clan_appeals (
                    appeal_id TEXT PRIMARY KEY NOT NULL,
                    sanction_id TEXT NOT NULL REFERENCES clan_sanctions(sanction_id),
                    clan_id TEXT REFERENCES clans(id) ON DELETE CASCADE,
                    submitted_by TEXT NOT NULL,
                    submitted_at TEXT NOT NULL,
                    reason TEXT NOT NULL CHECK (length(trim(reason)) BETWEEN 1 AND 2000),
                    evidence TEXT CHECK (evidence IS NULL OR length(evidence) <= 2000),
                    status TEXT NOT NULL CHECK (status IN ('PENDING', 'ACCEPTED', 'REJECTED')),
                    decided_by TEXT,
                    decided_at TEXT,
                    decision_note TEXT,
                    owner_override INTEGER NOT NULL DEFAULT 0 CHECK (owner_override IN (0, 1)),
                    CHECK ((decided_by IS NULL) = (decided_at IS NULL))
                )
                """);
        execute("CREATE UNIQUE INDEX clan_appeals_one_per_sanction_idx ON clan_appeals(sanction_id)");
        execute("""
                CREATE TABLE clan_appeal_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    appeal_id TEXT NOT NULL REFERENCES clan_appeals(appeal_id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL,
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        for (String table : List.of("clan_report_events", "clan_sanction_events", "clan_appeal_events")) {
            execute("CREATE TRIGGER " + table + "_no_update BEFORE UPDATE ON " + table
                    + " BEGIN SELECT RAISE(ABORT, '" + table + " are append-only'); END");
            execute("CREATE TRIGGER " + table + "_no_delete BEFORE DELETE ON " + table
                    + " BEGIN SELECT RAISE(ABORT, '" + table + " are append-only'); END");
        }
        execute("""
                CREATE TRIGGER clan_reports_no_delete
                BEFORE DELETE ON clan_reports
                BEGIN SELECT RAISE(ABORT, 'clan reports are retained'); END
                """);
        execute("""
                CREATE TRIGGER clan_sanctions_no_delete
                BEFORE DELETE ON clan_sanctions
                BEGIN SELECT RAISE(ABORT, 'clan sanctions are retained'); END
                """);
        execute("""
                CREATE TRIGGER clan_appeals_no_delete
                BEFORE DELETE ON clan_appeals
                BEGIN SELECT RAISE(ABORT, 'clan appeals are retained'); END
                """);
    }

    private void createClanQuestSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_quests (
                    quest_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    category TEXT NOT NULL CHECK (category IN ('DAILY', 'WEEKLY', 'SPECIAL')),
                    difficulty TEXT NOT NULL CHECK (difficulty IN ('EASY', 'MEDIUM', 'HARD')),
                    metric TEXT NOT NULL CHECK (metric IN ('MINE_BLOCK', 'KILL_MOB', 'COLLECT_ITEM', 'WIN_WAR')),
                    target_amount INTEGER NOT NULL CHECK (target_amount > 0),
                    progress INTEGER NOT NULL DEFAULT 0 CHECK (progress >= 0),
                    required_contributors INTEGER NOT NULL CHECK (required_contributors > 0),
                    status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'COMPLETED', 'EXPIRED')),
                    period_key TEXT NOT NULL,
                    slot INTEGER NOT NULL CHECK (slot BETWEEN 1 AND 3),
                    xp_awarded INTEGER NOT NULL DEFAULT 0 CHECK (xp_awarded >= 0),
                    issued_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    completed_at TEXT,
                    UNIQUE (clan_id, category, period_key, slot),
                    CHECK (progress <= target_amount),
                    CHECK (status <> 'COMPLETED' OR completed_at IS NOT NULL)
                )
                """);
        execute("CREATE INDEX clan_quests_clan_idx ON clan_quests(clan_id, status, category)");
        execute("""
                CREATE TABLE clan_quest_contributors (
                    quest_id TEXT NOT NULL REFERENCES clan_quests(quest_id) ON DELETE CASCADE,
                    player_id TEXT NOT NULL,
                    amount INTEGER NOT NULL CHECK (amount > 0),
                    PRIMARY KEY (quest_id, player_id)
                )
                """);
        execute("""
                CREATE TABLE clan_quest_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    quest_id TEXT NOT NULL REFERENCES clan_quests(quest_id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL,
                    actor_id TEXT,
                    amount INTEGER NOT NULL DEFAULT 0,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_quest_events_idx ON clan_quest_events(quest_id, event_id)");
        execute("""
                CREATE TRIGGER clan_quest_events_no_update
                BEFORE UPDATE ON clan_quest_events
                BEGIN SELECT RAISE(ABORT, 'clan quest events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_quest_events_no_delete
                BEFORE DELETE ON clan_quest_events
                BEGIN SELECT RAISE(ABORT, 'clan quest events are append-only'); END
                """);
    }

    private void createClanTournamentSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_tournaments (
                    tournament_id TEXT PRIMARY KEY NOT NULL,
                    discipline TEXT NOT NULL CHECK (discipline IN
                        ('PVP', 'PARKOUR', 'BUILDING', 'RESOURCE_GATHERING', 'TREASURE_HUNT')),
                    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 64),
                    state TEXT NOT NULL CHECK (state IN
                        ('DRAFT', 'REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'RUNNING', 'FINISHED', 'CANCELLED')),
                    team_size INTEGER NOT NULL CHECK (team_size IN (3, 5, 10)),
                    created_by TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    registration_closes_at TEXT,
                    voting_closes_at TEXT,
                    vote_minimum INTEGER NOT NULL DEFAULT 1 CHECK (vote_minimum >= 0),
                    vote_duration_minutes INTEGER NOT NULL DEFAULT 60 CHECK (vote_duration_minutes BETWEEN 1 AND 10080),
                    vote_permission TEXT NOT NULL DEFAULT 'skyworldclans.tournament.vote',
                    vote_points INTEGER NOT NULL DEFAULT 1 CHECK (vote_points BETWEEN 1 AND 100),
                    vote_allow_abstain INTEGER NOT NULL DEFAULT 0 CHECK (vote_allow_abstain IN (0, 1)),
                    vote_hide_results INTEGER NOT NULL DEFAULT 1 CHECK (vote_hide_results IN (0, 1)),
                    winner_clan_id TEXT,
                    ended_at TEXT
                )
                """);
        execute("CREATE INDEX clan_tournaments_state_idx ON clan_tournaments(state, created_at)");
        execute("""
                CREATE TABLE clan_tournament_votes (
                    vote_id TEXT PRIMARY KEY NOT NULL,
                    tournament_id TEXT NOT NULL REFERENCES clan_tournaments(tournament_id) ON DELETE CASCADE,
                    voter_id TEXT NOT NULL,
                    clan_id TEXT REFERENCES clans(id) ON DELETE CASCADE,
                    points INTEGER NOT NULL CHECK (points > 0),
                    created_at TEXT NOT NULL,
                    revoked_by TEXT,
                    revoked_at TEXT,
                    revoked_reason TEXT,
                    UNIQUE (tournament_id, voter_id)
                )
                """);
        execute("CREATE INDEX clan_tournament_votes_target_idx ON clan_tournament_votes(tournament_id, clan_id)");
        execute("""
                CREATE TABLE clan_tournament_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tournament_id TEXT NOT NULL REFERENCES clan_tournaments(tournament_id) ON DELETE CASCADE,
                    event_type TEXT NOT NULL,
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_tournament_events_idx ON clan_tournament_events(tournament_id, event_id)");
        execute("""
                CREATE TRIGGER clan_tournament_events_no_update
                BEFORE UPDATE ON clan_tournament_events
                BEGIN SELECT RAISE(ABORT, 'clan tournament events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_tournament_events_no_delete
                BEFORE DELETE ON clan_tournament_events
                BEGIN SELECT RAISE(ABORT, 'clan tournament events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_tournament_vote_no_revote
                BEFORE UPDATE OF voter_id, tournament_id, clan_id, points ON clan_tournament_votes
                WHEN OLD.voter_id IS NOT NEW.voter_id OR OLD.tournament_id IS NOT NEW.tournament_id
                  OR OLD.clan_id IS NOT NEW.clan_id OR OLD.points IS NOT NEW.points
                BEGIN SELECT RAISE(ABORT, 'clan tournament votes are immutable'); END
                """);
    execute("""
                CREATE TABLE clan_admin_audit (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    clan_id TEXT,
                    actor_id TEXT,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("""
                CREATE TRIGGER clan_admin_audit_no_update
                BEFORE UPDATE ON clan_admin_audit
                BEGIN SELECT RAISE(ABORT, 'clan admin audit is append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_admin_audit_no_delete
                BEFORE DELETE ON clan_admin_audit
                BEGIN SELECT RAISE(ABORT, 'clan admin audit is append-only'); END
                """);
    }

    private void createClanStorageCommittedOperationSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_storage_committed_operations (
                    operation_id TEXT PRIMARY KEY NOT NULL,
                    clan_id TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 10),
                    actor_id TEXT NOT NULL,
                    movement_type TEXT NOT NULL CHECK (movement_type IN ('DEPOSIT', 'WITHDRAWAL')),
                    item_type TEXT NOT NULL CHECK (length(item_type) BETWEEN 1 AND 128),
                    amount INTEGER NOT NULL CHECK (amount BETWEEN 1 AND 2304),
                    expected_revision INTEGER NOT NULL CHECK (expected_revision >= 0),
                    result_revision INTEGER NOT NULL CHECK (result_revision = expected_revision + 1),
                    contents_sha256 TEXT NOT NULL CHECK (length(contents_sha256) = 64),
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_storage_committed_operations_clan_idx ON clan_storage_committed_operations(clan_id, occurred_at)");
        execute("""
                CREATE TRIGGER clan_storage_committed_operations_no_update
                BEFORE UPDATE ON clan_storage_committed_operations
                BEGIN SELECT RAISE(ABORT, 'clan storage committed operations are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_storage_committed_operations_no_delete
                BEFORE DELETE ON clan_storage_committed_operations
                BEGIN SELECT RAISE(ABORT, 'clan storage committed operations are append-only'); END
                """);
    }

    private void createClanStorageMovementSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_storage_item_movements (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    operation_id TEXT NOT NULL UNIQUE,
                    clan_id TEXT NOT NULL,
                    page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 10),
                    actor_id TEXT NOT NULL,
                    movement_type TEXT NOT NULL CHECK (movement_type IN ('DEPOSIT', 'WITHDRAWAL')),
                    item_type TEXT NOT NULL CHECK (length(item_type) BETWEEN 1 AND 128),
                    amount INTEGER NOT NULL CHECK (amount BETWEEN 1 AND 2304),
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_storage_item_movements_clan_idx ON clan_storage_item_movements(clan_id, event_id)");
        execute("""
                CREATE TRIGGER clan_storage_item_movements_no_update
                BEFORE UPDATE ON clan_storage_item_movements
                BEGIN SELECT RAISE(ABORT, 'clan storage item movements are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_storage_item_movements_no_delete
                BEFORE DELETE ON clan_storage_item_movements
                BEGIN SELECT RAISE(ABORT, 'clan storage item movements are append-only'); END
                """);
    }

    private void createClanStorageSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_storage_accounts (
                    clan_id TEXT PRIMARY KEY NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
                    page_count INTEGER NOT NULL CHECK (page_count BETWEEN 1 AND 10),
                    revision INTEGER NOT NULL CHECK (revision >= 0),
                    updated_at TEXT NOT NULL
                )
                """);
        execute("""
                CREATE TABLE clan_storage_pages (
                    clan_id TEXT NOT NULL REFERENCES clan_storage_accounts(clan_id) ON DELETE CASCADE,
                    page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 10),
                    contents BLOB NOT NULL,
                    revision INTEGER NOT NULL CHECK (revision >= 0),
                    created_by TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    original_price TEXT NOT NULL,
                    charged_price TEXT NOT NULL,
                    discount_percent INTEGER NOT NULL CHECK (discount_percent IN (0, 5, 10)),
                    PRIMARY KEY (clan_id, page_number)
                )
                """);
        execute("""
                CREATE TABLE clan_storage_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    clan_id TEXT NOT NULL,
                    actor_id TEXT NOT NULL,
                    event_type TEXT NOT NULL CHECK (event_type IN ('FREE_PAGE_GRANTED', 'PAGE_PURCHASED')),
                    page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 10),
                    original_price TEXT NOT NULL,
                    charged_price TEXT NOT NULL,
                    discount_percent INTEGER NOT NULL CHECK (discount_percent IN (0, 5, 10)),
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_storage_events_clan_idx ON clan_storage_events(clan_id, event_id)");
        execute("""
                CREATE TRIGGER clan_storage_events_no_update
                BEFORE UPDATE ON clan_storage_events
                BEGIN SELECT RAISE(ABORT, 'clan storage events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_storage_events_no_delete
                BEFORE DELETE ON clan_storage_events
                BEGIN SELECT RAISE(ABORT, 'clan storage events are append-only'); END
                """);
        execute("""
                INSERT INTO clan_storage_accounts(clan_id, page_count, revision, updated_at)
                SELECT id, 1, 0, created_at FROM clans
                """);
        execute("""
                INSERT INTO clan_storage_pages(clan_id, page_number, contents, revision, created_by, created_at,
                    original_price, charged_price, discount_percent)
                SELECT c.id, 1, X'', 0, m.player_id, c.created_at, '0', '0', 0
                FROM clans c JOIN clan_members m ON m.clan_id = c.id AND m.role = 'LEADER'
                """);
        execute("""
                INSERT INTO clan_storage_events(clan_id, actor_id, event_type, page_number,
                    original_price, charged_price, discount_percent, occurred_at)
                SELECT c.id, m.player_id, 'FREE_PAGE_GRANTED', 1, '0', '0', 0, c.created_at
                FROM clans c JOIN clan_members m ON m.clan_id = c.id AND m.role = 'LEADER'
                """);
    }

    private void createClanStorageContentHistorySchema() throws SQLException {
        execute("""
                CREATE TABLE clan_storage_content_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    clan_id TEXT NOT NULL,
                    page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 10),
                    actor_id TEXT NOT NULL,
                    event_type TEXT NOT NULL CHECK (event_type IN ('SNAPSHOT', 'CONTENT_SAVED')),
                    revision INTEGER NOT NULL CHECK (revision >= 0),
                    content_sha256 TEXT NOT NULL CHECK (length(content_sha256) = 64),
                    content_size INTEGER NOT NULL CHECK (content_size >= 0),
                    occurred_at TEXT NOT NULL,
                    UNIQUE (clan_id, page_number, revision)
                )
                """);
        execute("CREATE INDEX clan_storage_content_events_page_idx ON clan_storage_content_events(clan_id, page_number, event_id)");
        execute("""
                CREATE TRIGGER clan_storage_content_events_no_update
                BEFORE UPDATE ON clan_storage_content_events
                BEGIN SELECT RAISE(ABORT, 'clan storage content events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_storage_content_events_no_delete
                BEFORE DELETE ON clan_storage_content_events
                BEGIN SELECT RAISE(ABORT, 'clan storage content events are append-only'); END
                """);
        try (PreparedStatement pages = connection.prepareStatement("""
                SELECT clan_id, page_number, contents, revision, created_by, created_at
                FROM clan_storage_pages ORDER BY clan_id, page_number
                """); ResultSet rows = pages.executeQuery();
             PreparedStatement event = connection.prepareStatement("""
                INSERT INTO clan_storage_content_events(clan_id, page_number, actor_id, event_type,
                    revision, content_sha256, content_size, occurred_at)
                VALUES (?, ?, ?, 'SNAPSHOT', ?, ?, ?, ?)
                """)) {
            while (rows.next()) {
                byte[] contents = rows.getBytes("contents");
                if (contents == null) contents = new byte[0];
                event.setString(1, rows.getString("clan_id")); event.setInt(2, rows.getInt("page_number"));
                event.setString(3, rows.getString("created_by")); event.setLong(4, rows.getLong("revision"));
                event.setString(5, sha256(contents)); event.setLong(6, contents.length);
                event.setString(7, rows.getString("created_at")); event.executeUpdate();
            }
        }
    }

    private static boolean isConstraintViolation(SQLException exception) {
        for (SQLException current = exception; current != null; current = current.getNextException()) {
            if (current.getErrorCode() == 19 || "23000".equals(current.getSQLState())) return true;
        }
        return false;
    }

    private static String sha256(byte[] contents) {
        try {
            return java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(contents));
        } catch (java.security.NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is not available", impossible);
        }
    }

    private void recordMigration(int version) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)")) {
            statement.setInt(1, version);
            statement.setString(2, Instant.now().toString());
            statement.executeUpdate();
        }
    }

    private void createClanBankWithdrawalRequestSchema() throws SQLException {
        execute("""
                CREATE TABLE clan_bank_withdrawal_requests (
                    request_id TEXT PRIMARY KEY NOT NULL,
                    idempotency_key TEXT NOT NULL UNIQUE,
                    clan_id TEXT NOT NULL REFERENCES clans(id),
                    requester_id TEXT NOT NULL,
                    beneficiary_id TEXT NOT NULL,
                    amount TEXT NOT NULL CHECK (length(amount) > 0),
                    reason TEXT NOT NULL CHECK (length(trim(reason)) BETWEEN 1 AND 500),
                    status TEXT NOT NULL CHECK (status IN ('PENDING', 'APPROVED', 'DECLINED', 'EXPIRED')),
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    CHECK (requester_id = beneficiary_id),
                    CHECK (julianday(expires_at) > julianday(created_at)),
                    CHECK (julianday(updated_at) >= julianday(created_at))
                )
                """);
        execute("CREATE INDEX clan_bank_withdrawal_requests_pending_idx ON clan_bank_withdrawal_requests(clan_id, status, expires_at)");
        execute("""
                CREATE TABLE clan_bank_withdrawal_request_events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    request_id TEXT NOT NULL REFERENCES clan_bank_withdrawal_requests(request_id),
                    from_status TEXT,
                    to_status TEXT NOT NULL CHECK (to_status IN ('PENDING', 'APPROVED', 'DECLINED', 'EXPIRED')),
                    actor_id TEXT NOT NULL,
                    details TEXT,
                    occurred_at TEXT NOT NULL
                )
                """);
        execute("CREATE INDEX clan_bank_withdrawal_request_events_idx ON clan_bank_withdrawal_request_events(request_id, event_id)");
        execute("""
                CREATE TRIGGER clan_bank_withdrawal_request_intent_immutable
                BEFORE UPDATE ON clan_bank_withdrawal_requests
                WHEN OLD.request_id <> NEW.request_id
                  OR OLD.idempotency_key <> NEW.idempotency_key
                  OR OLD.clan_id <> NEW.clan_id
                  OR OLD.requester_id <> NEW.requester_id
                  OR OLD.beneficiary_id <> NEW.beneficiary_id
                  OR OLD.amount <> NEW.amount
                  OR OLD.reason <> NEW.reason
                  OR OLD.created_at <> NEW.created_at
                  OR OLD.expires_at <> NEW.expires_at
                BEGIN SELECT RAISE(ABORT, 'clan bank withdrawal request intent is immutable'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_withdrawal_request_state_guard
                BEFORE UPDATE OF status ON clan_bank_withdrawal_requests
                WHEN NOT (OLD.status = 'PENDING' AND NEW.status IN ('APPROVED', 'DECLINED', 'EXPIRED'))
                  OR julianday(NEW.updated_at) < julianday(OLD.updated_at)
                BEGIN SELECT RAISE(ABORT, 'invalid clan bank withdrawal request transition'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_withdrawal_request_events_insert_guard
                BEFORE INSERT ON clan_bank_withdrawal_request_events
                WHEN NOT EXISTS (
                    SELECT 1 FROM clan_bank_withdrawal_requests r
                    WHERE r.request_id = NEW.request_id AND r.status = NEW.to_status
                      AND ((NEW.from_status IS NULL AND NOT EXISTS (
                            SELECT 1 FROM clan_bank_withdrawal_request_events e WHERE e.request_id = NEW.request_id))
                        OR NEW.from_status = (SELECT e.to_status FROM clan_bank_withdrawal_request_events e
                            WHERE e.request_id = NEW.request_id ORDER BY e.event_id DESC LIMIT 1))
                )
                BEGIN SELECT RAISE(ABORT, 'withdrawal request event does not match current state'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_withdrawal_request_events_no_update
                BEFORE UPDATE ON clan_bank_withdrawal_request_events
                BEGIN SELECT RAISE(ABORT, 'withdrawal request events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_withdrawal_request_events_no_delete
                BEFORE DELETE ON clan_bank_withdrawal_request_events
                BEGIN SELECT RAISE(ABORT, 'withdrawal request events are append-only'); END
                """);
        execute("""
                CREATE TRIGGER clan_bank_withdrawal_requests_no_delete
                BEFORE DELETE ON clan_bank_withdrawal_requests
                BEGIN SELECT RAISE(ABORT, 'withdrawal requests are retained'); END
                """);
    }

    private void validateSchema(int version) throws SQLException {
        Map<String, Set<String>> requiredColumns = new java.util.LinkedHashMap<>();
        requiredColumns.put("schema_migrations", Set.of("version", "applied_at"));
        requiredColumns.put("clans", Set.of(
                "id", "name", "tag", "tag_key", "created_at", "capacity",
                "total_xp", "tagline", "revision"));
        requiredColumns.put("clan_members", Set.of(
                "clan_id", "player_id", "role", "membership_started_at",
                "appointed_by_deputy_id"));
        requiredColumns.put("capacity_purchase_operations", new java.util.HashSet<>(Set.of(
                "operation_id", "idempotency_key", "business_operation_id", "clan_id",
                "actor_id", "expected_capacity", "target_capacity", "expected_revision",
                "amount", "state", "provider_operation_id", "created_at", "updated_at")));
        requiredColumns.put("capacity_purchase_events", purchaseEventColumns(version));
        requiredColumns.put("applied_business_operations", appliedOperationColumns(version));
        if (version >= 5) {
            requiredColumns.put("clan_settings", Set.of("clan_id", "public_applications_open"));
            requiredColumns.put("clan_requests", Set.of("request_id", "request_type", "clan_id",
                    "player_id", "actor_id", "created_at", "expires_at", "status"));
            requiredColumns.put("clan_request_events", Set.of("event_id", "request_id", "request_type",
                    "from_status", "to_status", "actor_id", "occurred_at"));
        }
        if (version >= 6) {
            requiredColumns.put("clan_xp_events", Set.of("event_id", "clan_id", "event_type",
                    "actor_id", "amount", "idempotency_key", "occurred_at"));
        }
        if (version >= 8) {
            requiredColumns.put("clan_player_activity", Set.of("player_id", "last_seen_epoch_millis"));
        }
        if (version >= 9) {
            requiredColumns.put("clan_election_owner_blocks", Set.of("election_id", "blocked_at", "reason"));
        }
        if (version >= 10) {
            requiredColumns.put("clan_creation_payment_operations", Set.of("operation_id", "idempotency_key",
                    "creator_id", "clan_id", "clan_name", "clan_tag", "clan_slogan", "clan_created_at",
                    "amount_units", "state", "diagnostic", "created_at", "updated_at"));
            requiredColumns.put("clan_creation_payment_events", Set.of("event_id", "operation_id", "from_state",
                    "to_state", "diagnostic", "occurred_at"));
        }
        if (version >= 11) {
            requiredColumns.put("clan_bank_accounts", new java.util.HashSet<>(Set.of("clan_id", "balance", "revision", "updated_at")));
            requiredColumns.put("clan_bank_transactions", Set.of("transaction_id", "idempotency_key", "clan_id",
                    "actor_id", "transaction_type", "amount", "balance_after", "reason", "approved_by", "occurred_at"));
        }
        if (version >= 12) {
            requiredColumns.put("clan_bank_withdrawal_requests", new java.util.HashSet<>(Set.of("request_id", "idempotency_key", "clan_id",
                    "requester_id", "beneficiary_id", "amount", "reason", "status", "created_at", "expires_at", "updated_at")));
            requiredColumns.put("clan_bank_withdrawal_request_events", Set.of("event_id", "request_id", "from_status",
                    "to_status", "actor_id", "details", "occurred_at"));
        }
        if (version >= 13) {
            requiredColumns.get("clan_bank_accounts").add("reserved_balance");
            requiredColumns.get("clan_bank_withdrawal_requests").add("payment_operation_id");
            requiredColumns.put("clan_bank_operations", Set.of("operation_id", "idempotency_key", "business_operation_id",
                    "clan_id", "actor_id", "beneficiary_id", "request_id", "operation_type", "amount", "state", "diagnostic", "created_at", "updated_at"));
            requiredColumns.put("clan_bank_operation_events", Set.of("event_id", "operation_id", "from_state", "to_state", "evidence", "occurred_at"));
            requiredColumns.put("clan_bank_reservations", Set.of("operation_id", "clan_id", "amount", "state", "created_at", "updated_at"));
        }
        if (version >= 14) {
            requiredColumns.put("clan_combat_log_sessions", Set.of("player_id", "opponent_id", "last_hit_at", "expires_at", "status", "updated_at"));
            requiredColumns.put("clan_combat_log_events", Set.of("event_id", "player_id", "opponent_id", "event_type", "occurred_at", "expires_at", "details"));
        }
        if (version >= 15) {
            requiredColumns.put("clan_home_points", Set.of("clan_id", "name", "world_id", "x", "y", "z", "yaw", "pitch", "created_by", "created_at", "updated_by", "updated_at"));
            requiredColumns.put("clan_home_events", Set.of("event_id", "clan_id", "actor_id", "event_type", "home_name", "world_id", "x", "y", "z", "yaw", "pitch", "occurred_at"));
        }
        if (version >= 16) {
            requiredColumns.put("clan_storage_accounts", Set.of("clan_id", "page_count", "revision", "updated_at"));
            requiredColumns.put("clan_storage_pages", Set.of("clan_id", "page_number", "contents", "revision", "created_by", "created_at", "original_price", "charged_price", "discount_percent"));
            requiredColumns.put("clan_storage_events", Set.of("event_id", "clan_id", "actor_id", "event_type", "page_number", "original_price", "charged_price", "discount_percent", "occurred_at"));
        }
        if (version >= 17) {
            requiredColumns.put("clan_storage_content_events", Set.of("event_id", "clan_id", "page_number", "actor_id", "event_type", "revision", "content_sha256", "content_size", "occurred_at"));
        }
        if (version >= 18) {
            requiredColumns.put("clan_storage_item_movements", Set.of("event_id", "operation_id", "clan_id", "page_number", "actor_id", "movement_type", "item_type", "amount", "occurred_at"));
        }
        if (version >= 19) {
            requiredColumns.put("clan_storage_committed_operations", Set.of("operation_id", "clan_id", "page_number", "actor_id", "movement_type", "item_type", "amount", "expected_revision", "result_revision", "contents_sha256", "occurred_at"));
        }
        if (version >= 20) {
            requiredColumns.put("clan_storage_transfer_operations", Set.of("operation_id", "clan_id", "page_number", "actor_id", "movement_type", "item_type", "amount", "expected_revision", "before_player_sha256", "after_player_sha256", "before_page_sha256", "after_page_sha256", "before_player_inventory", "after_player_inventory", "before_page_contents", "after_page_contents", "state", "created_at", "updated_at"));
            requiredColumns.put("clan_storage_transfer_events", Set.of("event_id", "operation_id", "from_state", "to_state", "actor_id", "details", "occurred_at"));
        }
        if (version >= 7) {
            requiredColumns.put("clan_elections", Set.of("election_id", "clan_id", "election_type", "phase", "started_by", "started_at", "closes_at", "winner_id", "completed_at"));
            requiredColumns.put("clan_election_candidates", Set.of("election_id", "phase", "candidate_id"));
            requiredColumns.put("clan_election_votes", Set.of("election_id", "phase", "voter_id", "candidate_id", "voted_at"));
            requiredColumns.put("clan_election_events", Set.of("event_id", "election_id", "event_type", "actor_id", "details", "occurred_at"));
        }
        if (version >= 11) {
            requireIndex("clan_bank_transactions_clan_idx", "clan_bank_transactions", List.of("clan_id", "occurred_at", "transaction_id"), false);
            requireObject("trigger", "clan_bank_transactions_no_update", "clan_bank_transactions");
            requireObject("trigger", "clan_bank_transactions_no_delete", "clan_bank_transactions");
        }
        if (version >= 18) {
            requireIndex("clan_storage_item_movements_clan_idx", "clan_storage_item_movements", List.of("clan_id", "event_id"), false);
            requireObject("trigger", "clan_storage_item_movements_no_update", "clan_storage_item_movements");
            requireObject("trigger", "clan_storage_item_movements_no_delete", "clan_storage_item_movements");
        }
        if (version >= 19) {
            requireIndex("clan_storage_committed_operations_clan_idx", "clan_storage_committed_operations", List.of("clan_id", "occurred_at"), false);
            requireObject("trigger", "clan_storage_committed_operations_no_update", "clan_storage_committed_operations");
            requireObject("trigger", "clan_storage_committed_operations_no_delete", "clan_storage_committed_operations");
        }
        if (version >= 20) {
            requireIndex("clan_storage_transfer_pending_page_idx", "clan_storage_transfer_operations", List.of("clan_id", "page_number"), true);
            requireIndex("clan_storage_transfer_pending_actor_idx", "clan_storage_transfer_operations", List.of("actor_id"), true);
            requireIndex("clan_storage_transfer_events_operation_idx", "clan_storage_transfer_events", List.of("operation_id", "event_id"), false);
            requireObject("trigger", "clan_storage_transfer_operations_payload_immutable", "clan_storage_transfer_operations");
            requireObject("trigger", "clan_storage_transfer_operations_state_guard", "clan_storage_transfer_operations");
            requireObject("trigger", "clan_storage_transfer_events_no_update", "clan_storage_transfer_events");
            requireObject("trigger", "clan_storage_transfer_events_no_delete", "clan_storage_transfer_events");
            validateIndexSql("clan_storage_transfer_pending_page_idx", "CREATE UNIQUE INDEX clan_storage_transfer_pending_page_idx ON clan_storage_transfer_operations(clan_id, page_number) WHERE state = 'PREPARED'");
            validateIndexSql("clan_storage_transfer_pending_actor_idx", "CREATE UNIQUE INDEX clan_storage_transfer_pending_actor_idx ON clan_storage_transfer_operations(actor_id) WHERE state = 'PREPARED'");
            requireTriggerFragments("clan_storage_transfer_operations_payload_immutable",
                    "old.before_player_inventory is not new.before_player_inventory",
                    "old.after_page_contents is not new.after_page_contents", "payload is immutable");
            requireTriggerFragments("clan_storage_transfer_operations_state_guard",
                    "old.state = 'prepared'", "new.state in ('committed', 'aborted', 'manual_review')");
            requireTriggerFragments("clan_storage_transfer_events_no_update", "before update", "append-only");
            requireTriggerFragments("clan_storage_transfer_events_no_delete", "before delete", "append-only");
            requireTableSql("clan_storage_transfer_operations", "state text not null check (state in ('prepared', 'committed', 'aborted', 'manual_review'))");
            requireTableSql("clan_storage_transfer_operations", "check (before_player_sha256 <> after_player_sha256)");
            requireTableSql("clan_storage_transfer_operations", "check (before_page_sha256 <> after_page_sha256)");
        }
        if (version >= 13) {
            requireIndex("clan_bank_withdrawal_request_payment_idx", "clan_bank_withdrawal_requests", List.of("payment_operation_id"), true);
            requireIndex("clan_bank_operations_business_operation_idx", "clan_bank_operations", List.of("business_operation_id"), true);
            requireIndex("clan_bank_operations_request_idx", "clan_bank_operations", List.of("request_id"), true);
            requireIndex("clan_bank_operations_actor_unresolved_idx", "clan_bank_operations", List.of("clan_id", "actor_id", "operation_type"), true);
            validateIndexSql("clan_bank_operations_actor_unresolved_idx", """
                    CREATE UNIQUE INDEX clan_bank_operations_actor_unresolved_idx
                    ON clan_bank_operations(clan_id, actor_id, operation_type)
                    WHERE operation_type IN ('DEPOSIT', 'LEADER_WITHDRAWAL') AND state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'UNKNOWN')
                    """);
            validateIndexSql("clan_bank_operations_business_operation_idx", """
                    CREATE UNIQUE INDEX clan_bank_operations_business_operation_idx
                    ON clan_bank_operations(business_operation_id)
                    WHERE state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'COMMITTED', 'UNKNOWN')
                    """);
            validateIndexSql("clan_bank_operations_request_idx", """
                    CREATE UNIQUE INDEX clan_bank_operations_request_idx
                    ON clan_bank_operations(request_id)
                    WHERE request_id IS NOT NULL AND state IN ('PREPARED', 'CALLING', 'EXTERNAL_CONFIRMED', 'COMMITTED', 'UNKNOWN')
                    """);
            requireIndex("clan_bank_operations_state_idx", "clan_bank_operations", List.of("state", "created_at"), false);
            requireIndex("clan_bank_operations_clan_idx", "clan_bank_operations", List.of("clan_id", "created_at", "operation_id"), false);
            requireIndex("clan_bank_operation_events_idx", "clan_bank_operation_events", List.of("operation_id", "event_id"), false);
            requireObject("trigger", "clan_bank_operations_intent_immutable", "clan_bank_operations");
            requireObject("trigger", "clan_bank_operations_state_guard", "clan_bank_operations");
            requireObject("trigger", "clan_bank_operation_events_insert_guard", "clan_bank_operation_events");
            requireObject("trigger", "clan_bank_operation_events_no_update", "clan_bank_operation_events");
            requireObject("trigger", "clan_bank_operation_events_no_delete", "clan_bank_operation_events");
            requireObject("trigger", "clan_bank_reservations_intent_immutable", "clan_bank_reservations");
            requireObject("trigger", "clan_bank_reservations_no_delete", "clan_bank_reservations");
            requireTriggerFragments("clan_bank_operations_intent_immutable", "old.business_operation_id <> new.business_operation_id",
                    "old.request_id is not new.request_id", "clan bank operation intent is immutable");
            requireTriggerFragments("clan_bank_operations_state_guard", "old.state = 'prepared' and new.state in ('calling', 'failed_no_effect')",
                    "old.state = 'calling' and new.state in ('external_confirmed', 'failed_no_effect', 'unknown')",
                    "old.state = 'unknown' and new.state in ('external_confirmed', 'failed_no_effect')");
            requireTriggerFragments("clan_bank_operation_events_insert_guard", "new.to_state", "new.from_state",
                    "does not match current state");
            requireTriggerFragments("clan_bank_operation_events_no_update", "before update", "append-only");
            requireTriggerFragments("clan_bank_operation_events_no_delete", "before delete", "append-only");
            requireTriggerFragments("clan_bank_reservations_intent_immutable", "old.amount <> new.amount",
                    "old.state = 'reserved' and new.state in ('consumed', 'released')");
            requireTriggerFragments("clan_bank_reservations_no_delete", "before delete", "are retained");
        }
        if (version >= 14) {
            requireIndex("clan_combat_log_sessions_expiry_idx", "clan_combat_log_sessions", List.of("status", "expires_at"), false);
            requireIndex("clan_combat_log_events_player_idx", "clan_combat_log_events", List.of("player_id", "event_id"), false);
            requireObject("trigger", "clan_combat_log_sessions_state_guard", "clan_combat_log_sessions");
            requireObject("trigger", "clan_combat_log_sessions_no_delete", "clan_combat_log_sessions");
            requireObject("trigger", "clan_combat_log_events_no_update", "clan_combat_log_events");
            requireObject("trigger", "clan_combat_log_events_no_delete", "clan_combat_log_events");
            requireTableSql("clan_combat_log_sessions", "status text not null check (status in ('active', 'expired', 'logout_violation', 'interrupted_review', 'cleared'))");
            requireTableSql("clan_combat_log_sessions", "check (julianday(expires_at) = julianday(last_hit_at) + (30.0 / 86400.0))");
            requireTableSql("clan_combat_log_events", "event_type text not null check (event_type in ('tagged', 'expired', 'logout_violation', 'interrupted_review', 'cleared'))");
            requireTriggerFragments("clan_combat_log_sessions_state_guard", "new.status = 'active'",
                    "old.status = 'active' and new.status in ('expired', 'logout_violation', 'interrupted_review', 'cleared')");
            requireTriggerFragments("clan_combat_log_sessions_no_delete", "before delete", "history is retained");
            requireTriggerFragments("clan_combat_log_events_no_update", "before update", "append-only");
            requireTriggerFragments("clan_combat_log_events_no_delete", "before delete", "append-only");
        }
        if (version >= 15) {
            requireIndex("clan_home_events_clan_idx", "clan_home_events", List.of("clan_id", "event_id"), false);
            requireObject("trigger", "clan_home_events_no_update", "clan_home_events");
            requireObject("trigger", "clan_home_events_no_delete", "clan_home_events");
            requireTableSql("clan_home_points", "name text not null check (length(trim(name)) between 1 and 32)");
            if (version >= 24) {
                // Owner decision #2 (preliminary): at most two home points, second one purchased.
                requireTableSql("clan_home_points", "primary key (clan_id, slot)");
                requireTableSql("clan_home_points", "check (slot in (1, 2))");
                requireTableSql("clan_home_events", "event_type text not null check (event_type in ('set', 'rename', 'delete', 'purchase'))");
                requireTableSql("clan_home_slots", "primary key (clan_id, slot)");
                requireTableSql("clan_home_slots", "check (length(price_paid) > 0)");
            } else {
                requireTableSql("clan_home_points", "clan_id text primary key not null references clans(id) on delete cascade");
                requireTableSql("clan_home_events", "event_type text not null check (event_type in ('set', 'rename', 'delete'))");
            }
            requireTriggerFragments("clan_home_events_no_update", "before update", "append-only");
            requireTriggerFragments("clan_home_events_no_delete", "before delete", "append-only");
        }
        if (version >= 16) {
            requireIndex("clan_storage_events_clan_idx", "clan_storage_events", List.of("clan_id", "event_id"), false);
            requireObject("trigger", "clan_storage_events_no_update", "clan_storage_events");
            requireObject("trigger", "clan_storage_events_no_delete", "clan_storage_events");
            requireTableSql("clan_storage_accounts", "page_count integer not null check (page_count between 1 and 10)");
            requireTableSql("clan_storage_pages", "primary key (clan_id, page_number)");
            requireTableSql("clan_storage_pages", "contents blob not null");
            requireTableSql("clan_storage_events", "event_type text not null check (event_type in ('free_page_granted', 'page_purchased'))");
            requireTriggerFragments("clan_storage_events_no_update", "before update", "append-only");
            requireTriggerFragments("clan_storage_events_no_delete", "before delete", "append-only");
        }
        if (version >= 17) {
            requireIndex("clan_storage_content_events_page_idx", "clan_storage_content_events", List.of("clan_id", "page_number", "event_id"), false);
            requireObject("trigger", "clan_storage_content_events_no_update", "clan_storage_content_events");
            requireObject("trigger", "clan_storage_content_events_no_delete", "clan_storage_content_events");
            requireTableSql("clan_storage_content_events", "event_type text not null check (event_type in ('snapshot', 'content_saved'))");
            requireTableSql("clan_storage_content_events", "unique (clan_id, page_number, revision)");
            requireTriggerFragments("clan_storage_content_events_no_update", "before update", "append-only");
            requireTriggerFragments("clan_storage_content_events_no_delete", "before delete", "append-only");
        }
        if (version >= 12) {
            requireIndex("clan_bank_withdrawal_requests_pending_idx", "clan_bank_withdrawal_requests", List.of("clan_id", "status", "expires_at"), false);
            requireIndex("clan_bank_withdrawal_request_events_idx", "clan_bank_withdrawal_request_events", List.of("request_id", "event_id"), false);
            requireObject("trigger", "clan_bank_withdrawal_request_intent_immutable", "clan_bank_withdrawal_requests");
            requireObject("trigger", "clan_bank_withdrawal_request_state_guard", "clan_bank_withdrawal_requests");
            requireObject("trigger", "clan_bank_withdrawal_request_events_insert_guard", "clan_bank_withdrawal_request_events");
            requireObject("trigger", "clan_bank_withdrawal_request_events_no_update", "clan_bank_withdrawal_request_events");
            requireObject("trigger", "clan_bank_withdrawal_request_events_no_delete", "clan_bank_withdrawal_request_events");
            requireObject("trigger", "clan_bank_withdrawal_requests_no_delete", "clan_bank_withdrawal_requests");
            requireTriggerFragments("clan_bank_withdrawal_request_intent_immutable", "old.amount <> new.amount",
                    "old.expires_at <> new.expires_at", "intent is immutable");
            requireTriggerFragments("clan_bank_withdrawal_request_state_guard",
                    "old.status = 'pending' and new.status in ('approved', 'declined', 'expired')");
            requireTriggerFragments("clan_bank_withdrawal_request_events_insert_guard", "new.to_status",
                    "new.from_status", "does not match current state");
            requireTriggerFragments("clan_bank_withdrawal_request_events_no_update", "before update", "append-only");
            requireTriggerFragments("clan_bank_withdrawal_request_events_no_delete", "before delete", "append-only");
            requireTriggerFragments("clan_bank_withdrawal_requests_no_delete", "before delete", "are retained");
        }
        if (version >= 2) {
            requiredColumns.get("capacity_purchase_operations").add("payload_fingerprint");
        }

        for (Map.Entry<String, Set<String>> table : requiredColumns.entrySet()) {
            if (!objectExists("table", table.getKey())) {
                throw new StorageException("Required SQLite table is missing: " + table.getKey());
            }
            Set<String> actual = tableColumns(table.getKey());
            if (!actual.containsAll(table.getValue())) {
                Set<String> missing = new java.util.HashSet<>(table.getValue());
                missing.removeAll(actual);
                throw new StorageException(
                        "SQLite table " + table.getKey() + " is missing columns: " + missing);
            }
        }

        requireIndex("clan_members_clan_id_idx", "clan_members", List.of("clan_id"), false);
        requireIndex(
                "capacity_purchase_state_idx",
                "capacity_purchase_operations",
                List.of("state", "created_at"),
                false);
        requireIndex(
                "capacity_purchase_events_operation_idx",
                "capacity_purchase_events",
                List.of("operation_id", "event_id"),
                false);
        requireObject("trigger", "capacity_purchase_events_no_update", "capacity_purchase_events");
        requireObject("trigger", "capacity_purchase_events_no_delete", "capacity_purchase_events");
        if (version >= 5) {
            requireIndex("clan_requests_pending_invitation_idx", "clan_requests", List.of("clan_id", "player_id"), true);
            requireIndex("clan_requests_pending_application_idx", "clan_requests", List.of("clan_id", "player_id"), true);
            requireIndex("clan_requests_player_idx", "clan_requests", List.of("player_id", "request_type", "status", "expires_at"), false);
            requireIndex("clan_requests_clan_idx", "clan_requests", List.of("clan_id", "request_type", "status", "expires_at"), false);
            requireIndex("clan_request_events_request_idx", "clan_request_events", List.of("request_id", "event_id"), false);
            requireObject("trigger", "clan_request_events_no_update", "clan_request_events");
            requireObject("trigger", "clan_request_events_no_delete", "clan_request_events");
            validateTriggerSql("clan_request_events_no_update", CLAN_REQUEST_NO_UPDATE_TRIGGER_DDL);
            validateTriggerSql("clan_request_events_no_delete", CLAN_REQUEST_NO_DELETE_TRIGGER_DDL);
            validateIndexSql("clan_requests_pending_invitation_idx", """
                    CREATE UNIQUE INDEX clan_requests_pending_invitation_idx
                    ON clan_requests(clan_id, player_id)
                    WHERE request_type = 'INVITATION' AND status = 'PENDING'
                    """);
            validateIndexSql("clan_requests_pending_application_idx", """
                    CREATE UNIQUE INDEX clan_requests_pending_application_idx
                    ON clan_requests(clan_id, player_id)
                    WHERE request_type = 'APPLICATION' AND status = 'PENDING'
                    """);
        }
        if (version >= 6) {
            requireIndex("clan_xp_events_clan_idx", "clan_xp_events", List.of("clan_id", "event_id"), false);
            requireObject("trigger", "clan_xp_events_no_update", "clan_xp_events");
            requireObject("trigger", "clan_xp_events_no_delete", "clan_xp_events");
            validateTriggerSql("clan_xp_events_no_update", CLAN_XP_NO_UPDATE_TRIGGER_DDL);
            validateTriggerSql("clan_xp_events_no_delete", CLAN_XP_NO_DELETE_TRIGGER_DDL);
        }
        if (version >= 8) {
            requireTableSql("clan_player_activity", "last_seen_epoch_millis integer not null check (last_seen_epoch_millis >= 0)");
        }
        if (version >= 9) {
            requireTableSql("clan_election_owner_blocks", "reason text not null check (reason = 'global_tie_remains_tied')");
            requireObject("trigger", "clan_election_owner_blocks_insert_guard", "clan_election_owner_blocks");
            requireObject("trigger", "clan_election_owner_blocks_no_update", "clan_election_owner_blocks");
            requireObject("trigger", "clan_election_owner_blocks_no_delete", "clan_election_owner_blocks");
            requireObject("trigger", "clan_election_candidates_insert_guard", "clan_election_candidates");
            requireObject("trigger", "clan_election_candidates_no_update", "clan_election_candidates");
            requireObject("trigger", "clan_election_candidates_no_delete", "clan_election_candidates");
            requireObject("trigger", "clan_election_votes_insert_guard", "clan_election_votes");
            requireObject("trigger", "clan_election_votes_no_update", "clan_election_votes");
            requireObject("trigger", "clan_election_votes_no_delete", "clan_election_votes");
            validateTriggerSql("clan_election_owner_blocks_insert_guard", CLAN_ELECTION_OWNER_BLOCKS_INSERT_GUARD_TRIGGER_DDL);
            validateTriggerSql("clan_election_owner_blocks_no_update", CLAN_ELECTION_OWNER_BLOCKS_NO_UPDATE_TRIGGER_DDL);
            validateTriggerSql("clan_election_owner_blocks_no_delete", CLAN_ELECTION_OWNER_BLOCKS_NO_DELETE_TRIGGER_DDL);
            validateTriggerSql("clan_election_candidates_insert_guard", CLAN_ELECTION_CANDIDATES_INSERT_GUARD_TRIGGER_DDL);
            validateTriggerSql("clan_election_candidates_no_update", CLAN_ELECTION_CANDIDATES_NO_UPDATE_TRIGGER_DDL);
            validateTriggerSql("clan_election_candidates_no_delete", CLAN_ELECTION_CANDIDATES_NO_DELETE_TRIGGER_DDL);
            validateTriggerSql("clan_election_votes_insert_guard", CLAN_ELECTION_VOTES_INSERT_GUARD_TRIGGER_DDL);
            validateTriggerSql("clan_election_votes_no_update", CLAN_ELECTION_VOTES_NO_UPDATE_TRIGGER_DDL);
            validateTriggerSql("clan_election_votes_no_delete", CLAN_ELECTION_VOTES_NO_DELETE_TRIGGER_DDL);
        }
        if (version >= 7) {
            requireIndex("clan_elections_one_active_per_clan_idx", "clan_elections", List.of("clan_id"), true);
            validateIndexSql("clan_elections_one_active_per_clan_idx", """
                    CREATE UNIQUE INDEX clan_elections_one_active_per_clan_idx
                    ON clan_elections(clan_id)
                    WHERE phase IN ('LOCAL', 'GLOBAL_TIE_BREAK')
                    """);
            requireIndex("clan_elections_due_idx", "clan_elections", List.of("phase", "closes_at"), false);
            requireIndex("clan_election_votes_candidate_idx", "clan_election_votes", List.of("election_id", "phase", "candidate_id"), false);
            requireIndex("clan_election_events_election_idx", "clan_election_events", List.of("election_id", "event_id"), false);
            requireObject("trigger", "clan_election_events_no_update", "clan_election_events");
            requireObject("trigger", "clan_election_events_no_delete", "clan_election_events");
            validateTriggerSql("clan_election_events_no_update", CLAN_ELECTION_EVENTS_NO_UPDATE_TRIGGER_DDL);
            validateTriggerSql("clan_election_events_no_delete", CLAN_ELECTION_EVENTS_NO_DELETE_TRIGGER_DDL);
        }
        if (version >= 10) {
            requireIndex("clan_creation_payment_creator_unresolved_idx", "clan_creation_payment_operations", List.of("creator_id"), true);
            requireIndex("clan_creation_payment_tag_unresolved_idx", "clan_creation_payment_operations", List.of("clan_tag"), true);
            requireIndex("clan_creation_payment_state_idx", "clan_creation_payment_operations", List.of("state", "created_at"), false);
            requireIndex("clan_creation_payment_events_operation_idx", "clan_creation_payment_events", List.of("operation_id", "event_id"), false);
            requireObject("trigger", "clan_creation_payment_operations_immutable", "clan_creation_payment_operations");
            requireObject("trigger", "clan_creation_payment_operations_no_delete", "clan_creation_payment_operations");
            requireObject("trigger", "clan_creation_payment_state_transition_guard", "clan_creation_payment_operations");
            requireObject("trigger", "clan_creation_payment_events_insert_guard", "clan_creation_payment_events");
            requireObject("trigger", "clan_creation_payment_events_no_update", "clan_creation_payment_events");
            requireObject("trigger", "clan_creation_payment_events_no_delete", "clan_creation_payment_events");
            validateTriggerSql("clan_creation_payment_operations_immutable", CLAN_CREATION_OPERATIONS_IMMUTABLE_TRIGGER_DDL);
            validateTriggerSql("clan_creation_payment_operations_no_delete", CLAN_CREATION_OPERATIONS_NO_DELETE_TRIGGER_DDL);
            validateTriggerSql("clan_creation_payment_state_transition_guard", CLAN_CREATION_STATE_TRANSITION_TRIGGER_DDL);
            validateTriggerSql("clan_creation_payment_events_insert_guard", CLAN_CREATION_EVENTS_INSERT_GUARD_TRIGGER_DDL);
            validateTriggerSql("clan_creation_payment_events_no_update", CLAN_CREATION_EVENTS_NO_UPDATE_TRIGGER_DDL);
            validateTriggerSql("clan_creation_payment_events_no_delete", CLAN_CREATION_EVENTS_NO_DELETE_TRIGGER_DDL);
            requireTableSql("clan_creation_payment_operations", "amount_units integer not null check (amount_units = 1000000)");
            requireTableSql("clan_creation_payment_operations", "check (julianday(updated_at) >= julianday(created_at))");
            requireTableSql("clan_creation_payment_operations", "check (state in ('prepared', 'calling', 'debit_confirmed', 'committed', 'failed_no_effect', 'unknown'))");
            validateIndexSql("clan_creation_payment_creator_unresolved_idx", "CREATE UNIQUE INDEX clan_creation_payment_creator_unresolved_idx ON clan_creation_payment_operations(creator_id) WHERE state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')");
            validateIndexSql("clan_creation_payment_tag_unresolved_idx", "CREATE UNIQUE INDEX clan_creation_payment_tag_unresolved_idx ON clan_creation_payment_operations(clan_tag COLLATE NOCASE) WHERE state IN ('PREPARED', 'CALLING', 'DEBIT_CONFIRMED', 'UNKNOWN')");
        }
        validateTableDefinitions(version);
        validatePurchaseEventTriggers();
        // The journal columns that carry stored evidence only exist from version 4 on, so the
        // history is validated once the on-disk schema can actually express it.
        validatePurchaseJournalConsistency(version >= 4);
        if (version >= 5) validateClanRequestHistory();
        if (version >= 6) validateClanXpHistory();
        if (version >= 10) validateClanCreationPaymentHistory();
        if (version >= 7) validateClanElectionHistory();
        if (version >= 8) validateClanActivityHistory();
        if (version >= 9) validateElectionOwnerBlocks();
        if (version >= 12) validateClanBankWithdrawalRequestHistory();
        if (version >= 13) validateClanBankOperationHistory();
        if (version >= 14) validateCombatLogHistory();
        if (version >= 15) {
            if (version >= 24) validateClanHomeHistory();
            else validateLegacyClanHomeHistory();
        }
        if (version >= 16) validateClanStorageHistory();
        if (version >= 17) validateClanStorageContentHistory();
        if (version >= 20) validateClanStorageTransferHistory();
        if (version >= 21) {
            requireTableSql("clan_wars", "state in ('pending', 'active', 'finished', 'cancelled')",
                    "check (attacker_clan_id <> defender_clan_id)",
                    "target_kills integer not null check (target_kills between 1 and 1000000)",
                    "duration_seconds integer not null check (duration_seconds between 60 and 2592000)");
            requireTableSql("clan_war_funds", "primary key (war_id, clan_id)");
            requireTableSql("clan_war_events", "references clan_wars(war_id)");
            requireIndex("clan_wars_one_open_pair_idx", "clan_wars", List.of("pair_key"), true);
            requireObject("trigger", "clan_war_events_no_update", "clan_war_events");
            requireObject("trigger", "clan_war_events_no_delete", "clan_war_events");
            requireObject("trigger", "clan_wars_terminal_state_guard", "clan_wars");
        }
        if (version >= 22) {
            requireTableSql("clan_chat_mutes", "primary key (clan_id, player_id)",
                    "check (length(reason) between 1 and 200)");
            requireTableSql("clan_chat_mute_events", "event_type in ('muted', 'unmuted', 'expired', 'cleared_on_leave')");
            requireTableSql("clan_warnings", "check ((removed_by is null) = (removed_at is null))");
            requireTableSql("clan_warning_cases", "status in ('open', 'escalated_to_leader')",
                    "check (julianday(deadline_at) > julianday(created_at))");
            requireTableSql("clan_warning_case_events", "event_type in ('created', 'escalated')");
            requireIndex("clan_warning_cases_one_per_player_idx", "clan_warning_cases",
                    List.of("clan_id", "player_id"), true);
            requireObject("trigger", "clan_chat_mute_events_no_update", "clan_chat_mute_events");
            requireObject("trigger", "clan_chat_mute_events_no_delete", "clan_chat_mute_events");
            requireObject("trigger", "clan_warning_case_events_no_update", "clan_warning_case_events");
            requireObject("trigger", "clan_warning_case_events_no_delete", "clan_warning_case_events");
            requireObject("trigger", "clan_warning_cases_no_delete", "clan_warning_cases");
        }
        if (version >= 23) {
            requireTableSql("clan_reward_operations",
                    "source in ('personal', 'bank')",
                    "state in (", "'prepared'", "'debit_calling'", "'debit_confirmed'",
                    "'credit_calling'", "'completed'", "'failed_no_effect'", "'manual_review'");
            requireTableSql("clan_reward_events", "references clan_reward_operations(operation_id)");
            requireObject("trigger", "clan_reward_events_no_update", "clan_reward_events");
            requireObject("trigger", "clan_reward_events_no_delete", "clan_reward_events");
        }
        if (version >= 25) {
            requireTableSql("clan_reward_requests",
                    "status in ('pending', 'approved', 'declined', 'expired')",
                    "check (julianday(expires_at) > julianday(created_at))");
            requireTableSql("clan_reward_request_events",
                    "event_type in ('created', 'approved', 'declined', 'expired')");
            requireIndex("clan_reward_requests_pending_idx", "clan_reward_requests",
                    List.of("clan_id", "deputy_id", "recipient_id", "amount"), true);
            requireObject("trigger", "clan_reward_request_events_no_update", "clan_reward_request_events");
            requireObject("trigger", "clan_reward_request_events_no_delete", "clan_reward_request_events");
        }
        if (version >= 26) {
            requireTableSql("clan_reports",
                    "status in ('new', 'under_review', 'needs_evidence', 'accepted', 'rejected')",
                    "category in ('rules', 'abuse', 'bank_fraud', 'chat_harassment')");
            requireTableSql("clan_report_evidence", "references clan_reports(report_id)");
            requireTableSql("clan_sanctions",
                    "kind in ('warning', 'final_warning', 'temporary_function_block')",
                    "scope in ('clan_chat', 'clan_bank', 'clan_requests', 'clan_wars', 'all')");
            requireTableSql("clan_appeals", "status in ('pending', 'accepted', 'rejected')");
            requireIndex("clan_reports_open_per_author_idx", "clan_reports",
                    List.of("clan_id", "author_id", "category"), true);
            requireIndex("clan_appeals_one_per_sanction_idx", "clan_appeals", List.of("sanction_id"), true);
            for (String table : List.of("clan_report_events", "clan_sanction_events", "clan_appeal_events")) {
                requireObject("trigger", table + "_no_update", table);
                requireObject("trigger", table + "_no_delete", table);
            }
            requireObject("trigger", "clan_reports_no_delete", "clan_reports");
            requireObject("trigger", "clan_sanctions_no_delete", "clan_sanctions");
            requireObject("trigger", "clan_appeals_no_delete", "clan_appeals");
        }
        if (version >= 27) {
            requireTableSql("clan_quests",
                    "category in ('daily', 'weekly', 'special')",
                    "difficulty in ('easy', 'medium', 'hard')",
                    "metric in ('mine_block', 'kill_mob', 'collect_item', 'win_war')",
                    "status in ('active', 'completed', 'expired')",
                    "unique (clan_id, category, period_key, slot)");
            requireTableSql("clan_quest_contributors", "primary key (quest_id, player_id)");
            requireTableSql("clan_quest_events", "references clan_quests");
            requireObject("trigger", "clan_quest_events_no_update", "clan_quest_events");
            requireObject("trigger", "clan_quest_events_no_delete", "clan_quest_events");
        }
        if (version >= 28) {
            requireTableSql("clan_tournaments",
                    "discipline in ('pvp', 'parkour', 'building', 'resource_gathering', 'treasure_hunt')",
                    "state in ('draft', 'registration_open', 'registration_closed', 'running', 'finished', 'cancelled')",
                    "team_size in (3, 5, 10)");
            requireTableSql("clan_tournament_votes", "unique (tournament_id, voter_id)");
            requireTableSql("clan_tournament_events", "references");
            requireObject("trigger", "clan_tournament_events_no_update", "clan_tournament_events");
            requireObject("trigger", "clan_tournament_events_no_delete", "clan_tournament_events");
            requireObject("trigger", "clan_tournament_vote_no_revote", "clan_tournament_votes");
            requireTableSql("clan_admin_audit", "event_type text not null");
            requireObject("trigger", "clan_admin_audit_no_update", "clan_admin_audit");
            requireObject("trigger", "clan_admin_audit_no_delete", "clan_admin_audit");
        }
        validateMigrationHistory(version);
        validateForeignKeys();
    }

    private void validateClanStorageTransferHistory() throws SQLException {
        List<ClanStorageTransferOperation> operations = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT * FROM clan_storage_transfer_operations ORDER BY created_at, operation_id")) {
            while (rows.next()) {
                ClanStorageTransferOperation operation;
                try {
                    operation = readTransferOperation(rows);
                } catch (RuntimeException exception) {
                    throw new StorageException("Corrupt clan storage transfer operation", exception);
                }
                if (!operation.beforePlayerSha256().equals(sha256(operation.beforePlayerInventory()))
                        || !operation.afterPlayerSha256().equals(sha256(operation.afterPlayerInventory()))
                        || !operation.beforePageSha256().equals(sha256(operation.beforePageContents()))
                        || !operation.afterPageSha256().equals(sha256(operation.afterPageContents()))
                        || operation.beforePlayerSha256().equals(operation.afterPlayerSha256())
                        || operation.beforePageSha256().equals(operation.afterPageSha256())
                        || operation.expectedRevision() == Long.MAX_VALUE)
                    throw new StorageException("Clan storage transfer snapshot digest or revision is invalid: " + operation.operationId());
                operations.add(operation);
            }
        }
        for (ClanStorageTransferOperation operation : operations) {
            int eventCount = 0;
            String lastState = null;
            Instant lastAt = null;
            try (PreparedStatement events = connection.prepareStatement("""
                    SELECT from_state, to_state, actor_id, details, occurred_at
                    FROM clan_storage_transfer_events WHERE operation_id = ? ORDER BY event_id
                    """)) {
                events.setString(1, operation.operationId().toString());
                try (ResultSet rows = events.executeQuery()) {
                    while (rows.next()) {
                        String from = rows.getString("from_state");
                        String to = rows.getString("to_state");
                        UUID actor;
                        Instant at;
                        try {
                            actor = UUID.fromString(rows.getString("actor_id"));
                            at = Instant.parse(rows.getString("occurred_at"));
                        } catch (RuntimeException exception) {
                            throw new StorageException("Clan storage transfer event contains invalid identity/time", exception);
                        }
                        if (rows.getString("details") == null || rows.getString("details").isBlank()
                                || !actor.equals(operation.actorId())
                                || (lastAt != null && at.isBefore(lastAt)))
                            throw new StorageException("Clan storage transfer event is invalid: " + operation.operationId());
                        if (eventCount == 0) {
                            if (from != null || !"PREPARED".equals(to) || !at.equals(operation.createdAt()))
                                throw new StorageException("Clan storage transfer history must begin with PREPARED");
                        } else if (eventCount == 1) {
                            if (!"PREPARED".equals(from) || !to.equals(operation.state())
                                    || !Set.of("COMMITTED", "ABORTED", "MANUAL_REVIEW").contains(to))
                                throw new StorageException("Clan storage transfer history has an invalid terminal transition");
                        } else {
                            throw new StorageException("Clan storage transfer history contains extra events");
                        }
                        eventCount++;
                        lastState = to;
                        lastAt = at;
                    }
                }
            }
            int expectedEvents = operation.state().equals("PREPARED") ? 1 : 2;
            if (eventCount != expectedEvents || !operation.state().equals(lastState)
                    || !operation.updatedAt().equals(lastAt))
                throw new StorageException("Clan storage transfer state does not match its append-only history: " + operation.operationId());
            boolean hasReceipt = exists("SELECT 1 FROM clan_storage_committed_operations WHERE operation_id = ?",
                    operation.operationId().toString());
            if (operation.state().equals("COMMITTED") != hasReceipt)
                throw new StorageException("Clan storage transfer receipt does not match operation state: " + operation.operationId());
            if (hasReceipt) {
                try (PreparedStatement receipt = connection.prepareStatement("""
                        SELECT clan_id, page_number, actor_id, movement_type, item_type, amount,
                               expected_revision, result_revision, contents_sha256
                        FROM clan_storage_committed_operations WHERE operation_id = ?
                        """)) {
                    receipt.setString(1, operation.operationId().toString());
                    try (ResultSet row = receipt.executeQuery()) {
                        if (!row.next() || !row.getString("clan_id").equals(operation.clanId().toString())
                                || row.getInt("page_number") != operation.pageNumber()
                                || !row.getString("actor_id").equals(operation.actorId().toString())
                                || !row.getString("movement_type").equals(operation.movementType())
                                || !row.getString("item_type").equals(operation.itemType())
                                || row.getInt("amount") != operation.amount()
                                || row.getLong("expected_revision") != operation.expectedRevision()
                                || row.getLong("result_revision") != operation.expectedRevision() + 1
                                || !row.getString("contents_sha256").equals(operation.afterPageSha256()))
                            throw new StorageException("Clan storage transfer receipt payload mismatch: " + operation.operationId());
                    }
                }
                if (!exists("SELECT 1 FROM clan_storage_content_events WHERE clan_id = ? AND page_number = ? AND revision = ? AND content_sha256 = ?",
                        operation.clanId().toString(), Integer.toString(operation.pageNumber()),
                        Long.toString(operation.expectedRevision() + 1), operation.afterPageSha256()))
                    throw new StorageException("Committed clan storage transfer has no matching content event: " + operation.operationId());
                try (PreparedStatement movement = connection.prepareStatement("""
                        SELECT 1 FROM clan_storage_item_movements WHERE operation_id = ? AND clan_id = ?
                          AND page_number = ? AND actor_id = ? AND movement_type = ? AND item_type = ? AND amount = ?
                        """)) {
                    movement.setString(1, operation.operationId().toString()); movement.setString(2, operation.clanId().toString());
                    movement.setInt(3, operation.pageNumber()); movement.setString(4, operation.actorId().toString());
                    movement.setString(5, operation.movementType()); movement.setString(6, operation.itemType());
                    movement.setInt(7, operation.amount());
                    try (ResultSet row = movement.executeQuery()) {
                        if (!row.next()) throw new StorageException(
                                "Committed clan storage transfer has no matching movement event: " + operation.operationId());
                    }
                }
            }
        }
        List<String> eventOperationIds = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT operation_id FROM clan_storage_transfer_events")) {
            while (rows.next()) eventOperationIds.add(rows.getString(1));
        }
        for (String eventOperationId : eventOperationIds) {
            if (!exists("SELECT 1 FROM clan_storage_transfer_operations WHERE operation_id = ?", eventOperationId))
                throw new StorageException("Orphan clan storage transfer event detected");
        }
    }

    private static Set<String> purchaseEventColumns(int version) {
        Set<String> columns = new java.util.HashSet<>(Set.of(
                "event_id", "operation_id", "provider_operation_id", "occurred_at",
                "evidence_provenance"));
        columns.add(version >= 4 ? "to_state" : "state");
        if (version >= 4) {
            columns.addAll(Set.of("from_state", "evidence"));
        } else {
            columns.remove("evidence_provenance");
        }
        return columns;
    }

    private static Set<String> appliedOperationColumns(int version) {
        Set<String> columns = new java.util.HashSet<>(Set.of(
                "business_operation_id", "operation_id", "clan_id",
                "from_capacity", "to_capacity", "committed_at"));
        if (version >= 4) {
            columns.addAll(Set.of(
                    "expected_revision", "applied_revision", "amount",
                    "commit_evidence_provenance"));
        }
        return columns;
    }

    private void validatePurchaseJournalConsistency() throws SQLException {
        validatePurchaseJournalConsistency(true);
    }

    private void validatePurchaseJournalConsistency(boolean validateStoredEvidence)
            throws SQLException {
        List<String> operationIds = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("""
                     SELECT operation_id
                     FROM capacity_purchase_operations
                     """)) {
            while (result.next()) {
                operationIds.add(result.getString("operation_id"));
            }
        }
        for (String operationId : operationIds) {
            if (findPurchaseBy("operation_id", operationId, validateStoredEvidence).isEmpty()) {
                throw new StorageException(
                        "Corrupt capacity purchase history for operation "
                                + operationId + ": operation row disappeared during validation");
            }
        }
    }

    /**
     * Replays the stored journal of one operation.
     *
     * <p>Every check uses the values the store wrote at the time of the transition: the stored
     * {@code from_state}, {@code to_state} and {@code evidence}. Nothing is derived backwards from a
     * pair of states. Rows tagged {@code UNVERIFIED_LEGACY} came from schema v1-v3, which did not
     * store evidence; they keep their structural role in the chain but never confirm a transition.
     */
    private void validatePurchaseJournalEntry(CapacityPurchaseOperation operation)
            throws SQLException {
        UUID operationId = operation.operationId();
        CapacityPurchaseState previousState = null;
        CapacityPurchaseState lastState = null;
        String lastProviderOperationId = null;
        boolean recordedEvidenceSeen = false;
        int eventCount = 0;
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT event_id, from_state, to_state, evidence, evidence_provenance,
                    provider_operation_id, occurred_at
                FROM capacity_purchase_events
                WHERE operation_id = ?
                ORDER BY event_id
                """)) {
            statement.setString(1, operationId.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    eventCount++;
                    String provenance = result.getString("evidence_provenance");
                    String eventProviderReference = result.getString("provider_operation_id");
                    CapacityPurchaseState eventState;
                    CapacityPurchaseState sourceState;
                    CapacityPurchaseTransitionEvidence evidence;
                    try {
                        eventState = CapacityPurchaseState.valueOf(result.getString("to_state"));
                        sourceState = parseStateOrNull(result.getString("from_state"));
                        evidence = parseEvidenceOrNull(result.getString("evidence"));
                        Instant.parse(result.getString("occurred_at"));
                    } catch (RuntimeException exception) {
                        throw invalidPurchaseHistory(operationId,
                                "event contains an invalid state, evidence or timestamp");
                    }
                    if (eventProviderReference != null && eventProviderReference.isBlank()) {
                        throw invalidPurchaseHistory(
                                operationId, "event contains a blank provider reference");
                    }
                    boolean initialEvent = previousState == null;
                    if (CapacityPurchaseEvidenceProvenance.RECORDED.name().equals(provenance)) {
                        recordedEvidenceSeen = true;
                        if (initialEvent) {
                            if (sourceState != null || evidence != null) {
                                throw invalidPurchaseHistory(operationId,
                                        "initial event claims a transition source or evidence");
                            }
                        } else {
                            if (sourceState == null || evidence == null) {
                                throw invalidPurchaseHistory(operationId,
                                        "recorded event does not store its transition source or evidence");
                            }
                            if (sourceState != previousState) {
                                throw invalidPurchaseHistory(operationId,
                                        "recorded transition starts from " + sourceState
                                                + " but the previous event ended in " + previousState);
                            }
                            Optional<CapacityPurchaseTransitionEvidence> required =
                                    CapacityPurchaseTransitionPolicy.evidenceForTransition(
                                            sourceState, eventState);
                            if (required.isEmpty() || required.get() != evidence) {
                                throw invalidPurchaseHistory(operationId, "stored evidence " + evidence
                                        + " does not confirm the recorded transition "
                                        + sourceState + " -> " + eventState);
                            }
                        }
                    } else if (CapacityPurchaseEvidenceProvenance.UNVERIFIED_LEGACY.name()
                            .equals(provenance)) {
                        if (recordedEvidenceSeen) {
                            throw invalidPurchaseHistory(operationId,
                                    "unverified legacy event follows recorded evidence");
                        }
                        if (sourceState != null || evidence != null) {
                            throw invalidPurchaseHistory(operationId,
                                    "unverified legacy event claims a transition source or evidence");
                        }
                    } else {
                        throw invalidPurchaseHistory(operationId,
                                "event has an unknown evidence provenance: " + provenance);
                    }
                    if (initialEvent) {
                        if (eventState != CapacityPurchaseState.PREPARED
                                || eventProviderReference != null) {
                            throw invalidPurchaseHistory(
                                    operationId, "history must start with PREPARED and no reference");
                        }
                    } else {
                        if (isTerminal(previousState)) {
                            throw invalidPurchaseHistory(
                                    operationId, "event follows a terminal state");
                        }
                        if (CapacityPurchaseTransitionPolicy
                                .evidenceForTransition(previousState, eventState).isEmpty()) {
                            throw invalidPurchaseHistory(operationId,
                                    "history contains an unsupported state transition");
                        }
                    }
                    previousState = eventState;
                    lastState = eventState;
                    lastProviderOperationId = eventProviderReference;
                }
            }
        }
        if (eventCount == 0) {
            throw invalidPurchaseHistory(operationId, "initial PREPARED event is missing");
        }
        if (lastState != operation.state()
                || !java.util.Objects.equals(
                        operation.providerOperationId(), lastProviderOperationId)) {
            throw invalidPurchaseHistory(
                    operationId, "final event disagrees with operation state or provider reference");
        }

        validatePurchaseBusinessMarker(operation);
    }

    /**
     * A committed purchase must be believable from the clan row itself, not from the marker alone.
     * The marker has to agree with the operation parameters and the clan must still retain at
     * least the capacity purchased by this operation. The clan revision is a monotonic aggregate
     * revision: later legitimate clan changes (including later capacity purchases) must not make
     * an older, correctly committed purchase look corrupt.
     */
    private void validatePurchaseBusinessMarker(CapacityPurchaseOperation operation)
            throws SQLException {
        UUID operationId = operation.operationId();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT business_operation_id, clan_id, from_capacity, to_capacity,
                    expected_revision, applied_revision, amount, commit_evidence_provenance
                FROM applied_business_operations
                WHERE operation_id = ?
                """)) {
            statement.setString(1, operationId.toString());
            try (ResultSet result = statement.executeQuery()) {
                boolean markerExists = result.next();
                if (operation.state() != CapacityPurchaseState.COMMITTED) {
                    if (markerExists) {
                        throw invalidPurchaseHistory(
                                operationId, "business-operation marker exists before COMMITTED");
                    }
                    return;
                }
                if (!markerExists
                        || !operation.businessOperationId()
                        .equals(result.getString("business_operation_id"))
                        || !operation.clanId().toString().equals(result.getString("clan_id"))
                        || operation.expectedCapacity() != result.getInt("from_capacity")
                        || operation.targetCapacity() != result.getInt("to_capacity")) {
                    throw invalidPurchaseHistory(
                            operationId, "COMMITTED lacks its matching business-operation marker");
                }
                validateCommitProof(operation, result);
            }
        }
    }

    private void validateCommitProof(
            CapacityPurchaseOperation operation,
            ResultSet marker) throws SQLException {
        UUID operationId = operation.operationId();
        long markerExpectedRevision = marker.getLong("expected_revision");
        boolean expectedRevisionStored = !marker.wasNull();
        long markerAppliedRevision = marker.getLong("applied_revision");
        boolean appliedRevisionStored = !marker.wasNull();
        long markerAmount = marker.getLong("amount");
        boolean amountStored = !marker.wasNull();
        String provenance = marker.getString("commit_evidence_provenance");

        Optional<ClanVersion> clan = readClanVersion(operation.clanId());
        if (clan.isEmpty()) {
            throw invalidPurchaseHistory(
                    operationId, "COMMITTED references a clan row that no longer exists");
        }
        if (clan.get().capacity() < operation.targetCapacity()) {
            throw invalidPurchaseHistory(operationId, "COMMITTED marker claims capacity "
                    + operation.targetCapacity()
                    + " but the clan currently stores lower capacity " + clan.get().capacity());
        }
        if (CapacityPurchaseEvidenceProvenance.UNVERIFIED_LEGACY.name().equals(provenance)) {
            if (expectedRevisionStored || appliedRevisionStored || amountStored) {
                throw invalidPurchaseHistory(operationId,
                        "unverified legacy commit marker stores revision or amount evidence");
            }
            return;
        }
        if (!CapacityPurchaseEvidenceProvenance.RECORDED.name().equals(provenance)) {
            throw invalidPurchaseHistory(operationId,
                    "commit marker has an unknown evidence provenance: " + provenance);
        }
        if (!expectedRevisionStored || !appliedRevisionStored || !amountStored) {
            throw invalidPurchaseHistory(operationId,
                    "recorded commit marker is missing its revision or amount evidence");
        }
        if (markerExpectedRevision != operation.expectedRevision()) {
            throw invalidPurchaseHistory(operationId, "commit marker expected_revision "
                    + markerExpectedRevision + " disagrees with the operation revision "
                    + operation.expectedRevision());
        }
        if (markerAppliedRevision != markerExpectedRevision + 1) {
            throw invalidPurchaseHistory(operationId, "commit marker applied_revision "
                    + markerAppliedRevision + " is not the revision produced by one atomic change");
        }
        if (markerAmount != operation.amount()) {
            throw invalidPurchaseHistory(operationId, "commit marker amount " + markerAmount
                    + " disagrees with the operation amount " + operation.amount());
        }
        if (clan.get().revision() < markerAppliedRevision) {
            throw invalidPurchaseHistory(operationId, "COMMITTED marker claims applied revision "
                    + markerAppliedRevision
                    + " but the clan currently has older revision " + clan.get().revision());
        }
    }

    private Optional<ClanVersion> readClanVersion(UUID clanId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT capacity, revision FROM clans WHERE id = ?")) {
            statement.setString(1, clanId.toString());
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    return Optional.empty();
                }
                return Optional.of(new ClanVersion(
                        result.getInt("capacity"), result.getLong("revision")));
            }
        }
    }

    private boolean purchaseHistoryIsFullyRecorded(UUID operationId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT COUNT(*) FROM capacity_purchase_events
                WHERE operation_id = ? AND evidence_provenance <> ?
                """)) {
            statement.setString(1, operationId.toString());
            statement.setString(2, CapacityPurchaseEvidenceProvenance.RECORDED.name());
            try (ResultSet result = statement.executeQuery()) {
                return result.next() && result.getInt(1) == 0;
            }
        }
    }

    private static boolean isTerminal(CapacityPurchaseState state) {
        return state == CapacityPurchaseState.COMMITTED
                || state == CapacityPurchaseState.FAILED_NO_EFFECT
                || state == CapacityPurchaseState.COMPENSATED
                || state == CapacityPurchaseState.COMPENSATION_FAILED;
    }

    private static CapacityPurchaseState parseStateOrNull(String value) {
        return value == null ? null : CapacityPurchaseState.valueOf(value);
    }

    private static CapacityPurchaseTransitionEvidence parseEvidenceOrNull(String value) {
        return value == null ? null : CapacityPurchaseTransitionEvidence.valueOf(value);
    }

    private StorageException invalidPurchaseHistory(UUID operationId, String reason) {
        return new StorageException(
                "Corrupt capacity purchase history for operation " + operationId + ": " + reason);
    }

    private void validateTableDefinitions(int version) throws SQLException {
        requireTableSql("schema_migrations", "version integer primary key");
        if (version >= 5) {
            requireTableSql("clan_settings", "public_applications_open integer not null default 1");
            requireTableSql("clan_settings", "check (public_applications_open in (0, 1))");
            requireTableSql("clan_requests", "request_type text not null check (request_type in ('invitation', 'application'))");
            requireTableSql("clan_requests", "check (expires_at > created_at)");
            requireTableSql("clan_requests", "check (request_type <> 'application' or actor_id = player_id)");
            requireTableSql("clan_request_events", "event_id integer primary key autoincrement");
            requireTableSql("clan_request_events", "actor_id text");
        }
        if (version >= 6) {
            requireTableSql("clan_xp_events", "amount integer not null check (amount >= 0)");
            requireTableSql("clan_xp_events", "idempotency_key text not null unique");
        }
        if (version >= 11) {
            requireTableSql("clan_bank_accounts", "balance text not null default '0'", "revision integer not null default 0");
            requireTableSql("clan_bank_transactions", "idempotency_key text not null unique", "transaction_id text primary key not null");
        }
        if (version >= 12) {
            requireTableSql("clan_bank_withdrawal_requests", "status text not null check (status in ('pending', 'approved', 'declined', 'expired'))");
            requireTableSql("clan_bank_withdrawal_requests", "check (julianday(expires_at) > julianday(created_at))");
            requireTableSql("clan_bank_withdrawal_request_events", "event_id integer primary key autoincrement");
        }
        if (version >= 13) {
            requireTableSql("clan_bank_accounts", "reserved_balance text not null default '0'");
            requireTableSql("clan_bank_operations", "business_operation_id text not null", "state text not null check");
            requireTableSql("clan_bank_operations", "'external_confirmed'", "'unknown'");
            requireTableSql("clan_bank_reservations", "state text not null check (state in ('reserved', 'consumed', 'released'))");
        }
        if (version >= 7) {
            requireTableSql("clan_elections", "election_type text not null check (election_type in ('departure', 'coup'))");
            requireTableSql("clan_elections", "phase text not null check (phase in ('local', 'global_tie_break', 'completed', 'cancelled'))");
            requireTableSql("clan_elections", "check (closes_at > started_at)");
            requireTableSql("clan_elections", "winner_id is not null and completed_at is not null");
            requireTableSql("clan_election_candidates", "primary key (election_id, phase, candidate_id)");
            requireTableSql("clan_election_votes", "primary key (election_id, phase, voter_id)");
            requireTableSql("clan_election_votes", "foreign key (election_id, phase, candidate_id)");
            requireTableSql("clan_election_events", "event_type text not null check");
        }
        requireTableSql(
                "clans",
                "id text primary key not null",
                "tag_key text not null unique",
                "capacity in (10, 20, 30, 40, 50)",
                "total_xp >= 0",
                "revision >= 0");
        requireTableSql("clan_members", "player_id text not null unique",
                "role in ('leader', 'deputy', 'moderator', 'member')",
                "references clans(id) on delete cascade");
        List<String> operationFragments = new ArrayList<>(List.of(
                "idempotency_key text not null unique",
                "operation_id text primary key not null",
                "business_operation_id text not null unique",
                "amount > 0",
                "state text not null check"));
        List<String> eventFragments = new ArrayList<>(List.of(
                "references capacity_purchase_operations",
                "event_id integer primary key autoincrement"));
        if (version >= 4) {
            eventFragments.add("to_state text not null check");
            eventFragments.add("from_state text check (from_state is null or from_state in");
            eventFragments.add("evidence text check (evidence is null or evidence in");
            eventFragments.add(
                    "evidence_provenance text not null check (evidence_provenance in"
                            + " ('recorded', 'unverified_legacy'))");
        } else {
            eventFragments.add("state text not null check");
        }
        if (version >= 3) {
            operationFragments.add("'compensation_calling'");
            operationFragments.add("'compensation_unknown'");
            eventFragments.add("'compensation_calling'");
            eventFragments.add("'compensation_unknown'");
        }
        requireTableSql("capacity_purchase_operations", operationFragments.toArray(String[]::new));
        requireTableSql("capacity_purchase_events", eventFragments.toArray(String[]::new));
        List<String> markerFragments = new ArrayList<>(List.of(
                "business_operation_id text primary key",
                "operation_id text not null unique",
                "references capacity_purchase_operations(operation_id)",
                "references clans(id)"));
        if (version >= 4) {
            markerFragments.add("commit_evidence_provenance text not null default"
                    + " 'unverified_legacy'");
        }
        requireTableSql("applied_business_operations", markerFragments.toArray(String[]::new));
    }

    private void requireTableSql(String tableName, String... requiredFragments)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?")) {
            statement.setString(1, tableName);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    throw new StorageException("Required SQLite table is missing: " + tableName);
                }
                String sql = result.getString(1).toLowerCase(Locale.ROOT)
                        .replaceAll("\\s+", " ");
                for (String fragment : requiredFragments) {
                    if (!sql.contains(fragment)) {
                        throw new StorageException(
                                "SQLite table has invalid definition: " + tableName);
                    }
                }
            }
        }
    }

    private Set<String> tableColumns(String tableName) throws SQLException {
        Set<String> columns = new java.util.HashSet<>();
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA table_info('" + tableName + "')")) {
            while (result.next()) {
                columns.add(result.getString("name"));
            }
        }
        return columns;
    }

    private boolean objectExists(String type, String name) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT 1 FROM sqlite_master WHERE type = ? AND name = ?
                """)) {
            statement.setString(1, type);
            statement.setString(2, name);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    private void requireObject(String type, String name, String tableName) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT tbl_name FROM sqlite_master WHERE type = ? AND name = ?
                """)) {
            statement.setString(1, type);
            statement.setString(2, name);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next() || !tableName.equals(result.getString(1))) {
                    throw new StorageException(
                            "Required SQLite " + type + " is missing or invalid: " + name);
                }
            }
        }
    }

    private void requireIndex(
            String name,
            String tableName,
            List<String> expectedColumns,
            boolean expectedUnique) throws SQLException {
        boolean found = false;
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA index_list('" + tableName + "')")) {
            while (result.next()) {
                if (name.equals(result.getString("name"))) {
                    found = result.getInt("unique") == (expectedUnique ? 1 : 0);
                    break;
                }
            }
        }
        if (!found) {
            throw new StorageException("Required SQLite index is missing or invalid: " + name);
        }

        List<String> actualColumns = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA index_info('" + name + "')")) {
            while (result.next()) {
                actualColumns.add(result.getString("name"));
            }
        }
        if (!actualColumns.equals(expectedColumns)) {
            throw new StorageException("SQLite index has invalid columns: " + name);
        }
    }

    private void validateClanXpHistory() throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT clan_id, event_type, actor_id, amount, idempotency_key, occurred_at FROM clan_xp_events ORDER BY event_id")) {
            while (rows.next()) {
                try {
                    UUID.fromString(rows.getString("clan_id"));
                    ClanXpEventType type = ClanXpEventType.valueOf(rows.getString("event_type"));
                    String actor = rows.getString("actor_id");
                    if (actor != null) UUID.fromString(actor);
                    String key = rows.getString("idempotency_key");
                    if (key == null || key.isBlank()) throw new IllegalArgumentException("blank idempotency key");
                    Instant.parse(rows.getString("occurred_at"));
                    if (rows.getLong("amount") != type.amount()) {
                        throw new IllegalArgumentException("XP amount does not match event type");
                    }
                } catch (RuntimeException exception) {
                    throw new StorageException("Corrupt clan XP event history", exception);
                }
            }
        }
    }

    private void validateElectionOwnerBlocks() throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet invalid = statement.executeQuery("""
                     SELECT COUNT(*) FROM clan_election_owner_blocks b
                     JOIN clan_elections e ON e.election_id = b.election_id
                     WHERE e.phase <> 'GLOBAL_TIE_BREAK' OR julianday(b.blocked_at) < julianday(e.closes_at)
                        OR b.reason <> 'GLOBAL_TIE_REMAINS_TIED'
                     """)) {
            if (invalid.next() && invalid.getLong(1) != 0)
                throw new StorageException("Clan election owner-block state is inconsistent");
        }
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT election_id, blocked_at, reason FROM clan_election_owner_blocks")) {
            while (rows.next()) {
                try {
                    UUID.fromString(rows.getString("election_id"));
                    Instant.parse(rows.getString("blocked_at"));
                    if (!"GLOBAL_TIE_REMAINS_TIED".equals(rows.getString("reason")))
                        throw new IllegalArgumentException("invalid owner block reason");
                } catch (RuntimeException exception) {
                    throw new StorageException("Corrupt election owner-block history", exception);
                }
            }
        }
    }

    private void validateClanActivityHistory() throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT player_id, last_seen_epoch_millis FROM clan_player_activity")) {
            while (rows.next()) {
                try {
                    UUID.fromString(rows.getString("player_id"));
                    if (rows.getLong("last_seen_epoch_millis") < 0) throw new IllegalArgumentException("negative activity timestamp");
                    Instant.ofEpochMilli(rows.getLong("last_seen_epoch_millis"));
                } catch (RuntimeException exception) {
                    throw new StorageException("Corrupt player activity history", exception);
                }
            }
        }
    }

    private void validateClanElectionHistory() throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet invalid = statement.executeQuery("""
                     SELECT COUNT(*) FROM clan_elections e
                     WHERE NOT EXISTS (SELECT 1 FROM clan_election_candidates c WHERE c.election_id = e.election_id AND c.phase = 'LOCAL')
                        OR (e.phase = 'GLOBAL_TIE_BREAK' AND NOT EXISTS (SELECT 1 FROM clan_election_candidates c WHERE c.election_id = e.election_id AND c.phase = 'GLOBAL_TIE_BREAK'))
                        OR (e.phase = 'COMPLETED' AND (e.winner_id IS NULL OR NOT EXISTS (
                            SELECT 1 FROM clan_election_candidates c WHERE c.election_id = e.election_id
                              AND c.phase = CASE WHEN EXISTS (SELECT 1 FROM clan_election_candidates g WHERE g.election_id = e.election_id AND g.phase = 'GLOBAL_TIE_BREAK') THEN 'GLOBAL_TIE_BREAK' ELSE 'LOCAL' END
                              AND c.candidate_id = e.winner_id)))
                        OR (e.phase IN ('LOCAL', 'GLOBAL_TIE_BREAK') AND (e.winner_id IS NOT NULL OR e.completed_at IS NOT NULL))
                        OR NOT EXISTS (SELECT 1 FROM clan_election_events ev WHERE ev.election_id = e.election_id AND ev.event_type = 'CREATED')
                     """)) {
            if (invalid.next() && invalid.getLong(1) != 0) throw new StorageException("Clan election state is inconsistent with its candidate/event history");
        }
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT election_id, clan_id, election_type, phase, started_by, started_at, closes_at, winner_id, completed_at FROM clan_elections")) {
            while (rows.next()) {
                try {
                    UUID.fromString(rows.getString("election_id"));
                    UUID.fromString(rows.getString("clan_id"));
                    if (!Set.of("DEPARTURE", "COUP").contains(rows.getString("election_type"))) throw new IllegalArgumentException("invalid election type");
                    if (!Set.of("LOCAL", "GLOBAL_TIE_BREAK", "COMPLETED", "CANCELLED").contains(rows.getString("phase"))) throw new IllegalArgumentException("invalid election phase");
                    UUID.fromString(rows.getString("started_by"));
                    Instant.parse(rows.getString("started_at"));
                    Instant.parse(rows.getString("closes_at"));
                    String winner = rows.getString("winner_id");
                    if (winner != null) UUID.fromString(winner);
                    String completed = rows.getString("completed_at");
                    if (completed != null) Instant.parse(completed);
                } catch (RuntimeException exception) {
                    throw new StorageException("Corrupt clan election history", exception);
                }
            }
        }
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT election_id, phase, candidate_id FROM clan_election_candidates")) {
            while (rows.next()) {
                try { UUID.fromString(rows.getString("election_id")); UUID.fromString(rows.getString("candidate_id")); if (!Set.of("LOCAL", "GLOBAL_TIE_BREAK").contains(rows.getString("phase"))) throw new IllegalArgumentException("invalid candidate phase"); }
                catch (RuntimeException exception) { throw new StorageException("Corrupt clan election candidate history", exception); }
            }
        }
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT election_id, phase, voter_id, candidate_id, voted_at FROM clan_election_votes")) {
            while (rows.next()) {
                try {
                    UUID.fromString(rows.getString("election_id")); UUID.fromString(rows.getString("voter_id")); UUID.fromString(rows.getString("candidate_id"));
                    if (!Set.of("LOCAL", "GLOBAL_TIE_BREAK").contains(rows.getString("phase"))) throw new IllegalArgumentException("invalid vote phase");
                    Instant.parse(rows.getString("voted_at"));
                } catch (RuntimeException exception) { throw new StorageException("Corrupt clan election vote history", exception); }
            }
        }
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT election_id, event_type, actor_id, details, occurred_at FROM clan_election_events ORDER BY event_id")) {
            while (rows.next()) {
                try {
                    UUID.fromString(rows.getString("election_id"));
                    String actor = rows.getString("actor_id"); if (actor != null) UUID.fromString(actor);
                    if (!Set.of("CREATED", "VOTE_CAST", "GLOBAL_TIE_BREAK_STARTED", "COMPLETED", "LEADERSHIP_APPLIED").contains(rows.getString("event_type"))) throw new IllegalArgumentException("invalid election event type");
                    if (rows.getString("details") == null) throw new IllegalArgumentException("missing election event details");
                    Instant.parse(rows.getString("occurred_at"));
                } catch (RuntimeException exception) { throw new StorageException("Corrupt clan election event history", exception); }
            }
        }
    }

    private void validateClanCreationPaymentHistory() throws SQLException {
        try (PreparedStatement operations = connection.prepareStatement(
                "SELECT * FROM clan_creation_payment_operations ORDER BY created_at, operation_id");
             ResultSet rows = operations.executeQuery()) {
            while (rows.next()) {
                ClanCreationPaymentOperation operation;
                try {
                    operation = readClanCreationPayment(rows);
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan creation payment operation contains invalid data", exception);
                }
                ClanCreationPaymentState expected = null;
                Instant previousAt = null;
                int eventCount = 0;
                try (PreparedStatement events = connection.prepareStatement(
                        "SELECT from_state, to_state, diagnostic, occurred_at FROM clan_creation_payment_events WHERE operation_id = ? ORDER BY event_id")) {
                    events.setString(1, operation.operationId().toString());
                    try (ResultSet eventRows = events.executeQuery()) {
                        while (eventRows.next()) {
                            ClanCreationPaymentState from = eventRows.getString("from_state") == null
                                    ? null : ClanCreationPaymentState.valueOf(eventRows.getString("from_state"));
                            ClanCreationPaymentState to = ClanCreationPaymentState.valueOf(eventRows.getString("to_state"));
                            Instant at = Instant.parse(eventRows.getString("occurred_at"));
                            if (eventCount == 0) {
                                if (from != null || to != ClanCreationPaymentState.PREPARED || !at.equals(operation.createdAt()))
                                    throw new StorageException("Clan creation payment history must begin with PREPARED at creation time");
                            } else if (from != expected || !validClanCreationPaymentTransition(from, to)) {
                                throw new StorageException("Clan creation payment history contains an invalid transition");
                            }
                            if (previousAt != null && at.isBefore(previousAt))
                                throw new StorageException("Clan creation payment event timestamps are not monotonic");
                            expected = to;
                            previousAt = at;
                            eventCount++;
                        }
                    }
                }
                if (eventCount == 0 || expected != operation.state() || !operation.updatedAt().equals(previousAt))
                    throw new StorageException("Clan creation payment state does not match its append-only history");
                String lastDiagnostic;
                try (PreparedStatement latest = connection.prepareStatement("SELECT diagnostic FROM clan_creation_payment_events WHERE operation_id = ? ORDER BY event_id DESC LIMIT 1")) {
                    latest.setString(1, operation.operationId().toString());
                    try (ResultSet last = latest.executeQuery()) { lastDiagnostic = last.next() ? last.getString(1) : null; }
                }
                if (!Objects.equals(lastDiagnostic, operation.diagnostic()))
                    throw new StorageException("Clan creation payment diagnostic does not match its latest event");
            }
        }
        if (scalarInt("SELECT COUNT(*) FROM clan_creation_payment_events e LEFT JOIN clan_creation_payment_operations o ON o.operation_id = e.operation_id WHERE o.operation_id IS NULL") > 0)
            throw new StorageException("Orphan clan creation payment event detected");
    }

    private void validateClanBankWithdrawalRequestHistory() throws SQLException {
        try (PreparedStatement requests = connection.prepareStatement("""
                SELECT request_id, amount, reason, status, created_at, expires_at, updated_at
                FROM clan_bank_withdrawal_requests ORDER BY created_at, request_id
                """); ResultSet rows = requests.executeQuery()) {
            while (rows.next()) {
                String requestId = rows.getString("request_id");
                Instant createdAt;
                Instant expiresAt;
                Instant updatedAt;
                BigDecimal amount;
                try {
                    createdAt = Instant.parse(rows.getString("created_at"));
                    expiresAt = Instant.parse(rows.getString("expires_at"));
                    updatedAt = Instant.parse(rows.getString("updated_at"));
                    amount = new BigDecimal(rows.getString("amount"));
                    UUID.fromString(requestId);
                    if (amount.signum() <= 0 || amount.stripTrailingZeros().scale() > 8
                            || !expiresAt.equals(createdAt.plusSeconds(86_400))
                            || rows.getString("reason") == null || rows.getString("reason").isBlank()
                            || rows.getString("reason").length() > 500) {
                        throw new IllegalArgumentException("Invalid withdrawal request fields");
                    }
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan bank withdrawal request contains invalid data", exception);
                }
                String expected = null;
                Instant previousAt = null;
                int eventCount = 0;
                try (PreparedStatement events = connection.prepareStatement("""
                        SELECT from_status, to_status, actor_id, occurred_at
                        FROM clan_bank_withdrawal_request_events WHERE request_id = ? ORDER BY event_id
                        """)) {
                    events.setString(1, requestId);
                    try (ResultSet eventRows = events.executeQuery()) {
                        while (eventRows.next()) {
                            String from = eventRows.getString("from_status");
                            String to = eventRows.getString("to_status");
                            Instant at;
                            try {
                                UUID.fromString(eventRows.getString("actor_id"));
                                at = Instant.parse(eventRows.getString("occurred_at"));
                            } catch (RuntimeException exception) {
                                throw new StorageException("Clan bank withdrawal request event contains invalid data", exception);
                            }
                            if (eventCount == 0) {
                                if (from != null || !"PENDING".equals(to) || !at.equals(createdAt))
                                    throw new StorageException("Withdrawal request history must begin with PENDING at creation time");
                            } else if (!"PENDING".equals(expected) || !"PENDING".equals(from)
                                    || !Set.of("APPROVED", "DECLINED", "EXPIRED").contains(to)) {
                                throw new StorageException("Withdrawal request history contains an invalid transition");
                            }
                            if (previousAt != null && at.isBefore(previousAt))
                                throw new StorageException("Withdrawal request event timestamps are not monotonic");
                            expected = to;
                            previousAt = at;
                            eventCount++;
                        }
                    }
                }
                if (eventCount == 0 || !rows.getString("status").equals(expected) || !updatedAt.equals(previousAt))
                    throw new StorageException("Withdrawal request state does not match its append-only history");
            }
        }
        if (scalarInt("SELECT COUNT(*) FROM clan_bank_withdrawal_request_events e LEFT JOIN clan_bank_withdrawal_requests r ON r.request_id = e.request_id WHERE r.request_id IS NULL") > 0)
            throw new StorageException("Orphan clan bank withdrawal request event detected");
    }

    private void validateClanStorageContentHistory() throws SQLException {
        Map<StoragePageKey, List<StorageContentEventSnapshot>> eventsByPage = new HashMap<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT clan_id, page_number, actor_id, event_type, revision, content_sha256, content_size, occurred_at
                FROM clan_storage_content_events ORDER BY event_id
                """); ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                try {
                    StoragePageKey key = new StoragePageKey(UUID.fromString(rows.getString("clan_id")), rows.getInt("page_number"));
                    UUID actorId = UUID.fromString(rows.getString("actor_id"));
                    StorageContentEventType type = StorageContentEventType.valueOf(rows.getString("event_type"));
                    long revision = rows.getLong("revision");
                    String hash = rows.getString("content_sha256");
                    long size = rows.getLong("content_size");
                    Instant occurredAt = Instant.parse(rows.getString("occurred_at"));
                    if (key.pageNumber() < 1 || key.pageNumber() > 10 || revision < 0 || size < 0
                            || hash == null || !hash.matches("[0-9a-f]{64}"))
                        throw new IllegalArgumentException("Invalid storage content event values");
                    eventsByPage.computeIfAbsent(key, ignored -> new ArrayList<>())
                            .add(new StorageContentEventSnapshot(actorId, type, revision, hash, size, occurredAt));
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan storage content event contains invalid data", exception);
                }
            }
        }
        Set<StoragePageKey> pageKeys = new HashSet<>();
        try (PreparedStatement pages = connection.prepareStatement("""
                SELECT clan_id, page_number, contents, revision FROM clan_storage_pages ORDER BY clan_id, page_number
                """); ResultSet rows = pages.executeQuery()) {
            while (rows.next()) {
                StoragePageKey key = new StoragePageKey(UUID.fromString(rows.getString("clan_id")), rows.getInt("page_number"));
                byte[] contents = rows.getBytes("contents");
                if (contents == null) contents = new byte[0];
                long revision = rows.getLong("revision");
                List<StorageContentEventSnapshot> events = eventsByPage.getOrDefault(key, List.of());
                if (events.isEmpty()) throw new StorageException("Clan storage page has no content snapshot");
                StorageContentEventSnapshot previous = null;
                for (int index = 0; index < events.size(); index++) {
                    StorageContentEventSnapshot event = events.get(index);
                    if (index == 0) {
                        if (event.type() != StorageContentEventType.SNAPSHOT)
                            throw new StorageException("Clan storage content history must begin with SNAPSHOT");
                    } else {
                        if (event.type() != StorageContentEventType.CONTENT_SAVED
                                || event.revision() != previous.revision() + 1
                                || event.occurredAt().isBefore(previous.occurredAt()))
                            throw new StorageException("Clan storage content revisions are not sequential");
                    }
                    previous = event;
                }
                StorageContentEventSnapshot latest = events.get(events.size() - 1);
                if (latest.revision() != revision || latest.contentSize() != contents.length
                        || !latest.contentSha256().equals(sha256(contents)))
                    throw new StorageException("Clan storage page contents do not match their immutable event history");
                pageKeys.add(key);
            }
        }
        for (StoragePageKey key : eventsByPage.keySet()) {
            if (!exists("SELECT 1 FROM clan_storage_pages WHERE clan_id = ? AND page_number = ?",
                    key.clanId().toString(), Integer.toString(key.pageNumber()))) {
                if (exists("SELECT 1 FROM clans WHERE id = ?", key.clanId().toString()))
                    throw new StorageException("Clan storage content history references a missing page");
            }
        }
        if (pageKeys.size() != scalarInt("SELECT COUNT(*) FROM clan_storage_pages"))
            throw new StorageException("Clan storage page/content history cardinality mismatch");
    }

    private enum StorageContentEventType { SNAPSHOT, CONTENT_SAVED }
    private record StoragePageKey(UUID clanId, int pageNumber) { }
    private record StorageContentEventSnapshot(UUID actorId, StorageContentEventType type, long revision,
            String contentSha256, long contentSize, Instant occurredAt) { }

    private void validateClanStorageHistory() throws SQLException {
        Map<UUID, List<StorageEventSnapshot>> eventsByClan = new HashMap<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT clan_id, actor_id, event_type, page_number, original_price, charged_price,
                    discount_percent, occurred_at
                FROM clan_storage_events ORDER BY event_id
                """); ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                try {
                    UUID clanId = UUID.fromString(rows.getString("clan_id"));
                    UUID actorId = UUID.fromString(rows.getString("actor_id"));
                    StorageEventType type = StorageEventType.valueOf(rows.getString("event_type"));
                    int pageNumber = rows.getInt("page_number");
                    BigDecimal original = new BigDecimal(rows.getString("original_price"));
                    BigDecimal charged = new BigDecimal(rows.getString("charged_price"));
                    int discount = rows.getInt("discount_percent");
                    Instant occurredAt = Instant.parse(rows.getString("occurred_at"));
                    if (pageNumber < 1 || pageNumber > 10 || original.signum() < 0 || charged.signum() < 0
                            || (discount != 0 && discount != 5 && discount != 10))
                        throw new IllegalArgumentException("Invalid storage event values");
                    if (type == StorageEventType.FREE_PAGE_GRANTED) {
                        if (pageNumber != 1 || original.signum() != 0 || charged.signum() != 0 || discount != 0)
                            throw new IllegalArgumentException("Invalid free page event");
                    } else {
                        BigDecimal expectedOriginal = BigDecimal.valueOf(100_000L).multiply(BigDecimal.valueOf(2L).pow(pageNumber - 2));
                        if (pageNumber < 2 || original.compareTo(expectedOriginal) != 0
                                || charged.compareTo(original.multiply(BigDecimal.valueOf(100 - discount)).movePointLeft(2)) != 0)
                            throw new IllegalArgumentException("Invalid paid page price/discount");
                    }
                    eventsByClan.computeIfAbsent(clanId, ignored -> new ArrayList<>())
                            .add(new StorageEventSnapshot(clanId, actorId, type, pageNumber, original, charged, discount, occurredAt));
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan storage event contains invalid data", exception);
                }
            }
        }
        Set<UUID> accountClanIds = new HashSet<>();
        try (PreparedStatement accounts = connection.prepareStatement(
                "SELECT clan_id, page_count FROM clan_storage_accounts ORDER BY clan_id");
             ResultSet rows = accounts.executeQuery()) {
            while (rows.next()) {
                UUID clanId = UUID.fromString(rows.getString("clan_id"));
                int pageCount = rows.getInt("page_count");
                if (pageCount < 1 || pageCount > 10) throw new StorageException("Invalid clan storage page count");
                accountClanIds.add(clanId);
                if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()))
                    throw new StorageException("Orphan clan storage account detected");
                List<StorageEventSnapshot> events = eventsByClan.getOrDefault(clanId, List.of());
                if (events.size() != pageCount || events.isEmpty()
                        || scalarInt("SELECT COUNT(*) FROM clan_storage_pages WHERE clan_id = '" + clanId + "'") != pageCount)
                    throw new StorageException("Clan storage page count does not match its page/event history");
                for (int index = 0; index < events.size(); index++) {
                    StorageEventSnapshot event = events.get(index);
                    int expectedPage = index + 1;
                    if (event.pageNumber() != expectedPage
                            || (index == 0 && event.type() != StorageEventType.FREE_PAGE_GRANTED)
                            || (index > 0 && event.type() != StorageEventType.PAGE_PURCHASED))
                        throw new StorageException("Clan storage page purchase history is not sequential");
                    if (index > 0 && event.occurredAt().isBefore(events.get(index - 1).occurredAt()))
                        throw new StorageException("Clan storage event timestamps are not monotonic");
                    ClanStoragePage page = readClanStoragePage(clanId, expectedPage).orElse(null);
                    if (page == null || !page.createdBy().equals(event.actorId()) || !page.createdAt().equals(event.occurredAt())
                            || page.originalPrice().compareTo(event.originalPrice()) != 0
                            || page.chargedPrice().compareTo(event.chargedPrice()) != 0
                            || page.discountPercent() != event.discountPercent())
                        throw new StorageException("Clan storage page metadata does not match its event");
                    if (index > 0) {
                        String idempotencyKey = "storage-page-purchase:" + clanId + ":" + expectedPage;
                        String reason = "STORAGE_PAGE_PURCHASE page=" + expectedPage;
                        if (!exists("SELECT 1 FROM clan_bank_transactions WHERE idempotency_key = ? AND clan_id = ? AND actor_id = ? AND transaction_type = 'ADJUSTMENT' AND amount = ? AND reason = ? AND approved_by IS NULL",
                                idempotencyKey, clanId.toString(), event.actorId().toString(),
                                event.chargedPrice().negate().toPlainString(), reason))
                            throw new StorageException("Clan storage page purchase has no matching bank ledger entry");
                    }
                }
                if (events.get(events.size() - 1).pageNumber() != pageCount)
                    throw new StorageException("Clan storage account page count does not match its last event");
            }
        }
        if (scalarInt("SELECT COUNT(*) FROM clan_storage_pages p LEFT JOIN clan_storage_accounts a ON a.clan_id = p.clan_id WHERE a.clan_id IS NULL") > 0)
            throw new StorageException("Orphan clan storage page detected");
        try (PreparedStatement clans = connection.prepareStatement("SELECT id FROM clans"); ResultSet rows = clans.executeQuery()) {
            while (rows.next()) {
                UUID clanId = UUID.fromString(rows.getString(1));
                if (!accountClanIds.contains(clanId)) throw new StorageException("Clan has no storage account/free page");
            }
        }
        for (UUID clanId : eventsByClan.keySet()) {
            if (exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString()) && !accountClanIds.contains(clanId))
                throw new StorageException("Clan storage events exist without a storage account");
        }
    }

    private enum StorageEventType { FREE_PAGE_GRANTED, PAGE_PURCHASED }
    private record StorageEventSnapshot(UUID clanId, UUID actorId, StorageEventType type, int pageNumber,
            BigDecimal originalPrice, BigDecimal chargedPrice, int discountPercent, Instant occurredAt) { }

    /** Pre-v24 snapshots have a single home point per clan and no purchase events. */
    private void validateLegacyClanHomeHistory() throws SQLException {
        Map<UUID, HomeEventSnapshot> latest = new HashMap<>();
        Map<UUID, Instant> lastTimes = new HashMap<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT clan_id, actor_id, event_type, home_name, world_id, x, y, z, yaw, pitch, occurred_at
                FROM clan_home_events ORDER BY event_id
                """); ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                UUID clanId; UUID actorId; UUID worldId; ClanHomeEventType type; Instant occurredAt;
                try {
                    clanId = UUID.fromString(rows.getString("clan_id"));
                    actorId = UUID.fromString(rows.getString("actor_id"));
                    worldId = UUID.fromString(rows.getString("world_id"));
                    type = ClanHomeEventType.valueOf(rows.getString("event_type"));
                    occurredAt = Instant.parse(rows.getString("occurred_at"));
                    String name = rows.getString("home_name");
                    double x = rows.getDouble("x"), y = rows.getDouble("y"), z = rows.getDouble("z");
                    float yaw = rows.getFloat("yaw"), pitch = rows.getFloat("pitch");
                    if (!validHomeName(name) || !finite(x, y, z, yaw, pitch))
                        throw new IllegalArgumentException("Invalid home event payload");
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan home event contains invalid data", exception);
                }
                Instant previousTime = lastTimes.get(clanId);
                if (previousTime != null && occurredAt.isBefore(previousTime))
                    throw new StorageException("Clan home event timestamps are not monotonic");
                latest.put(clanId, new HomeEventSnapshot(clanId, 1, actorId, type,
                        rows.getString("home_name"), worldId,
                        rows.getDouble("x"), rows.getDouble("y"), rows.getDouble("z"),
                        rows.getFloat("yaw"), rows.getFloat("pitch"), occurredAt));
                lastTimes.put(clanId, occurredAt);
            }
        }
        Set<UUID> pointClanIds = new HashSet<>();
        try (PreparedStatement points = connection.prepareStatement("""
                SELECT clan_id, name, world_id, x, y, z, yaw, pitch, created_by, created_at, updated_by, updated_at
                FROM clan_home_points
                """); ResultSet rows = points.executeQuery()) {
            while (rows.next()) {
                UUID clanId;
                String name;
                UUID worldId;
                double x, y, z;
                float yaw, pitch;
                UUID updatedBy;
                Instant updatedAt;
                try {
                    clanId = UUID.fromString(rows.getString("clan_id"));
                    name = rows.getString("name");
                    worldId = UUID.fromString(rows.getString("world_id"));
                    x = rows.getDouble("x"); y = rows.getDouble("y"); z = rows.getDouble("z");
                    yaw = rows.getFloat("yaw"); pitch = rows.getFloat("pitch");
                    updatedBy = UUID.fromString(rows.getString("updated_by"));
                    updatedAt = Instant.parse(rows.getString("updated_at"));
                    if (!validHomeName(name) || !finite(x, y, z, yaw, pitch))
                        throw new IllegalArgumentException("Invalid home point");
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan home point contains invalid data", exception);
                }
                pointClanIds.add(clanId);
                HomeEventSnapshot last = latest.get(clanId);
                if (last == null || last.type() == ClanHomeEventType.DELETE || last.type() == ClanHomeEventType.PURCHASE
                        || !name.equals(last.name()) || !worldId.equals(last.worldId())
                        || Double.compare(x, last.x()) != 0 || Double.compare(y, last.y()) != 0
                        || Double.compare(z, last.z()) != 0 || Float.compare(yaw, last.yaw()) != 0
                        || Float.compare(pitch, last.pitch()) != 0 || !updatedBy.equals(last.actorId())
                        || !updatedAt.equals(last.occurredAt()))
                    throw new StorageException("Clan home point does not match its append-only event history");
            }
        }
        for (Map.Entry<UUID, HomeEventSnapshot> entry : latest.entrySet()) {
            UUID clanId = entry.getKey();
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString())) continue;
            if (entry.getValue().type() == ClanHomeEventType.DELETE) {
                if (pointClanIds.contains(clanId))
                    throw new StorageException("Deleted clan home point still exists");
            } else if (!pointClanIds.contains(clanId)) {
                throw new StorageException("Clan home event history has no current point");
            }
        }
    }

    private void validateClanHomeHistory() throws SQLException {
        // History is validated per (clan, slot); slot 1 is the free point, slot 2 must be purchased.
        Map<String, HomeEventSnapshot> latest = new HashMap<>();
        Map<String, HomeEventSnapshot> first = new HashMap<>();
        Map<String, Instant> lastTimes = new HashMap<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT clan_id, slot, actor_id, event_type, home_name, world_id, x, y, z, yaw, pitch, occurred_at
                FROM clan_home_events ORDER BY event_id
                """); ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                UUID clanId; UUID actorId; UUID worldId; ClanHomeEventType type; Instant occurredAt;
                int slot; HomeEventSnapshot event;
                try {
                    clanId = UUID.fromString(rows.getString("clan_id"));
                    slot = rows.getInt("slot");
                    if (slot < 1 || slot > MAX_HOME_POINTS)
                        throw new IllegalArgumentException("Invalid home slot");
                    actorId = UUID.fromString(rows.getString("actor_id"));
                    worldId = UUID.fromString(rows.getString("world_id"));
                    type = ClanHomeEventType.valueOf(rows.getString("event_type"));
                    occurredAt = Instant.parse(rows.getString("occurred_at"));
                    String name = rows.getString("home_name");
                    double x = rows.getDouble("x"), y = rows.getDouble("y"), z = rows.getDouble("z");
                    float yaw = rows.getFloat("yaw"), pitch = rows.getFloat("pitch");
                    if (!validHomeName(name) || !finite(x, y, z, yaw, pitch))
                        throw new IllegalArgumentException("Invalid home event payload");
                    event = new HomeEventSnapshot(clanId, slot, actorId, type, name, worldId,
                            x, y, z, yaw, pitch, occurredAt);
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan home event contains invalid data", exception);
                }
                String key = clanId + ":" + slot;
                HomeEventSnapshot previous = latest.get(key);
                Instant previousTime = lastTimes.get(key);
                if (previousTime != null && occurredAt.isBefore(previousTime))
                    throw new StorageException("Clan home event timestamps are not monotonic");
                if (previous == null) {
                    if (type != ClanHomeEventType.SET && type != ClanHomeEventType.PURCHASE)
                        throw new StorageException("Clan home history must begin with SET or PURCHASE");
                    first.put(key, event);
                } else if (type == ClanHomeEventType.PURCHASE) {
                    if (previous.type() != ClanHomeEventType.PURCHASE
                            && previous.type() != ClanHomeEventType.DELETE)
                        throw new StorageException("Clan home PURCHASE event is out of order");
                } else if (previous.type() == ClanHomeEventType.DELETE && type == ClanHomeEventType.SET) {
                    first.put(key, event);
                } else if (type == ClanHomeEventType.RENAME || type == ClanHomeEventType.DELETE) {
                    if (previous.type() == ClanHomeEventType.DELETE
                            || previous.type() == ClanHomeEventType.PURCHASE
                            || !sameHomeLocation(previous, event))
                        throw new StorageException("Clan home rename/delete event has no matching active point");
                } else if (previous.type() != ClanHomeEventType.DELETE
                        && previous.type() != ClanHomeEventType.PURCHASE
                        && !previous.name().equals(event.name())) {
                    throw new StorageException("Clan home SET event unexpectedly changes the name");
                }
                latest.put(key, event);
                lastTimes.put(key, occurredAt);
            }
        }
        Set<String> pointKeys = new HashSet<>();
        try (PreparedStatement points = connection.prepareStatement("""
                SELECT clan_id, slot, name, world_id, x, y, z, yaw, pitch, created_by, created_at,
                       updated_by, updated_at
                FROM clan_home_points ORDER BY clan_id, slot
                """); ResultSet rows = points.executeQuery()) {
            while (rows.next()) {
                UUID clanId;
                ClanHomePoint point;
                try {
                    clanId = UUID.fromString(rows.getString("clan_id"));
                    point = readClanHomePointRow(rows);
                    if (!validHomeName(point.name()) || !finite(point.x(), point.y(), point.z(), point.yaw(), point.pitch()))
                        throw new IllegalArgumentException("Invalid home point");
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan home point contains invalid data", exception);
                }
                String key = clanId + ":" + point.slot();
                pointKeys.add(key);
                HomeEventSnapshot last = latest.get(key);
                HomeEventSnapshot initial = first.get(key);
                if (last == null || last.type() == ClanHomeEventType.DELETE
                        || last.type() == ClanHomeEventType.PURCHASE || initial == null
                        || !point.name().equals(last.name()) || !point.worldId().equals(last.worldId())
                        || Double.compare(point.x(), last.x()) != 0 || Double.compare(point.y(), last.y()) != 0
                        || Double.compare(point.z(), last.z()) != 0 || Float.compare(point.yaw(), last.yaw()) != 0
                        || Float.compare(point.pitch(), last.pitch()) != 0 || !point.updatedBy().equals(last.actorId())
                        || !point.updatedAt().equals(last.occurredAt()) || !point.createdBy().equals(initial.actorId())
                        || !point.createdAt().equals(initial.occurredAt()))
                    throw new StorageException("Clan home point does not match its append-only event history");
            }
        }
        for (Map.Entry<String, HomeEventSnapshot> entry : latest.entrySet()) {
            String key = entry.getKey();
            UUID clanId = entry.getValue().clanId();
            if (!exists("SELECT 1 FROM clans WHERE id = ?", clanId.toString())) continue;
            boolean ended = entry.getValue().type() == ClanHomeEventType.DELETE
                    || entry.getValue().type() == ClanHomeEventType.PURCHASE;
            if (ended) {
                if (pointKeys.contains(key)) throw new StorageException("Deleted clan home point still exists");
            } else if (!pointKeys.contains(key)) {
                throw new StorageException("Clan home event history has no current point");
            }
        }
        for (String key : pointKeys) {
            if (!latest.containsKey(key)) throw new StorageException("Clan home point has no event history");
        }
        // A slot-2 point may only exist for a clan that actually purchased the slot.
        try (PreparedStatement points = connection.prepareStatement("""
                SELECT p.clan_id, p.slot FROM clan_home_points p
                LEFT JOIN clan_home_slots s ON s.clan_id = p.clan_id AND s.slot = p.slot
                WHERE p.slot > 1 AND s.clan_id IS NULL
                """); ResultSet rows = points.executeQuery()) {
            if (rows.next()) throw new StorageException("Clan home point exists in an unpurchased slot");
        }
    }

    private static boolean sameHomeLocation(HomeEventSnapshot left, HomeEventSnapshot right) {
        return left.worldId().equals(right.worldId()) && Double.compare(left.x(), right.x()) == 0
                && Double.compare(left.y(), right.y()) == 0 && Double.compare(left.z(), right.z()) == 0
                && Float.compare(left.yaw(), right.yaw()) == 0 && Float.compare(left.pitch(), right.pitch()) == 0;
    }

    private record HomeEventSnapshot(UUID clanId, int slot, UUID actorId, ClanHomeEventType type, String name,
            UUID worldId, double x, double y, double z, float yaw, float pitch, Instant occurredAt) { }

    private void validateCombatLogHistory() throws SQLException {
        try (PreparedStatement sessions = connection.prepareStatement("""
                SELECT player_id, opponent_id, last_hit_at, expires_at, status, updated_at
                FROM clan_combat_log_sessions ORDER BY player_id
                """); ResultSet rows = sessions.executeQuery()) {
            while (rows.next()) {
                UUID playerId;
                UUID sessionOpponent;
                Instant sessionLastHit;
                Instant sessionExpires;
                Instant sessionUpdated;
                CombatLogSessionStatus sessionStatus;
                try {
                    playerId = UUID.fromString(rows.getString("player_id"));
                    sessionOpponent = UUID.fromString(rows.getString("opponent_id"));
                    sessionLastHit = Instant.parse(rows.getString("last_hit_at"));
                    sessionExpires = Instant.parse(rows.getString("expires_at"));
                    sessionUpdated = Instant.parse(rows.getString("updated_at"));
                    sessionStatus = CombatLogSessionStatus.valueOf(rows.getString("status"));
                    if (!sessionExpires.equals(sessionLastHit.plusSeconds(30)) || sessionUpdated.isBefore(sessionLastHit))
                        throw new IllegalArgumentException("Invalid combat log session timestamps");
                } catch (RuntimeException exception) {
                    throw new StorageException("Combat log session contains invalid data", exception);
                }
                CombatLogSessionStatus expectedStatus = null;
                Instant lastEventAt = null;
                Instant lastTagAt = null;
                Instant lastTagExpires = null;
                UUID lastTagOpponent = null;
                int eventCount = 0;
                try (PreparedStatement events = connection.prepareStatement("""
                        SELECT opponent_id, event_type, occurred_at, expires_at, details
                        FROM clan_combat_log_events WHERE player_id = ? ORDER BY event_id
                        """)) {
                    events.setString(1, playerId.toString());
                    try (ResultSet eventRows = events.executeQuery()) {
                        while (eventRows.next()) {
                            UUID opponent;
                            CombatLogEventType type;
                            Instant at;
                            Instant expires;
                            try {
                                opponent = UUID.fromString(eventRows.getString("opponent_id"));
                                type = CombatLogEventType.valueOf(eventRows.getString("event_type"));
                                at = Instant.parse(eventRows.getString("occurred_at"));
                                expires = Instant.parse(eventRows.getString("expires_at"));
                                if (eventRows.getString("details") == null || eventRows.getString("details").isBlank())
                                    throw new IllegalArgumentException("Missing event details");
                            } catch (RuntimeException exception) {
                                throw new StorageException("Combat log event contains invalid data", exception);
                            }
                            if (lastEventAt != null && at.isBefore(lastEventAt))
                                throw new StorageException("Combat log event timestamps are not monotonic");
                            if (type == CombatLogEventType.TAGGED) {
                                if (!expires.equals(at.plusSeconds(30)))
                                    throw new StorageException("Combat log tag does not have the configured 30-second duration");
                                expectedStatus = CombatLogSessionStatus.ACTIVE;
                                lastTagAt = at; lastTagExpires = expires; lastTagOpponent = opponent;
                            } else {
                                if (expectedStatus != CombatLogSessionStatus.ACTIVE || lastTagExpires == null
                                        || !expires.equals(lastTagExpires) || !opponent.equals(lastTagOpponent))
                                    throw new StorageException("Combat log terminal event does not follow an active tag");
                                expectedStatus = switch (type) {
                                    case EXPIRED -> {
                                        if (at.isBefore(lastTagExpires)) throw new StorageException("Combat log expired before its deadline");
                                        yield CombatLogSessionStatus.EXPIRED;
                                    }
                                    case LOGOUT_VIOLATION -> {
                                        if (!at.isBefore(lastTagExpires)) throw new StorageException("Combat log logout violation is outside combat time");
                                        yield CombatLogSessionStatus.LOGOUT_VIOLATION;
                                    }
                                    case INTERRUPTED_REVIEW -> CombatLogSessionStatus.INTERRUPTED_REVIEW;
                                    case CLEARED -> CombatLogSessionStatus.CLEARED;
                                    case TAGGED -> throw new IllegalStateException("unreachable");
                                };
                            }
                            lastEventAt = at;
                            eventCount++;
                        }
                    }
                }
                if (eventCount == 0 || expectedStatus != sessionStatus || !sessionUpdated.equals(lastEventAt)
                        || !sessionLastHit.equals(lastTagAt) || !sessionExpires.equals(lastTagExpires)
                        || !sessionOpponent.equals(lastTagOpponent))
                    throw new StorageException("Combat log session does not match its append-only event history");
            }
        }
        if (scalarInt("SELECT COUNT(*) FROM clan_combat_log_events e LEFT JOIN clan_combat_log_sessions s ON s.player_id = e.player_id WHERE s.player_id IS NULL") > 0)
            throw new StorageException("Orphan combat log event detected");
    }

    private void validateClanBankOperationHistory() throws SQLException {
        try (PreparedStatement operations = connection.prepareStatement("""
                SELECT operation_id, state, operation_type, amount, clan_id, request_id, created_at, updated_at
                FROM clan_bank_operations ORDER BY created_at, operation_id
                """); ResultSet rows = operations.executeQuery()) {
            while (rows.next()) {
                UUID operationId;
                ClanBankOperation operation;
                try {
                    operationId = UUID.fromString(rows.getString("operation_id"));
                    operation = readClanBankOperation(operationId).orElseThrow();
                    if (operation.amount().signum() <= 0 || operation.amount().stripTrailingZeros().scale() > 8)
                        throw new IllegalArgumentException("Invalid operation amount");
                } catch (RuntimeException exception) {
                    throw new StorageException("Clan bank operation contains invalid data", exception);
                }
                ClanBankOperationState expected = null;
                Instant previousAt = null;
                int eventCount = 0;
                try (PreparedStatement events = connection.prepareStatement("""
                        SELECT from_state, to_state, evidence, occurred_at
                        FROM clan_bank_operation_events WHERE operation_id = ? ORDER BY event_id
                        """)) {
                    events.setString(1, operationId.toString());
                    try (ResultSet eventRows = events.executeQuery()) {
                        while (eventRows.next()) {
                            ClanBankOperationState from;
                            ClanBankOperationState to;
                            Instant at;
                            try {
                                from = eventRows.getString("from_state") == null ? null
                                        : ClanBankOperationState.valueOf(eventRows.getString("from_state"));
                                to = ClanBankOperationState.valueOf(eventRows.getString("to_state"));
                                at = Instant.parse(eventRows.getString("occurred_at"));
                                if (eventRows.getString("evidence") == null || eventRows.getString("evidence").isBlank())
                                    throw new IllegalArgumentException("Missing operation event evidence");
                            } catch (RuntimeException exception) {
                                throw new StorageException("Clan bank operation event contains invalid data", exception);
                            }
                            if (eventCount == 0) {
                                if (from != null || to != ClanBankOperationState.PREPARED || !at.equals(operation.createdAt()))
                                    throw new StorageException("Clan bank operation history must begin with PREPARED at creation time");
                            } else if (from != expected || !validClanBankOperationTransition(from, to)) {
                                throw new StorageException("Clan bank operation history contains an invalid transition");
                            }
                            if (previousAt != null && at.isBefore(previousAt))
                                throw new StorageException("Clan bank operation event timestamps are not monotonic");
                            expected = to;
                            previousAt = at;
                            eventCount++;
                        }
                    }
                }
                if (eventCount == 0 || expected != operation.state() || !operation.updatedAt().equals(previousAt))
                    throw new StorageException("Clan bank operation state does not match its append-only history");
                boolean shouldHaveReservation = !operation.operationType().equals("DEPOSIT");
                try (PreparedStatement reservation = connection.prepareStatement("""
                        SELECT clan_id, amount, state FROM clan_bank_reservations WHERE operation_id = ?
                        """)) {
                    reservation.setString(1, operationId.toString());
                    try (ResultSet row = reservation.executeQuery()) {
                        if (shouldHaveReservation) {
                            if (!row.next()) throw new StorageException("Bank withdrawal operation has no reservation");
                            String expectedReservation = switch (operation.state()) {
                                case PREPARED, CALLING, EXTERNAL_CONFIRMED, UNKNOWN -> "RESERVED";
                                case COMMITTED -> "CONSUMED";
                                case FAILED_NO_EFFECT -> "RELEASED";
                            };
                            if (!row.getString("clan_id").equals(operation.clanId().toString())
                                    || new BigDecimal(row.getString("amount")).compareTo(operation.amount()) != 0
                                    || !row.getString("state").equals(expectedReservation))
                                throw new StorageException("Clan bank reservation does not match its operation");
                        } else if (row.next()) {
                            throw new StorageException("Clan bank deposit unexpectedly has a reservation");
                        }
                    }
                }
                if (operation.requestId() != null) {
                    try (PreparedStatement request = connection.prepareStatement("""
                            SELECT payment_operation_id, status FROM clan_bank_withdrawal_requests WHERE request_id = ?
                            """)) {
                        request.setString(1, operation.requestId().toString());
                        try (ResultSet row = request.executeQuery()) {
                            if (!row.next() || !"APPROVED".equals(row.getString("status"))
                                    || operation.state() != ClanBankOperationState.FAILED_NO_EFFECT
                                        && !operation.operationId().toString().equals(row.getString("payment_operation_id")))
                                throw new StorageException("Bank withdrawal operation is not linked to its approved request");
                        }
                    }
                }
            }
        }
        if (scalarInt("SELECT COUNT(*) FROM clan_bank_operation_events e LEFT JOIN clan_bank_operations o ON o.operation_id = e.operation_id WHERE o.operation_id IS NULL") > 0)
            throw new StorageException("Orphan clan bank operation event detected");
        if (scalarInt("""
                SELECT COUNT(*) FROM clan_bank_withdrawal_requests r
                LEFT JOIN clan_bank_operations o ON o.operation_id = r.payment_operation_id
                WHERE r.payment_operation_id IS NOT NULL
                  AND (o.operation_id IS NULL OR o.request_id <> r.request_id)
                """) > 0)
            throw new StorageException("Clan bank withdrawal request points to an invalid payment operation");
        if (scalarInt("SELECT COUNT(*) FROM clan_bank_reservations r LEFT JOIN clan_bank_operations o ON o.operation_id = r.operation_id WHERE o.operation_id IS NULL") > 0)
            throw new StorageException("Orphan clan bank reservation detected");
        if (scalarInt("""
                SELECT COUNT(*) FROM clan_bank_reservations r
                LEFT JOIN clan_bank_accounts a ON a.clan_id = r.clan_id
                WHERE r.state = 'RESERVED' AND a.clan_id IS NULL
                """) > 0)
            throw new StorageException("Reserved clan bank funds have no account row");
        try (PreparedStatement accounts = connection.prepareStatement(
                "SELECT clan_id, balance, reserved_balance FROM clan_bank_accounts ORDER BY clan_id");
             ResultSet rows = accounts.executeQuery()) {
            while (rows.next()) {
                UUID clanId = UUID.fromString(rows.getString("clan_id"));
                BigDecimal balance = new BigDecimal(rows.getString("balance"));
                BigDecimal reserved = new BigDecimal(rows.getString("reserved_balance"));
                BigDecimal expectedReserved = BigDecimal.ZERO;
                try (PreparedStatement reservations = connection.prepareStatement("""
                        SELECT amount FROM clan_bank_reservations WHERE clan_id = ? AND state = 'RESERVED'
                        """)) {
                    reservations.setString(1, clanId.toString());
                    try (ResultSet reservationRows = reservations.executeQuery()) {
                        while (reservationRows.next()) expectedReserved = expectedReserved.add(new BigDecimal(reservationRows.getString(1)));
                    }
                }
                if (balance.signum() < 0 || reserved.signum() < 0 || reserved.compareTo(balance) > 0
                        || reserved.compareTo(expectedReserved) != 0)
                    throw new StorageException("Clan bank account reservation aggregate is inconsistent");
            }
        } catch (NumberFormatException exception) {
            throw new StorageException("Clan bank account contains invalid decimal data", exception);
        }
    }

    private void validateClanRequestHistory() throws SQLException {
        try (Statement settings = connection.createStatement();
             ResultSet invalid = settings.executeQuery("""
                     SELECT COUNT(*) FROM clans c LEFT JOIN clan_settings s ON s.clan_id = c.id
                     WHERE s.clan_id IS NULL
                     """)) {
            if (invalid.next() && invalid.getLong(1) != 0) {
                throw new StorageException("One or more clans are missing persistent settings");
            }
        }

        List<ClanRequest> storedRequests = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT * FROM clan_requests ORDER BY request_id")) {
            while (rows.next()) {
                try {
                    storedRequests.add(readClanRequest(rows));
                } catch (RuntimeException exception) {
                    throw new StorageException("Corrupt clan request record", exception);
                }
            }
        }

        for (ClanRequest request : storedRequests) {
            List<RequestEvent> events = new ArrayList<>();
            try (PreparedStatement eventQuery = connection.prepareStatement("""
                    SELECT request_type, from_status, to_status, actor_id
                    FROM clan_request_events WHERE request_id = ? ORDER BY event_id
                    """)) {
                eventQuery.setString(1, request.id().toString());
                try (ResultSet eventRows = eventQuery.executeQuery()) {
                    while (eventRows.next()) {
                        try {
                            String from = eventRows.getString("from_status");
                            String actor = eventRows.getString("actor_id");
                            events.add(new RequestEvent(
                                    ClanRequest.Type.valueOf(eventRows.getString("request_type")),
                                    from == null ? null : ClanRequest.Status.valueOf(from),
                                    ClanRequest.Status.valueOf(eventRows.getString("to_status")),
                                    actor == null ? null : UUID.fromString(actor)));
                        } catch (RuntimeException exception) {
                            throw new StorageException(
                                    "Corrupt clan request event for " + request.id(), exception);
                        }
                    }
                }
            }
            if (events.isEmpty() || events.size() > 2) {
                throw new StorageException(
                        "Clan request has missing or excessive history: " + request.id());
            }
            RequestEvent first = events.get(0);
            if (first.type() != request.type() || first.from() != null
                    || first.to() != ClanRequest.Status.PENDING
                    || !request.actorId().equals(first.actorId())) {
                throw new StorageException(
                        "Clan request has an invalid creation event: " + request.id());
            }
            if (events.size() == 1) {
                if (request.status() != ClanRequest.Status.PENDING) {
                    throw new StorageException(
                            "Clan request terminal state has no terminal event: " + request.id());
                }
            } else {
                RequestEvent terminal = events.get(1);
                if (terminal.type() != request.type() || terminal.from() != ClanRequest.Status.PENDING
                        || terminal.to() == ClanRequest.Status.PENDING
                        || terminal.to() != request.status()) {
                    throw new StorageException(
                            "Clan request event chain is inconsistent: " + request.id());
                }
                if ((terminal.to() == ClanRequest.Status.EXPIRED) != (terminal.actorId() == null)) {
                    throw new StorageException(
                            "Clan request expiry actor provenance is inconsistent: " + request.id());
                }
            }
        }
    }

    private record RequestEvent(ClanRequest.Type type, ClanRequest.Status from,
            ClanRequest.Status to, UUID actorId) { }

    private void validateIndexSql(String name, String expectedDdl) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT sql FROM sqlite_master WHERE type = 'index' AND name = ?")) {
            statement.setString(1, name);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next() || !normalizeSql(result.getString(1))
                        .equals(normalizeSql(expectedDdl))) {
                    throw new StorageException("SQLite index has an unexpected definition: " + name);
                }
            }
        }
    }

    private void validatePurchaseEventTriggers() throws SQLException {
        validateTriggerSql("capacity_purchase_events_no_update", NO_UPDATE_TRIGGER_DDL);
        validateTriggerSql("capacity_purchase_events_no_delete", NO_DELETE_TRIGGER_DDL);
    }

    private void requireTriggerFragments(String name, String... fragments) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT sql FROM sqlite_master WHERE type = 'trigger' AND name = ?")) {
            statement.setString(1, name);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) throw new StorageException("Required SQLite trigger is missing: " + name);
                String sql = normalizeSql(result.getString(1)).toLowerCase(Locale.ROOT);
                for (String fragment : fragments) {
                    if (!sql.contains(normalizeSql(fragment).toLowerCase(Locale.ROOT)))
                        throw new StorageException("SQLite trigger has an invalid definition: " + name);
                }
            }
        }
    }

    private void validateTriggerSql(String name, String expectedDdl) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT sql FROM sqlite_master WHERE type = 'trigger' AND name = ?")) {
            statement.setString(1, name);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    throw new StorageException("Required SQLite trigger is missing: " + name);
                }
                if (!normalizeSql(result.getString(1)).equals(normalizeSql(expectedDdl))) {
                    throw new StorageException(
                            "SQLite trigger has an unexpected definition: " + name);
                }
            }
        }
    }

    private static String normalizeSql(String sql) {
        StringBuilder normalized = new StringBuilder(sql.length());
        char quote = 0;
        boolean pendingWhitespace = false;
        for (int i = 0; i < sql.length(); i++) {
            char current = sql.charAt(i);
            if (quote == 0) {
                if (current == '-' && i + 1 < sql.length() && sql.charAt(i + 1) == '-'
                        || current == '/' && i + 1 < sql.length() && sql.charAt(i + 1) == '*') {
                    throw new StorageException("Comments are not allowed in required trigger DDL");
                }
                if (isSqlWhitespace(current)) {
                    pendingWhitespace = normalized.length() > 0;
                    continue;
                }
                if (pendingWhitespace) {
                    normalized.append(' ');
                    pendingWhitespace = false;
                }
                if (current == '\'' || current == '"' || current == '`' || current == '[') {
                    quote = current == '[' ? ']' : current;
                }
                normalized.append(current);
                continue;
            }

            normalized.append(current);
            if (current == quote) {
                if (i + 1 < sql.length() && sql.charAt(i + 1) == quote) {
                    normalized.append(sql.charAt(++i));
                } else {
                    quote = 0;
                }
            }
        }
        if (quote != 0) {
            throw new StorageException("Unterminated quoted token in required trigger DDL");
        }

        int end = normalized.length();
        while (end > 0 && normalized.charAt(end - 1) == ' ') {
            end--;
        }
        if (end > 0 && normalized.charAt(end - 1) == ';') {
            end--;
            while (end > 0 && normalized.charAt(end - 1) == ' ') {
                end--;
            }
        }
        return normalized.substring(0, end);
    }

    private static boolean isSqlWhitespace(char value) {
        return value == ' ' || value == '\t' || value == '\n'
                || value == '\r' || value == '\f';
    }

    private void validateMigrationHistory(int version) throws SQLException {
        List<Integer> versions = new ArrayList<>();
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(
                     "SELECT version FROM schema_migrations ORDER BY version")) {
            while (result.next()) {
                versions.add(result.getInt(1));
            }
        }
        List<Integer> expected = java.util.stream.IntStream.rangeClosed(1, version)
                .boxed()
                .toList();
        if (!versions.equals(expected)) {
            throw new StorageException(
                    "SQLite migration history does not match user_version " + version);
        }
    }

    private void validateForeignKeys() throws SQLException {
        if (pragmaInt("PRAGMA foreign_keys") != 1) {
            throw new StorageException("SQLite foreign key enforcement is disabled");
        }
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery("PRAGMA foreign_key_check")) {
            if (result.next()) {
                throw new StorageException("SQLite database contains a foreign key violation");
            }
        }
    }

    private boolean hasUserTables() throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT 1 FROM sqlite_master
                WHERE type = 'table' AND name NOT LIKE 'sqlite_%'
                LIMIT 1
                """);
             ResultSet result = statement.executeQuery()) {
            return result.next();
        }
    }

    private boolean isTombstonedClan(UUID clanId) throws SQLException {
        try (PreparedStatement query = connection.prepareStatement(
                "SELECT tag_key FROM clans WHERE id = ?")) {
            query.setString(1, clanId.toString());
            try (ResultSet row = query.executeQuery()) {
                return row.next() && row.getString(1) != null && row.getString(1).startsWith("deleted:");
            }
        }
    }

    private Optional<StoredClan> readClan(UUID id) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT id, name, tag, created_at, capacity, total_xp, tagline, revision
                FROM clans WHERE id = ?
                """)) {
            statement.setString(1, id.toString());
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    return Optional.empty();
                }
                UUID clanId = UUID.fromString(result.getString("id"));
                Map<UUID, ClanMember> members = readMembers(clanId);
                String tagline = result.getString("tagline");
                Clan clan = new Clan(
                        clanId,
                        result.getString("name"),
                        result.getString("tag"),
                        Instant.parse(result.getString("created_at")),
                        result.getInt("capacity"),
                        members,
                        result.getLong("total_xp"),
                        tagline);
                return Optional.of(new StoredClan(clan, result.getLong("revision")));
            }
        }
    }

    private Map<UUID, ClanMember> readMembers(UUID clanId) throws SQLException {
        Map<UUID, ClanMember> members = new HashMap<>();
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT player_id, role, membership_started_at, appointed_by_deputy_id
                FROM clan_members WHERE clan_id = ?
                """)) {
            statement.setString(1, clanId.toString());
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    UUID playerId = UUID.fromString(result.getString("player_id"));
                    String appointer = result.getString("appointed_by_deputy_id");
                    members.put(playerId, new ClanMember(
                            playerId,
                            ClanRole.valueOf(result.getString("role")),
                            Instant.parse(result.getString("membership_started_at")),
                            appointer == null ? null : UUID.fromString(appointer)));
                }
            }
        }
        return members;
    }

    private void insertMembers(Clan clan) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO clan_members (
                    clan_id, player_id, role, membership_started_at, appointed_by_deputy_id
                ) VALUES (?, ?, ?, ?, ?)
                """)) {
            for (ClanMember member : clan.members().values()) {
                statement.setString(1, clan.id().toString());
                statement.setString(2, member.playerId().toString());
                statement.setString(3, member.role().name());
                statement.setString(4, member.membershipStartedAt().toString());
                statement.setString(5, member.appointedByDeputyId() == null
                        ? null : member.appointedByDeputyId().toString());
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }

    private void insertClan(Clan clan) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO clans (
                    id, name, tag, tag_key, created_at, capacity, total_xp, tagline, revision
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                """)) {
            statement.setString(1, clan.id().toString());
            statement.setString(2, clan.name());
            statement.setString(3, clan.tag());
            statement.setString(4, normalizeTag(clan.tag()));
            statement.setString(5, clan.createdAt().toString());
            statement.setInt(6, clan.capacity());
            statement.setLong(7, clan.totalXp());
            statement.setString(8, clan.tagline());
            statement.executeUpdate();
        }
        insertMembers(clan);
        try (PreparedStatement settings = connection.prepareStatement(
                "INSERT INTO clan_settings(clan_id, public_applications_open) VALUES (?, 1)")) {
            settings.setString(1, clan.id().toString());
            settings.executeUpdate();
        }
        try (PreparedStatement bank = connection.prepareStatement("""
                INSERT INTO clan_bank_accounts(clan_id, balance, reserved_balance, revision, updated_at)
                VALUES (?, '0', '0', 0, ?)
                """)) {
            bank.setString(1, clan.id().toString()); bank.setString(2, clan.createdAt().toString());
            bank.executeUpdate();
        }
        UUID leaderId = clan.members().values().stream().filter(member -> member.role() == ClanRole.LEADER)
                .map(ClanMember::playerId).findFirst().orElseThrow();
        try (PreparedStatement account = connection.prepareStatement("""
                INSERT INTO clan_storage_accounts(clan_id, page_count, revision, updated_at) VALUES (?, 1, 0, ?)
                """)) {
            account.setString(1, clan.id().toString()); account.setString(2, clan.createdAt().toString());
            account.executeUpdate();
        }
        try (PreparedStatement page = connection.prepareStatement("""
                INSERT INTO clan_storage_pages(clan_id, page_number, contents, revision, created_by, created_at,
                    original_price, charged_price, discount_percent)
                VALUES (?, 1, X'', 0, ?, ?, '0', '0', 0)
                """)) {
            page.setString(1, clan.id().toString()); page.setString(2, leaderId.toString());
            page.setString(3, clan.createdAt().toString()); page.executeUpdate();
        }
        try (PreparedStatement event = connection.prepareStatement("""
                INSERT INTO clan_storage_events(clan_id, actor_id, event_type, page_number,
                    original_price, charged_price, discount_percent, occurred_at)
                VALUES (?, ?, 'FREE_PAGE_GRANTED', 1, '0', '0', 0, ?)
                """)) {
            event.setString(1, clan.id().toString()); event.setString(2, leaderId.toString());
            event.setString(3, clan.createdAt().toString()); event.executeUpdate();
        }
        insertClanStorageContentEvent(clan.id(), 1, leaderId, "SNAPSHOT", 0, new byte[0], clan.createdAt());
    }

    private int updateCapacity(UUID clanId, long expectedRevision, int newCapacity)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                UPDATE clans SET capacity = ?, revision = revision + 1
                WHERE id = ? AND revision = ?
                """)) {
            statement.setInt(1, newCapacity);
            statement.setString(2, clanId.toString());
            statement.setLong(3, expectedRevision);
            return statement.executeUpdate();
        }
    }

    /**
     * Writes the transition source, destination and caller evidence together with the event, so a
     * later reopening validates the stored values instead of reconstructing them backwards.
     */
    private void insertPurchaseEvent(
            UUID operationId,
            CapacityPurchaseState fromState,
            CapacityPurchaseState toState,
            CapacityPurchaseTransitionEvidence evidence,
            String providerOperationId) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                INSERT INTO capacity_purchase_events (
                    operation_id, from_state, to_state, evidence, evidence_provenance,
                    provider_operation_id, occurred_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """)) {
            statement.setString(1, operationId.toString());
            statement.setString(2, fromState == null ? null : fromState.name());
            statement.setString(3, toState.name());
            statement.setString(4, evidence == null ? null : evidence.name());
            statement.setString(
                    5, CapacityPurchaseEvidenceProvenance.RECORDED.name());
            statement.setString(6, providerOperationId);
            statement.setString(7, Instant.now().toString());
            statement.executeUpdate();
        }
    }

    private Optional<CapacityPurchaseOperation> findPurchaseBy(String column, String value)
            throws SQLException {
        return findPurchaseBy(column, value, true);
    }

    private Optional<CapacityPurchaseOperation> findPurchaseBy(
            String column,
            String value,
            boolean validateJournalHistory) throws SQLException {
        if (!List.of(
                "operation_id", "idempotency_key", "business_operation_id").contains(column)) {
            throw new IllegalArgumentException("Unsupported purchase lookup column");
        }
        CapacityPurchaseOperation operation;
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT * FROM capacity_purchase_operations WHERE " + column + " = ?")) {
            statement.setString(1, value);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) {
                    return Optional.empty();
                }
                String operationIdText = result.getString("operation_id");
                try {
                    operation = new CapacityPurchaseOperation(
                            UUID.fromString(operationIdText),
                            result.getString("idempotency_key"),
                            result.getString("business_operation_id"),
                            UUID.fromString(result.getString("clan_id")),
                            UUID.fromString(result.getString("actor_id")),
                            result.getInt("expected_capacity"),
                            result.getInt("target_capacity"),
                            result.getLong("expected_revision"),
                            result.getLong("amount"),
                            CapacityPurchaseState.valueOf(result.getString("state")),
                            result.getString("provider_operation_id"),
                            Instant.parse(result.getString("created_at")),
                            Instant.parse(result.getString("updated_at")));
                } catch (RuntimeException exception) {
                    throw new StorageException(
                            "Corrupt capacity purchase history for operation "
                                    + operationIdText + ": invalid operation record");
                }
            }
        }
        if (validateJournalHistory) {
            validatePurchaseJournalEntry(operation);
        }
        return Optional.of(operation);
    }

    private Optional<String> findPurchaseFingerprint(String idempotencyKey)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT payload_fingerprint FROM capacity_purchase_operations
                WHERE idempotency_key = ?
                """)) {
            statement.setString(1, idempotencyKey);
            try (ResultSet result = statement.executeQuery()) {
                return result.next()
                        ? Optional.ofNullable(result.getString(1))
                        : Optional.empty();
            }
        }
    }

    private boolean exists(String sql, String value) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, value);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    private boolean exists(String sql, String firstValue, String secondValue)
            throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, firstValue);
            statement.setString(2, secondValue);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    private boolean exists(String sql, String firstValue, String secondValue,
            String thirdValue) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, firstValue);
            statement.setString(2, secondValue);
            statement.setString(3, thirdValue);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    private boolean exists(String sql, String firstValue, String secondValue,
            String thirdValue, String fourthValue) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, firstValue);
            statement.setString(2, secondValue);
            statement.setString(3, thirdValue);
            statement.setString(4, fourthValue);
            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }
        }
    }

    private boolean exists(String sql, String firstValue, String secondValue, String thirdValue,
            String fourthValue, String fifthValue) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, firstValue); statement.setString(2, secondValue);
            statement.setString(3, thirdValue); statement.setString(4, fourthValue);
            statement.setString(5, fifthValue);
            try (ResultSet result = statement.executeQuery()) { return result.next(); }
        }
    }

    private <T> T inWriteTransaction(String operation, SqlWork<T> work) {
        ensureOpen();
        boolean transactionStarted = false;
        boolean commitAttempted = false;
        try {
            transactionControl.begin(connection);
            transactionStarted = true;
            T value = work.run();
            commitAttempted = true;
            transactionControl.commit(connection);
            return value;
        } catch (SQLException | RuntimeException | Error exception) {
            if (commitAttempted) {
                poisonConnection(exception);
                throw new StorageException(
                        operation + "; commit outcome is unknown and connection was closed",
                        exception);
            }
            rollback(transactionStarted, exception);
            if (exception instanceof SQLException sqlException) {
                throw new StorageException(operation, sqlException);
            }
            if (exception instanceof RuntimeException runtimeException) {
                throw runtimeException;
            }
            throw (Error) exception;
        }
    }

    private void rollback(boolean transactionStarted, Throwable original) {
        if (!transactionStarted) {
            return;
        }
        try {
            transactionControl.rollback(connection);
        } catch (SQLException | RuntimeException rollbackException) {
            original.addSuppressed(rollbackException);
            poisonConnection(original);
        }
    }

    private void poisonConnection(Throwable original) {
        if (connectionState != ConnectionState.OPEN) {
            return;
        }
        connectionState = ConnectionState.FAILED;
        connectionFailure = original;
        try {
            connection.close();
        } catch (SQLException closeException) {
            original.addSuppressed(closeException);
        }
    }

    private void execute(String sql) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.execute(sql);
        }
    }

    private static boolean isLeader(Clan clan, UUID playerId) {
        return clan.leader()
                .map(leader -> leader.playerId().equals(playerId))
                .orElse(false);
    }

    private static boolean isValidExpansion(Clan expectedClan, Clan updatedClan) {
        try {
            return expectedClan.id().equals(updatedClan.id())
                    && expectedClan.withExpandedCapacity(updatedClan.capacity()).equals(updatedClan);
        } catch (IllegalArgumentException exception) {
            return false;
        }
    }

    private static String normalizeTag(String tag) {
        return tag.toLowerCase(Locale.ROOT);
    }

    private void ensureOpen() {
        if (connectionState == ConnectionState.CLOSED) {
            throw new StorageException("SQLite clan store is closed");
        }

        if (connectionState == ConnectionState.FAILED) {
            throw new StorageException(
                    "SQLite clan store is unusable after a transaction failure",
                    connectionFailure);
        }
    }

    private static StorageException storageFailure(String message, Exception cause) {
        if (cause instanceof StorageException storageException) {
            return storageException;
        }
        return new StorageException(message, cause);
    }

    private static boolean closeAfterOpenFailure(Connection connection, Exception original) {
        if (connection == null) {
            return true;
        }
        try {
            connection.close();
            return true;
        } catch (SQLException closeException) {
            original.addSuppressed(closeException);
            return false;
        }
    }

    private static void deleteDatabaseCreatedByFailedMigration(Path database, Throwable original) {
        for (String suffix : List.of("-wal", "-shm", "")) {
            try {
                Files.deleteIfExists(Path.of(database + suffix));
            } catch (IOException cleanupException) {
                original.addSuppressed(cleanupException);
            }
        }
    }

    private static final class InitialMigrationException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        private InitialMigrationException(Throwable cause) {
            super("Initial SQLite migration failed", cause);
        }
    }

    @FunctionalInterface
    private interface SqlWork<T> {
        T run() throws SQLException;
    }

    private record StoredClan(Clan clan, long revision) {
    }

    private record ClanVersion(int capacity, long revision) {
    }

    record PragmaSettings(
            int foreignKeys,
            String journalMode,
            int synchronous,
            int busyTimeoutMillis) {
    }

    private enum ConnectionState {
        OPEN,
        CLOSED,
        FAILED
    }
}

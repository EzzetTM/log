package com.skyworldclans.clan.xp;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ClanXpEventTypeTest {
    @Test
    void everyConfiguredXpAmountMatchesTheTechnicalSpecification() {
        assertEquals(1_000, ClanXpEventType.WAR_WIN.amount());
        assertEquals(250, ClanXpEventType.WAR_DRAW.amount());
        assertEquals(0, ClanXpEventType.WAR_LOSS.amount());
        assertEquals(500, ClanXpEventType.TOURNAMENT_PARTICIPATION.amount());
        assertEquals(3_000, ClanXpEventType.TOURNAMENT_WIN_BONUS.amount());
        assertEquals(500, ClanXpEventType.FIRST_WAR_WIN.amount());
        assertEquals(2_000, ClanXpEventType.TEN_WAR_WINS.amount());
        assertEquals(3_000, ClanXpEventType.HUNDRED_TASKS_COMPLETED.amount());
        assertEquals(1_000, ClanXpEventType.TEN_MEMBERS_COMPLETED_TASKS.amount());
        assertEquals(2_000, ClanXpEventType.BANK_CONTRIBUTION_10M.amount());
        assertEquals(2_500, ClanXpEventType.FIRST_TOURNAMENT_WIN.amount());
        assertEquals(10_000, ClanXpEventType.LEVEL_TEN_ACHIEVEMENT.amount());
        assertEquals(100, ClanXpEventType.FIRST_RECRUIT_JOINED.amount());
        assertEquals(500, ClanXpEventType.MEMBER_PEAK_5.amount());
        assertEquals(1_000, ClanXpEventType.MEMBER_PEAK_10.amount());
        assertEquals(2_500, ClanXpEventType.MEMBER_PEAK_25.amount());
        assertEquals(4_000, ClanXpEventType.MEMBER_PEAK_40.amount());
        assertEquals(7_500, ClanXpEventType.MEMBER_PEAK_50.amount());
    }
}

package com.skyworldclans.clan.xp;

import java.util.Objects;
import java.util.OptionalLong;

public record ClanXpAwardResult(Status status, OptionalLong totalXp, int level) {
    public ClanXpAwardResult {
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(totalXp, "totalXp");
        if ((status == Status.AWARDED || status == Status.DUPLICATE) != totalXp.isPresent()) {
            throw new IllegalArgumentException("Only successful or duplicate awards include the XP total");
        }
        if (totalXp.isPresent() && level < 1) throw new IllegalArgumentException("Invalid clan level");
    }
    public enum Status { AWARDED, DUPLICATE, IDEMPOTENCY_KEY_CONFLICT, CLAN_NOT_FOUND, INVALID_INPUT, XP_OVERFLOW }
}

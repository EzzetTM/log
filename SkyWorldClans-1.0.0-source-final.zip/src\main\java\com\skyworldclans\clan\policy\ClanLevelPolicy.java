package com.skyworldclans.clan.policy;

/** Cumulative XP thresholds for the ten clan levels defined by the specification. */
public final class ClanLevelPolicy {
    private static final long[] LEVEL_THRESHOLDS = {
            0L, 5_000L, 12_000L, 22_000L, 37_000L,
            58_000L, 88_000L, 130_000L, 190_000L, 275_000L
    };

    private ClanLevelPolicy() { }

    public static int levelForXp(long totalXp) {
        if (totalXp < 0) throw new IllegalArgumentException("Clan XP cannot be negative");
        int low = 0;
        int high = LEVEL_THRESHOLDS.length - 1;
        while (low < high) {
            int middle = (low + high + 1) >>> 1;
            if (totalXp >= LEVEL_THRESHOLDS[middle]) low = middle;
            else high = middle - 1;
        }
        return low + 1;
    }

    /** Returns the cumulative XP threshold for a level in the inclusive range 1..10. */
    public static long thresholdForLevel(int level) {
        if (level < 1 || level > LEVEL_THRESHOLDS.length) {
            throw new IllegalArgumentException("Clan level must be between 1 and 10");
        }
        return LEVEL_THRESHOLDS[level - 1];
    }

    public static int maxLevel() {
        return LEVEL_THRESHOLDS.length;
    }
}

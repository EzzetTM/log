package com.skyworldclans.clan.catalog;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanMembershipStateValidator;
import com.skyworldclans.clan.validation.ClanTagSource;
import com.skyworldclans.clan.validation.ClanTagUniquenessChecker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class InMemoryClanCatalog implements ClanCatalog, ClanTagSource {
    private final Map<UUID, Clan> clansById = new HashMap<>();
    private final Map<String, Clan> clansByTag = new HashMap<>();
    private final Map<UUID, Clan> clansByPlayerId = new HashMap<>();
    private final Map<UUID, Long> clanRevisions = new HashMap<>();
    private final ClanTagUniquenessChecker tagUniquenessChecker =
            new ClanTagUniquenessChecker(this);

    @Override
    public synchronized Optional<Clan> findById(UUID clanId) {
        return Optional.ofNullable(clanId == null ? null : clansById.get(clanId));
    }

    @Override
    public synchronized Optional<Clan> findByTag(String tag) {
        return Optional.ofNullable(tag == null ? null : clansByTag.get(normalizeTag(tag)));
    }

    @Override
    public synchronized Optional<Clan> findByPlayerId(UUID playerId) {
        return Optional.ofNullable(
                playerId == null ? null : clansByPlayerId.get(playerId));
    }

        @Override
        public synchronized Optional<Long> findRevision(UUID clanId) {
            return Optional.ofNullable(clanId == null ? null : clanRevisions.get(clanId));
        }

    @Override
    public synchronized RegistrationStatus registerIfAvailable(Clan clan) {
        if (clan == null) {
            return RegistrationStatus.CLAN_REQUIRED;
        }
        if (clansById.containsKey(clan.id())) {
            return RegistrationStatus.CLAN_ID_CONFLICT;
        }
        if (!tagUniquenessChecker.isUnique(clan.tag())) {
            return RegistrationStatus.TAG_CONFLICT;
        }
        for (UUID playerId : clan.members().keySet()) {
            if (clansByPlayerId.containsKey(playerId)) {
                return RegistrationStatus.MEMBER_CONFLICT;
            }
        }

        clansById.put(clan.id(), clan);
        clansByTag.put(normalizeTag(clan.tag()), clan);
        for (ClanMember member : clan.members().values()) {
            clansByPlayerId.put(member.playerId(), clan);
        }
                clanRevisions.put(clan.id(), 0L);
                return RegistrationStatus.REGISTERED;
    }

    @Override
    public synchronized CapacityUpdateStatus updateCapacityIfUnchanged(
            Clan expectedClan,
            UUID leaderId,
            Clan updatedClan) {
        if (expectedClan == null || leaderId == null || updatedClan == null) {
            return CapacityUpdateStatus.INVALID_UPDATE;
        }

        Clan current = clansById.get(expectedClan.id());
        if (current == null) {
            return CapacityUpdateStatus.CLAN_NOT_FOUND;
        }
        if (!current.leader().map(leader -> leader.playerId().equals(leaderId)).orElse(false)) {
            return CapacityUpdateStatus.LEADER_CHANGED;
        }
        if (current.capacity() != expectedClan.capacity() || !current.equals(expectedClan)) {
            return CapacityUpdateStatus.STATE_CONFLICT;
        }

        Clan expectedExpansion;
        try {
            expectedExpansion = expectedClan.withExpandedCapacity(updatedClan.capacity());
        } catch (IllegalArgumentException exception) {
            return CapacityUpdateStatus.INVALID_UPDATE;
        }
        if (!expectedExpansion.equals(updatedClan)) {
            return CapacityUpdateStatus.INVALID_UPDATE;
        }

        clansById.put(updatedClan.id(), updatedClan);
        clansByTag.put(normalizeTag(updatedClan.tag()), updatedClan);
        for (ClanMember member : updatedClan.members().values()) {
            clansByPlayerId.put(member.playerId(), updatedClan);
        }
                clanRevisions.put(updatedClan.id(), clanRevisions.getOrDefault(updatedClan.id(), 0L) + 1);
                return CapacityUpdateStatus.UPDATED;
    }

    @Override
    public synchronized MembershipUpdateStatus updateMembershipIfUnchanged(
            Clan expectedClan, Clan updatedClan) {
        if (expectedClan == null || updatedClan == null
                || !expectedClan.id().equals(updatedClan.id())
                || !expectedClan.name().equals(updatedClan.name())
                || !expectedClan.tag().equals(updatedClan.tag())
                || !expectedClan.createdAt().equals(updatedClan.createdAt())
                || expectedClan.capacity() != updatedClan.capacity()
                || expectedClan.totalXp() != updatedClan.totalXp()
                || !java.util.Objects.equals(expectedClan.tagline(), updatedClan.tagline())
                || expectedClan.members().equals(updatedClan.members())
                || !new ClanMembershipStateValidator().validate(updatedClan, false).isEmpty()) {
            return MembershipUpdateStatus.INVALID_UPDATE;
        }
        Clan current = clansById.get(expectedClan.id());
        if (current == null) {
            return MembershipUpdateStatus.CLAN_NOT_FOUND;
        }
        if (!current.equals(expectedClan)) {
            return MembershipUpdateStatus.STATE_CONFLICT;
        }
        for (UUID playerId : updatedClan.members().keySet()) {
            Clan owner = clansByPlayerId.get(playerId);
            if (owner != null && !owner.id().equals(expectedClan.id())) {
                return MembershipUpdateStatus.MEMBER_CONFLICT;
            }
        }
        for (UUID playerId : expectedClan.members().keySet()) {
            clansByPlayerId.remove(playerId);
        }
        clansById.put(updatedClan.id(), updatedClan);
        clansByTag.put(normalizeTag(updatedClan.tag()), updatedClan);
        for (ClanMember member : updatedClan.members().values()) {
            clansByPlayerId.put(member.playerId(), updatedClan);
        }
        // The catalog revision tracks capacity-purchase evidence only, not membership edits.
        return MembershipUpdateStatus.UPDATED;
    }

    @Override
    public synchronized Iterable<String> getExistingTags() {
        List<String> tags = new ArrayList<>(clansById.size());
        for (Clan clan : clansById.values()) {
            tags.add(clan.tag());
        }
        return List.copyOf(tags);
    }

    public synchronized int size() {
        return clansById.size();
    }

    public synchronized void replaceForTest(Clan expectedClan, Clan replacement) {
        if (expectedClan == null || replacement == null
                || !expectedClan.id().equals(replacement.id())
                || !clansById.remove(expectedClan.id(), expectedClan)) {
            throw new IllegalArgumentException("Expected clan snapshot is not current");
        }
        clansByTag.remove(normalizeTag(expectedClan.tag()));
        for (UUID playerId : expectedClan.members().keySet()) {
            clansByPlayerId.remove(playerId);
        }
        clansById.put(replacement.id(), replacement);
        clansByTag.put(normalizeTag(replacement.tag()), replacement);
        for (ClanMember member : replacement.members().values()) {
            clansByPlayerId.put(member.playerId(), replacement);
        }
    }

    private static String normalizeTag(String tag) {
        return tag.toLowerCase(java.util.Locale.ROOT);
    }
}

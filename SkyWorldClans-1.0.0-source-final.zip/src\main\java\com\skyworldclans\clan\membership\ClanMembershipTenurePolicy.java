package com.skyworldclans.clan.membership;

import java.time.Duration;
import java.time.Instant;

public final class ClanMembershipTenurePolicy {
    private static final Duration REQUIRED_TENURE = Duration.ofDays(7);

    public boolean isEligibleForBankReward(Instant membershipStartedAt, Instant now) {
        return membershipStartedAt != null
                && now != null
                && Duration.between(membershipStartedAt, now).compareTo(REQUIRED_TENURE) >= 0;
    }
}

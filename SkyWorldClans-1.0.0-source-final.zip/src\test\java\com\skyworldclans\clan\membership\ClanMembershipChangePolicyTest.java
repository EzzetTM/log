package com.skyworldclans.clan.membership;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanMembershipChangePolicyTest {
    private final ClanMembershipChangePolicy policy = new ClanMembershipChangePolicy();

    @Test
    void everyRoleCanVoluntarilyLeave() {
        for (ClanRole role : ClanRole.values()) {
            assertTrue(policy.canVoluntarilyLeave(role), "role: " + role);
        }
    }

    @Test
    void nullRoleCannotVoluntarilyLeave() {
        assertFalse(policy.canVoluntarilyLeave(null));
    }

    @Test
    void checksEveryActorAndTargetRolePairOutsideElections() {
        for (ClanRole actorRole : ClanRole.values()) {
            for (ClanRole targetRole : ClanRole.values()) {
                boolean expected = switch (actorRole) {
                    case LEADER -> targetRole == ClanRole.DEPUTY
                            || targetRole == ClanRole.MODERATOR
                            || targetRole == ClanRole.MEMBER;
                    case DEPUTY -> targetRole == ClanRole.MODERATOR
                            || targetRole == ClanRole.MEMBER;
                    case MODERATOR, MEMBER -> false;
                };
                assertEquals(
                        expected,
                        policy.canRemoveMember(actorRole, targetRole, false, false),
                        () -> actorRole + " removing " + targetRole);
            }
        }
    }

    @Test
    void deniesEveryActorAndTargetRolePairDuringElections() {
        for (ClanRole actorRole : ClanRole.values()) {
            for (ClanRole targetRole : ClanRole.values()) {
                assertFalse(
                        policy.canRemoveMember(actorRole, targetRole, false, true),
                        () -> actorRole + " removing " + targetRole + " during elections");
            }
        }
    }

    @Test
    void selfRemovalIsDeniedForEveryActorAndTargetRolePair() {
        for (ClanRole actorRole : ClanRole.values()) {
            for (ClanRole targetRole : ClanRole.values()) {
                assertFalse(
                        policy.canRemoveMember(actorRole, targetRole, true, false),
                        () -> actorRole + " self-removal as " + targetRole);
            }
        }
    }

    @Test
    void nullActorRoleIsDenied() {
        for (ClanRole targetRole : ClanRole.values()) {
            assertFalse(policy.canRemoveMember(null, targetRole, false, false));
        }
    }

    @Test
    void nullTargetRoleIsDenied() {
        for (ClanRole actorRole : ClanRole.values()) {
            assertFalse(policy.canRemoveMember(actorRole, null, false, false));
        }
    }

    @Test
    void leaderCanRemoveDeputyModeratorAndMemberButNotLeader() {
        assertTrue(policy.canRemoveMember(ClanRole.LEADER, ClanRole.DEPUTY, false, false));
        assertTrue(policy.canRemoveMember(ClanRole.LEADER, ClanRole.MODERATOR, false, false));
        assertTrue(policy.canRemoveMember(ClanRole.LEADER, ClanRole.MEMBER, false, false));
        assertFalse(policy.canRemoveMember(ClanRole.LEADER, ClanRole.LEADER, false, false));
    }

    @Test
    void deputyCanRemoveModeratorAndMemberButNotLeaderOrDeputy() {
        assertTrue(policy.canRemoveMember(ClanRole.DEPUTY, ClanRole.MODERATOR, false, false));
        assertTrue(policy.canRemoveMember(ClanRole.DEPUTY, ClanRole.MEMBER, false, false));
        assertFalse(policy.canRemoveMember(ClanRole.DEPUTY, ClanRole.LEADER, false, false));
        assertFalse(policy.canRemoveMember(ClanRole.DEPUTY, ClanRole.DEPUTY, false, false));
    }

    @Test
    void onlyLeaderCanDemoteDeputyAndElectionBlocksIt() {
        assertTrue(policy.canDemoteDeputy(ClanRole.LEADER, ClanRole.DEPUTY, false));
        assertFalse(policy.canDemoteDeputy(ClanRole.DEPUTY, ClanRole.DEPUTY, false));
        assertFalse(policy.canDemoteDeputy(ClanRole.LEADER, ClanRole.MEMBER, false));
        assertFalse(policy.canDemoteDeputy(ClanRole.LEADER, ClanRole.DEPUTY, true));
    }

    @Test
    void leaderCanDemoteAnyModeratorButDeputyOnlyTheirOwn() {
        java.util.UUID deputy = java.util.UUID.randomUUID();
        java.util.UUID otherDeputy = java.util.UUID.randomUUID();
        assertTrue(policy.canDemoteModerator(ClanRole.LEADER, ClanRole.MODERATOR,
                deputy, otherDeputy, false));
        assertTrue(policy.canDemoteModerator(ClanRole.DEPUTY, ClanRole.MODERATOR,
                deputy, deputy, false));
        assertFalse(policy.canDemoteModerator(ClanRole.DEPUTY, ClanRole.MODERATOR,
                deputy, otherDeputy, false));
        assertFalse(policy.canDemoteModerator(ClanRole.MODERATOR, ClanRole.MODERATOR,
                deputy, deputy, false));
        assertFalse(policy.canDemoteModerator(ClanRole.LEADER, ClanRole.MODERATOR,
                deputy, otherDeputy, true));
    }

    @Test
    void doesNotMutateInputsOrRetainResultsBetweenCalls() {
        ClanRole actorRole = ClanRole.LEADER;
        ClanRole targetRole = ClanRole.MEMBER;
        ClanRole expectedActorRole = actorRole;
        ClanRole expectedTargetRole = targetRole;

        boolean firstResult = policy.canRemoveMember(actorRole, targetRole, false, false);
        policy.canRemoveMember(ClanRole.DEPUTY, ClanRole.MODERATOR, false, true);
        boolean secondResult = policy.canRemoveMember(actorRole, targetRole, false, false);

        assertTrue(firstResult);
        assertEquals(firstResult, secondResult);
        assertEquals(expectedActorRole, actorRole);
        assertEquals(expectedTargetRole, targetRole);
        assertTrue(policy.canVoluntarilyLeave(actorRole));
        assertTrue(policy.canRemoveMember(actorRole, targetRole, false, false));
    }
}

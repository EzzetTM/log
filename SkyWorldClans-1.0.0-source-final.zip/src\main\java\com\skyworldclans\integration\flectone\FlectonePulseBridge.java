package com.skyworldclans.integration.flectone;

import net.flectone.pulse.FlectonePulse;
import net.flectone.pulse.FlectonePulseAPI;
import net.flectone.pulse.constant.ModuleName;
import net.flectone.pulse.dispatcher.MessageDispatcher;
import net.flectone.pulse.model.entity.FPlayer;
import net.flectone.pulse.model.event.EventMetadata;
import net.flectone.pulse.model.event.message.context.MessageContext;
import net.flectone.pulse.model.value.Destination;
import net.flectone.pulse.model.value.Range;
import net.flectone.pulse.service.FPlayerService;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.UUID;

/** Isolated optional FlectonePulse 1.15.x API bridge. */
public final class FlectonePulseBridge {
    private final FPlayerService players;
    private final MessageDispatcher dispatcher;

    private FlectonePulseBridge(FPlayerService players, MessageDispatcher dispatcher) {
        this.players = players;
        this.dispatcher = dispatcher;
    }

    public static FlectonePulseBridge connectIfReady() {
        FlectonePulse pulse = FlectonePulseAPI.getInstance();
        if (pulse == null || !pulse.isReady()) return null;
        FPlayerService players = pulse.get(FPlayerService.class);
        MessageDispatcher dispatcher = pulse.get(MessageDispatcher.class);
        if (players == null || dispatcher == null) return null;
        return new FlectonePulseBridge(players, dispatcher);
    }

    public boolean sendClanMessage(Player sender, Set<UUID> clanMemberIds, String rawMessage) {
        if (sender == null || clanMemberIds == null || clanMemberIds.isEmpty() || rawMessage == null || rawMessage.isBlank())
            return false;
        try {
            FPlayer fSender = players.getFPlayer(sender);
            if (fSender == null || fSender.isUnknown()) return false;
            String senderName = fSender.name() == null ? "Игрок" : fSender.name();
            String message = "[Клан] " + MiniMessage.miniMessage().escapeTags(senderName) + ": "
                    + MiniMessage.miniMessage().escapeTags(rawMessage);
            Set<FPlayer> delivered = dispatcher.dispatch(EventMetadata.builder()
                    .range(Range.Type.SERVER)
                    .destination(Destination.EMPTY_CHAT)
                    .filter(receiver -> clanMemberIds.contains(receiver.uuid()))
                    .messageContext(receiver -> MessageContext.builder()
                            .module(ModuleName.ADDON)
                            .sender(fSender)
                            .receiver(receiver)
                            .message(message)
                            .build())
                    .build());
            return delivered != null && delivered.stream().anyMatch(receiver -> sender.getUniqueId().equals(receiver.uuid()));
        } catch (RuntimeException exception) {
            return false;
        }
    }
}

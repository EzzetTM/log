package com.skyworldclans.clan.application.creation;

import com.skyworldclans.clan.Clan;

import java.time.Instant;
import java.util.Optional;
import java.util.List;
import java.util.UUID;

/** Durable journal boundary for the one-time ordinary-currency clan creation payment. */
public interface ClanCreationPaymentJournal {
    CreationPrepareResult prepare(ClanCreationPaymentOperation operation);
    Optional<ClanCreationPaymentOperation> findCreationByIdempotencyKey(String idempotencyKey);
    Optional<ClanCreationPaymentOperation> findCreationById(UUID operationId);
    List<ClanCreationPaymentOperation> findUnresolvedCreations();
    CreationTransitionResult transition(UUID operationId, ClanCreationPaymentState expected,
            ClanCreationPaymentState next, String diagnostic, Instant at);
    CreationCommitResult commitPaidClan(UUID operationId, Clan clan, Instant at);

    enum CreationPrepareStatus { CREATED, DUPLICATE, IDEMPOTENCY_CONFLICT, OPERATION_CONFLICT,
        PLAYER_ALREADY_IN_CLAN, TAG_TAKEN, PLAYER_HAS_UNRESOLVED_CREATION }
    record CreationPrepareResult(CreationPrepareStatus status, Optional<ClanCreationPaymentOperation> operation) { }
    enum CreationTransitionStatus { UPDATED, NOT_FOUND, STATE_CONFLICT, INVALID_TRANSITION }
    record CreationTransitionResult(CreationTransitionStatus status, Optional<ClanCreationPaymentOperation> operation) { }
    enum CreationCommitStatus { COMMITTED, NOT_FOUND, NOT_DEBIT_CONFIRMED, CLAN_MISMATCH,
        TAG_CONFLICT, MEMBER_CONFLICT, CLAN_ID_CONFLICT }
    record CreationCommitResult(CreationCommitStatus status, Optional<Clan> clan) { }
}

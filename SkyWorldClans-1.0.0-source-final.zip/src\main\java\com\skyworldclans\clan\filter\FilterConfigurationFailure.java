package com.skyworldclans.clan.filter;

import java.util.Objects;

public record FilterConfigurationFailure(
        String context,
        String detail,
        Throwable cause) {

    public FilterConfigurationFailure {
        Objects.requireNonNull(context, "context");
        detail = detail == null ? "" : detail;
    }

    public String diagnostic() {
        if (cause == null) {
            return detail.isBlank() ? context : context + ": " + detail;
        }

        String causeMessage = cause.getMessage();
        String causeDescription = cause.getClass().getSimpleName()
                + (causeMessage == null || causeMessage.isBlank() ? "" : ": " + causeMessage);
        String detailPart = detail.isBlank() ? "" : ": " + detail;
        return context + detailPart + " (" + causeDescription + ")";
    }
}

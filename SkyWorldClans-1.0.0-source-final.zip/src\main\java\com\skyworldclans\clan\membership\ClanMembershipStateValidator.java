package com.skyworldclans.clan.membership;

import com.skyworldclans.clan.Clan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class ClanMembershipStateValidator {

    public List<Violation> validate(Clan clan, boolean electionActive) {
        if (clan == null) {
            return List.of(Violation.CLAN_REQUIRED);
        }

        List<Violation> violations = new ArrayList<>();
        if (!electionActive && clan.leader().isEmpty()) {
            violations.add(Violation.LEADER_REQUIRED_OUTSIDE_ELECTION);
        }

        int deputyCount = 0;
        int totalDeputyAssignedModeratorCount = 0;
        Map<UUID, Integer> moderatorCountsByDeputy = new HashMap<>();
        for (ClanMember member : clan.members().values()) {
            if (member.role() == ClanRole.DEPUTY) {
                deputyCount++;
            }
            if (member.appointedByDeputyId() != null) {
                totalDeputyAssignedModeratorCount++;
                moderatorCountsByDeputy.merge(member.appointedByDeputyId(), 1, Integer::sum);
            }
        }

        if (!ClanMembershipPolicy.isValidDeputyCount(deputyCount)) {
            violations.add(Violation.DEPUTY_LIMIT_EXCEEDED);
        }
        if (moderatorCountsByDeputy.values().stream()
                .anyMatch(count -> !ClanMembershipPolicy.isValidDeputyAssignedModeratorCount(count))) {
            violations.add(Violation.DEPUTY_MODERATOR_LIMIT_EXCEEDED);
        }
        if (!ClanMembershipPolicy.isValidTotalDeputyAssignedModeratorCount(
                totalDeputyAssignedModeratorCount)) {
            violations.add(Violation.TOTAL_DEPUTY_MODERATOR_LIMIT_EXCEEDED);
        }

        return List.copyOf(violations);
    }

    public enum Violation {
        CLAN_REQUIRED,
        LEADER_REQUIRED_OUTSIDE_ELECTION,
        DEPUTY_LIMIT_EXCEEDED,
        DEPUTY_MODERATOR_LIMIT_EXCEEDED,
        TOTAL_DEPUTY_MODERATOR_LIMIT_EXCEEDED
    }
}

package com.skyworldclans.clan.service;

import com.skyworldclans.clan.membership.ClanMembershipStateValidator;

import java.util.List;
import java.util.Objects;

public record ClanRegistrationResult(
        Status status,
        List<ClanMembershipStateValidator.Violation> validationViolations) {

    public ClanRegistrationResult {
        Objects.requireNonNull(status, "status");
        validationViolations = List.copyOf(validationViolations);
        if (status == Status.INVALID_MEMBERSHIP_STATE && validationViolations.isEmpty()) {
            throw new IllegalArgumentException(
                    "Invalid membership state must include at least one violation");
        }
        if (status != Status.INVALID_MEMBERSHIP_STATE && !validationViolations.isEmpty()) {
            throw new IllegalArgumentException(
                    "Validation violations are only valid for an invalid membership state");
        }
    }

    public boolean registered() {
        return status == Status.REGISTERED;
    }

    public enum Status {
        REGISTERED,
        CLAN_REQUIRED,
        INVALID_MEMBERSHIP_STATE,
        CLAN_ID_CONFLICT,
        TAG_CONFLICT,
        MEMBER_CONFLICT
    }
}

package com.skyworldclans.admin;

import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Complaints, sanctions and appeals.
 *
 * <p>Access levels are resolved by the caller (console or LuckPerms-backed permissions) and passed
 * in explicitly, so this domain class never guesses at permission configuration. Anonymous reports
 * hide the author from {@code ADMIN} and {@code MODERATOR}; only {@code OWNER} may reveal it, and
 * every reveal is written to the append-only audit table.</p>
 */
public final class ClanAdministrationService {
    /** An appeal may be filed within seven days of the sanction (owner decision-independent rule). */
    public static final Duration APPEAL_WINDOW = Duration.ofDays(7);
    public static final int REPORT_EVIDENCE_LIMIT = 10;

    public enum Level { NONE, MODERATOR, ADMIN, OWNER }

    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final Clock clock;
    private final Supplier<UUID> ids;

    public ClanAdministrationService(ClanCatalog clans, SqliteClanStore store, Clock clock, Supplier<UUID> ids) {
        this.clans = Objects.requireNonNull(clans); this.store = Objects.requireNonNull(store);
        this.clock = Objects.requireNonNull(clock); this.ids = Objects.requireNonNull(ids);
    }

    // --- reports -------------------------------------------------------

    public Result submitReport(UUID authorId, String authorName, String clanTag, String category,
            String reason, List<String> evidenceUrls) {
        var clan = clans.findByTag(clanTag).orElse(null);
        if (clan == null) return Result.of(Status.CLAN_NOT_FOUND);
        if (reason == null || reason.isBlank() || reason.trim().length() > 2000)
            return Result.of(Status.INVALID_INPUT);
        if (evidenceUrls == null || evidenceUrls.size() > REPORT_EVIDENCE_LIMIT)
            return Result.of(Status.INVALID_INPUT);
        String normalizedCategory = category == null ? "" : category.trim().toUpperCase(java.util.Locale.ROOT);
        if (!List.of("RULES", "ABUSE", "BANK_FRAUD", "CHAT_HARASSMENT").contains(normalizedCategory))
            return Result.of(Status.INVALID_CATEGORY);
        UUID reportId = ids.get();
        var created = store.createClanReport(reportId, clan.id(), authorId, authorName,
                false, normalizedCategory, reason, evidenceUrls, clock.instant());
        return switch (created) {
            case CREATED -> new Result(Status.CREATED, store.findClanReport(reportId).orElse(null));
            case DUPLICATE -> Result.of(Status.DUPLICATE);
            case NOT_FOUND -> Result.of(Status.CLAN_NOT_FOUND);
            default -> Result.of(Status.INVALID_INPUT);
        };
    }

    /** Anonymous submission; the author remains available to the owner only. */
    public Result submitAnonymousReport(UUID authorId, String authorName, String clanTag, String category,
            String reason, List<String> evidenceUrls) {
        var clan = clans.findByTag(clanTag).orElse(null);
        if (clan == null) return Result.of(Status.CLAN_NOT_FOUND);
        String normalizedCategory = category == null ? "" : category.trim().toUpperCase(java.util.Locale.ROOT);
        if (!List.of("RULES", "ABUSE", "BANK_FRAUD", "CHAT_HARASSMENT").contains(normalizedCategory))
            return Result.of(Status.INVALID_CATEGORY);
        var created = store.createClanReport(ids.get(), clan.id(), authorId, authorName,
                true, normalizedCategory, reason, evidenceUrls, clock.instant());
        return switch (created) {
            case CREATED -> Result.of(Status.CREATED);
            case DUPLICATE -> Result.of(Status.DUPLICATE);
            default -> Result.of(Status.INVALID_INPUT);
        };
    }

    public List<SqliteClanStore.ClanReport> reports(Level level, String status, int limit) {
        if (level == Level.NONE) return List.of();
        return store.findClanReports(status, limit);
    }

    public Result changeReportStatus(Level level, UUID actorId, UUID reportId, String status, String note) {
        if (level == Level.NONE) return Result.of(Status.UNAUTHORIZED);
        if (reportId == null) return Result.of(Status.INVALID_INPUT);
        var statusResult = store.updateReportStatus(reportId, actorId, status, note, clock.instant());
        return switch (statusResult) {
            case UPDATED -> new Result(Status.UPDATED, store.findClanReport(reportId).orElse(null));
            case NOT_FOUND -> Result.of(Status.NOT_FOUND);
            default -> Result.of(Status.INVALID_INPUT);
        };
    }

    /** Anonymous reports hide the author from everyone except the owner. */
    public Optional<SqliteClanStore.ClanReport> viewReport(Level level, UUID viewerId, UUID reportId) {
        if (level == Level.NONE || reportId == null) return Optional.empty();
        var report = store.findClanReport(reportId);
        if (report.isEmpty()) return Optional.empty();
        if (report.get().anonymous() && level != Level.OWNER) {
            // Present the report without author identity.
            var value = report.get();
            return Optional.of(new SqliteClanStore.ClanReport(value.reportId(), value.clanId(),
                    new UUID(0L, 0L), "anonymous", true, value.category(), value.reason(),
                    value.status(), value.assignedTo(), value.createdAt(), value.updatedAt()));
        }
        if (report.get().anonymous() && level == Level.OWNER) {
            store.revealReportAuthor(reportId, viewerId, clock.instant());
        }
        return report;
    }

    public List<SqliteClanStore.ClanReportEvidence> evidence(Level level, UUID reportId) {
        if (level == Level.NONE || reportId == null) return List.of();
        return store.findReportEvidence(reportId);
    }

    // --- sanctions -----------------------------------------------------

    /**
     * Approved escalation: first violation — warning, second — final warning, third — temporary
     * function block. A serious violation may be sanctioned more strictly immediately.
     */
    public Result issueSanction(Level level, UUID actorId, UUID targetId, String kind, String scope,
            String reason, Duration duration, boolean ownerIssued) {
        if (level == Level.NONE) return Result.of(Status.UNAUTHORIZED);
        if (level == Level.MODERATOR && !"WARNING".equalsIgnoreCase(kind))
            return Result.of(Status.UNAUTHORIZED);
        if (level != Level.OWNER && ownerIssued)
            return Result.of(Status.UNAUTHORIZED);
        Instant now = clock.instant();
        Instant expiresAt = duration == null ? null : now.plus(duration);
        // A sanction belongs to the target's clan so its leader may appeal on the clan's behalf.
        UUID clanId = clans.findByPlayerId(targetId).map(clan -> clan.id()).orElse(null);
        var created = store.createClanSanction(ids.get(), clanId, targetId, actorId,
                kind.toUpperCase(java.util.Locale.ROOT), scope.toUpperCase(java.util.Locale.ROOT),
                reason, now, expiresAt, ownerIssued);
        return switch (created) {
            case CREATED -> Result.of(Status.CREATED);
            default -> Result.of(Status.INVALID_INPUT);
        };
    }

    /** The owner may revoke or amend any sanction; an admin only its own. */
    public Result revokeSanction(Level level, UUID actorId, UUID sanctionId) {
        if (level == Level.NONE) return Result.of(Status.UNAUTHORIZED);
        var sanction = store.findClanSanction(sanctionId).orElse(null);
        if (sanction == null) return Result.of(Status.NOT_FOUND);
        if (level != Level.OWNER && sanction.ownerIssued())
            return Result.of(Status.UNAUTHORIZED);
        if (level == Level.MODERATOR && !sanction.issuedBy().equals(actorId))
            return Result.of(Status.UNAUTHORIZED);
        var result = store.revokeClanSanction(sanctionId, actorId, clock.instant());
        return result == SqliteClanStore.ReportStatus.UPDATED
                ? Result.of(Status.UPDATED) : Result.of(Status.NOT_FOUND);
    }

    public List<SqliteClanStore.ClanSanction> sanctions(Level level, UUID targetId, int limit) {
        if (level == Level.NONE) return List.of();
        return store.findClanSanctions(targetId, limit);
    }

    /** True when an active function-block sanction covers the requested scope. */
    public boolean isFunctionBlocked(UUID playerId, String scope, Instant now) {
        if (playerId == null) return false;
        for (var sanction : store.findActiveClanSanctions(playerId, now)) {
            if (sanction.kind() != SqliteClanStore.ClanSanctionKind.TEMPORARY_FUNCTION_BLOCK) continue;
            if (sanction.scope() == SqliteClanStore.ClanSanctionScope.ALL
                    || sanction.scope().name().equalsIgnoreCase(scope)) return true;
        }
        return false;
    }

    // --- appeals -------------------------------------------------------

    /** Only the clan leader may appeal on behalf of the clan (or the sanctioned player themself). */
    public Result submitAppeal(UUID submitterId, UUID sanctionId, String reason, String evidence,
            boolean ownerOverride) {
        var sanction = store.findClanSanction(sanctionId).orElse(null);
        if (sanction == null) return Result.of(Status.NOT_FOUND);
        boolean leader = sanction.clanId() != null && clans.findById(sanction.clanId())
                .flatMap(clan -> clan.member(submitterId))
                .map(member -> member.role() == ClanRole.LEADER).orElse(false);
        if (!leader && !sanction.targetId().equals(submitterId))
            return Result.of(Status.UNAUTHORIZED);
        Instant now = clock.instant();
        if (!ownerOverride && now.isAfter(sanction.issuedAt().plus(APPEAL_WINDOW)))
            return Result.of(Status.APPEAL_WINDOW_EXPIRED);
        var created = store.createClanAppeal(ids.get(), sanctionId, sanction.clanId(), submitterId,
                reason, evidence, now);
        return switch (created) {
            case CREATED -> Result.of(Status.CREATED);
            case DUPLICATE -> Result.of(Status.DUPLICATE);
            default -> Result.of(Status.INVALID_INPUT);
        };
    }

    /** Admin decides; a sanction issued by the owner may only be decided by the owner. */
    public Result decideAppeal(Level level, UUID actorId, UUID appealId, boolean accept, String note) {
        if (level != Level.ADMIN && level != Level.OWNER) return Result.of(Status.UNAUTHORIZED);
        var appeal = store.findClanAppeal(appealId).orElse(null);
        if (appeal == null) return Result.of(Status.NOT_FOUND);
        if (appeal.status() != SqliteClanStore.ClanAppealStatus.PENDING)
            return Result.of(Status.ALREADY_DECIDED);
        var sanction = store.findClanSanction(appeal.sanctionId()).orElse(null);
        if (sanction != null && sanction.ownerIssued() && level != Level.OWNER)
            return Result.of(Status.OWNER_ONLY);
        var result = store.decideClanAppeal(appealId, actorId, accept, note, clock.instant());
        return result == SqliteClanStore.ReportStatus.UPDATED
                ? Result.of(Status.UPDATED) : Result.of(Status.NOT_FOUND);
    }

    public List<SqliteClanStore.ClanAppeal> appeals(Level level, String status, int limit) {
        if (level == Level.NONE) return List.of();
        return store.findClanAppeals(status, limit);
    }

    public List<SqliteClanStore.ClanSanction> activeSanctions(UUID playerId) {
        return store.findActiveClanSanctions(playerId, clock.instant());
    }

    public enum Status {
        CREATED, UPDATED, DUPLICATE, INVALID_INPUT, INVALID_CATEGORY, CLAN_NOT_FOUND, NOT_FOUND,
        UNAUTHORIZED, OWNER_ONLY, APPEAL_WINDOW_EXPIRED, ALREADY_DECIDED
    }

    public record Result(Status status, SqliteClanStore.ClanReport report) {
        public static Result of(Status status) { return new Result(status, null); }
    }
}
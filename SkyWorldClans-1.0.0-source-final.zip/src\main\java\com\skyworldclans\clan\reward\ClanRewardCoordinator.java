package com.skyworldclans.clan.reward;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.catalog.ClanCatalog;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import com.skyworldclans.clan.storage.sqlite.SqliteClanStore;
import com.skyworldclans.integration.EconomyOperations;

import java.math.BigDecimal;
import java.time.Clock;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Durable coordinator for personal payouts and bank-funded rewards.
 *
 * <p>Money always moves through two independently recorded steps: the local journal row is
 * committed first, then the external provider is called. A provider result that cannot be
 * determined is frozen as {@code MANUAL_REVIEW} and never replayed, so neither duplicate payment
 * nor silent loss is possible. Bank rewards debit the clan bank inside the same SQLite transaction
 * that records {@code DEBIT_CONFIRMED}.</p>
 */
public final class ClanRewardCoordinator {
    private final ClanCatalog clans;
    private final SqliteClanStore store;
    private final EconomyOperations economy;
    private final Clock clock;
    private final Supplier<UUID> ids;
    private final ClanRewardPolicy policy = new ClanRewardPolicy();

    public ClanRewardCoordinator(ClanCatalog clans, SqliteClanStore store, EconomyOperations economy,
            Clock clock, Supplier<UUID> ids) {
        this.clans = Objects.requireNonNull(clans); this.store = Objects.requireNonNull(store);
        this.economy = economy; this.clock = Objects.requireNonNull(clock);
        this.ids = Objects.requireNonNull(ids);
    }

    public Result personalPayout(UUID issuerId, UUID recipientId, BigDecimal amount) {
        Clan clan = clans.findByPlayerId(issuerId).orElse(null);
        if (clan == null) return new Result(Status.NOT_IN_CLAN, null);
        ClanRewardPolicy.Decision decision = policy.personalPayout(clan, issuerId, recipientId, amount);
        if (decision == ClanRewardPolicy.Decision.INVALID_AMOUNT) return new Result(Status.INVALID_AMOUNT, null);
        if (decision == ClanRewardPolicy.Decision.INVALID_RECIPIENT) return new Result(Status.RECIPIENT_NOT_MEMBER, null);
        if (decision != ClanRewardPolicy.Decision.ALLOWED) return new Result(Status.NOT_AUTHORIZED, null);
        if (clan.member(recipientId).isEmpty()) return new Result(Status.RECIPIENT_NOT_MEMBER, null);
        if (economy == null) return new Result(Status.ECONOMY_UNAVAILABLE, null);
        return execute(clan, issuerId, recipientId, "PERSONAL", amount, "personal payout", null);
    }

    public Result bankReward(UUID issuerId, UUID recipientId, BigDecimal amount) {
        Clan clan = clans.findByPlayerId(issuerId).orElse(null);
        if (clan == null) return new Result(Status.NOT_IN_CLAN, null);
        int today = store.countDeputyOrdinaryRewardsToday(clan.id(), issuerId, clock.instant());
        ClanRewardPolicy.Decision decision = policy.ordinaryBankReward(
                clan, issuerId, recipientId, amount, today, clock.instant());
        switch (decision) {
            case INVALID_AMOUNT -> { return new Result(Status.INVALID_AMOUNT, null); }
            case RECIPIENT_NOT_MEMBER -> { return new Result(Status.RECIPIENT_NOT_MEMBER, null); }
            case RECIPIENT_MEMBERSHIP_TOO_NEW -> { return new Result(Status.RECIPIENT_MEMBERSHIP_TOO_NEW, null); }
            case DEPUTY_AMOUNT_LIMIT -> { return new Result(Status.DEPUTY_AMOUNT_LIMIT, null); }
            case DEPUTY_DAILY_LIMIT -> { return new Result(Status.DEPUTY_DAILY_LIMIT, null); }
            case ISSUER_NOT_AUTHORIZED -> { return new Result(Status.NOT_AUTHORIZED, null); }
            default -> { }
        }
        if (economy == null) return new Result(Status.ECONOMY_UNAVAILABLE, null);
        if (store.clanBankAvailableBalance(clan.id()).compareTo(amount.stripTrailingZeros()) < 0)
            return new Result(Status.INSUFFICIENT_BANK_FUNDS, null);
        return execute(clan, issuerId, recipientId, "BANK", amount, "bank reward", null);
    }

    /** Deputies may only request large rewards; the weekly quota rule stays an owner decision. */
    public Result largeBankRewardRequest(UUID deputyId, UUID recipientId, BigDecimal amount) {
        Clan clan = clans.findByPlayerId(deputyId).orElse(null);
        if (clan == null) return new Result(Status.NOT_IN_CLAN, null);
        ClanRewardPolicy.Decision decision = policy.largeBankRewardRequest(
                clan, deputyId, recipientId, amount, clock.instant());
        return switch (decision) {
            case WEEKLY_QUOTA_POLICY_UNRESOLVED -> new Result(Status.WEEKLY_QUOTA_POLICY_UNRESOLVED, null);
            case RECIPIENT_MEMBERSHIP_TOO_NEW -> new Result(Status.RECIPIENT_MEMBERSHIP_TOO_NEW, null);
            case RECIPIENT_NOT_MEMBER -> new Result(Status.RECIPIENT_NOT_MEMBER, null);
            case INVALID_LARGE_REWARD_AMOUNT -> new Result(Status.INVALID_AMOUNT, null);
            default -> new Result(Status.NOT_AUTHORIZED, null);
        };
    }

    private Result execute(Clan clan, UUID issuerId, UUID recipientId, String source,
            BigDecimal amount, String reason, UUID approvedBy) {
        UUID operationId = ids.get();
        String idempotencyKey = "reward:" + source + ":" + operationId;
        var prepared = store.prepareClanReward(operationId, idempotencyKey, clan.id(), issuerId,
                recipientId, source, amount, reason, clock.instant());
        if (prepared.status() != SqliteClanStore.ClanRewardPrepareStatus.CREATED)
            return new Result(Status.STORAGE_ERROR, prepared.operation());

        // 1. Record the debit intent before touching the provider.
        var calling = store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.PREPARED,
                SqliteClanStore.ClanRewardState.DEBIT_CALLING, issuerId, "DEBIT_INTENT", clock.instant());
        if (calling.operation() == null) return new Result(Status.STORAGE_ERROR, null);

        EconomyOperations.OperationResult debit = source.equals("PERSONAL")
                ? economy.withdraw(issuerId, amount.doubleValue())
                : new EconomyOperations.OperationResult(EconomyOperations.Status.SUCCESS, "clan bank");
        if (debit == null || debit.status() == EconomyOperations.Status.UNKNOWN) {
            store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.DEBIT_CALLING,
                    SqliteClanStore.ClanRewardState.MANUAL_REVIEW, issuerId, "DEBIT_UNKNOWN", clock.instant());
            return new Result(Status.MANUAL_RECONCILIATION_REQUIRED,
                    store.findClanReward(operationId).orElse(null));
        }
        if (debit.status() != EconomyOperations.Status.SUCCESS) {
            store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.DEBIT_CALLING,
                    SqliteClanStore.ClanRewardState.FAILED_NO_EFFECT, issuerId,
                    "DEBIT_" + debit.status(), clock.instant());
            return new Result(debit.status() == EconomyOperations.Status.INSUFFICIENT_FUNDS
                    ? Status.INSUFFICIENT_PERSONAL_FUNDS : Status.DEBIT_REJECTED,
                    store.findClanReward(operationId).orElse(null));
        }
        var confirmed = store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.DEBIT_CALLING,
                SqliteClanStore.ClanRewardState.DEBIT_CONFIRMED, issuerId, "DEBIT_CONFIRMED", clock.instant());
        if (confirmed.operation() == null) {
            return new Result(Status.MANUAL_RECONCILIATION_REQUIRED,
                    store.findClanReward(operationId).orElse(null));
        }

        // 2. Record the credit intent, then pay the recipient exactly once.
        var creditCalling = store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.DEBIT_CONFIRMED,
                SqliteClanStore.ClanRewardState.CREDIT_CALLING, issuerId, "CREDIT_INTENT", clock.instant());
        if (creditCalling.operation() == null) {
            return new Result(Status.MANUAL_RECONCILIATION_REQUIRED,
                    store.findClanReward(operationId).orElse(null));
        }
        EconomyOperations.OperationResult credit = economy.deposit(recipientId, amount.doubleValue());
        if (credit == null || credit.status() == EconomyOperations.Status.UNKNOWN) {
            store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.CREDIT_CALLING,
                    SqliteClanStore.ClanRewardState.MANUAL_REVIEW, issuerId, "CREDIT_UNKNOWN", clock.instant());
            return new Result(Status.MANUAL_RECONCILIATION_REQUIRED,
                    store.findClanReward(operationId).orElse(null));
        }
        if (credit.status() != EconomyOperations.Status.SUCCESS) {
            // The debit succeeded but the credit did not: keep the record for reconciliation.
            store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.CREDIT_CALLING,
                    SqliteClanStore.ClanRewardState.MANUAL_REVIEW, issuerId,
                    "CREDIT_" + credit.status(), clock.instant());
            return new Result(Status.MANUAL_RECONCILIATION_REQUIRED,
                    store.findClanReward(operationId).orElse(null));
        }
        var completed = store.transitionClanReward(operationId, SqliteClanStore.ClanRewardState.CREDIT_CALLING,
                SqliteClanStore.ClanRewardState.COMPLETED, issuerId, "PAID", clock.instant());
        return new Result(completed.operation() != null ? Status.SUCCESS : Status.MANUAL_RECONCILIATION_REQUIRED,
                completed.operation());
    }

    /** Deputies may only request large rewards; the weekly quota is consumed on approval. */
    public RequestResult requestLarge(UUID deputyId, UUID recipientId, BigDecimal amount, String reason) {
        Clan clan = clans.findByPlayerId(deputyId).orElse(null);
        if (clan == null) return new RequestResult(Status.NOT_IN_CLAN, null);
        ClanMember deputy = clan.member(deputyId).orElse(null);
        if (deputy == null || deputy.role() != ClanRole.DEPUTY)
            return new RequestResult(Status.NOT_AUTHORIZED, null);
        ClanRewardPolicy.Decision decision = policy.largeBankRewardRequest(
                clan, deputyId, recipientId, amount, clock.instant());
        switch (decision) {
            case RECIPIENT_NOT_MEMBER -> { return new RequestResult(Status.RECIPIENT_NOT_MEMBER, null); }
            case RECIPIENT_MEMBERSHIP_TOO_NEW -> { return new RequestResult(Status.RECIPIENT_MEMBERSHIP_TOO_NEW, null); }
            case INVALID_LARGE_REWARD_AMOUNT -> { return new RequestResult(Status.INVALID_AMOUNT, null); }
            // The weekly quota rule is now defined by the owner, so the request may be created.
            case WEEKLY_QUOTA_POLICY_UNRESOLVED, ALLOWED -> { }
            default -> { return new RequestResult(Status.NOT_AUTHORIZED, null); }
        }
        var created = store.createRewardRequest(ids.get(), clan.id(), deputyId, recipientId, amount,
                reason, clock.instant());
        return switch (created.status()) {
            case CREATED -> new RequestResult(Status.REQUEST_CREATED, created.request());
            case DUPLICATE -> new RequestResult(Status.REQUEST_DUPLICATE, created.request());
            case NOT_A_MEMBER -> new RequestResult(Status.RECIPIENT_NOT_MEMBER, null);
            default -> new RequestResult(Status.STORAGE_ERROR, created.request());
        };
    }

    /** Leader decision. The approval consumes one of the three weekly large-reward slots. */
    public RequestResult resolveLarge(UUID leaderId, UUID requestId, boolean approve) {
        Clan clan = clans.findByPlayerId(leaderId).orElse(null);
        if (clan == null) return new RequestResult(Status.NOT_IN_CLAN, null);
        var request = store.findRewardRequest(requestId).orElse(null);
        if (request == null || !request.clanId().equals(clan.id()))
            return new RequestResult(Status.REQUEST_NOT_FOUND, null);
        if (approve && request.amount().compareTo(ClanRewardPolicy.LARGE_REWARD_MAXIMUM) > 0)
            return new RequestResult(Status.INVALID_AMOUNT, request);
        var resolved = store.resolveRewardRequest(requestId, leaderId, approve, clock.instant());
        switch (resolved.status()) {
            case DECLINED -> { return new RequestResult(Status.REQUEST_DECLINED, resolved.request()); }
            case EXPIRED -> { return new RequestResult(Status.REQUEST_EXPIRED, resolved.request()); }
            case QUOTA_EXHAUSTED -> { return new RequestResult(Status.WEEKLY_QUOTA_EXHAUSTED, resolved.request()); }
            case ALREADY_RESOLVED -> { return new RequestResult(Status.REQUEST_ALREADY_RESOLVED, resolved.request()); }
            case NOT_A_MEMBER -> { return new RequestResult(Status.NOT_AUTHORIZED, resolved.request()); }
            case NOT_FOUND -> { return new RequestResult(Status.REQUEST_NOT_FOUND, null); }
            case APPROVED -> { }
            default -> { return new RequestResult(Status.STORAGE_ERROR, resolved.request()); }
        }
        UUID recipient = resolved.request().recipientId();
        BigDecimal amount = resolved.request().amount();
        Result payout = bankReward(leaderId, recipient, amount);
        if (payout.operation() != null) {
            store.attachRewardRequestOperation(requestId, payout.operation().operationId(), clock.instant());
        }
        return new RequestResult(payout.status(), resolved.request(), payout.operation());
    }

    public List<SqliteClanStore.ClanRewardRequest> requests(UUID viewerId, boolean pendingOnly) {
        Clan clan = clans.findByPlayerId(viewerId).orElse(null);
        if (clan == null) return List.of();
        ClanMember viewer = clan.member(viewerId).orElse(null);
        if (viewer == null) return List.of();
        List<SqliteClanStore.ClanRewardRequest> all = store.findRewardRequests(clan.id(), pendingOnly);
        return viewer.role() == ClanRole.LEADER ? all
                : all.stream().filter(request -> request.deputyId().equals(viewerId)).toList();
    }

    public int approvedLargeRewardsThisWeek(UUID clanId) {
        return store.approvedLargeRewardsThisWeek(clanId, clock.instant());
    }

    public List<UUID> expireDueRequests() {
        return store.expireDueRewardRequests(clock.instant());
    }

    public List<SqliteClanStore.ClanRewardOperation> history(UUID clanId, int limit) {
        return store.findClanRewards(clanId, limit);
    }

    public List<SqliteClanStore.ClanRewardOperation> recoverAfterRestart() {
        return store.recoverClanRewardsAfterRestart(clock.instant());
    }

    public enum Status {
        SUCCESS, NOT_IN_CLAN, NOT_AUTHORIZED, RECIPIENT_NOT_MEMBER, RECIPIENT_MEMBERSHIP_TOO_NEW,
        INVALID_AMOUNT, INSUFFICIENT_PERSONAL_FUNDS, INSUFFICIENT_BANK_FUNDS, DEPUTY_AMOUNT_LIMIT,
        DEPUTY_DAILY_LIMIT, ECONOMY_UNAVAILABLE, DEBIT_REJECTED, MANUAL_RECONCILIATION_REQUIRED,
        WEEKLY_QUOTA_POLICY_UNRESOLVED, REQUEST_CREATED, REQUEST_DUPLICATE, REQUEST_NOT_FOUND,
        REQUEST_DECLINED, REQUEST_EXPIRED, REQUEST_ALREADY_RESOLVED, WEEKLY_QUOTA_EXHAUSTED, STORAGE_ERROR
    }

    public record Result(Status status, SqliteClanStore.ClanRewardOperation operation) { }

    public record RequestResult(Status status, SqliteClanStore.ClanRewardRequest request,
            SqliteClanStore.ClanRewardOperation operation) {
        public RequestResult(Status status, SqliteClanStore.ClanRewardRequest request) {
            this(status, request, null);
        }
    }
}
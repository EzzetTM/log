package com.skyworldclans.clan.application.purchase;

import java.util.UUID;

/**
 * Neutral provider-independent contract used by capacity-purchase tests and coordinators.
 * Implementations must be thread-safe and idempotent where possible.
 * This contract is not a Vault or SWCoin integration.
 */
public interface PaymentPort {
    /**
     * Attempts to debit the requested amount from the player/clan account.
     *
     * @param actorId player performing the action
     * @param amount amount in the smallest currency unit
     * @param context optional diagnostic context, not an idempotency key
     */
    PaymentResult debit(UUID actorId, long amount, String context) throws PaymentException;

    /**
     * Compensates a previously executed debit. The compensation ID must be stable and
     * deterministically derived from the original purchase operation ID.
     */
    CompensationResult compensate(UUID actorId, long amount, String originalProviderOperationId,
            String compensationId, String context) throws PaymentException;

    /** Checks the result of a previously initiated compensation without issuing another refund. */
    CompensationResult reconcile(String originalProviderOperationId, String compensationId)
            throws PaymentException;

    record PaymentResult(boolean success, boolean unknown, String providerOperationId) {
        public static PaymentResult success(String providerOperationId) {
            return new PaymentResult(true, false, providerOperationId);
        }

        public static PaymentResult unknown(String providerOperationId) {
            return new PaymentResult(false, true, providerOperationId);
        }

        public static PaymentResult failure(String providerOperationId) {
            return new PaymentResult(false, false, providerOperationId);
        }
    }

    record CompensationResult(boolean success, boolean unknown, String compensationId,
            String originalProviderOperationId) {
        public static CompensationResult success(String compensationId, String originalProviderOperationId) {
            return new CompensationResult(true, false, compensationId, originalProviderOperationId);
        }

        public static CompensationResult failureNoEffect(String compensationId, String originalProviderOperationId) {
            return new CompensationResult(false, false, compensationId, originalProviderOperationId);
        }

        public static CompensationResult unknown(String compensationId, String originalProviderOperationId) {
            return new CompensationResult(false, true, compensationId, originalProviderOperationId);
        }
    }

    class PaymentException extends Exception {
        private static final long serialVersionUID = 1L;

        public PaymentException(String message) {
            super(message);
        }

        public PaymentException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}

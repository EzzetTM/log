package com.skyworldclans.clan.application.purchase;

/**
 * States whether a persisted journal record carries evidence that was actually written by the store.
 *
 * <p>{@link #RECORDED} means the row was written by {@code SqliteClanStore} together with the
 * transition it describes, so the stored evidence is the value the caller really supplied.
 * {@link #UNVERIFIED_LEGACY} marks rows imported from schema versions 1-3, which never stored
 * evidence. Legacy rows are preserved verbatim; no source state or evidence is invented for them,
 * and they must never be presented as confirmed historical confirmation.
 */
public enum CapacityPurchaseEvidenceProvenance {
    RECORDED,
    UNVERIFIED_LEGACY
}

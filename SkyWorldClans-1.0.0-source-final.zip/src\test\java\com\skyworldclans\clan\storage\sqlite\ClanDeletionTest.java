package com.skyworldclans.clan.storage.sqlite;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.membership.ClanMember;
import com.skyworldclans.clan.membership.ClanRole;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ClanDeletionTest {
    @TempDir Path temporaryDirectory;
    private static final Instant NOW = Instant.parse("2026-12-10T12:00:00Z");

    @Test
    void leaderDeletionRemovesOwnedDataAndIsAudited() {
        Path database = temporaryDirectory.resolve("clan-delete.sqlite");
        UUID leader = new UUID(1, 1);
        UUID deputy = new UUID(1, 2);
        Clan clan = new Clan(new UUID(0, 1), "DeleteMe", "DL1", NOW, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, NOW, null),
                        deputy, new ClanMember(deputy, ClanRole.DEPUTY, NOW, null)), 0, null);
        try (SqliteClanStore store = SqliteClanStore.open(database)) {
            assertEquals(com.skyworldclans.clan.catalog.ClanCatalog.RegistrationStatus.REGISTERED,
                    store.registerIfAvailable(clan));
            store.recordClanBankMovement(UUID.randomUUID(), "seed", clan.id(), leader, "DEPOSIT",
                    new BigDecimal("1000"), "seed", null, NOW);
            store.setClanHomePoint(clan.id(), leader, "Дом", UUID.randomUUID(), 1, 2, 3, 0, 0, NOW);
            store.declareClanWar(UUID.randomUUID(), clan.id(), otherClan(store), leader, 5, 3600, NOW);
            store.insertClanQuest(UUID.randomUUID(), clan.id(), "DAILY", "EASY", "MINE_BLOCK",
                    5000, 1, "2026-12-10", 1, NOW, NOW.plusSeconds(3600));

            // Only the leader may delete.
            assertFalse(store.deleteClan(clan.id(), deputy, NOW));
            assertTrue(store.findById(clan.id()).isPresent());

            assertTrue(store.deleteClan(clan.id(), leader, NOW.plusSeconds(10)));
            // The clan is gone from every public read path; only immutable history keeps the id.
            assertTrue(store.findById(clan.id()).isEmpty());
            assertTrue(store.findByTag("DL1").isEmpty(), "the original tag must be freed");
            assertTrue(store.findByPlayerId(leader).isEmpty());
            assertTrue(store.findByPlayerId(deputy).isEmpty());
            assertEquals(1, store.countClans(), "only the unrelated clan remains");
            assertTrue(store.allClanIds().stream().noneMatch(id -> id.equals(clan.id())));
            assertEquals(0, store.clanBankBalance(clan.id()).signum());
            assertFalse(store.findClanHomePoint(clan.id()).isPresent());
            var remainingQuests = store.findClanQuests(clan.id(), false);
            assertEquals(1, remainingQuests.size(), "history of the quest is retained");
            assertEquals(SqliteClanStore.ClanQuestStatus.EXPIRED, remainingQuests.get(0).status());
            assertEquals(0, store.findClanQuests(clan.id(), true).size(), "no active quests remain");
            assertFalse(store.findOpenClanWar(clan.id()).isPresent());
        }
        try (SqliteClanStore reopened = SqliteClanStore.open(database)) {
            assertTrue(reopened.findById(clan.id()).isEmpty(), "deletion must persist across restart");
            assertTrue(reopened.findByPlayerId(deputy).isEmpty());
            assertTrue(reopened.findByTag("DL1").isEmpty());
        }
    }

    private static UUID otherClan(SqliteClanStore store) {
        UUID leader = new UUID(1, 10);
        Clan other = new Clan(new UUID(0, 10), "OtherClan", "OT10", NOW, 10,
                Map.of(leader, new ClanMember(leader, ClanRole.LEADER, NOW, null)), 0, null);
        assertEquals(com.skyworldclans.clan.catalog.ClanCatalog.RegistrationStatus.REGISTERED,
                store.registerIfAvailable(other));
        return other.id();
    }
}
package com.skyworldclans.clan.application;

import com.skyworldclans.clan.Clan;
import com.skyworldclans.clan.ClanFactory;
import com.skyworldclans.clan.filter.ForbiddenExpressionField;
import com.skyworldclans.clan.filter.ForbiddenExpressionFilter;
import com.skyworldclans.clan.filter.ForbiddenExpressionResult;
import com.skyworldclans.clan.service.ClanRegistrationResult;
import com.skyworldclans.clan.service.ClanService;
import com.skyworldclans.clan.validation.ClanNameTagValidator;

import java.time.Clock;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

public final class CreateClanUseCase {
    private final ClanFactory clanFactory;
    private final ClanService clanService;
    private final ForbiddenExpressionFilter forbiddenExpressionFilter;
    private final Supplier<UUID> clanIdSupplier;
    private final Clock clock;

    public CreateClanUseCase(
            ClanFactory clanFactory,
            ClanService clanService,
            ForbiddenExpressionFilter forbiddenExpressionFilter,
            Supplier<UUID> clanIdSupplier,
            Clock clock) {
        this.clanFactory = Objects.requireNonNull(clanFactory, "clanFactory");
        this.clanService = Objects.requireNonNull(clanService, "clanService");
        this.forbiddenExpressionFilter = Objects.requireNonNull(
                forbiddenExpressionFilter, "forbiddenExpressionFilter");
        this.clanIdSupplier = Objects.requireNonNull(clanIdSupplier, "clanIdSupplier");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    public ClanCreationPreflightResult prepare(CreateClanCommand command) {
        if (command == null || command.creatorId() == null
                || command.name() == null || command.tag() == null) {
            return preflight(ClanCreationPreflightResult.Status.INVALID_INPUT);
        }
        if (!ClanNameTagValidator.isValidName(command.name())) {
            return preflight(ClanCreationPreflightResult.Status.INVALID_NAME_FORMAT);
        }
        if (!ClanNameTagValidator.isValidTag(command.tag())) {
            return preflight(ClanCreationPreflightResult.Status.INVALID_TAG_FORMAT);
        }
        if (!forbiddenExpressionFilter.isAvailable()) {
            return preflight(ClanCreationPreflightResult.Status.FILTER_UNAVAILABLE);
        }

        ClanCreationPreflightResult filterResult = checkPreflightFilter(ForbiddenExpressionField.NAME, command.name());
        if (filterResult != null) return filterResult;
        filterResult = checkPreflightFilter(ForbiddenExpressionField.TAG, command.tag());
        if (filterResult != null) return filterResult;
        if (command.slogan() != null) {
            filterResult = checkPreflightFilter(ForbiddenExpressionField.SLOGAN, command.slogan());
            if (filterResult != null) return filterResult;
        }

        if (clanService.isPlayerInClan(command.creatorId())) {
            return preflight(ClanCreationPreflightResult.Status.CREATOR_ALREADY_IN_CLAN);
        }
        if (!clanService.isTagAvailable(command.tag())) {
            return preflight(ClanCreationPreflightResult.Status.TAG_TAKEN);
        }

        UUID clanId = Objects.requireNonNull(clanIdSupplier.get(), "clanIdSupplier must return a UUID");
        java.time.Instant now = clock.instant();
        Clan clan = clanFactory.create(clanId, command.name(), command.tag(),
                command.creatorId(), now, now, command.slogan());
        return new ClanCreationPreflightResult(ClanCreationPreflightResult.Status.READY,
                Optional.of(clan), Optional.empty());
    }

    /**
     * Unpaid registration path retained for isolated domain tests only.
     * Runtime commands must use the validated preflight with the durable paid-creation coordinator.
     */
    CreateClanResult create(CreateClanCommand command) {
        ClanCreationPreflightResult prepared = prepare(command);
        if (prepared.status() != ClanCreationPreflightResult.Status.READY) {
            return fromPreflight(prepared);
        }
        Clan clan = prepared.clan().orElseThrow();
        ClanRegistrationResult registration = clanService.registerClan(clan);
        if (!registration.registered()) return registrationFailure(registration);
        return new CreateClanResult(CreateClanResult.Status.CREATED, Optional.empty(),
                Optional.empty(), List.of(), Optional.of(clan));
    }

    private ClanCreationPreflightResult checkPreflightFilter(ForbiddenExpressionField field, String value) {
        ForbiddenExpressionResult result = forbiddenExpressionFilter.check(field, value);
        return switch (result.status()) {
            case ALLOWED -> null;
            case FORBIDDEN_EXPRESSION -> new ClanCreationPreflightResult(
                    ClanCreationPreflightResult.Status.FORBIDDEN_EXPRESSION,
                    Optional.empty(), result.field());
            case FILTER_UNAVAILABLE -> preflight(ClanCreationPreflightResult.Status.FILTER_UNAVAILABLE);
            case INVALID_INPUT -> preflight(ClanCreationPreflightResult.Status.INVALID_INPUT);
        };
    }

    private static ClanCreationPreflightResult preflight(ClanCreationPreflightResult.Status status) {
        return new ClanCreationPreflightResult(status, Optional.empty(), Optional.empty());
    }

    private static CreateClanResult fromPreflight(ClanCreationPreflightResult prepared) {
        CreateClanResult.Status status = switch (prepared.status()) {
            case READY -> throw new IllegalArgumentException("READY is not a failure");
            case INVALID_INPUT -> CreateClanResult.Status.INVALID_INPUT;
            case INVALID_NAME_FORMAT -> CreateClanResult.Status.INVALID_NAME_FORMAT;
            case INVALID_TAG_FORMAT -> CreateClanResult.Status.INVALID_TAG_FORMAT;
            case FILTER_UNAVAILABLE -> CreateClanResult.Status.FILTER_UNAVAILABLE;
            case FORBIDDEN_EXPRESSION -> CreateClanResult.Status.FORBIDDEN_EXPRESSION;
            case CREATOR_ALREADY_IN_CLAN -> CreateClanResult.Status.CREATOR_ALREADY_IN_CLAN;
            case TAG_TAKEN -> CreateClanResult.Status.TAG_TAKEN;
        };
        return new CreateClanResult(status, prepared.forbiddenField(), Optional.empty(), List.of(), Optional.empty());
    }

    static CreateClanResult registrationFailure(ClanRegistrationResult registration) {
        Objects.requireNonNull(registration, "registration");
        return new CreateClanResult(
                CreateClanResult.Status.REGISTRATION_FAILED,
                Optional.empty(),
                Optional.of(registration.status()),
                registration.validationViolations(),
                Optional.empty());
    }
}
